package br.com.hermespardini.passelivre.dao;

import org.wdelmaschio.base.db.BasicStatement;
import org.wdelmaschio.base.db.MainDAO;
import org.wdelmaschio.base.model.ValueObject;

import br.com.hermespardini.corebusiness.exception.IHPCoreException;
import br.com.hermespardini.passelivre.model.PresencaHistorico;

public class PresencaHistoricoDAO extends MainDAO {

	public static final String SEQUENCE = "SEQ_PRESENCAHISTORICO";

	public PresencaHistoricoDAO(final ValueObject parVo) {
		super(parVo);
	}

	private static final BasicStatement STMT_LEGADO = BasicStatement.createStatement(PresencaHistorico.class,
			"BIOMETRIA.PRESENCAHISTORICO");

	private static final String SQL_INSERT = PresencaHistoricoDAO.STMT_LEGADO.addField("id").addField("carteira")
			.addField("filial").addField("datahora").addField("status").addField("datacadastro")
			.addField("datamodificacao").addField("versao").getInsertStatement();

	@Override
	public final int insert() throws Exception {
		try {
			final int rowsAffected = insert(PresencaHistoricoDAO.SQL_INSERT);
			return rowsAffected;
		} catch (final Exception exc) {
			exc.printStackTrace();
			throw new IHPCoreException(exc);
		}
	}

	public Long getId() throws Exception {
		Long valor = null;
		try {
			final Integer sequence = (Integer) selectAsSingleField(
					"select InterSystems.Sequences_GetNext('" + PresencaHistoricoDAO.SEQUENCE
							+ "') as value from InterSystems.Sequences where ucase(name)=ucase('"
							+ PresencaHistoricoDAO.SEQUENCE + "')");
			valor = sequence.longValue();
		} catch (final NullPointerException n) {
			return 0L;
		} catch (final Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}
		return valor;
	}
}
