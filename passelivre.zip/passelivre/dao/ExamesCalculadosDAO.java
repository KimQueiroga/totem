package br.com.hermespardini.passelivre.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.map.HashedMap;
import org.wdelmaschio.base.db.BasicStatement;
import org.wdelmaschio.base.db.MainDAO;
import org.wdelmaschio.base.model.ValueObject;

import br.com.hermespardini.corebusiness.dao.IhpMainDao;
import br.com.hermespardini.passelivre.model.ExameHermesPardini;
import br.com.hermespardini.passelivre.model.ExamePreCalculado;
import br.com.hermespardini.passelivre.model.ExameSimplificado;
import br.com.hermespardini.passelivre.model.ExameSimplificado.TypeCalculo;
import br.gov.ans.www.padroes.tiss.schemas.Ct_itemSolicitacao;


public class ExamesCalculadosDAO {
	
//	public ExamesCalculadosDAO(ValueObject parValueObject) {
//		super(parValueObject);
//	}
	

	private static final String SQL_PADRAO = "select ativo, acao, combinacao_exames, exames_calculados from HPardini_Basico_TOTEM.EXAME_CALCULADO";
	
	private static final String SQL_POR_EXAME = "";
	
	private static final BasicStatement STMT = BasicStatement.createStatement(ExamesCalculadosDAO.class,
			"HPARDINI_BASICO_TOTEM.EXAME_CALCULADO");
			
	//[acao_1,examesPai_1,examesFilho_1]; [acao_2,examesPai_2,examesFilho_2] ....
	private static final String DADOS_PADRAO = "[J, ]"; 
	
	
	private static final List<String> RPTCRE_EXAMES_HP = new ArrayList<String>(Arrays.asList("ÍNDICE PROTEÍNA/CREATININA,0,RPTCRE,U,URINA"));
	private static final List<String> RCC_EXAMES_HP = new ArrayList<String>(Arrays.asList("ÍNDICE CÁLCIO/CREATININA,0,RCC,U,URINA"));
	
	private static final ExamePreCalculado PRECALC_RPTCRE = new ExamePreCalculado("ÍNDICE PROTEÍNA/CREATININA - URINA", "40322483", new BigDecimal(0));
	private static final ExamePreCalculado PRECALC_CREA = new ExamePreCalculado("CREATININA - URINA", "40301630", new BigDecimal(0));
	private static final ExamePreCalculado PRECALC_PROT = new ExamePreCalculado("PROTEÍNA - URINA", "40302377", new BigDecimal(0));
	
	
	private static final ExamePreCalculado PRECAL_RCC = new ExamePreCalculado("ÍNDICE CÁLCIO/CREATININA - URINA", "40322475", new BigDecimal(0));
	private static final ExamePreCalculado PRECALC_CALC = new ExamePreCalculado("CÁLCIO - URINA", "40301400", new BigDecimal(0));
		
	private static final ExamePreCalculado PRECALC_CRET_SANGUE = new ExamePreCalculado("CREATININA - SANGUE", "40301630", new BigDecimal(0));//teste
	private static final ExamePreCalculado PRECALC_CRET_GERAL = new ExamePreCalculado("CREATININA - ", "40301630", new BigDecimal(0));//teste
	private static final ExamePreCalculado PRECALC_GLICOSE = new ExamePreCalculado("GLICOSE", "40302040", new BigDecimal(0));//teste
	private static final ExamePreCalculado PRECALC_UREIA_SANGUE = new ExamePreCalculado("UREIA - SANGUE", "40302580", new BigDecimal(0));//teste
	
	
	private static final List<String> CODIGOS_EXAMESCALC = new ArrayList<String>(Arrays.asList("40322483","40322475"));
	
//	public static Map<String, String> getCombinacaoCompleta() {
//		Map<String, String> combinacoes = new HashedMap();
//		
//		combinacoes.put("S||CRE,S||CA;S", "U||RCC");
//		combinacoes.put("U||RCC;D", "S||CRE,S||CA");
//		
//		combinacoes.put("U||PROTE,S||CRE;S", "U||RPTCRE");
//		combinacoes.put("U||RPTCRE;D", "U||PROTE,S||CRE");
//		
//		combinacoes.put("S||G,S||INSU;S", "S||HOMA");
//		combinacoes.put("S||HOMA;D", "S||G,S||INSU");
//		
//		return combinacoes;
//	}
	
	public static Map<String, String> getCombinacaoCompletaCodigos() {
		Map<String, String> combinacoes = new HashedMap();
		
		//exemplo combinacoes.put("U||RCC;D", "S||CRE,S||CA");
		//combinacoes.put("40901211", "40301630,40301400");
		
//		combinacoes.put("40310213,40311210", "40322483");
//		combinacoes.put("40302040,40302075", "40322483");
//		combinacoes.put("40310213,40311210", "40322483"); //teste RPTCRE
//		
//		combinacoes.put("40302040,40302075", "40322475");
				
		//RPTCRE
		//combinacoes.put("40322483", "40301630,40302377");
		combinacoes.put("40301630,40302377", "40322483");
		
		
//		//homa
//		combinacoes.put("", "40302040,40316360");
//		combinacoes.put("40302040,40316360", "");
		
		//RCC
		//combinacoes.put("40322475", "40301630,40301400");
		combinacoes.put("40301630,40301400", "40322475");
		
		return combinacoes;
	}
	
	public static List<String> getCodigosExamePais() {
		return CODIGOS_EXAMESCALC;
	}
	
	public static Map<List<ExamePreCalculado>, ExamePreCalculado> getCombinacaoCompletaExCalcs() {
		Map<List<ExamePreCalculado>, ExamePreCalculado> combinacoes = new HashedMap();
		
		combinacoes.put(Arrays.asList(PRECALC_CREA, PRECALC_PROT), PRECALC_RPTCRE);
		combinacoes.put(Arrays.asList(PRECALC_CREA, PRECALC_CALC), PRECAL_RCC);
		
		//testes
		combinacoes.put(Arrays.asList(PRECALC_CRET_GERAL, PRECALC_GLICOSE), PRECALC_RPTCRE);
		combinacoes.put(Arrays.asList(PRECALC_UREIA_SANGUE, PRECALC_GLICOSE), PRECAL_RCC);
		combinacoes.put(Arrays.asList(PRECALC_CRET_SANGUE, PRECALC_UREIA_SANGUE), PRECALC_RPTCRE);
		
		return combinacoes;
	}
	
	public static String getDescricaoExameByCodigo(String codigo) {
//		if ("40301630".equals(codigo)) {
//			return "CRE - Creatinina (40301630)";
//		}
//		else if ("40301400".equals(codigo)) {
//			return "CA - Cálcio (40301400)";
//		}
//		else if ("40302377".equals(codigo)) {
//			return "PROTE - Proteína (40302377)";
//		}
//		else if ("40316360".equals(codigo)) {
//			return "INSU - Insulina (40316360)";
//		}
//		else if ("40302040".equals(codigo)) {
//			return "G - Glicose (40302040)";
//		}
//		else 
		if ("40322475".equals(codigo)) {
			return "RCC (Índice cálcio/creatinina) - URINA ";//Cod: 40322475 
		}
		else if ("40322483".equals(codigo)) {
			return "RPTCRE (Índice proteína/creatinina) - URINA";// Cod: 40322483
		}
		return "";
	}
	
	
	public static List<String> getExamesPaiHP(String codigo) {
		if ("40322475".equals(codigo)) {
			return RCC_EXAMES_HP;
		}
		else if ("40322483".equals(codigo)) {
			return RPTCRE_EXAMES_HP;
		}
		return null;
	}
	
		
	public static List<ExameHermesPardini> getDadosExameHPbyCod(String codigo) {
		List<ExameHermesPardini> examesHP = new ArrayList<ExameHermesPardini>();
		for (String paramExameHP : getExamesPaiHP(codigo)) {
			ExameHermesPardini exameHP = new ExameHermesPardini(paramExameHP.split(","));
			examesHP.add(exameHP);
		}
		return examesHP;
	}
	
	public static ExameSimplificado getExameSimplificadoByCod(String codigo) {
		return new ExameSimplificado(codigo, getDescricaoExameByCodigo(codigo));
	}
	
	public static ExameSimplificado getExameSimplificadoByItem(Ct_itemSolicitacao item) {
		return new ExameSimplificado(item.getIdentificacaoProcedimentos().getCodigo(), item.getIdentificacaoProcedimentos().getDescricao());
	}
	
	
	public static ExameSimplificado getExameSimplificadoPaiDesmByCod(Ct_itemSolicitacao item) {
		ExameSimplificado exameSimplificado = getExameSimplificadoByItem(item);
		exameSimplificado.setTipoCalculo(TypeCalculo.DESMEMBRA);
		return exameSimplificado;
	}
	
	public static ExameSimplificado getExameSimplificadoPaiUniaoByCod(String codigo) {
		ExameSimplificado exameSimplificado = getExameSimplificadoByCod(codigo);
		exameSimplificado.setTipoCalculo(TypeCalculo.SUBSTITUI);
		return exameSimplificado;
	}
	
	
//	public static List<ExameSimplificado> getListExameSimplificadoByCods(List<String> codigos) {
//		List<ExameSimplificado> exameSimplificados = new ArrayList<ExameSimplificado>();
//		for (String cod: codigos) {
//			exameSimplificados.add(getExameSimplificadoByCod(cod));
//		}
//		return exameSimplificados;
//	}
	
//	public static List<ExameSimplificado> getListExameSimplificadoByItens(List<Ct_itemSolicitacao> itens) {
//		List<ExameSimplificado> exameSimplificados = new ArrayList<ExameSimplificado>();
//		for (Ct_itemSolicitacao tem: itens) {
//			exameSimplificados.add(getExameSimplificadoByItem(tem));
//		}
//		return exameSimplificados;
//	}
	
	public static List<ExameSimplificado> getListExameSimplificadoByExamPreCalc(List<ExamePreCalculado> examesPreCalc) {
		List<ExameSimplificado> exameSimplificados = new ArrayList<ExameSimplificado>();
		for (ExamePreCalculado preCalculado: examesPreCalc) {
			exameSimplificados.add(getExameSimplificadoByExamPreCalc(preCalculado));
		}
		return exameSimplificados;
	}
	
	public static ExameSimplificado getExameSimplificadoByExamPreCalc(ExamePreCalculado examePreCalc) {
		return new ExameSimplificado(examePreCalc.getCodigo(), examePreCalc.getDescricaoCompleta(), examePreCalc.getMaterial());
	}
	
	//Retorna vazio caso não consiga determinar o material do exame por ter informação específica na descrição do exame
	public static String getMaterialByDescExame(String descExame) {
		String material = "";
		boolean jaPreencheu = false;
		List<String> listaMateriaisExamesCalcs = Arrays.asList("URINA");
		
		for (String materialExameCalc : listaMateriaisExamesCalcs) {
			
			if (descExame.contains(materialExameCalc) && !jaPreencheu) {
				material = materialExameCalc;
				jaPreencheu = true;
			}
			else if (jaPreencheu) {
				material = "";
			}
		}
		return material;
	}

	public static boolean contemTodosFilhosCod(List<ExamePreCalculado> examesPreCalculados,
			List<ExamePreCalculado> exameCalcPais) {
		return (exameCalcPais.stream().allMatch(examPai -> examesPreCalculados.stream().anyMatch(examGuia -> examGuia.getCodigo().equals(examPai.getCodigo()))));
	}
	
//	public static boolean contemTodosFilhosCod(List<ExamePreCalculado> examesPreCalculados,
//			List<ExamePreCalculado> exameCalcPais) {
//		Integer qtd = 0;
//		boolean retorno = false;
//		
//		for (ExamePreCalculado examPai: exameCalcPais) {
//			for (ExamePreCalculado exameGuia: examesPreCalculados) {
//				if (examPai.getCodigo().equals(exameGuia.getCodigo())) {
//					qtd++;
//					break;
//				}
//			}
//			if (qtd == exameCalcPais.size()) {
//				retorno = true;
//				break;
//			}
//		}
//		return retorno;
//	}
}
