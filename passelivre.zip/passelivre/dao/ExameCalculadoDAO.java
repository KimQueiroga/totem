package br.com.hermespardini.passelivre.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.collections.map.MultiValueMap;
import org.apache.log4j.Logger;

import br.com.hermespardini.corebusiness.util.ConnectionCore;
import br.com.hermespardini.passelivre.model.ExameHermesPardini;
import br.com.hermespardini.passelivre.model.ExameSimplificado;
import br.com.hermespardini.passelivre.model.ExameSimplificado.TypeCalculo;
import br.com.hermespardini.passelivre.model.MotivosGlosas;

public class ExameCalculadoDAO {
	
	private static Logger log = Logger.getLogger(ExameCalculadoDAO.class);
	
	private static String SQL_CONSULTA_GERAL = "select "
			+ "	pai.ExamePai examePai, "
			+ "	filho.ExameFilho exameFilho "
			+ " from "
			+ "	HPardini_Basico_Totem.ExameCalculado pai "
			+ " inner join HPardini_Basico_Totem.ExameCalculadoFilhos filho on "
			+ "	pai.ID = filho.ExameCalculado";
	
	private static String SQL_CONSULTA_DADOS_EXAME_UNICO = "select ex.CodigoTUSS, "
			+ "ex.Descricao, "
			+ "ex.Descricao||','||'0'||','||ex.MneExa||','||ex.MATERIAL||','||mat.Descricao "
			+ "from HPardini_Basico_Totem.ExameCalculado pai "
			+ "inner join HPardini_Basico.EXAME ex on ex.id = replace(pai.ExamePai, '/', '||') "
			+ "inner join HPardini_Basico.MATERIAL mat on mat.ID = ex.MATERIAL "
			+ "where pai.ExamePai = ? ";
	
	private static String SQL_CONSULTA_DADOS_EXAME_MULTIPLO = "";
	
	public ExameCalculadoDAO() {
		
	}
	
	public static Map<String, List<String>> getTodasCombinacoes() {
		@SuppressWarnings("unchecked")
		MultiValueMap combinacaoPaiFilhos = new MultiValueMap();
		
		
		try (Connection con = ConnectionCore.getInstance().getDataSource(ConnectionCore.DATASOURCE_TOTEM).getConnection();
				PreparedStatement statement = con.prepareStatement(SQL_CONSULTA_GERAL)){ 
			
			try (ResultSet result = statement.executeQuery()) {
				while (result.next()) {
					combinacaoPaiFilhos.put(result.getString(1), result.getString(2));
				}
			}
			
			
		} catch (Exception e) {
			log.error("Erro ao buscar combinacao exames calculados. "+e.getMessage(), e);
		} 
		
		return combinacaoPaiFilhos;
	}

	public static ExameSimplificado retornaExameSimplificadoByMnemonico(String mnemonicoPaiCalc, String guia) {
		ExameSimplificado simplificado = new ExameSimplificado();
		try (Connection con = ConnectionCore.getInstance().getDataSource(ConnectionCore.DATASOURCE_TOTEM).getConnection();
				PreparedStatement statement = con.prepareStatement(SQL_CONSULTA_DADOS_EXAME_UNICO)) {
			statement.setString(1, mnemonicoPaiCalc);
			try (ResultSet result = statement.executeQuery()) {
				if(result.next()) {
					simplificado.setCodigo(result.getString(1));
					simplificado.setDescricao(result.getString(2));
					simplificado.setExame(new ExameHermesPardini(result.getString(3).split(",")));
					simplificado.setGlosas(new MotivosGlosas());
					simplificado.setGuia(guia);
					simplificado.setIdComposicao(null);
					simplificado.setInformacoesClinica("");
					simplificado.setObservacao("");
					simplificado.setQuantidadeAutorizada(1);
					simplificado.setQuantidadeSolicitada(1);
					simplificado.setTipoCalculo(TypeCalculo.SUBSTITUI);
				}
				else {
					simplificado = null;
				}
			}
		} catch (Exception e) {
			log.error("Erro ao preencher exame calculado. "+e.getMessage(), e);
		}
		return simplificado;
	}

}
