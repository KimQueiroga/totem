package br.com.hermespardini.passelivre.dao;

import java.util.Map;

import org.wdelmaschio.base.db.BasicStatement;
import org.wdelmaschio.base.db.MainDAO;
import org.wdelmaschio.base.model.ValueObject;

import br.com.hermespardini.corebusiness.exception.IHPCoreException;
import br.com.hermespardini.passelivre.model.Localidade;

public class LocalidadeDAO extends MainDAO {

	public LocalidadeDAO(final ValueObject valueObject) {
		super(valueObject);
	}

	private static final BasicStatement STMT_LEGADO = BasicStatement.createStatement(Localidade.class,
			"BIOMETRIA.LOCALIDADE");

	private static final String SQL_SELECT_BY_IP = LocalidadeDAO.STMT_LEGADO.addFilter("ip").getSelectStatement();

	public Localidade getLocalidadeIp() throws Exception {
		try {
			final Map<?, ?> loMap = selectAsMap(LocalidadeDAO.SQL_SELECT_BY_IP);
			return loMap == null ? null : new Localidade(loMap);
		} catch (final Exception e) {
			e.printStackTrace();
			throw new IHPCoreException(e);
		}
	}

}
