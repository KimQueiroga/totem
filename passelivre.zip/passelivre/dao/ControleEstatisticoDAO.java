package br.com.hermespardini.passelivre.dao;

import org.wdelmaschio.base.db.BasicStatement;
import org.wdelmaschio.base.db.MainDAO;
import org.wdelmaschio.base.model.ValueObject;

import br.com.hermespardini.corebusiness.exception.IHPCoreException;
import br.com.hermespardini.passelivre.model.ControleEstatistico;

public class ControleEstatisticoDAO extends MainDAO {

	public ControleEstatisticoDAO(final ValueObject parVo) {
		super(parVo);
	}

	private static final BasicStatement STMT = BasicStatement.createStatement(ControleEstatistico.class,
			"HPARDINI_BASICO_TOTEM.ESTATISTICA_ATENDIMENTO");

	private static final String SQL_INSERT = ControleEstatisticoDAO.STMT.addField("codigo").addField("idServico")
			.addField("codigoCliente").addField("operadoraConvenio").addField("data").addField("dataHoraUltAtualizacao")
			.addField("empresa").addField("idTotem").addField("matricula").addField("planoConvenio")
			.addField("usuUltAtualizacao").addField("origem").addField("sigla").addField("unidade")
			.getInsertStatement();

	@Override
	public final int insert() throws Exception {
		try {
			final int rowsAffected = insert(ControleEstatisticoDAO.SQL_INSERT);
			return rowsAffected;
		} catch (final Exception exc) {
			exc.printStackTrace();
			throw new IHPCoreException(exc);
		}
	}
}
