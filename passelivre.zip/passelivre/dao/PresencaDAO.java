package br.com.hermespardini.passelivre.dao;

import java.util.Map;

import org.wdelmaschio.base.db.BasicStatement;
import org.wdelmaschio.base.db.MainDAO;
import org.wdelmaschio.base.model.ValueObject;

import br.com.hermespardini.corebusiness.exception.IHPCoreException;
import br.com.hermespardini.passelivre.model.Presenca;

public class PresencaDAO extends MainDAO {

	public PresencaDAO(final ValueObject parVo) {
		super(parVo);
	}

	private static final BasicStatement STMT_LEGADO = BasicStatement.createStatement(Presenca.class,
			"BIOMETRIA.PRESENCA");

	private static final String SQL_SELECT_BY_CARTEIRA = PresencaDAO.STMT_LEGADO.addFilter("carteira")
			.getSelectStatement();

	private static final String SQL_INSERT = PresencaDAO.STMT_LEGADO.addField("carteira").addField("filial")
			.addField("datahora").addField("status").addField("datacadastro").addField("datamodificacao")
			.addField("versao").getInsertStatement();

	private static final String SQL_UPDATE = PresencaDAO.STMT_LEGADO.addFilter("carteira").getUpdateStatement();

	public Presenca getPresencaByCarteira() throws Exception {
		try {
			final Map<?, ?> loMap = selectAsMap(PresencaDAO.SQL_SELECT_BY_CARTEIRA);
			return loMap == null ? null : new Presenca(loMap);
		} catch (final Exception e) {
			e.printStackTrace();
			throw new IHPCoreException(e);
		}
	}

	@Override
	public final int insert() throws Exception {
		try {
			return insert(PresencaDAO.SQL_INSERT);
		} catch (final Exception exc) {
			exc.printStackTrace();
			throw new IHPCoreException(exc);
		}
	}

	@Override
	public final int update() throws Exception {
		try {
			return update(PresencaDAO.SQL_UPDATE);
		} catch (final Exception exc) {
			exc.printStackTrace();
			throw new IHPCoreException(exc);
		}
	}

}
