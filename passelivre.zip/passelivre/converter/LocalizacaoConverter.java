package br.com.hermespardini.passelivre.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import org.apache.commons.lang3.StringUtils;

import br.com.hermespardini.passelivre.model.Localizacao;

@FacesConverter(value = "localizacaoConverter", forClass = Localizacao.class)
public class LocalizacaoConverter implements Converter {

	@Override
	public Object getAsObject(final FacesContext parArg0, final UIComponent parArg1, final String parArg2) {
		if (parArg2 != null && parArg2.trim().length() > 0) {
			if (parArg2 != null && !parArg2.isEmpty()) {
				return parArg1.getAttributes().get(parArg2);
			}
			return null;
		}
		return null;
	}

	@Override
	public String getAsString(final FacesContext parArg0, final UIComponent parArg1, final Object parArg2) {
		try {
			if (parArg2 instanceof Localizacao) {
				final Localizacao entity = (Localizacao) parArg2;
				if (entity != null && entity instanceof Localizacao) {
					parArg1.getAttributes().put(entity.toString(), entity);
					return entity.toString();
				}
			}
		} catch (final Exception locExc) {
			return StringUtils.EMPTY;
		}
		return StringUtils.EMPTY;
	}
}
