package br.com.hermespardini.passelivre.converter;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

@FacesConverter(value = "formatoDataConverter")
public class FormatoDataConverter implements Converter {
	public String formataData(final String data) {
		final SimpleDateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy");
		final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String dataRetorno = "";
		try {
			dataRetorno = sdf.format(dateFormatter.parse(data));
		} catch (final ParseException locExc) {
			locExc.printStackTrace();
		}

		return dataRetorno;
	}

	@Override
	public Object getAsObject(final FacesContext parArg0, final UIComponent parArg1, final String parArg2) {
		return parArg2;
	}

	@Override
	public String getAsString(final FacesContext parArg0, final UIComponent parArg1, final Object value) {
		if (value == null) {
			return "";
		}
		final SimpleDateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy");
		final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String dataRetorno = "";
		try {
			dataRetorno = sdf.format(dateFormatter.parse(value.toString()));
		} catch (final ParseException locExc) {
			locExc.printStackTrace();
		}

		return null;
	}

}
