package br.com.hermespardini.passelivre.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import org.apache.commons.lang3.StringUtils;

import br.com.hermespardini.passelivre.model.ExameHermesPardini;

@FacesConverter(value = "exameHermesPardiniConverter", forClass = ExameHermesPardini.class)
public class ExameHermesPardiniConverter implements Converter {

	@Override
	public Object getAsObject(final FacesContext parArg0, final UIComponent parArg1, final String parArg2) {
		if (parArg2 != null && parArg2.trim().length() > 0) {
			try {
				if (parArg2 != null && !parArg2.isEmpty()) {
					return parArg1.getAttributes().get(parArg2);
				}
				return null;
			} catch (final NumberFormatException e) {
			}
		}
		return null;
	}

	@Override
	public String getAsString(final FacesContext parArg0, final UIComponent parArg1, final Object parArg2) {
		if (parArg2 instanceof ExameHermesPardini) {
			final ExameHermesPardini entity = (ExameHermesPardini) parArg2;
			if (entity != null && entity instanceof ExameHermesPardini) {
				parArg1.getAttributes().put(entity.toString(), entity);
				return entity.toString();
			}
		}
		return StringUtils.EMPTY;
	}

}
