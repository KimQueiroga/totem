package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

@SuppressWarnings("serial")
public class CriarPedidoResult implements Serializable {

	private Long codigoPaciente;
	private ExamesResultadosPedido exames;
	private String mensagem;
	private Integer pedido;
	private String status;
	private Integer unidade;

	public Long getCodigoPaciente() {
		return codigoPaciente;
	}

	public void setCodigoPaciente(final Long parCodigoPaciente) {
		codigoPaciente = parCodigoPaciente;
	}

	public ExamesResultadosPedido getExames() {
		return exames;
	}

	public void setExames(final ExamesResultadosPedido parExames) {
		exames = parExames;
	}

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(final String parMensagem) {
		mensagem = parMensagem;
	}

	public Integer getPedido() {
		return pedido;
	}

	public void setPedido(final Integer parPedido) {
		pedido = parPedido;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(final String parStatus) {
		status = parStatus;
	}

	public Integer getUnidade() {
		return unidade;
	}

	public void setUnidade(final Integer parUnidade) {
		unidade = parUnidade;
	}

}
