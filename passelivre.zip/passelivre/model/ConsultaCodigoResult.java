package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.util.List;

@SuppressWarnings("serial")
public class ConsultaCodigoResult implements Serializable {

	private List<ExameHermesPardini> exames;
	private String mensagem;
	private String status;
	private String operadora;

	public List<ExameHermesPardini> getExames() {
		return exames;
	}

	public void setExames(final List<ExameHermesPardini> parExames) {
		exames = parExames;
	}

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(final String parMensagem) {
		mensagem = parMensagem;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(final String parStatus) {
		status = parStatus;
	}

	public String getOperadora() {
		return operadora;
	}

	public void setOperadora(final String parOperadora) {
		operadora = parOperadora;
	}

}
