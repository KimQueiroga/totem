package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

public class Erro implements Serializable {

	private String message;
	private Integer code;

	public String getMessage() {
		return message;
	}

	public void setMessage(final String parMessage) {
		message = parMessage;
	}

	public Integer getCode() {
		return code;
	}

	public void setCode(final Integer parCode) {
		code = parCode;
	}

}
