package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.util.List;

import org.wdelmaschio.base.model.ValueObject;

import br.com.hermespardini.passelivre.constantsenum.Constantes;

@SuppressWarnings("serial")
public class ParametroPreparoExame extends ValueObject implements Serializable {

	private String empresa;
	private String material;
	private String exame;
	private String perfil;
	private String origem;
	private String token;

	public ParametroPreparoExame(final ExameHermesPardini parExameHermesPardini,
			final List<InformacaoTotem> parInformacoesTotem, final TokenResult parTokenResult) {
		setExame(parExameHermesPardini.getExame());
		setEmpresa(Constantes.EMPRESA);
		setMaterial(parExameHermesPardini.getMaterial());
		setOrigem(Constantes.ORIGEM_PADRAO);
		setPerfil("T");
		setToken(parTokenResult.getToken());
	}

	public ParametroPreparoExame(final ExameHermesPardini parExameHermesPardini, final TokenResult parTokenResult,
			final Unidade parUnidade) {
		setExame(parExameHermesPardini.getExame());
		setEmpresa(Constantes.EMPRESA);
		setMaterial(parExameHermesPardini.getMaterial());
		setOrigem(parUnidade.getCodigo().toString());
		setToken(parTokenResult.getToken());
	}

	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(final String parEmpresa) {
		empresa = parEmpresa;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(final String parMaterial) {
		material = parMaterial;
	}

	public String getExame() {
		return exame;
	}

	public void setExame(final String parExame) {
		exame = parExame;
	}

	public String getPerfil() {
		return perfil;
	}

	public void setPerfil(final String parPerfil) {
		perfil = parPerfil;
	}

	public String getOrigem() {
		return origem;
	}

	public void setOrigem(final String parOrigem) {
		origem = parOrigem;
	}

	public String getToken() {
		return token;
	}

	public void setToken(final String parToken) {
		token = parToken;
	}

}
