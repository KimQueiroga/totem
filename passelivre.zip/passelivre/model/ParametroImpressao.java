package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

import br.com.hermespardini.passelivre.constantsenum.Constantes;

public class ParametroImpressao implements Serializable {

	private String docId;
	private String codigoCliente;
	private String impressora;
	private String frenteEVerso;
	private String origem;
	private String tokenCliente;
	private String token;

	public ParametroImpressao(final DetalhePedidoCliente parDetalhePedidoExibicao,
			final InformacaoTotem parInformacaoTotem, final TokenResult parTokenResult,
			final ClienteUnidadePasseLivre parClienteUnidadePasseLivre) {
		docId = parDetalhePedidoExibicao.getTestId();
		frenteEVerso = Constantes.IMPRIME_FRENTE_VERSO;
		origem = Constantes.ORIGEM_PADRAO;
		impressora = parInformacaoTotem.getImpressoraDefault();
		token = parTokenResult.getToken();
		tokenCliente = parClienteUnidadePasseLivre.getId();
		codigoCliente = parClienteUnidadePasseLivre.getCodigoCliente();
	}

	public ParametroImpressao(final PedidoCliente parPedidoSelecionado, final InformacaoTotem parInformacaoTotem,
			final TokenResult parTokenResult, final ClienteUnidadePasseLivre parClienteUnidadePasseLivre) {
		docId = parPedidoSelecionado.getId();
		frenteEVerso = Constantes.IMPRIME_FRENTE_VERSO;
		origem = Constantes.ORIGEM_PADRAO;
		impressora = parInformacaoTotem.getImpressoraDefault();
		token = parTokenResult.getToken();
		tokenCliente = parClienteUnidadePasseLivre.getId();
		codigoCliente = parClienteUnidadePasseLivre.getCodigoCliente();
	}

	public ParametroImpressao(final String idPedido, final InformacaoTotem parInformacaoTotem,
			final TokenResult parTokenResult) {
		docId = retornarPedidoValido(idPedido);
		frenteEVerso = Constantes.IMPRIME_FRENTE_VERSO;
		origem = Constantes.ORIGEM_PADRAO;
		impressora = parInformacaoTotem.getImpressoraDefault();
		token = parTokenResult.getToken();
		// tokenCliente = parClienteUnidadePasseLivre.getId();
		// codigoCliente = parClienteUnidadePasseLivre.getCodigoCliente();
	}

	private String retornarPedidoValido(String idPedido) {
		try {
			idPedido = retirarOsDoisPrimeirosDigitos(idPedido);
			final String unidade = idPedido.substring(0, 3);
			final String ano = "****";
			final String pedido = idPedido.substring(3, idPedido.length() - 2);
			return unidade + "||" + ano + "||" + pedido;
		} catch (final Exception locExc) {
			return "";
		}
	}

	private String retirarOsDoisPrimeirosDigitos(final String idPedido) {
		return idPedido.substring(2, idPedido.length());
	}

	public static void main(final String[] args) {
		String idPedido = "01040201317500";
		idPedido = idPedido.substring(2, idPedido.length());
		final String unidade = idPedido.substring(0, 3);
		final String ano = "****";
		final String pedido = idPedido.substring(3, idPedido.length() - 2);
		System.out.println(idPedido);
		System.out.println("unidade:" + unidade);
		System.out.println("ano:" + ano);
		System.out.println("pedido:" + pedido);
	}

	public String getDocId() {
		return docId;
	}

	public void setDocId(final String parDocId) {
		docId = parDocId;
	}

	public String getCodigoCliente() {
		return codigoCliente;
	}

	public void setCodigoCliente(final String parCodigoCliente) {
		codigoCliente = parCodigoCliente;
	}

	public String getImpressora() {
		return impressora;
	}

	public void setImpressora(final String parImpressora) {
		impressora = parImpressora;
	}

	public String getFrenteEVerso() {
		return frenteEVerso;
	}

	public void setFrenteEVerso(final String parFrenteEVerso) {
		frenteEVerso = parFrenteEVerso;
	}

	public String getOrigem() {
		return origem;
	}

	public void setOrigem(final String parOrigem) {
		origem = parOrigem;
	}

	public String getTokenCliente() {
		return tokenCliente;
	}

	public void setTokenCliente(final String parTokenCliente) {
		tokenCliente = parTokenCliente;
	}

	public String getToken() {
		return token;
	}

	public void setToken(final String parToken) {
		token = parToken;
	}

}
