package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.util.List;

public class Localizacao implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long codigo;
	private String descricao;
	private List<Impressora> impressoras;

	public Localizacao() {
	}

	public Localizacao(final Long codigo, final String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(final Long parCodigo) {
		codigo = parCodigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(final String parDescricao) {
		descricao = parDescricao;
	}

	@Override
	public String toString() {
		return descricao;
	}

	public List<Impressora> getImpressoras() {
		return impressoras;
	}

	public void setImpressoras(final List<Impressora> parImpressoras) {
		impressoras = parImpressoras;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (codigo == null ? 0 : codigo.hashCode());
		result = prime * result + (descricao == null ? 0 : descricao.hashCode());
		return result;
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final Localizacao other = (Localizacao) obj;
		if (codigo == null) {
			if (other.codigo != null) {
				return false;
			}
		} else if (!codigo.equals(other.codigo)) {
			return false;
		}
		if (descricao == null) {
			if (other.descricao != null) {
				return false;
			}
		} else if (!descricao.equals(other.descricao)) {
			return false;
		}
		return true;
	}

	public Impressora retornarImpressoraValida() {
		try {
			for (final Impressora locImpressora : impressoras) {
				if (locImpressora.getTipoFormulario().equals("I")) {
					return locImpressora;
				}
			}
			return null;
		} catch (final Exception locExc) {
			return null;
		}
	}
}
