package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.to.ProcedimentoComExamesTO;
import br.com.hermespardini.passelivre.utils.DataUtil;
import br.com.hermespardini.passelivre.utils.Util;

public class ExamePedidoFilho implements Serializable {

	private String exame;
	private String material;
	private String descricaoMaterial;
	private String localColeta;
	private String dataHoraMarcacao;
	private String dataHoraColeta;
	private QuestionariosEntrega questionarios;
	private String codigoSolicitanteOperadora;

	public ExamePedidoFilho(final ExameHermesPardini parExameHermesPardini,
			final List<ConsultaQuestionarioExameResult> parQuestionarios, final List<PerguntaEntrega> parPerguntas,
			final InformacaoTotem parInformacaoTotem, final String parDataMarcacao,
			final ProcedimentoComExamesTO parProcedimento) {
		exame = parExameHermesPardini.getExame();
		material = parExameHermesPardini.getMaterial();
		localColeta = Constantes.LOCAL_COLETA_PADRAO;
		dataHoraMarcacao = parDataMarcacao;
		verificarSeProcedimentoEhVt(parProcedimento);
		questionarios = new QuestionariosEntrega();
		for (final ConsultaQuestionarioExameResult locConsultaQuestionarioExameResult : parQuestionarios) {
			if (parExameHermesPardini.getExame().equals(locConsultaQuestionarioExameResult.getExame())
					&& locConsultaQuestionarioExameResult.getQuestionarios() != null) {
				for (final Questionario questionario : locConsultaQuestionarioExameResult.getQuestionarios()) {
					questionarios.add(new QuestionarioEntrega(questionario, parPerguntas));
				}
			}
		}
	}

	public ExamePedidoFilho(final ExameHermesPardini parExameHermesPardini,
			final List<ConsultaQuestionarioExameResult> parQuestionarios, final List<PerguntaEntrega> parPerguntas,
			final String parDataMarcacao, final ProcedimentoComExamesTO parProcedimento) {
		exame = parExameHermesPardini.getExame();
		material = parExameHermesPardini.getMaterial();
		localColeta = Constantes.LOCAL_COLETA_PADRAO;
		dataHoraMarcacao = parDataMarcacao;
		verificarSeProcedimentoEhVt(parProcedimento);
		questionarios = new QuestionariosEntrega();
		for (final ConsultaQuestionarioExameResult locConsultaQuestionarioExameResult : parQuestionarios) {
			if (parExameHermesPardini.getExame().equals(locConsultaQuestionarioExameResult.getExame())
					&& locConsultaQuestionarioExameResult.getQuestionarios() != null) {
				for (final Questionario questionario : locConsultaQuestionarioExameResult.getQuestionarios()) {
					if (!questionario.getImpresso().equals("S")) {
						questionarios.add(new QuestionarioEntrega(questionario, parPerguntas));
					}
				}
			}
		}
	}

	public ExamePedidoFilho(final DetalhePreparacao parDetalhePreparacao, final Composicao parComposicao,
			final List<ConsultaQuestionarioExameResult> parQuestionarios, final List<PerguntaEntrega> parPerguntas) {
		exame = parComposicao.getExame();
		material = parComposicao.getMaterial();
		localColeta = Constantes.LOCAL_COLETA_PADRAO;
		dataHoraMarcacao = parComposicao.getDataHoraMarcacao();
		descricaoMaterial = retornarDescricaoMaterial(parComposicao);
		dataHoraColeta = "";
		questionarios = new QuestionariosEntrega();
		for (final ConsultaQuestionarioExameResult locConsultaQuestionarioExameResult : parQuestionarios) {
			if (parComposicao.getExame().equals(locConsultaQuestionarioExameResult.getExame())
					&& locConsultaQuestionarioExameResult.getQuestionarios() != null) {
				for (final Questionario questionario : locConsultaQuestionarioExameResult.getQuestionarios()) {
					if (!questionario.getImpresso().equals("S")) {
						questionarios.add(new QuestionarioEntrega(questionario, parPerguntas));
					}
				}
			}
		}
	}

	private String retornarExame(final DetalhePreparacao parDetalhePreparacao) {
		try {
			return parDetalhePreparacao.getId().substring(parDetalhePreparacao.getId().indexOf("||") + 2,
					parDetalhePreparacao.getId().length());
		} catch (final Exception locExc) {
			return "";
		}
	}

	private String retornarDescricaoMaterial(final Composicao parComposicao) {
		try {
			if (parComposicao.getMaterial().equals("DIV")) {
				return "*****";
			} else {
				return retornarDescricaoComTamanhoValido(parComposicao.getDescricaoMaterial());
			}
		} catch (final Exception locExc) {
			return "*****";
		}
	}

	private String retornarDescricaoComTamanhoValido(final String parInformacoesAdicionais) {
		try {
			return Util.cortarCaractere(parInformacoesAdicionais, 30);
		} catch (final Exception locExc) {
			return "";
		}
	}

	private void verificarSeProcedimentoEhVt(final ProcedimentoComExamesTO parProcedimento) {
		if (parProcedimento.getVt()) {
			dataHoraColeta = "";
		} else {
			dataHoraColeta = new DataUtil().formatarDateParaStringoComHoraSegundo(new Date());
		}
	}

	public String getExame() {
		return exame;
	}

	public void setExame(final String parExame) {
		exame = parExame;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(final String parMaterial) {
		material = parMaterial;
	}

	public String getDescricaoMaterial() {
		return descricaoMaterial;
	}

	public void setDescricaoMaterial(final String parDescricaoMaterial) {
		descricaoMaterial = parDescricaoMaterial;
	}

	public String getLocalColeta() {
		return localColeta;
	}

	public void setLocalColeta(final String parLocalColeta) {
		localColeta = parLocalColeta;
	}

	public String getDataHoraMarcacao() {
		return dataHoraMarcacao;
	}

	public void setDataHoraMarcacao(final String parDataHoraMarcacao) {
		dataHoraMarcacao = parDataHoraMarcacao;
	}

	public String getDataHoraColeta() {
		return dataHoraColeta;
	}

	public void setDataHoraColeta(final String parDataHoraColeta) {
		dataHoraColeta = parDataHoraColeta;
	}

	public QuestionariosEntrega getQuestionarios() {
		return questionarios;
	}

	public void setQuestionarios(final QuestionariosEntrega parQuestionarios) {
		questionarios = parQuestionarios;
	}

	public String getCodigoSolicitanteOperadora() {
		return codigoSolicitanteOperadora;
	}

	public void setCodigoSolicitanteOperadora(final String parCodigoSolicitanteOperadora) {
		codigoSolicitanteOperadora = parCodigoSolicitanteOperadora;
	}

}
