package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

public class TokenResult implements Serializable {

	private String mensagem;
	private String status;
	private String token;

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(final String parMensagem) {
		mensagem = parMensagem;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(final String parStatus) {
		status = parStatus;
	}

	public String getToken() {
		return token;
	}

	public void setToken(final String parToken) {
		token = parToken;
	}
}
