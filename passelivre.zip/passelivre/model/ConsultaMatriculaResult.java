package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.util.List;

public class ConsultaMatriculaResult implements Serializable {

	private String mensagem;
	private String status;
	private List<ClienteUnidadePasseLivre> clientes;

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(final String parMensagem) {
		mensagem = parMensagem;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(final String parStatus) {
		status = parStatus;
	}

	public List<ClienteUnidadePasseLivre> getClientes() {
		return clientes;
	}

	public void setClientes(final List<ClienteUnidadePasseLivre> parClientes) {
		clientes = parClientes;
	}

}
