package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

public class Product implements Serializable {

	private String sku;
	private String qty;
	private String price;
	private Integer unidade;
	private String discount;
	private Integer pedido_ihp;

	public Product() {
	}

	private Product(final DetalhePreparacao parDetalhePreparacao, final CriarPedidoResult parCriarPedidoResult) {
		sku = parDetalhePreparacao.getId();
		qty = "1";
		price = retornarPrecoValido(parDetalhePreparacao);
		discount = "0.0";
		pedido_ihp = parCriarPedidoResult.getPedido();
		unidade = parCriarPedidoResult.getUnidade();
	}

	private String retornarPrecoValido(final DetalhePreparacao parDetalhePreparacao) {
		try {
			String valorAlterado = parDetalhePreparacao.getPrivatePrice();
			if (parDetalhePreparacao.getPrivatePrice().contains("R$")) {
				valorAlterado = parDetalhePreparacao.getPrivatePrice().replace("R$", "");
			}
			if (parDetalhePreparacao.getPrivatePrice().contains(",")) {
				valorAlterado = valorAlterado.replace(",", ".");
			}
			return valorAlterado.trim();
		} catch (final Exception locExc) {
			return "";
		}
	}

	public static Product criarCheckup(final DetalhePreparacao detalhePreparacao,
			final CriarPedidoResult parCriarPedidoResult) {
		return new Product(detalhePreparacao, parCriarPedidoResult);
	}

}
