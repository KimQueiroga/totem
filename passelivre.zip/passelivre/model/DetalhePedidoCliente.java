package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

@SuppressWarnings("serial")
public class DetalhePedidoCliente implements Serializable {

	private String material;
	private String resultPacsUrl;
	private String resultScheduledDate;
	private String testHistChartUrl;
	private String testId;
	private String testName;
	private String testPdfUrl;
	private Integer testStatus;
	private Integer samplePendency;

	public String getMaterial() {
		return material;
	}

	public void setMaterial(final String parMaterial) {
		material = parMaterial;
	}

	public String getResultPacsUrl() {
		return resultPacsUrl;
	}

	public void setResultPacsUrl(final String parResultPacsUrl) {
		resultPacsUrl = parResultPacsUrl;
	}

	public String getResultScheduledDate() {
		return resultScheduledDate;
	}

	public void setResultScheduledDate(final String parResultScheduledDate) {
		resultScheduledDate = parResultScheduledDate;
	}

	public String getTestHistChartUrl() {
		return testHistChartUrl;
	}

	public void setTestHistChartUrl(final String parTestHistChartUrl) {
		testHistChartUrl = parTestHistChartUrl;
	}

	public String getTestId() {
		return testId;
	}

	public void setTestId(final String parTestId) {
		testId = parTestId;
	}

	public String getTestName() {
		return testName;
	}

	public void setTestName(final String parTestName) {
		testName = parTestName;
	}

	public String getTestPdfUrl() {
		return testPdfUrl;
	}

	public void setTestPdfUrl(final String parTestPdfUrl) {
		testPdfUrl = parTestPdfUrl;
	}

	public Integer getTestStatus() {
		return testStatus;
	}

	public void setTestStatus(final Integer parTestStatus) {
		testStatus = parTestStatus;
	}

	public Boolean exibirPDFDetalhe() {
		return testPdfUrl != null && !testPdfUrl.isEmpty();
	}

	public Integer getSamplePendency() {
		return samplePendency;
	}

	public void setSamplePendency(Integer samplePendency) {
		this.samplePendency = samplePendency;
	}
	
	
}