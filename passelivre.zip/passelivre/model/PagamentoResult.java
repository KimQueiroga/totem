package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.util.List;

public class PagamentoResult implements Serializable {
	private List<Messages> messages;

	public List<Messages> getMessages() {
		return messages;
	}

	public void setMessages(final List<Messages> parMessages) {
		messages = parMessages;
	}

}
