package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.util.List;

@SuppressWarnings("serial")
public class ExameEntrega implements Serializable {

	private String exame;
	private String material;
	private String sequenciaExame;
	private QuestionariosEntrega questionarios;

	public ExameEntrega(final ExameMaterialPendente parExameMaterialPendente) {
		setExame(parExameMaterialPendente.getExame());
		setMaterial(parExameMaterialPendente.getMaterial());
		setSequenciaExame(String.valueOf(parExameMaterialPendente.getSequencia()));
	}

	public ExameEntrega(final ExameEntrega parExameEntrega,
			final List<ConsultaQuestionarioExameResult> parQuestionariosExamesResult,
			final List<PerguntaEntrega> parPerguntas) {
		setExame(parExameEntrega.getExame());
		setMaterial(parExameEntrega.getMaterial());
		setSequenciaExame(parExameEntrega.getSequenciaExame());
		questionarios = new QuestionariosEntrega();
		if (parQuestionariosExamesResult != null) {
			for (final ConsultaQuestionarioExameResult locConsultaQuestionarioExameResult : parQuestionariosExamesResult) {
				if (locConsultaQuestionarioExameResult.getQuestionarios() != null
						&& parExameEntrega.getExame().equals(locConsultaQuestionarioExameResult.getExame())) {
					for (final Questionario questionario : locConsultaQuestionarioExameResult.getQuestionarios()) {
						questionarios.add(new QuestionarioEntrega(questionario, parPerguntas));
					}
				}
			}
		}
	}

	public ExameEntrega(final DetalhePreparacao parDetalhePreparacao) {
		exame = retornarExame(parDetalhePreparacao);
		sequenciaExame = "1";
		material = parDetalhePreparacao.getMaterialId();
		questionarios = new QuestionariosEntrega();

	}

	public ExameEntrega(final Composicao parParComposicao,
			final List<ConsultaQuestionarioExameResult> parQuestionariosExamesResult,
			final List<PerguntaEntrega> parPerguntas) {
		exame = parParComposicao.getExame();
		sequenciaExame = "1";
		material = parParComposicao.getMaterial();
		questionarios = new QuestionariosEntrega();
		if (parQuestionariosExamesResult != null) {
			for (final ConsultaQuestionarioExameResult locConsultaQuestionarioExameResult : parQuestionariosExamesResult) {
				if (locConsultaQuestionarioExameResult.getQuestionarios() != null
						&& parParComposicao.getExame().equals(locConsultaQuestionarioExameResult.getExame())) {
					for (final Questionario questionario : locConsultaQuestionarioExameResult.getQuestionarios()) {
						questionarios.add(new QuestionarioEntrega(questionario, parPerguntas));
					}
				}
			}
		}
	}

	private String retornarExame(final DetalhePreparacao parDetalhePreparacao) {
		return parDetalhePreparacao.getId().substring(parDetalhePreparacao.getId().indexOf("||") + 2,
				parDetalhePreparacao.getId().length());
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(final String parMaterial) {
		material = parMaterial;
	}

	public String getExame() {
		return exame;
	}

	public void setExame(final String parExame) {
		exame = parExame;
	}

	public String getSequenciaExame() {
		return sequenciaExame;
	}

	public void setSequenciaExame(final String parSequenciaExame) {
		sequenciaExame = parSequenciaExame;
	}

	public QuestionariosEntrega getQuestionarios() {
		return questionarios;
	}

	public void setQuestionarios(final QuestionariosEntrega parQuestionarios) {
		questionarios = parQuestionarios;
	}

}
