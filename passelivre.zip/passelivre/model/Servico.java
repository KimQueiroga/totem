package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Servico implements Serializable {

	private Long idGestaoServico;
	private Long idServico;
	private Long idTotem;
	private String ip;
	private String ativo;
	private Boolean ativoTemp;
	private String descricao;
	private String horaFimFuncionamento;
	private String horaInicioFuncionamento;
	private String observacao;

	public Servico(final Servico parServico, final Totem parTotem) {
		ativoTemp = converterStatusStringParaBoolean(parServico.getAtivo());
		ip = parTotem.getIp();
		idTotem = parTotem.getIdTotem();
		idGestaoServico = parServico.getIdGestaoServico();
		idServico = parServico.getIdServico();
		ativo = parServico.getAtivo();
		descricao = parServico.getDescricao();
		horaFimFuncionamento = parServico.getHoraFimFuncionamento();
		horaInicioFuncionamento = parServico.getHoraInicioFuncionamento();
		observacao = parServico.getObservacao();
	}

	private Boolean converterStatusStringParaBoolean(final String parAtivo) {
		if (parAtivo != null && parAtivo.equals("S")) {
			return true;
		} else {
			if (parAtivo != null && parAtivo.equals("N")) {
				return false;
			}
		}
		return false;
	}

	public Long getIdGestaoServico() {
		return idGestaoServico;
	}

	public void setIdGestaoServico(final Long parIdGestaoServico) {
		idGestaoServico = parIdGestaoServico;
	}

	public Long getIdServico() {
		return idServico;
	}

	public void setIdServico(final Long parIdServico) {
		idServico = parIdServico;
	}

	public Long getIdTotem() {
		return idTotem;
	}

	public void setIdTotem(final Long parIdTotem) {
		idTotem = parIdTotem;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(final String parIp) {
		ip = parIp;
	}

	public String getAtivo() {
		return ativo;
	}

	public void setAtivo(final String parAtivo) {
		ativo = parAtivo;
	}

	public Boolean getAtivoTemp() {
		return ativoTemp;
	}

	public void setAtivoTemp(final Boolean parAtivoTemp) {
		ativoTemp = parAtivoTemp;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(final String parDescricao) {
		descricao = parDescricao;
	}

	public String getHoraFimFuncionamento() {
		return horaFimFuncionamento;
	}

	public void setHoraFimFuncionamento(final String parHoraFimFuncionamento) {
		horaFimFuncionamento = parHoraFimFuncionamento;
	}

	public String getHoraInicioFuncionamento() {
		return horaInicioFuncionamento;
	}

	public void setHoraInicioFuncionamento(final String parHoraInicioFuncionamento) {
		horaInicioFuncionamento = parHoraInicioFuncionamento;
	}

	public String getObservacao() {
		return observacao;
	}

	public void setObservacao(final String parObservacao) {
		observacao = parObservacao;
	}

}
