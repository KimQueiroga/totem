package br.com.hermespardini.passelivre.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class MotivosGlosas extends ArrayList<MotivoGlosa> {
	public MotivosGlosas() {
		super();
	}

	public MotivosGlosas(final Collection<? extends MotivoGlosa> parMotivosGlosas) {
		super(parMotivosGlosas);
	}

	public final List<MotivoGlosa> getMotivosGlosas() {
		return this;
	}

	public final void setMotivosGlosas(final List<MotivoGlosa> parMotivosGlosas) {
		this.addAll(parMotivosGlosas);
	}
}
