package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

import br.com.hermespardini.passelivre.constantsenum.Constantes;

public class ParametroPagamento implements Serializable {

	private String token;
	private Customer customer;
	private Product product;
	private Payment payment;

	private ParametroPagamento(final Customer parCliente, final Product parProdut, final Payment parPagamento,
			final String parToken) {
		token = Constantes.TOKEN_CHECKUP;
		// token = parTokenResult.getToken();
		customer = parCliente;
		product = parProdut;
		payment = parPagamento;
	}

	public static ParametroPagamento criarPagamentoCheckup(final Customer parCliente, final Product parProduto,
			final Payment parPagamento, final String parToken) {
		return new ParametroPagamento(parCliente, parProduto, parPagamento, parToken);
	}

	public String getToken() {
		return token;
	}

	public void setToken(final String parToken) {
		token = parToken;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(final Customer parCustomer) {
		customer = parCustomer;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(final Product parProduct) {
		product = parProduct;
	}

	public Payment getPayment() {
		return payment;
	}

	public void setPayment(final Payment parPayment) {
		payment = parPayment;
	}

}
