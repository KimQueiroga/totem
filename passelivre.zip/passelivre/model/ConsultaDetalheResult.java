package br.com.hermespardini.passelivre.model;

import java.util.ArrayList;

public class ConsultaDetalheResult {

	private float Atributo;
	private String Descricao;
	private String Exame;
	private float HelpInformativo;
	private String Layout;
	private String Perfil;
	private float Sucesso;
	private ArrayList<Atributos> atributos = new ArrayList<Atributos>();

	public float getAtributo() {
		return Atributo;
	}

	public String getDescricao() {
		return Descricao;
	}

	public String getExame() {
		return Exame;
	}

	public float getHelpInformativo() {
		return HelpInformativo;
	}

	public String getLayout() {
		return Layout;
	}

	public String getPerfil() {
		return Perfil;
	}

	public float getSucesso() {
		return Sucesso;
	}

	public void setAtributo(float Atributo) {
		this.Atributo = Atributo;
	}

	public void setDescricao(String Descricao) {
		this.Descricao = Descricao;
	}

	public void setExame(String Exame) {
		this.Exame = Exame;
	}

	public void setHelpInformativo(float HelpInformativo) {
		this.HelpInformativo = HelpInformativo;
	}

	public void setLayout(String Layout) {
		this.Layout = Layout;
	}

	public void setPerfil(String Perfil) {
		this.Perfil = Perfil;
	}

	public void setSucesso(float Sucesso) {
		this.Sucesso = Sucesso;
	}

	public ArrayList<Atributos> getAtributos() {
		return atributos;
	}

	public void setAtributos(ArrayList<Atributos> atributos) {
		this.atributos = atributos;
	}

}
