package br.com.hermespardini.passelivre.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@SuppressWarnings("serial")
public class Totens extends ArrayList<Totem> {

	public Totens() {
		super();
	}

	public Totens(final Collection<? extends Totem> parTotens) {
		super(parTotens);
	}

	public final List<Totem> getTotens() {
		return this;
	}

	public final void setTotens(final List<Totem> parTotens) {
		this.addAll(parTotens);
	}

}
