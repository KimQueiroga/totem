package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.math.BigDecimal;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.unimedbh.www.Ct_dadosAutorizacao;

@SuppressWarnings("serial")
public class Solicitante implements Serializable {

	private String nomeSolicitante;
	private BigDecimal numeroConselho;
	private String codigoSolicitanteOperadora;
	private String conselho;
	private String ufConselho;
	private String cbo;
	private String cnes;
	private String nome;

	public Solicitante(final Ct_dadosAutorizacao parCt_dadosAutorizacao) {
		nomeSolicitante = parCt_dadosAutorizacao.getSolicitante().getNomeSolicitante();
		nome = parCt_dadosAutorizacao.getSolicitante().getNomeSolicitante();
		numeroConselho = parCt_dadosAutorizacao.getSolicitante().getNumeroConselho();
		conselho = parCt_dadosAutorizacao.getSolicitante().getSiglaConselho();
		ufConselho = parCt_dadosAutorizacao.getSolicitante().getUfConselho();
		codigoSolicitanteOperadora = parCt_dadosAutorizacao.getSolicitante().getCodigoNaOperadora();
		cbo = parCt_dadosAutorizacao.getSolicitante().getCodigoCBO();
		cnes = Constantes.CODIGO_CNES;
	}

	public String getNomeSolicitante() {
		return nomeSolicitante;
	}

	public void setNomeSolicitante(final String parNomeSolicitante) {
		nomeSolicitante = parNomeSolicitante;
	}

	public BigDecimal getNumeroConselho() {
		return numeroConselho;
	}

	public void setNumeroConselho(final BigDecimal parNumeroConselho) {
		numeroConselho = parNumeroConselho;
	}

	public String getConselho() {
		return conselho;
	}

	public void setConselho(final String parConselho) {
		conselho = parConselho;
	}

	public String getUfConselho() {
		return ufConselho;
	}

	public void setUfConselho(final String parUfConselho) {
		ufConselho = parUfConselho;
	}

	public String getCbo() {
		return cbo;
	}

	public void setCbo(final String parCbo) {
		cbo = parCbo;
	}

	public String getCnes() {
		return cnes;
	}

	public void setCnes(final String parCnes) {
		cnes = parCnes;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

}
