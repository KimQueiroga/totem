package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.util.List;

public class Messages implements Serializable {
	private List<Success> success;
	private List<Erro> error;

	public List<Success> getSuccess() {
		return success;
	}

	public void setSuccess(final List<Success> parSuccess) {
		success = parSuccess;
	}

	public List<Erro> getError() {
		return error;
	}

	public void setError(final List<Erro> parError) {
		error = parError;
	}

}
