package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Questionario implements Serializable {

	private String codigoFase;
	private String codigoQuestionario;
	private String descricaoFase;
	private String descricaoQuestionario;
	private String exigeAssinatura;
	private String impresso;
	private String nomeArquivo;
	private String observacao;
	private Perguntas perguntas;
	private Integer qtdePagina;
	private String tipoArquivo;

	public Questionario() {
	}

	public String getCodigoFase() {
		return codigoFase;
	}

	public void setCodigoFase(final String parCodigoFase) {
		codigoFase = parCodigoFase;
	}

	public String getCodigoQuestionario() {
		return codigoQuestionario;
	}

	public void setCodigoQuestionario(final String parCodigoQuestionario) {
		codigoQuestionario = parCodigoQuestionario;
	}

	public String getDescricaoFase() {
		return descricaoFase;
	}

	public void setDescricaoFase(final String parDescricaoFase) {
		descricaoFase = parDescricaoFase;
	}

	public String getDescricaoQuestionario() {
		return descricaoQuestionario;
	}

	public void setDescricaoQuestionario(final String parDescricaoQuestionario) {
		descricaoQuestionario = parDescricaoQuestionario;
	}

	public String getExigeAssinatura() {
		return exigeAssinatura;
	}

	public void setExigeAssinatura(final String parExigeAssinatura) {
		exigeAssinatura = parExigeAssinatura;
	}

	public String getImpresso() {
		return impresso;
	}

	public void setImpresso(final String parImpresso) {
		impresso = parImpresso;
	}

	public String getNomeArquivo() {
		return nomeArquivo;
	}

	public void setNomeArquivo(final String parNomeArquivo) {
		nomeArquivo = parNomeArquivo;
	}

	public String getObservacao() {
		return observacao;
	}

	public void setObservacao(final String parObservacao) {
		observacao = parObservacao;
	}

	public Perguntas getPerguntas() {
		return perguntas;
	}

	public void setPerguntas(final Perguntas parPerguntas) {
		perguntas = parPerguntas;
	}

	public Integer getQtdePagina() {
		return qtdePagina;
	}

	public void setQtdePagina(final Integer parQtdePagina) {
		qtdePagina = parQtdePagina;
	}

	public String getTipoArquivo() {
		return tipoArquivo;
	}

	public void setTipoArquivo(final String parTipoArquivo) {
		tipoArquivo = parTipoArquivo;
	}

}
