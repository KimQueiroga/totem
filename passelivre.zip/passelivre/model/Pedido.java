package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.util.Date;

@SuppressWarnings("serial")
public class Pedido implements Serializable {
	private String pedido;
	private String unidade;
	private String descricaoUnidade;
	private Date dataPedido;
	private Exames exames;
	private Paciente paciente;

	public String getPedido() {
		return pedido;
	}

	public void setPedido(final String parPedido) {
		pedido = parPedido;
	}

	public String getUnidade() {
		return unidade;
	}

	public void setUnidade(final String parUnidade) {
		unidade = parUnidade;
	}

	public String getDescricaoUnidade() {
		return descricaoUnidade;
	}

	public void setDescricaoUnidade(final String parDescricaoUnidade) {
		descricaoUnidade = parDescricaoUnidade;
	}

	public Date getDataPedido() {
		return dataPedido;
	}

	public void setDataPedido(final Date parDataPedido) {
		dataPedido = parDataPedido;
	}

	public Exames getExames() {
		return exames;
	}

	public void setExames(final Exames parExames) {
		exames = parExames;
	}

	public Paciente getPaciente() {
		return paciente;
	}

	public void setPaciente(Paciente paciente) {
		this.paciente = paciente;
	}

	@Override
	public String toString() {
		return pedido;
	}
}
