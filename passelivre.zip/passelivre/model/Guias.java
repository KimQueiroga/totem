package br.com.hermespardini.passelivre.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@SuppressWarnings("serial")
public class Guias extends ArrayList<Guia> {
	public Guias() {
		super();
	}

	public Guias(final Collection<? extends Guia> parGuias) {
		super(parGuias);
	}

	public final List<Guia> getGuias() {
		return this;
	}

	public final void setGuias(final List<Guia> parGuias) {
		this.addAll(parGuias);
	}
}
