package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

public class UsuarioAd implements Serializable {

	private String nome;
	private String sobreNome;
	private String cpf;
	private String empresa;
	private String departamento;
	private String sigla;
	private String cargo;
	private String telefone;
	private String displayName;
	private String siglaUsuarioAd;
	private String email;

	public String getCargo() {
		return cargo;
	}

	public void setCargo(final String parCargo) {
		cargo = parCargo;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(final String parCpf) {
		cpf = parCpf;
	}

	public String getDepartamento() {
		return departamento;
	}

	public void setDepartamento(final String parDepartamento) {
		departamento = parDepartamento;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(final String parDisplayName) {
		displayName = parDisplayName;
	}

	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(final String parEmpresa) {
		empresa = parEmpresa;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(final String parNome) {
		nome = parNome;
	}

	public String getSigla() {
		return sigla;
	}

	public void setSigla(final String parSigla) {
		sigla = parSigla;
	}

	public String getSiglaUsuarioAd() {
		return siglaUsuarioAd;
	}

	public void setSiglaUsuarioAd(final String parSiglaUsuarioAd) {
		siglaUsuarioAd = parSiglaUsuarioAd;
	}

	public String getSobreNome() {
		return sobreNome;
	}

	public void setSobreNome(final String parSobreNome) {
		sobreNome = parSobreNome;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(final String parTelefone) {
		telefone = parTelefone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(final String parEmail) {
		email = parEmail;
	}

}
