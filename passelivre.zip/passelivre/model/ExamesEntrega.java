package br.com.hermespardini.passelivre.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@SuppressWarnings("serial")
public class ExamesEntrega extends ArrayList<ExameEntrega> {
	public ExamesEntrega() {
		super();
	}

	public ExamesEntrega(final Collection<? extends ExameEntrega> parExames) {
		super(parExames);
	}

	public final List<ExameEntrega> getExamesEntregas() {
		return this;
	}

	public final void setExamesEntrega(final List<ExameEntrega> parExames) {
		this.addAll(parExames);
	}
}
