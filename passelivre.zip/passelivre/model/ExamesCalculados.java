package br.com.hermespardini.passelivre.model;

import br.com.hermespardini.corebusiness.coreenum.EnumValueOfHelper;

public class ExamesCalculados {
	
	private Boolean possuiExamesCalculados;
	private Boolean ajusteExamesCalculados;
	private TypeCalculo tipoCalculo;
	
	
	private enum TypeCalculo {
		INCLUI("Deseja incluir esse(s) exame(s) filho(s) na guia ?"), DESMEMBRA("Deseja desmembrar esse exame nos filhos acima ?"), SUBSTITUI("Deseja substituir esses exames da guia no pai acima ?");
		
		private String descricao;

		TypeCalculo(final String descricao) {
			this.descricao = descricao;
		}
		
		public static TypeCalculo valueOfDescricao(final String parDescricao) {
			return EnumValueOfHelper.valueOf(TypeCalculo.class, "descricao", parDescricao);
		}
		
		public String getDescricao() {
			return this.descricao;
		}

	}
	
	public ExamesCalculados() {		
	}
	
	
	public ExamesCalculados(Boolean possuiExamesCalculados, TypeCalculo tipoCalculo) {
		this.possuiExamesCalculados = possuiExamesCalculados;
		this.ajusteExamesCalculados = false;
		this.tipoCalculo = tipoCalculo;
	}
	
	public ExamesCalculados(Boolean possuiExamesCalculados, Boolean ajusteExamesCalculados, TypeCalculo tipoCalculo) {
		this.possuiExamesCalculados = possuiExamesCalculados;
		this.ajusteExamesCalculados = ajusteExamesCalculados;
		this.tipoCalculo = tipoCalculo;
	}
	


	public Boolean getPossuiExamesCalculados() {
		return possuiExamesCalculados;
	}


	public void setPossuiExamesCalculados(Boolean possuiExamesCalculados) {
		this.possuiExamesCalculados = possuiExamesCalculados;
	}


	public Boolean getAjusteExamesCalculados() {
		return ajusteExamesCalculados;
	}


	public void setAjusteExamesCalculados(Boolean ajusteExamesCalculados) {
		this.ajusteExamesCalculados = ajusteExamesCalculados;
	}


	public TypeCalculo getTipoCalculo() {
		return tipoCalculo;
	}


	public void setTipoCalculo(TypeCalculo tipoCalculo) {
		this.tipoCalculo = tipoCalculo;
	}
	
	

}
