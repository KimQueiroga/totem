package br.com.hermespardini.passelivre.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class Perfis extends ArrayList<Perfil> {
	public Perfis() {
		super();
	}

	public Perfis(final Collection<? extends Perfil> parPerfis) {
		super(parPerfis);
	}

	public final List<Perfil> getPerfis() {
		return this;
	}

	public final void setPerfis(final List<Perfil> parPerfis) {
		this.addAll(parPerfis);
	}
}
