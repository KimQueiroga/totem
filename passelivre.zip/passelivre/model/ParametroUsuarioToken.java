package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

import br.com.hermespardini.passelivre.constantsenum.Constantes;

public class ParametroUsuarioToken implements Serializable {

	private String authKey;
	private String authPass;

	public ParametroUsuarioToken(final String origem) {
		if (origem.equals("%PASSELIVRE")) {
			authKey = Constantes.USUARIO_TOKEN;
			authPass = Constantes.SENHA_TOKEN;
		} else {
			if (origem.equals("%PASSELIVREDESK")) {
				authKey = Constantes.USUARIO_TOKEN_DESK;
				authPass = Constantes.SENHA_TOKEN_DESK;
			}
		}
	}

	public String getAuthKey() {
		return authKey;
	}

	public void setAuthKey(final String parAuthKey) {
		authKey = parAuthKey;
	}

	public String getAuthPass() {
		return authPass;
	}

	public void setAuthPass(final String parAuthPass) {
		authPass = parAuthPass;
	}

}
