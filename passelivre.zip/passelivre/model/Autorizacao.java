package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

import br.com.unimedbh.www.Ct_dadosAutorizacao;

@SuppressWarnings("serial")
public class Autorizacao implements Serializable {

	private String senha;
	private String data;
	private String dataValidade;

	public Autorizacao(final Ct_dadosAutorizacao parCt_dadosAutorizacao) {
		senha = parCt_dadosAutorizacao.getDadosAutorizacao().getSenhaAutorizacao();
		data = parCt_dadosAutorizacao.getDadosAutorizacao().getDataAutorizacao();
		dataValidade = parCt_dadosAutorizacao.getDadosAutorizacao().getValidadeSenha();
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(final String parSenha) {
		senha = parSenha;
	}

	public String getData() {
		return data;
	}

	public void setData(final String parData) {
		data = parData;
	}

	public String getDataValidade() {
		return dataValidade;
	}

	public void setDataValidade(final String parDataValidade) {
		dataValidade = parDataValidade;
	}

}
