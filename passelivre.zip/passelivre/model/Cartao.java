package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.constantsenum.TipoCartao;

public class Cartao implements Serializable {
	private String numero;
	private String codigoAutorizacao;
	private String codigoPreAutorizacao;
	private String comprovanteVenda;
	private String operadora;
	private String tipo;
	private String validade;
	private Integer numeroParcelas;
	private String valor;
	private String nome;
	private String codigoLoteVenda;

	public Cartao(final DadosCartao parDadosCartao, final DetalhePreparacao parDetalhePreparacao,
			final PagamentoResult parPagamentoResult) {
		numero = parDadosCartao.getNumber();
		codigoAutorizacao = returnarNsu(parPagamentoResult);
		codigoPreAutorizacao = returnarNsu(parPagamentoResult);
		comprovanteVenda = returnarNsu(parPagamentoResult);
		operadora = retornarOperadora(parDadosCartao);
		tipo = Constantes.PAGAMENTO_CARTAO;
		validade = parDadosCartao.getExpiry();
		numeroParcelas = 1;
		valor = retornarPrecoValido(parDetalhePreparacao);
		nome = parDadosCartao.getName();
		codigoLoteVenda = returnarNsu(parPagamentoResult);
	}

	private String returnarNsu(final PagamentoResult parPagamentoResult) {
		try {
			return parPagamentoResult.getMessages().get(0).getSuccess().get(0).getMessage().getNsu();
		} catch (final Exception locExc) {
			return "";
		}

	}

	private String retornarPrecoValido(final DetalhePreparacao parDetalhePreparacao) {
		try {
			String valorAlterado = parDetalhePreparacao.getPrivatePrice();
			if (parDetalhePreparacao.getPrivatePrice().contains("R$")) {
				valorAlterado = parDetalhePreparacao.getPrivatePrice().replace("R$", "");
			}
			if (parDetalhePreparacao.getPrivatePrice().contains(",")) {
				valorAlterado = valorAlterado.replace(",", ".");
			}
			return valorAlterado.trim();
		} catch (final Exception locExc) {
			return "";
		}
	}

	private String retornarOperadora(final DadosCartao parDadosCartao) {
		try {
			return TipoCartao.getCartaoPorNumero(String.valueOf(parDadosCartao.getNumber().replace(" ", "")))
					.getNomeCartao();
		} catch (final Exception locExc) {
			return "";
		}
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(final String parNumero) {
		numero = parNumero;
	}

	public String getCodigoAutorizacao() {
		return codigoAutorizacao;
	}

	public void setCodigoAutorizacao(final String parCodigoAutorizacao) {
		codigoAutorizacao = parCodigoAutorizacao;
	}

	public String getCodigoPreAutorizacao() {
		return codigoPreAutorizacao;
	}

	public void setCodigoPreAutorizacao(final String parCodigoPreAutorizacao) {
		codigoPreAutorizacao = parCodigoPreAutorizacao;
	}

	public String getComprovanteVenda() {
		return comprovanteVenda;
	}

	public void setComprovanteVenda(final String parComprovanteVenda) {
		comprovanteVenda = parComprovanteVenda;
	}

	public String getOperadora() {
		return operadora;
	}

	public void setOperadora(final String parOperadora) {
		operadora = parOperadora;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(final String parTipo) {
		tipo = parTipo;
	}

	public String getValidade() {
		return validade;
	}

	public void setValidade(final String parValidade) {
		validade = parValidade;
	}

	public Integer getNumeroParcelas() {
		return numeroParcelas;
	}

	public void setNumeroParcelas(final Integer parNumeroParcelas) {
		numeroParcelas = parNumeroParcelas;
	}

	public String getValor() {
		return valor;
	}

	public void setValor(final String parValor) {
		valor = parValor;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(final String parNome) {
		nome = parNome;
	}

	public String getCodigoLoteVenda() {
		return codigoLoteVenda;
	}

	public void setCodigoLoteVenda(final String parCodigoLoteVenda) {
		codigoLoteVenda = parCodigoLoteVenda;
	}

}
