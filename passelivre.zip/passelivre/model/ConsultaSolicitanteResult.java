package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.util.List;

public class ConsultaSolicitanteResult implements Serializable {

	private String mensagem;
	private String status;
	private List<Profissional> profissionais;

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<Profissional> getProfissionais() {
		return profissionais;
	}

	public void setProfissionais(List<Profissional> profissionais) {
		this.profissionais = profissionais;
	}

}
