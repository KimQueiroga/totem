package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.util.Date;

import org.wdelmaschio.base.model.ValueObject;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.unimedbh.www.ws.tipos.Ws_respostaCobertura;

@SuppressWarnings("serial")
public class InformacaoConvenio extends ValueObject implements Serializable {

	private String plano;
	private String token;
	private String codigo;
	private String origem;
	private String unidade;
	private String convenio;
	private Long idComposicao;
	private Date dataReferencia;
	private String codigoCliente;
	private String matriculaCliente;

	public InformacaoConvenio(final Procedimento procedimento, final Ws_respostaCobertura parWs_respostaCobertura,
			final TokenResult parTokenResult, final String parUnidade, final String parNumeroCarteira,
			final ClienteUnidadePasseLivre parClienteUnidadePasseLivre) {
		codigo = procedimento.getProcedimento();
		idComposicao = procedimento.getIdComposicao();
		plano = retornarPlanoValido(
				parWs_respostaCobertura.getRespostaCobertura().getSituacaoBeneficiario().getProdutoBeneficiario());
		convenio = Constantes.CONVENIO_PADRAO;
		dataReferencia = new Date();
		origem = Constantes.USUARIO_PADRAO;
		token = parTokenResult.getToken();
		unidade = parUnidade;
		codigoCliente = parClienteUnidadePasseLivre.getCodigoCliente();
		matriculaCliente = parNumeroCarteira;
	}

	public InformacaoConvenio(final ExamePedido exame, final PreAtendimento parPreAtendimento,
			final TokenResult parTokenResult, final String parUnidade, final String parNumeroCarteira,
			final ClienteUnidadePasseLivre parClienteUnidadePasseLivre) {
		codigo = exame.getCodigoExame();
		convenio = retornaConvenioValido(parPreAtendimento.getPaciente().getOperadora());
		dataReferencia = new Date();
		origem = Constantes.ORIGEM_PADRAO;
		token = parTokenResult.getToken();
		unidade = parUnidade;
		codigoCliente = parClienteUnidadePasseLivre.getCodigoCliente();
	}

	private String retornarPlanoValido(final String parProdutoBeneficiario) {
		try {
			if (parProdutoBeneficiario.equals("-")) {
				return "";
			} else {
				return parProdutoBeneficiario;
			}
		} catch (final Exception locExc) {
			return parProdutoBeneficiario;
		}
	}

	private String retornaConvenioValido(String descricaoOperadora) {
		if (descricaoOperadora.equals("PARTICULAR")) {
			return "PART";
		} else if (descricaoOperadora.contains("UNIMED BH")) {
			return "UNIMED BH";
		} else {
			return descricaoOperadora;
		}
	}

	// public InformacaoConvenio(final Procedimento procedimento, final
	// Ws_respostaCobertura
	// parWs_respostaCobertura,
	// final TokenResult parTokenResult, final Localidade parLocalidade, final
	// String
	// parNumeroCarteira,
	// final ClienteUnidadePasseLivre parClienteUnidadePasseLivre) {
	// codigo = procedimento.getProcedimento();
	// idComposicao = procedimento.getIdComposicao();
	// plano = retornarPlanoValido(
	// parWs_respostaCobertura.getRespostaCobertura().getSituacaoBeneficiario().getProdutoBeneficiario());
	// convenio = Constantes.CONVENIO_PADRAO;
	// dataReferencia = new Date();
	// origem = Constantes.USUARIO_PADRAO;
	// token = parTokenResult.getToken();
	// unidade = parLocalidade.getFilial().toString();
	// codigoCliente = parClienteUnidadePasseLivre.getCodigoCliente();
	// matriculaCliente = parNumeroCarteira;
	// }

	public InformacaoConvenio(final Procedimento procedimento, final Ws_respostaCobertura parWs_respostaCobertura,
			final TokenResult parTokenResult, final Unidade parUnidade, final String tipo,
			final String parNumeroCarteira, final ClienteUnidadePasseLivre parClienteUnidadePasseLivre)
			throws Exception {
		codigo = procedimento.getProcedimento();
		idComposicao = procedimento.getIdComposicao();
		plano = retornarPlanoValido(
				parWs_respostaCobertura.getRespostaCobertura().getSituacaoBeneficiario().getProdutoBeneficiario());
		convenio = Constantes.CONVENIO_PADRAO;
		dataReferencia = new Date();
		origem = Constantes.USUARIO_TOKEN_DESK;
		token = parTokenResult.getToken();
		unidade = parUnidade.getCodigo().toString();
		codigoCliente = parClienteUnidadePasseLivre.getCodigoCliente();
		matriculaCliente = parNumeroCarteira;
	}

	public String getPlano() {
		return plano;
	}

	public void setPlano(final String parPlano) {
		plano = parPlano;
	}

	public String getToken() {
		return token;
	}

	public void setToken(final String parToken) {
		token = parToken;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(final String parCodigo) {
		codigo = parCodigo;
	}

	public String getOrigem() {
		return origem;
	}

	public void setOrigem(final String parOrigem) {
		origem = parOrigem;
	}

	public String getUnidade() {
		return unidade;
	}

	public void setUnidade(final String parUnidade) {
		unidade = parUnidade;
	}

	public String getConvenio() {
		return convenio;
	}

	public void setConvenio(final String parConvenio) {
		convenio = parConvenio;
	}

	public Long getIdComposicao() {
		return idComposicao;
	}

	public void setIdComposicao(final Long parIdComposicao) {
		idComposicao = parIdComposicao;
	}

	public Date getDataReferencia() {
		return dataReferencia;
	}

	public void setDataReferencia(final Date parDataReferencia) {
		dataReferencia = parDataReferencia;
	}

	public String getCodigoCliente() {
		return codigoCliente;
	}

	public void setCodigoCliente(final String parCodigoCliente) {
		codigoCliente = parCodigoCliente;
	}

	public String getMatriculaCliente() {
		return matriculaCliente;
	}

	public void setMatriculaCliente(final String parMatriculaCliente) {
		matriculaCliente = parMatriculaCliente;
	}

}
