package br.com.hermespardini.passelivre.model;

import java.sql.Timestamp;
import java.util.Date;
import java.util.Map;

import org.wdelmaschio.base.model.ValueObject;

public class Presenca extends ValueObject {

	private String carteira;
	private String filial;
	private Date datahora;
	private String status;
	private Date datacadastro;
	private Date datamodificacao;
	private Integer versao;

	public Presenca() {
	}

	public Presenca(final Map<?, ?> pObjectMapping) {
		super(pObjectMapping);
	}

	public Presenca(final String parNumeroCarteira, final Integer parFilial) {
		carteira = parNumeroCarteira;
		filial = parFilial.toString();
	}

	public Presenca(final String parNumeroCarteira, final Long parFilial) {
		carteira = parNumeroCarteira;
		filial = parFilial.toString();
	}

	public void inserirPresenca(final Presenca parParamPresenca) {
		final Timestamp dataHoraAtual = new Timestamp(System.currentTimeMillis());
		parParamPresenca.setStatus("0");
		parParamPresenca.setDatahora(dataHoraAtual);
		parParamPresenca.setDatacadastro(dataHoraAtual);
		parParamPresenca.setDatamodificacao(dataHoraAtual);
		parParamPresenca.setVersao(1);
	}

	public void atualizarPresenca(final Presenca parParamPresenca, final Presenca parLoPresenca) {
		final Timestamp dataHoraAtual = new Timestamp(System.currentTimeMillis());
		parParamPresenca.setStatus("0");
		parParamPresenca.setDatacadastro(new Timestamp(parLoPresenca.getDatacadastro().getTime()));
		parParamPresenca.setVersao(parLoPresenca.getVersao() == null ? 1 : parLoPresenca.getVersao() + 1);
		parParamPresenca.setDatahora(dataHoraAtual);
		parParamPresenca.setDatamodificacao(dataHoraAtual);
	}

	public String getCarteira() {
		return carteira;
	}

	public void setCarteira(final String parCarteira) {
		carteira = parCarteira;
	}

	public String getFilial() {
		return filial;
	}

	public void setFilial(final String parFilial) {
		filial = parFilial;
	}

	public Date getDatahora() {
		return datahora;
	}

	public void setDatahora(final Date parDatahora) {
		datahora = parDatahora;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(final String parStatus) {
		status = parStatus;
	}

	public Date getDatacadastro() {
		return datacadastro;
	}

	public void setDatacadastro(final Date parDatacadastro) {
		datacadastro = parDatacadastro;
	}

	public Date getDatamodificacao() {
		return datamodificacao;
	}

	public void setDatamodificacao(final Date parDatamodificacao) {
		datamodificacao = parDatamodificacao;
	}

	public Integer getVersao() {
		return versao;
	}

	public void setVersao(final Integer parVersao) {
		versao = parVersao;
	}

}
