package br.com.hermespardini.passelivre.model;

import java.util.Date;

public class AgendamentoUnidade {

	private Date dataAgendada;
	private String exame;
	private String grupoMedicoEspecialidade;
	private String horarioAgendado;
	private String material;
	private String nomeClienteAgenda;
	private String primeiroTelefone;
	private String solicitanteExame;
	private String tipoServico;
	private String uf;
	private String usuarioAgendamento;
	private String descricaoUnidade;
	private String unidade;
	private String descricaoExame;
	private String sequencia;
	private String idAgendamento;
	private String idSala;
	private String idEspecialista;
	private String nomeEspecialista;
	private String nomeModalidade;
	private String nomeSala;

	public String getDescricaoExame() {
		return descricaoExame;
	}

	public void setDescricaoExame(final String parDescricaoExame) {
		descricaoExame = parDescricaoExame;
	}

	public String getDescricaoUnidade() {
		return descricaoUnidade;
	}

	public void setDescricaoUnidade(final String parDescricaoUnidade) {
		descricaoUnidade = parDescricaoUnidade;
	}

	public String getUnidade() {
		return unidade;
	}

	public void setUnidade(final String parUnidade) {
		unidade = parUnidade;
	}

	public Date getDataAgendada() {
		return dataAgendada;
	}

	public void setDataAgendada(final Date parDataAgendada) {
		dataAgendada = parDataAgendada;
	}

	public String getExame() {
		return exame;
	}

	public void setExame(final String parExame) {
		exame = parExame;
	}

	public String getGrupoMedicoEspecialidade() {
		return grupoMedicoEspecialidade;
	}

	public void setGrupoMedicoEspecialidade(final String parGrupoMedicoEspecialidade) {
		grupoMedicoEspecialidade = parGrupoMedicoEspecialidade;
	}

	public String getHorarioAgendado() {
		return horarioAgendado;
	}

	public void setHorarioAgendado(final String parHorarioAgendado) {
		horarioAgendado = parHorarioAgendado;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(final String parMaterial) {
		material = parMaterial;
	}

	public String getNomeClienteAgenda() {
		return nomeClienteAgenda;
	}

	public void setNomeClienteAgenda(final String parNomeClienteAgenda) {
		nomeClienteAgenda = parNomeClienteAgenda;
	}

	public String getPrimeiroTelefone() {
		return primeiroTelefone;
	}

	public void setPrimeiroTelefone(final String parPrimeiroTelefone) {
		primeiroTelefone = parPrimeiroTelefone;
	}

	public String getSolicitanteExame() {
		return solicitanteExame;
	}

	public void setSolicitanteExame(final String parSolicitanteExame) {
		solicitanteExame = parSolicitanteExame;
	}

	public String getTipoServico() {
		return tipoServico;
	}

	public void setTipoServico(final String parTipoServico) {
		tipoServico = parTipoServico;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(final String parUf) {
		uf = parUf;
	}

	public String getUsuarioAgendamento() {
		return usuarioAgendamento;
	}

	public void setUsuarioAgendamento(final String parUsuarioAgendamento) {
		usuarioAgendamento = parUsuarioAgendamento;
	}

	public String getSequencia() {
		return sequencia;
	}

	public void setSequencia(final String parSequencia) {
		sequencia = parSequencia;
	}

	public String getIdAgendamento() {
		return idAgendamento;
	}

	public void setIdAgendamento(String idAgendamento) {
		this.idAgendamento = idAgendamento;
	}

	public String getIdSala() {
		return idSala;
	}

	public void setIdSala(String idSala) {
		this.idSala = idSala;
	}

	public String getIdEspecialista() {
		return idEspecialista;
	}

	public void setIdEspecialista(String idEspecialista) {
		this.idEspecialista = idEspecialista;
	}

	public String getNomeEspecialista() {
		return nomeEspecialista;
	}

	public void setNomeEspecialista(String nomeEspecialista) {
		this.nomeEspecialista = nomeEspecialista;
	}

	public String getNomeModalidade() {
		return nomeModalidade;
	}

	public void setNomeModalidade(String nomeModalidade) {
		this.nomeModalidade = nomeModalidade;
	}

	public String getNomeSala() {
		return nomeSala;
	}

	public void setNomeSala(String nomeSala) {
		this.nomeSala = nomeSala;
	}

}
