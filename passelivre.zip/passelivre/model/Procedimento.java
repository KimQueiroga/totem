package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import br.com.unimedbh.esb.prontuario.schemas.ComposicaoDTO;
import br.com.unimedbh.www.Ct_dadosAutorizacao;
import br.gov.ans.www.padroes.tiss.schemas.Ct_itemSolicitacao;
import br.gov.ans.www.padroes.tiss.schemas.Ct_motivoGlosa;

@SuppressWarnings("serial")
public class Procedimento implements Serializable {
	private String procedimento;
	private String guia;
	private String descricao;
	private BigDecimal quantidadeAutorizadas;
	private BigDecimal quantidadeSolicitacadas;
	private MotivosGlosas glosas;
	private ExameHermesPardini exame;
	private Long idComposicao;
	private String informacoesAdicionais;
	private String informacoesClinica;
	
	private ExamesCalculados examesCalculados;


	public Procedimento(final Ct_dadosAutorizacao parLoc_dadosAutorizacao, final Object parObject,
			final List<ComposicaoDTO> parComposicoes, final Ct_itemSolicitacao parLoc_itemSolicitacao) {
		guia = parLoc_dadosAutorizacao.getIdentificacaoAutorizacao().getNumeroGuiaPrestador();
		procedimento = parLoc_itemSolicitacao.getIdentificacaoProcedimentos().getCodigo();
		descricao = parLoc_itemSolicitacao.getIdentificacaoProcedimentos().getDescricao();
		idComposicao = retornarComposicao(parComposicoes, this);
		informacoesAdicionais = parLoc_itemSolicitacao.getObservacao();
		informacoesClinica = parLoc_dadosAutorizacao.getIndicacaoClinica();
		exame = null;
		quantidadeSolicitacadas = parLoc_itemSolicitacao.getQuantidadeSolicitada();
		quantidadeAutorizadas = parLoc_itemSolicitacao.getQuantidadeAutorizada();
		glosas = new MotivosGlosas();
		if (parLoc_itemSolicitacao.getGlosas() != null) {
			for (final Ct_motivoGlosa ct_motivoGlosa : parLoc_itemSolicitacao.getGlosas()) {
				glosas.add(new MotivoGlosa(ct_motivoGlosa));
			}
		}
	}

	public Procedimento(final Ct_dadosAutorizacao parLoc_dadosAutorizacao, final List<ComposicaoDTO> parComposicoes,
			final Ct_itemSolicitacao parLoc_itemSolicitacao) {
		guia = parLoc_dadosAutorizacao.getIdentificacaoAutorizacao().getNumeroGuiaPrestador();
		procedimento = parLoc_itemSolicitacao.getIdentificacaoProcedimentos().getCodigo();
		descricao = parLoc_itemSolicitacao.getIdentificacaoProcedimentos().getDescricao();
		idComposicao = retornarComposicao(parComposicoes, this);
		informacoesAdicionais = parLoc_itemSolicitacao.getObservacao();
		informacoesClinica = parLoc_dadosAutorizacao.getIndicacaoClinica();
		quantidadeSolicitacadas = parLoc_itemSolicitacao.getQuantidadeSolicitada();
		quantidadeAutorizadas = parLoc_itemSolicitacao.getQuantidadeAutorizada();
		glosas = new MotivosGlosas();
		if (parLoc_itemSolicitacao.getGlosas() != null) {
			for (final Ct_motivoGlosa ct_motivoGlosa : parLoc_itemSolicitacao.getGlosas()) {
				glosas.add(new MotivoGlosa(ct_motivoGlosa));
			}
		}
	}

	public Procedimento(final Ct_dadosAutorizacao parLoc_dadosAutorizacao,
			final Ct_itemSolicitacao parLoc_itemSolicitacao, final Object parObject) {
		guia = parLoc_dadosAutorizacao.getIdentificacaoAutorizacao().getNumeroGuiaPrestador();
		procedimento = parLoc_itemSolicitacao.getIdentificacaoProcedimentos().getCodigo();
		descricao = parLoc_itemSolicitacao.getIdentificacaoProcedimentos().getDescricao();
		exame = null;
		informacoesAdicionais = parLoc_itemSolicitacao.getObservacao();
		informacoesClinica = parLoc_dadosAutorizacao.getIndicacaoClinica();
		quantidadeSolicitacadas = parLoc_itemSolicitacao.getQuantidadeSolicitada();
		quantidadeAutorizadas = parLoc_itemSolicitacao.getQuantidadeAutorizada();
		glosas = new MotivosGlosas();
		if (parLoc_itemSolicitacao.getGlosas() != null) {
			for (final Ct_motivoGlosa ct_motivoGlosa : parLoc_itemSolicitacao.getGlosas()) {
				glosas.add(new MotivoGlosa(ct_motivoGlosa));
			}
		}
	}

	public Procedimento(final Ct_dadosAutorizacao parLoc_dadosAutorizacao,
			final Ct_itemSolicitacao parLoc_itemSolicitacao) {
		guia = parLoc_dadosAutorizacao.getIdentificacaoAutorizacao().getNumeroGuiaPrestador();
		procedimento = parLoc_itemSolicitacao.getIdentificacaoProcedimentos().getCodigo();
		descricao = parLoc_itemSolicitacao.getIdentificacaoProcedimentos().getDescricao();
		informacoesAdicionais = parLoc_itemSolicitacao.getObservacao();
		informacoesClinica = parLoc_dadosAutorizacao.getIndicacaoClinica();
		quantidadeSolicitacadas = parLoc_itemSolicitacao.getQuantidadeSolicitada();
		quantidadeAutorizadas = parLoc_itemSolicitacao.getQuantidadeAutorizada();
		glosas = new MotivosGlosas();
		if (parLoc_itemSolicitacao.getGlosas() != null) {
			for (final Ct_motivoGlosa ct_motivoGlosa : parLoc_itemSolicitacao.getGlosas()) {
				glosas.add(new MotivoGlosa(ct_motivoGlosa));
			}
		}
	}

	public String getProcedimento() {
		return procedimento;
	}

	public void setProcedimento(final String parProcedimento) {
		procedimento = parProcedimento;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(final String parDescricao) {
		descricao = parDescricao;
	}

	public ExameHermesPardini getExame() {
		return exame;
	}

	public void setExame(final ExameHermesPardini parExame) {
		exame = parExame;
	}

	public String getGuia() {
		return guia;
	}

	public void setGuia(final String parGuia) {
		guia = parGuia;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (procedimento == null ? 0 : procedimento.hashCode());
		result = prime * result + (descricao == null ? 0 : descricao.hashCode());
		return result;
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final Procedimento other = (Procedimento) obj;
		if (procedimento == null) {
			if (other.procedimento != null) {
				return false;
			}
		} else if (!procedimento.equals(other.procedimento)) {
			return false;
		}
		if (descricao == null) {
			if (other.descricao != null) {
				return false;
			}
		} else if (!descricao.equals(other.descricao)) {
			return false;
		}
		return true;
	}

	public Long getIdComposicao() {
		return idComposicao;
	}

	public void setIdComposicao(final Long parIdComposicao) {
		idComposicao = parIdComposicao;
	}

	private Long retornarComposicao(final List<ComposicaoDTO> parComposicoes, final Procedimento parProcedimento) {
		Long idComposicao = 0L;
		for (int x = 0; x < parComposicoes.size(); x++) {
			if (parComposicoes.get(x).getCodProced().equals(parProcedimento.getProcedimento())) {
				idComposicao = parComposicoes.get(x).getIdCtrlComposProcSolicItem();
				parComposicoes.remove(parComposicoes.get(x));
				return idComposicao;
			} else {
				return null;
			}
		}
		return null;
	}

	public String getInformacoesAdicionais() {
		return informacoesAdicionais;
	}

	public void setInformacoesAdicionais(final String parInformacoesAdicionais) {
		informacoesAdicionais = parInformacoesAdicionais;
	}

	public String getInformacoesClinica() {
		return informacoesClinica;
	}

	public void setInformacoesClinica(final String parInformacoesClinica) {
		informacoesClinica = parInformacoesClinica;
	}

	public BigDecimal getQuantidadeAutorizadas() {
		return quantidadeAutorizadas;
	}

	public void setQuantidadeAutorizadas(final BigDecimal parQuantidadeAutorizadas) {
		quantidadeAutorizadas = parQuantidadeAutorizadas;
	}

	public BigDecimal getQuantidadeSolicitacadas() {
		return quantidadeSolicitacadas;
	}

	public void setQuantidadeSolicitacadas(final BigDecimal parQuantidadeSolicitacadas) {
		quantidadeSolicitacadas = parQuantidadeSolicitacadas;
	}

	public MotivosGlosas getGlosas() {
		return glosas;
	}

	public void setGlosas(final MotivosGlosas parGlosas) {
		glosas = parGlosas;
	}
	
	public ExamesCalculados getExamesCalculados() {
		return examesCalculados;
	}
	
	public void setExamesCalculados(ExamesCalculados examesCalculados) {
		this.examesCalculados = examesCalculados;
	}

}
