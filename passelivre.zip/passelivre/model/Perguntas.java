package br.com.hermespardini.passelivre.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@SuppressWarnings("serial")
public class Perguntas extends ArrayList<Pergunta> {
	public Perguntas() {
		super();
	}

	public Perguntas(final Collection<? extends Pergunta> parPerguntas) {
		super(parPerguntas);
	}

	public final List<Pergunta> getPerguntas() {
		return this;
	}

	public final void setPerguntas(final List<Pergunta> parPerguntas) {
		this.addAll(parPerguntas);
	}

	public List<Pergunta> listarPerguntasConsolidadas() {
		final List<Pergunta> perguntasFinais = new ArrayList<Pergunta>();
		for (final Pergunta pergunta : getPerguntas()) {
			if (perguntaEhConsolidada(pergunta)) {
				if (perguntaNaoFoiAdicionada(pergunta, perguntasFinais)) {
					perguntasFinais.add(pergunta);
				}
			} else {
				perguntasFinais.add(pergunta);
			}
		}
		return perguntasFinais;
	}

	private boolean perguntaEhConsolidada(final Pergunta pergunta) {
		return pergunta.getPermiteConsolidacao().equals("S");
	}

	private boolean perguntaNaoFoiAdicionada(final Pergunta parPergunta, final List<Pergunta> perguntasFinais) {
		return !perguntasFinais.contains(parPergunta);
	}
}
