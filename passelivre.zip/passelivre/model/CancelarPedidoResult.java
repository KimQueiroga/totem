package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

public class CancelarPedidoResult implements Serializable {

	private String mensagem;
	private String status;

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(final String parMensagem) {
		mensagem = parMensagem;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(final String parStatus) {
		status = parStatus;
	}

}
