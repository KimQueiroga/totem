package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

import br.gov.ans.www.padroes.tiss.schemas.Ct_motivoGlosa;

public class MotivoGlosa implements Serializable {

	private String codigoGlosa;
	private String descricaoGlosa;

	public MotivoGlosa(final Ct_motivoGlosa parCt_motivoGlosa) {
		codigoGlosa = parCt_motivoGlosa.getCodigoGlosa();
		descricaoGlosa = parCt_motivoGlosa.getDescricaoGlosa();
	}

	public String getCodigoGlosa() {
		return codigoGlosa;
	}

	public void setCodigoGlosa(final String parCodigoGlosa) {
		codigoGlosa = parCodigoGlosa;
	}

	public String getDescricaoGlosa() {
		return descricaoGlosa;
	}

	public void setDescricaoGlosa(final String parDescricaoGlosa) {
		descricaoGlosa = parDescricaoGlosa;
	}
}
