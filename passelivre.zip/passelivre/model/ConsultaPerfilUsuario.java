package br.com.hermespardini.passelivre.model;

public class ConsultaPerfilUsuario {

}
