package br.com.hermespardini.passelivre.model;

public class Agenda {

	private String idAgendamento;
	private String tipoServico;
	private String dataHoraAgendamento;
	private String recursoAgenda;
	private String sequencia;

	public String getIdAgendamento() {
		return idAgendamento;
	}

	public void setIdAgendamento(String idAgendamento) {
		this.idAgendamento = idAgendamento;
	}

	public String getTipoServico() {
		return tipoServico;
	}

	public void setTipoServico(final String parTipoServico) {
		tipoServico = parTipoServico;
	}

	public String getDataHoraAgendamento() {
		return dataHoraAgendamento;
	}

	public void setDataHoraAgendamento(final String parDataHoraAgendamento) {
		dataHoraAgendamento = parDataHoraAgendamento;
	}

	public String getRecursoAgenda() {
		return recursoAgenda;
	}

	public void setRecursoAgenda(final String parRecursoAgenda) {
		recursoAgenda = parRecursoAgenda;
	}

	public String getSequencia() {
		return sequencia;
	}

	public void setSequencia(final String parSequencia) {
		sequencia = parSequencia;
	}

}
