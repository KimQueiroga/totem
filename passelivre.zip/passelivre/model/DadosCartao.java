package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

import org.apache.commons.lang3.StringUtils;

import br.com.hermespardini.passelivre.exception.RegraNegocioException;

public class DadosCartao implements Serializable {

	private String name;
	private String number;
	private String cvc;
	private String expiry;

	public void verificarSeCamposForamPreenchidos() throws RegraNegocioException {
		verificarSeNomeEstaVazio();
		verificarSeNumeroEstaVazio();
		verificarSeCvcEstaVazio();
		verificarSeExpiryEstaVazio();
	}

	private void verificarSeNomeEstaVazio() throws RegraNegocioException {
		if (isNameNull()) {
			throw new RegraNegocioException("Campo nome não pode ser vazio!");
		}
	}

	private boolean isNameNull() {
		return StringUtils.isEmpty(name) || name == null || StringUtils.isBlank(name);
	}

	private void verificarSeNumeroEstaVazio() throws RegraNegocioException {
		if (isNumeroNull()) {
			throw new RegraNegocioException("Campo número não pode ser vazio!");
		}
	}

	private boolean isNumeroNull() {
		return StringUtils.isEmpty(number) || number == null || StringUtils.isBlank(number);
	}

	private void verificarSeCvcEstaVazio() throws RegraNegocioException {
		if (isCvcNull()) {
			throw new RegraNegocioException("Campo código segurança não pode ser vazio!");
		}
	}

	private boolean isCvcNull() {
		return StringUtils.isEmpty(cvc) || cvc == null || StringUtils.isBlank(cvc);
	}

	private void verificarSeExpiryEstaVazio() throws RegraNegocioException {
		if (isExpiryNull()) {
			throw new RegraNegocioException("Campo data validade não pode ser vazio!");
		}
	}

	private boolean isExpiryNull() {
		return StringUtils.isEmpty(expiry) || expiry == null || StringUtils.isBlank(expiry);
	}

	public String getName() {
		return name;
	}

	public void setName(final String parName) {
		name = parName;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(final String parNumber) {
		number = parNumber;
	}

	public String getCvc() {
		return cvc;
	}

	public void setCvc(final String parCvc) {
		cvc = parCvc;
	}

	public String getExpiry() {
		return expiry;
	}

	public void setExpiry(final String parExpiry) {
		expiry = parExpiry;
	}

}
