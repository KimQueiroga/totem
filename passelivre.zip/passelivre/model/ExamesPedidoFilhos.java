package br.com.hermespardini.passelivre.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class ExamesPedidoFilhos extends ArrayList<ExamePedidoFilho> {
	public ExamesPedidoFilhos() {
		super();
	}

	public ExamesPedidoFilhos(final Collection<? extends ExamePedidoFilho> parExames) {
		super(parExames);
	}

	public final List<ExamePedidoFilho> getExamesPedidoFilhos() {
		return this;
	}

	public final void setExamesPedidoFilhos(final List<ExamePedidoFilho> parExames) {
		this.addAll(parExames);
	}
}
