package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

public class ParametroLogin implements Serializable {

	private String authKey;
	private String authPass;
	private Integer authKeyType;
	private String siglaAplicacao;
	private Long idEmpresa;

	public String getAuthKey() {
		return authKey;
	}

	public void setAuthKey(final String parAuthKey) {
		authKey = parAuthKey;
	}

	public String getAuthPass() {
		return authPass;
	}

	public void setAuthPass(final String parAuthPass) {
		authPass = parAuthPass;
	}

	public Integer getAuthKeyType() {
		return authKeyType;
	}

	public void setAuthKeyType(final Integer parAuthKeyType) {
		authKeyType = parAuthKeyType;
	}

	public String getSiglaAplicacao() {
		return siglaAplicacao;
	}

	public void setSiglaAplicacao(final String parSiglaAplicacao) {
		siglaAplicacao = parSiglaAplicacao;
	}

	public Long getIdEmpresa() {
		return idEmpresa;
	}

	public void setIdEmpresa(final Long parIdEmpresa) {
		idEmpresa = parIdEmpresa;
	}
}
