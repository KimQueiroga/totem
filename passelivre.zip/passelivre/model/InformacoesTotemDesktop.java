package br.com.hermespardini.passelivre.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class InformacoesTotemDesktop extends ArrayList<InformacaoTotemDesktop> {
	public InformacoesTotemDesktop() {
		super();
	}

	public InformacoesTotemDesktop(final Collection<? extends InformacaoTotemDesktop> parInformacaoTotemDesktop) {
		super(parInformacaoTotemDesktop);
	}

	public final List<InformacaoTotemDesktop> getInformacaoTotemDesktop() {
		return this;
	}

	public final void setPerfis(final List<InformacaoTotemDesktop> parInformacaoTotemDesktop) {
		this.addAll(parInformacaoTotemDesktop);
	}
}
