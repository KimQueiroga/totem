package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Endereco implements Serializable {

	private String tipoLogradouro;
	private String logradouro;
	private String numero;
	private String complemento;
	private String bairro;
	private String cidade;
	private String uf;
	private String cep;

	public Endereco(final ClienteUnidadePasseLivre parClienteUnidadePasseLivre) {
		tipoLogradouro = parClienteUnidadePasseLivre.getTipoLogradouro();
		logradouro = parClienteUnidadePasseLivre.getLogradouro();
		numero = parClienteUnidadePasseLivre.getNumero();
		complemento = parClienteUnidadePasseLivre.getComplemento();
		bairro = parClienteUnidadePasseLivre.getBairro();
		cidade = parClienteUnidadePasseLivre.getCidade();
		uf = parClienteUnidadePasseLivre.getUf();
		cep = parClienteUnidadePasseLivre.getCep();
	}

	public String getTipoLogradouro() {
		return tipoLogradouro;
	}

	public void setTipoLogradouro(final String parTipoLogradouro) {
		tipoLogradouro = parTipoLogradouro;
	}

	public String getLogradouro() {
		return logradouro;
	}

	public void setLogradouro(final String parLogradouro) {
		logradouro = parLogradouro;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(final String parNumero) {
		numero = parNumero;
	}

	public String getComplemento() {
		return complemento;
	}

	public void setComplemento(final String parComplemento) {
		complemento = parComplemento;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(final String parBairro) {
		bairro = parBairro;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(final String parCidade) {
		cidade = parCidade;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(final String parUf) {
		uf = parUf;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(final String parCep) {
		cep = parCep;
	}

}
