package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

public class Preparacao implements Serializable {

	private String id;
	private String name;
	private String mensagem;

	public String getId() {
		return id;
	}

	public void setId(final String parId) {
		id = parId;
	}

	public String getName() {
		return name;
	}

	public void setName(final String parName) {
		name = parName;
	}

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(final String parMensagem) {
		mensagem = parMensagem;
	}
}
