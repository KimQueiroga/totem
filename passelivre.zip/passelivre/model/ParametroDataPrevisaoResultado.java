package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.owlike.genson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.utils.TotemUtil;

@SuppressWarnings("serial")
public class ParametroDataPrevisaoResultado implements Serializable{

	//Campos para os HEADERS da requisição
	@JsonIgnore
	private String origem;
	@JsonIgnore
	private String token;
	
	//Campos para o BODY da requisição 
	private String unidade;
	private String dataReferencia;
	@JsonInclude(Include.NON_NULL)
	private String especialista;
	@JsonInclude(Include.NON_NULL)
	private String sala;
	private String exame;
	private String material;
	
	public ParametroDataPrevisaoResultado(AgendamentoUnidade parAgendamentoUnidade, TokenResult parTokenResult) {
		token = parTokenResult.getToken();
		if (TotemUtil.isDesktop()) {
			origem = Constantes.ORIGEM_DESKTOP;
		} else {
			origem = Constantes.ORIGEM_PADRAO;
		}
		unidade = parAgendamentoUnidade.getUnidade();
		dataReferencia = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
		preencheEspecialistaOuSala(parAgendamentoUnidade.getIdEspecialista(), parAgendamentoUnidade.getIdSala());
		exame = parAgendamentoUnidade.getExame();
		material = parAgendamentoUnidade.getMaterial();
	}
	
	private void preencheEspecialistaOuSala(String parIdEspecialista, String parIdSala) {
		if (parIdEspecialista == null && parIdSala != null) {
			this.sala = parIdSala;
		} else if (parIdSala == null && parIdEspecialista != null) {
			this.especialista = parIdEspecialista;
		}
	}

	public String getOrigem() {
		return origem;
	}
	
	public void setOrigem(String origem) {
		this.origem = origem;
	}
	
	public String getToken() {
		return token;
	}
	
	public void setToken(String token) {
		this.token = token;
	}
	
	public String getUnidade() {
		return unidade;
	}
	
	public void setUnidade(String unidade) {
		this.unidade = unidade;
	}
	
	public String getDataReferencia() {
		return dataReferencia;
	}
	
	public void setDataReferencia(String dataReferencia) {
		this.dataReferencia = dataReferencia;
	}
	
	public String getSala() {
		return sala;
	}
	
	public void setSala(String sala) {
		this.sala = sala;
	}
	
	public String getExame() {
		return exame;
	}
	
	public void setExame(String exame) {
		this.exame = exame;
	}
	
	public String getMaterial() {
		return material;
	}
	
	public void setMaterial(String material) {
		this.material = material;
	}
	
}
