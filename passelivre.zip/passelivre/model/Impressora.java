package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

public class Impressora implements Serializable {

	private String codigo;
	private String tipoFormulario;

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(final String parCodigo) {
		codigo = parCodigo;
	}

	public String getTipoFormulario() {
		return tipoFormulario;
	}

	public void setTipoFormulario(final String parTipoFormulario) {
		tipoFormulario = parTipoFormulario;
	}

	@Override
	public String toString() {
		return codigo;
	}
}
