package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

public class ExameOrcamento implements Serializable, Comparable<ExameOrcamento> {

	private String exame;
	private String valor;
	private String codigo;

	public ExameOrcamento(final DetalhePreparacao parDetalhePreparacao, final Preparacao parPreparacaoSelecionada) {
		exame = parDetalhePreparacao.getTestName();
		valor = parDetalhePreparacao.getPrivatePrice();
		codigo = parDetalhePreparacao.getId();
	}

	public String getExame() {
		return exame;
	}

	public void setExame(final String parExame) {
		exame = parExame;
	}

	public String getValor() {
		return valor;
	}

	public void setValor(final String parValor) {
		valor = parValor;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(final String parCodigo) {
		codigo = parCodigo;
	}

	@Override
	public int compareTo(final ExameOrcamento exameOrcamento) {
		return exame.compareTo(exameOrcamento.getExame());
	}

}
