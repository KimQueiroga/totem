package br.com.hermespardini.passelivre.model;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.utils.StringUtil;
import sun.swing.StringUIClientPropertyKey;

public class ParametroRecibo {

	private String codigoCliente;
	private String atendente;
	private String nomeCliente;
	private String cpf;
	private String valor;
	private String numPedidoUnidade;
	private String senha;
	private String arquivoReport;
	private String unidade;
	private String cidade;
	private String descricao;

	public ParametroRecibo() {
	}

	private ParametroRecibo(final ClienteUnidadePasseLivre parClienteUnidadePasseLivre,
			final CriarPedidoResult parCriaPedidoResult, final DetalhePreparacao parDetalhePreparacao,
			final String parPathArquivoReport) {
		codigoCliente = parClienteUnidadePasseLivre.getCodigoCliente();
		atendente = Constantes.NOME_SISTEMA;
		nomeCliente = parClienteUnidadePasseLivre.getNomeCliente();
		cpf = formataCPFComMask(parClienteUnidadePasseLivre.getCpf());
		valor = retornarPrecoValido(parDetalhePreparacao);
		numPedidoUnidade = retornarPedido(parCriaPedidoResult);
		senha = parClienteUnidadePasseLivre.getCurrentPass();
		arquivoReport = parPathArquivoReport;
		descricao = parDetalhePreparacao.getTestName();
	}

	private String retornarPedido(final CriarPedidoResult parCriaPedidoResult) {
		if (parCriaPedidoResult.getPedido() != null) {
			return parCriaPedidoResult.getPedido().toString();
		} else {
			return "";
		}
	}

	private String retornarPrecoValido(final DetalhePreparacao parDetalhePreparacao) {
		try {
			String valorAlterado = parDetalhePreparacao.getPrivatePrice();
			if (parDetalhePreparacao.getPrivatePrice().contains("R$")) {
				valorAlterado = parDetalhePreparacao.getPrivatePrice().replace("R$", "");
			}
			/*
			 * if (parDetalhePreparacao.getPrivatePrice().contains(",")) { valorAlterado =
			 * valorAlterado.replace(",", "."); }
			 */
			return valorAlterado.trim();
		} catch (final Exception locExc) {
			return "";
		}
	}

	private String formataCPFComMask(String parCPF) {
		StringUtil util = new StringUtil();
		return util.formatarCPFComMask(parCPF);
	}

	public static ParametroRecibo criarParametros(final ClienteUnidadePasseLivre parClienteUnidadePasseLivre,
			final CriarPedidoResult parCriaPedidoResult, final DetalhePreparacao parDetalhePreparacao,
			final String pathArquivoReport) {
		return new ParametroRecibo(parClienteUnidadePasseLivre, parCriaPedidoResult, parDetalhePreparacao,
				pathArquivoReport);
	}

	public String getCodigoCliente() {
		return codigoCliente;
	}

	public void setCodigoCliente(final String parCodigoCliente) {
		codigoCliente = parCodigoCliente;
	}

	public String getAtendente() {
		return atendente;
	}

	public void setAtendente(final String parAtendente) {
		atendente = parAtendente;
	}

	public String getNomeCliente() {
		return nomeCliente;
	}

	public void setNomeCliente(final String parNomeCliente) {
		nomeCliente = parNomeCliente;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(final String parCpf) {
		cpf = parCpf;
	}

	public String getValor() {
		return valor;
	}

	public void setValor(final String parValor) {
		valor = parValor;
	}

	public String getNumPedidoUnidade() {
		return numPedidoUnidade;
	}

	public void setNumPedidoUnidade(final String parNumPedidoUnidade) {
		numPedidoUnidade = parNumPedidoUnidade;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(final String parSenha) {
		senha = parSenha;
	}

	public String getArquivoReport() {
		return arquivoReport;
	}

	public void setArquivoReport(final String parArquivoReport) {
		arquivoReport = parArquivoReport;
	}

	public String getUnidade() {
		return unidade;
	}

	public void setUnidade(String unidade) {
		this.unidade = unidade;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

}
