package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

import br.com.hermespardini.passelivre.constantsenum.Constantes;

public class ParametroPreparacao implements Serializable {

	private String id;
	private String q;
	private String tipoPaciente;

	public ParametroPreparacao() {
		tipoPaciente = Constantes.HUMANO;
	}

	public ParametroPreparacao(final String id) {
		tipoPaciente = Constantes.HUMANO;
		this.id = id;
	}

	public ParametroPreparacao(final Preparacao parPreparacaoSelecionada) {
		id = parPreparacaoSelecionada.getId();
		tipoPaciente = Constantes.HUMANO;
	}

	public static ParametroPreparacao criarBuscaCheckupMasculino() {
		return new ParametroPreparacao("S||CHEMAS");
	}

	public static ParametroPreparacao criarBuscaCheckupFeminino() {
		return new ParametroPreparacao("S||CHEFEM");
	}

	public String getId() {
		return id;
	}

	public void setId(final String parId) {
		id = parId;
	}

	public String getQ() {
		return q;
	}

	public void setQ(final String parQ) {
		q = parQ;
	}

	public String getTipoPaciente() {
		return tipoPaciente;
	}

	public void setTipoPaciente(final String parTipoPaciente) {
		tipoPaciente = parTipoPaciente;
	}

}
