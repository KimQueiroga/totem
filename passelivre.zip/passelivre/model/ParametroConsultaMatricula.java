package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

import br.com.hermespardini.passelivre.constantsenum.Constantes;

public class ParametroConsultaMatricula implements Serializable {

	private String grupoOperadora;
	private String codigoCliente;
	private String matricula;
	private String token;
	private String origem;
	private String sessionId;

	public ParametroConsultaMatricula(final String parMatricula, final TokenResult parTokenResult) {
		grupoOperadora = Constantes.OPERADORA_PADRAO;
		codigoCliente = "";
		matricula = parMatricula;
		token = parTokenResult.getToken();
		origem = Constantes.USUARIO_PADRAO;
	}

	public ParametroConsultaMatricula(final String parMatricula, final TokenResult parTokenResult, final String tipo,
			final String parSessionId) {
		grupoOperadora = Constantes.OPERADORA_PADRAO;
		codigoCliente = "";
		matricula = parMatricula;
		token = parTokenResult.getToken();
		origem = Constantes.USUARIO_TOKEN_DESK;
		sessionId = parSessionId;
	}

	public String getGrupoOperadora() {
		return grupoOperadora;
	}

	public void setGrupoOperadora(final String parGrupoOperadora) {
		grupoOperadora = parGrupoOperadora;
	}

	public String getCodigoCliente() {
		return codigoCliente;
	}

	public void setCodigoCliente(final String parCodigoCliente) {
		codigoCliente = parCodigoCliente;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(final String parMatricula) {
		matricula = parMatricula;
	}

	public String getToken() {
		return token;
	}

	public void setToken(final String parToken) {
		token = parToken;
	}

	public String getOrigem() {
		return origem;
	}

	public void setOrigem(final String parOrigem) {
		origem = parOrigem;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(final String parSessionId) {
		sessionId = parSessionId;
	}

}
