package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Profissional implements Serializable {

	private String tipo;
	private String numeroConselho;
	private String conselho;
	private String uf;

}
