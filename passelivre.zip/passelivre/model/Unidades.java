package br.com.hermespardini.passelivre.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class Unidades extends ArrayList<Unidade> {
	public Unidades() {
		super();
	}

	public Unidades(final Collection<? extends Unidade> parUnidades) {
		super(parUnidades);
	}

	public final List<Unidade> getUnidades() {
		return this;
	}

	public final void setUnidades(final List<Unidade> parUnidades) {
		this.addAll(parUnidades);
	}

}
