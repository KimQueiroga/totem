package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.utils.TotemUtil;

@SuppressWarnings("serial")
public class ParametroPreAtendimento implements Serializable {

	private String codigoCliente;
	private String numeroPreAtendimento;
	private String tipoAtendimento;
	private String atendidos;
	private String token;
	private String senhaOrigem;
	private String origem;
	private String Conta;

	public ParametroPreAtendimento(final ClienteUnidadePasseLivre parClienteUnidadePasseLivre,
			final TokenResult parTokenResult) {
		codigoCliente = parClienteUnidadePasseLivre.getCodigoCliente();
		Conta = Constantes.CONTA_PRE_ATENDIMENTO;
		token = parTokenResult.getToken();
		if (TotemUtil.isDesktop()) {
			origem = Constantes.ORIGEM_DESKTOP;
		} else {
			origem = Constantes.ORIGEM_PADRAO;
		}
		tipoAtendimento = Constantes.TIPO_PRE_ATENDIMENTO;
		atendidos = Constantes.NAO;
	}

	public ParametroPreAtendimento(final String parNumeroPreAtendimento, final TokenResult parTokenResult) {
		numeroPreAtendimento = parNumeroPreAtendimento.substring(3);
		Conta = Constantes.CONTA_PRE_ATENDIMENTO;
		token = parTokenResult.getToken();
		if (TotemUtil.isDesktop()) {
			origem = Constantes.ORIGEM_DESKTOP;
		} else {
			origem = Constantes.ORIGEM_PADRAO;
		}
		tipoAtendimento = Constantes.TIPO_PRE_ATENDIMENTO;
		atendidos = Constantes.NAO;
	}

	public String getCodigoCliente() {
		return codigoCliente;
	}

	public void setCodigoCliente(final String parCodigocliente) {
		codigoCliente = parCodigocliente;
	}

	public String getNumeroPreAtendimento() {
		return numeroPreAtendimento;
	}

	public void setNumeroPreAtendimento(final String parNumeroPreAtendimento) {
		numeroPreAtendimento = parNumeroPreAtendimento;
	}

	public String getTipoAtendimento() {
		return tipoAtendimento;
	}

	public void setTipoAtendimento(final String parTipoAtendimento) {
		tipoAtendimento = parTipoAtendimento;
	}

	public String getAtendidos() {
		return atendidos;
	}

	public void setAtendidos(final String parAtendidos) {
		atendidos = parAtendidos;
	}

	public String getToken() {
		return token;
	}

	public void setToken(final String parToken) {
		token = parToken;
	}

	public String getSenhaOrigem() {
		return senhaOrigem;
	}

	public void setSenhaOrigem(final String parSenhaOrigem) {
		senhaOrigem = parSenhaOrigem;
	}

	public String getOrigem() {
		return origem;
	}

	public void setOrigem(final String parOrigem) {
		origem = parOrigem;
	}

	public String getConta() {
		return Conta;
	}

	public void setConta(final String parConta) {
		Conta = parConta;
	}

}
