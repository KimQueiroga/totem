package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Pergunta implements Serializable, Comparable<Pergunta> {

	private String codigo;
	private String descricao;
	private String faixaEtaria;
	private String genero;
	private String inviolavel;
	private String obrigatorio;
	private Integer ordem;
	private String permiteConsolidacao;
	private String tipoResposta;
	private String usoAreaTecnica;
	private String usoAtendimento;
	private String usoLaudo;
	private String gabarito;
	private String formato;
	private String violavelComTermo;

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(final String parCodigo) {
		codigo = parCodigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(final String parDescricao) {
		descricao = parDescricao;
	}

	public Integer getOrdem() {
		return ordem;
	}

	public void setOrdem(final Integer parOrdem) {
		ordem = parOrdem;
	}

	public String getGabarito() {
		return gabarito;
	}

	public void setGabarito(final String parGabarito) {
		gabarito = parGabarito;
	}

	public String getTipoResposta() {
		return tipoResposta;
	}

	public void setTipoResposta(final String parTipoResposta) {
		tipoResposta = parTipoResposta;
	}

	public String getFormato() {
		return formato;
	}

	public void setFormato(final String parFormato) {
		formato = parFormato;
	}

	public String getGenero() {
		return genero;
	}

	public void setGenero(final String parGenero) {
		genero = parGenero;
	}

	public String getFaixaEtaria() {
		return faixaEtaria;
	}

	public void setFaixaEtaria(final String parFaixaEtaria) {
		faixaEtaria = parFaixaEtaria;
	}

	public String getInviolavel() {
		return inviolavel;
	}

	public void setInviolavel(final String parInviolavel) {
		inviolavel = parInviolavel;
	}

	public String getViolavelComTermo() {
		return violavelComTermo;
	}

	public void setViolavelComTermo(final String parViolavelComTermo) {
		violavelComTermo = parViolavelComTermo;
	}

	public String getObrigatorio() {
		return obrigatorio;
	}

	public void setObrigatorio(final String parObrigatorio) {
		obrigatorio = parObrigatorio;
	}

	public String getUsoAreaTecnica() {
		return usoAreaTecnica;
	}

	public void setUsoAreaTecnica(final String parUsoAreaTecnica) {
		usoAreaTecnica = parUsoAreaTecnica;
	}

	public String getUsoAtendimento() {
		return usoAtendimento;
	}

	public void setUsoAtendimento(final String parUsoAtendimento) {
		usoAtendimento = parUsoAtendimento;
	}

	public String getPermiteConsolidacao() {
		return permiteConsolidacao;
	}

	public void setPermiteConsolidacao(final String parPermiteConsolidacao) {
		permiteConsolidacao = parPermiteConsolidacao;
	}

	public String getUsoLaudo() {
		return usoLaudo;
	}

	public void setUsoLaudo(final String parUsoLaudo) {
		usoLaudo = parUsoLaudo;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (codigo == null ? 0 : codigo.hashCode());
		return result;
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final Pergunta other = (Pergunta) obj;
		if (codigo == null) {
			if (other.codigo != null) {
				return false;
			}
		} else if (!codigo.equals(other.codigo)) {
			return false;
		}
		return true;
	}

	@Override
	public int compareTo(final Pergunta parPergunta) {
		if (getOrdem() < parPergunta.getOrdem()) {
			return -1;
		}
		if (getOrdem() > parPergunta.getOrdem()) {
			return 1;
		}
		return 0;
	}

	public boolean isPermiteConsolidacao() {
		return permiteConsolidacao.equals("S");
	}

}
