package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.gson.annotations.Expose;

import br.com.hermespardini.passelivre.constantsenum.Constantes;

public class ParametroConsultaCliente implements Serializable {
	@Expose
	private String authKey;
	@Expose
	private String birthDate;
	@Expose
	private String authKeyType;
	@Expose
	private String token;
	@Expose
	private String origem;
	@Expose
	private String name;
	@Expose
	private String nameMother;
	@Expose
	private String senhaOrigem;
	@Expose
	private String zipCode;
	@Expose
	private String pedido;
	@Expose
	private String unidade;
	@JsonIgnore
	private String cpf;
	@JsonIgnore
	private String codigo;

	public ParametroConsultaCliente() {
	}

	public ParametroConsultaCliente(final TokenResult parTokenResult,
			final ParametroConsultaCliente parParametroConsultaCliente) {
		authKey = parParametroConsultaCliente.getAuthKey();
		birthDate = parParametroConsultaCliente.getBirthDate();
		authKeyType = Constantes.AUTH_KEY_TYPE_CPF;
		token = parTokenResult.getToken();
		origem = Constantes.ORIGEM_PADRAO;
		name = parParametroConsultaCliente.getName();
		nameMother = parParametroConsultaCliente.getNameMother();
		senhaOrigem = parParametroConsultaCliente.getSenhaOrigem();
		zipCode = parParametroConsultaCliente.getZipCode();
		cpf = parParametroConsultaCliente.getCpf();
		codigo = parParametroConsultaCliente.getCodigo();
		pedido = parParametroConsultaCliente.getPedido();
		unidade = parParametroConsultaCliente.getUnidade();
	}

	public String getAuthKey() {
		return authKey;
	}

	public void setAuthKey(final String parAuthKey) {
		authKey = parAuthKey;
	}

	public String getName() {
		return name;
	}

	public void setName(final String parName) {
		name = parName;
	}

	public String getNameMother() {
		return nameMother;
	}

	public void setNameMother(final String parNameMother) {
		nameMother = parNameMother;
	}

	public String getSenhaOrigem() {
		return senhaOrigem;
	}

	public void setSenhaOrigem(final String parSenhaOrigem) {
		senhaOrigem = parSenhaOrigem;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(final String parZipCode) {
		zipCode = parZipCode;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(final String parCpf) {
		cpf = parCpf;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(final String parCodigo) {
		codigo = parCodigo;
	}

	public String getAuthKeyType() {
		return authKeyType;
	}

	public void setAuthKeyType(final String parAuthKeyType) {
		authKeyType = parAuthKeyType;
	}

	public String getToken() {
		return token;
	}

	public void setToken(final String parToken) {
		token = parToken;
	}

	public String getOrigem() {
		return origem;
	}

	public void setOrigem(final String parOrigem) {
		origem = parOrigem;
	}

	public String getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(final String parBirthDate) {
		birthDate = parBirthDate;
	}

	public String getPedido() {
		return pedido;
	}

	public void setPedido(final String parPedido) {
		pedido = parPedido;
	}

	public String getUnidade() {
		return unidade;
	}

	public void setUnidade(final String parUnidade) {
		unidade = parUnidade;
	}

}
