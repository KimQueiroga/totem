package br.com.hermespardini.passelivre.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@SuppressWarnings("serial")
public class ExamesResultadosPedido extends ArrayList<ExameResultadoPedido> {
	public ExamesResultadosPedido() {
		super();
	}

	public ExamesResultadosPedido(final Collection<? extends ExameResultadoPedido> parExames) {
		super(parExames);
	}

	public final List<ExameResultadoPedido> getExamesResultadosPedido() {
		return this;
	}

	public final void setExamesResultadosPedido(final List<ExameResultadoPedido> parExames) {
		this.addAll(parExames);
	}
}
