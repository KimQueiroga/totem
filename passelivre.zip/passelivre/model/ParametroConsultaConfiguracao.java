package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

import br.com.hermespardini.passelivre.constantsenum.Constantes;

@SuppressWarnings("serial")
public class ParametroConsultaConfiguracao implements Serializable {

	private String empresa;
	private String unidade;
	private String totem;
	private String ip;
	private String token;
	private String origem;

	public ParametroConsultaConfiguracao(final ParametroConsultaConfiguracao parParametrosConsultaConfiguracao,
			final TokenResult parTokenResult) {
		token = parTokenResult.getToken();
		unidade = parParametrosConsultaConfiguracao.getUnidade();
		origem = Constantes.ORIGEM_PADRAO;
		ip = parParametrosConsultaConfiguracao.getIp();
	}

	public ParametroConsultaConfiguracao() {

	}

	public ParametroConsultaConfiguracao(final String parRetornarNomeDaMaquina, final TokenResult parTokenResult) {
		ip = parRetornarNomeDaMaquina;
		token = parTokenResult.getToken();
		origem = Constantes.ORIGEM_PADRAO;
	}

	public ParametroConsultaConfiguracao(final String parRetornarNomeDaMaquina, final TokenResult parTokenResult,
			final String tipo) {
		ip = parRetornarNomeDaMaquina;
		token = parTokenResult.getToken();
		origem = Constantes.ORIGEM_DESKTOP;
	}

	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(final String parEmpresa) {
		empresa = parEmpresa;
	}

	public String getUnidade() {
		return unidade;
	}

	public void setUnidade(final String parUnidade) {
		unidade = parUnidade;
	}

	public String getTotem() {
		return totem;
	}

	public void setTotem(final String parTotem) {
		totem = parTotem;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(final String parIp) {
		ip = parIp;
	}

	public String getToken() {
		return token;
	}

	public void setToken(final String parToken) {
		token = parToken;
	}

	public String getOrigem() {
		return origem;
	}

	public void setOrigem(final String parOrigem) {
		origem = parOrigem;
	}

}
