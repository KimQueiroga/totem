package br.com.hermespardini.passelivre.model;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;

public class ParametroAgendamentoCliente {
	private Date dataInicial; // olhar data
	private Date dataFinal; // olhar data
	private String codigoCliente;
	private String cpfCliente;
	private String nomeCliente;
	private String dataNascimentoCliente;
	private String tipoServico;
	private String token; // olhar se é pra passar isso mesmo por list (acho que nao)
	private String origem;
	// private String senhaOrigem;
	private String unidade;

	public ParametroAgendamentoCliente() {
	}

	public ParametroAgendamentoCliente(final TokenResult parTokenResult,
			final ClienteUnidadePasseLivre parParametroConsultaCliente) throws RegraNegocioException {
		dataInicial = java.sql.Date.valueOf(LocalDate.now(ZoneId.systemDefault()));
		;
		dataFinal = java.sql.Date.valueOf(LocalDate.now(ZoneId.systemDefault()));
		;
		codigoCliente = parParametroConsultaCliente.getCodigoCliente();
		tipoServico = ""; // Passar ou não passa? Olhar com breno e john
		token = parTokenResult.getToken();
		origem = Constantes.ORIGEM_DESKTOP; // Quando for fazer para o totem (sem ser desktop) colocar a
											// var do totem e nao do desk
		// senhaOrigem = Constantes.SENHA_TOKEN_DESK; //Quando for fazer para o totem
		// (sem ser desktop)
		// colocar a var do totem e nao do desk
		unidade = parParametroConsultaCliente.getUnidade();
	}

	public String getDataNascimentoCliente() {
		return dataNascimentoCliente;
	}

	public void setDataNascimentoCliente(final String parDataNascimentoCliente) {
		dataNascimentoCliente = parDataNascimentoCliente;
	}

	public String getUnidade() {
		return unidade;
	}

	public void setUnidade(final String parUnidade) {
		unidade = parUnidade;
	}

	public Date getDataInicial() {
		return dataInicial;
	}

	public void setDataInicial(final Date parDataInicial) {
		dataInicial = parDataInicial;
	}

	public Date getDataFinal() {
		return dataFinal;
	}

	public void setDataFinal(final Date parDataFinal) {
		dataFinal = parDataFinal;
	}

	public String getToken() {
		return token;
	}

	public void setToken(final String parToken) {
		token = parToken;
	}

	public String getCodigoCliente() {
		return codigoCliente;
	}

	public void setCodigoCliente(final String parCodigoCliente) {
		codigoCliente = parCodigoCliente;
	}

	public String getCpfCliente() {
		return cpfCliente;
	}

	public void setCpfCliente(final String parCpfCliente) {
		cpfCliente = parCpfCliente;
	}

	public String getNomeCliente() {
		return nomeCliente;
	}

	public void setNomeCliente(final String parNomeCliente) {
		nomeCliente = parNomeCliente;
	}

	public String getTipoServico() {
		return tipoServico;
	}

	public void setTipoServico(final String parTipoServico) {
		tipoServico = parTipoServico;
	}

	/*
	 * public String getSenhaOrigem() { return this.senhaOrigem; } public void
	 * setSenhaOrigem(String parSenhaOrigem) { this.senhaOrigem = parSenhaOrigem; }
	 */
	public String getOrigem() {
		return origem;
	}

	public void setOrigem(final String parOrigem) {
		origem = parOrigem;
	}
}
