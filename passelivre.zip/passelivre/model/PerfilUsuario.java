package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

public class PerfilUsuario implements Serializable {
	private Long id;
	private Long idAplicacao;
	private Long idPerfil;
	private Long idUsuario;
	private Long idEmpresa;
	private String siglaUsuario;
	private String siglaAplicacao;
	private String nomePerfil;
	private String nomeAplicacao;
	private String nomeUsuario;
	private String ativo;
	private String descricaoPerfil;
	private String tipoPerfil;
	private String descricaoEmpresa;

	public Long getId() {
		return id;
	}

	public void setId(final Long parId) {
		id = parId;
	}

	public Long getIdAplicacao() {
		return idAplicacao;
	}

	public void setIdAplicacao(final Long parIdAplicacao) {
		idAplicacao = parIdAplicacao;
	}

	public Long getIdPerfil() {
		return idPerfil;
	}

	public void setIdPerfil(final Long parIdPerfil) {
		idPerfil = parIdPerfil;
	}

	public Long getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(final Long parIdUsuario) {
		idUsuario = parIdUsuario;
	}

	public Long getIdEmpresa() {
		return idEmpresa;
	}

	public void setIdEmpresa(final Long parIdEmpresa) {
		idEmpresa = parIdEmpresa;
	}

	public String getSiglaUsuario() {
		return siglaUsuario;
	}

	public void setSiglaUsuario(final String parSiglaUsuario) {
		siglaUsuario = parSiglaUsuario;
	}

	public String getSiglaAplicacao() {
		return siglaAplicacao;
	}

	public void setSiglaAplicacao(final String parSiglaAplicacao) {
		siglaAplicacao = parSiglaAplicacao;
	}

	public String getNomePerfil() {
		return nomePerfil;
	}

	public void setNomePerfil(final String parNomePerfil) {
		nomePerfil = parNomePerfil;
	}

	public String getNomeAplicacao() {
		return nomeAplicacao;
	}

	public void setNomeAplicacao(final String parNomeAplicacao) {
		nomeAplicacao = parNomeAplicacao;
	}

	public String getNomeUsuario() {
		return nomeUsuario;
	}

	public void setNomeUsuario(final String parNomeUsuario) {
		nomeUsuario = parNomeUsuario;
	}

	public String getAtivo() {
		return ativo;
	}

	public void setAtivo(final String parAtivo) {
		ativo = parAtivo;
	}

	public String getDescricaoPerfil() {
		return descricaoPerfil;
	}

	public void setDescricaoPerfil(final String parDescricaoPerfil) {
		descricaoPerfil = parDescricaoPerfil;
	}

	public String getTipoPerfil() {
		return tipoPerfil;
	}

	public void setTipoPerfil(final String parTipoPerfil) {
		tipoPerfil = parTipoPerfil;
	}

	public String getDescricaoEmpresa() {
		return descricaoEmpresa;
	}

	public void setDescricaoEmpresa(final String parDescricaoEmpresa) {
		descricaoEmpresa = parDescricaoEmpresa;
	}

}
