package br.com.hermespardini.passelivre.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@SuppressWarnings("serial")
public class Pedidos extends ArrayList<Pedido> {
	public Pedidos() {
		super();
	}

	public Pedidos(final Collection<? extends Pedido> parPedidos) {
		super(parPedidos);
	}

	public final List<Pedido> getPedidos() {
		return this;
	}

	public final void setPedidos(final List<Pedido> parPedidos) {
		this.addAll(parPedidos);
	}
}
