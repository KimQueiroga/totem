package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.google.gson.annotations.SerializedName;
import com.owlike.genson.annotation.JsonIgnore;

@SuppressWarnings("serial")
public class ExameHermesPardini implements Serializable {

	private String exame;
	private String departamento;
	private String descricaoExame;
	private String descricaoMaterial;
	private String examePacote;
	@JsonIgnore
	private String materialPAI;
	@JsonIgnore
	private String examePAI;
	private Integer utilizado;
	private String material;

	private Integer ePacote;
	private List<ExameHermesPardini> composicaoPacote;
	private Date dataHoraMarcacao;

	@SerializedName("default")
	private Integer valueDefault;
	@JsonIgnore
	private String observacao;
	@JsonIgnore
	private String condicaoAmostra;

	private String corConservante;
	private String nomeConservante;
	private Long idConservante;
	
	private String mnemonicoConcat;
	private String situacao;

	public ExameHermesPardini(final String parDescricaoExame) {
		descricaoExame = parDescricaoExame;
		valueDefault = 0;
	}
	
	/*
	 * O array é obrigatório ter o tamanho de 5
	 */
	public ExameHermesPardini(final String[] parDadosExameHP) {
		this.descricaoExame = parDadosExameHP[0];
		this.valueDefault = 0;
		this.ePacote = Integer.valueOf(parDadosExameHP[1]);
		this.exame = parDadosExameHP[2];
		this.material = parDadosExameHP[3];
		this.descricaoMaterial = parDadosExameHP[4];
	}

	@Override
	public String toString() {
		String complemento = ("S").equals(situacao) ? "SUSP* ": "";
		if (getDescricaoMaterial() == null) {
			return complemento + getDescricaoExame();
		} else {
			return complemento + getMaterial() + "/" + getExame() + " - " + getDescricaoExame() + " - " + getDescricaoMaterial();
		}
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (exame == null ? 0 : exame.hashCode());
		result = prime * result + (material == null ? 0 : material.hashCode());
		return result;
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final ExameHermesPardini other = (ExameHermesPardini) obj;
		if (exame == null) {
			if (other.exame != null) {
				return false;
			}
		} else if (!exame.equals(other.exame)) {
			return false;
		}
		if (material == null) {
			if (other.material != null) {
				return false;
			}
		} else if (!material.equals(other.material)) {
			return false;
		}
		return true;
	}

	public String getExame() {
		return exame;
	}

	public void setExame(final String parExame) {
		exame = parExame;
	}

	public String getDepartamento() {
		return departamento;
	}

	public void setDepartamento(final String parDepartamento) {
		departamento = parDepartamento;
	}

	public String getDescricaoExame() {
		return descricaoExame;
	}

	public void setDescricaoExame(final String parDescricaoExame) {
		descricaoExame = parDescricaoExame;
	}

	public String getDescricaoMaterial() {
		return descricaoMaterial;
	}

	public void setDescricaoMaterial(final String parDescricaoMaterial) {
		descricaoMaterial = parDescricaoMaterial;
	}

	public String getExamePacote() {
		return examePacote;
	}

	public void setExamePacote(final String parExamePacote) {
		examePacote = parExamePacote;
	}

	public String getMaterialPAI() {
		return materialPAI;
	}

	public void setMaterialPAI(final String parMaterialPAI) {
		materialPAI = parMaterialPAI;
	}

	public String getExamePAI() {
		return examePAI;
	}

	public void setExamePAI(final String parExamePAI) {
		examePAI = parExamePAI;
	}

	public Integer getUtilizado() {
		return utilizado;
	}

	public void setUtilizado(final Integer parUtilizado) {
		utilizado = parUtilizado;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(final String parMaterial) {
		material = parMaterial;
	}

	public Integer getEPacote() {
		return ePacote;
	}

	public void setEPacote(final Integer parEPacote) {
		ePacote = parEPacote;
	}

	public List<ExameHermesPardini> getComposicaoPacote() {
		return composicaoPacote;
	}

	public void setComposicaoPacote(final List<ExameHermesPardini> parComposicaoPacote) {
		composicaoPacote = parComposicaoPacote;
	}

	public Date getDataHoraMarcacao() {
		return dataHoraMarcacao;
	}

	public void setDataHoraMarcacao(final Date parDataHoraMarcacao) {
		dataHoraMarcacao = parDataHoraMarcacao;
	}

	public Integer getValueDefault() {
		return valueDefault;
	}

	public void setValueDefault(final Integer parValueDefault) {
		valueDefault = parValueDefault;
	}

	public String getObservacao() {
		return observacao;
	}

	public void setObservacao(final String parObservacao) {
		observacao = parObservacao;
	}

	public String getCondicaoAmostra() {
		return condicaoAmostra;
	}

	public void setCondicaoAmostra(final String parCondicaoAmostra) {
		condicaoAmostra = parCondicaoAmostra;
	}

	public String getCorConservante() {
		return corConservante;
	}

	public void setCorConservante(String corConservante) {
		this.corConservante = corConservante;
	}
	
	public String getNomeConservante() {
		return nomeConservante;
	}

	public void setNomeConservante(String nomeConservante) {
		this.nomeConservante = nomeConservante;
	}


	public Long getIdConservante() {
		return idConservante;
	}

	public void setIdConservante(Long idConservante) {
		this.idConservante = idConservante;
	}
	
	public String getMnemonicoConcat() {
		this.mnemonicoConcat = this.material + "/" + this.exame; 
		return this.mnemonicoConcat;
	}

	public String getSituacao() {
		return situacao;
	}

	public void setSituacao(String situacao) {
		this.situacao = situacao;
	}
}
