package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.util.List;

import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.exception.RegraParaExameJaAdicionadoException;

public class DetalhePreparacao implements Serializable {
  private String id;
  private String testName;
  private String testId;
  private String material;
  private String materialId;
  private String fastingTime;
  private String instructions;
  private String privatePrice;
  private String scheduleTime;
  private String scheduleNeeded;
  private String units;
  
  public DetalhePreparacao() {}

  public DetalhePreparacao(ConsultaDetalheResult detalhePreparacao) {

    setTestName(detalhePreparacao.getDescricao());
    setId(detalhePreparacao.getExame());

    if (detalhePreparacao.getAtributos() != null) {

      List<Atributos> listAtributos = detalhePreparacao.getAtributos();
      String noTagRegex = "&nbsp;";
      String noTagRegexBr = "<br/>";
      
      for (Atributos atributo : listAtributos) {

        if (atributo.getDescricao().equalsIgnoreCase("Material")) {
          setMaterial(atributo.getValor());
          material = material.replaceAll(noTagRegex, " ");
        } else if (atributo.getDescricao().equalsIgnoreCase("Jejum")) {
          setFastingTime(atributo.getValor());
          fastingTime = fastingTime.replaceAll(noTagRegex, " ");
        } else if (atributo.getDescricao().equalsIgnoreCase("Lojas que disponibilizam o serviço")) {
          setUnits(atributo.getValor()); 
          units = units.replaceAll(noTagRegex, " ");
          units = units.replaceAll(noTagRegexBr, "\n");
        } else if (atributo.getDescricao().equalsIgnoreCase("Marcação")) {
          setScheduleTime(atributo.getValor());
          scheduleTime = scheduleTime.replaceAll(noTagRegex, " ");
        } else if (atributo.getDescricao().equalsIgnoreCase("Preço particular")) {
          setPrivatePrice(atributo.getValor());
          privatePrice = privatePrice.replaceAll(noTagRegex, " ");
        } else if (atributo.getDescricao().equalsIgnoreCase("Instruções")) {
          setInstructions(atributo.getValor());
          instructions = instructions.replaceAll(noTagRegex, " ");
          instructions = instructions.replaceAll(noTagRegexBr, "\n");
        }
      }
    }
  }

  public String getId() {
    return id;
  }

  public void setId(final String parId) {
    id = parId;
  }

  public String getTestName() {
    return testName;
  }

  public void setTestName(final String parTestName) {
    testName = parTestName;
  }

  public String getTestId() {
    return testId;
  }

  public void setTestId(final String parTestId) {
    testId = parTestId;
  }

  public String getMaterial() {
    return material;
  }

  public void setMaterial(final String parMaterial) {
    material = parMaterial;
  }

  public String getMaterialId() {
    return materialId;
  }

  public void setMaterialId(final String parMaterialId) {
    materialId = parMaterialId;
  }

  public String getFastingTime() {
    return fastingTime;
  }

  public void setFastingTime(final String parFastingTime) {
    fastingTime = parFastingTime;
  }

  public String getInstructions() {
    return instructions;
  }

  public void setInstructions(final String parInstructions) {
    instructions = parInstructions;
  }

  public String getPrivatePrice() {
    return privatePrice;
  }

  public void setPrivatePrice(final String parPrivatePrice) {
    privatePrice = parPrivatePrice;
  }

  public String getScheduleTime() {
    return scheduleTime;
  }

  public void setScheduleTime(final String parScheduleTime) {
    scheduleTime = parScheduleTime;
  }

  public String getScheduleNeeded() {
    return scheduleNeeded;
  }

  public void setScheduleNeeded(final String parScheduleNeeded) {
    scheduleNeeded = parScheduleNeeded;
  }

  public String getUnits() {
    return units;
  }

  public void setUnits(final String parUnits) {
    units = parUnits;
  }

  @Override
  public String toString() {
    return "Id = " + testId + " nome = " + testName;
  }

  public void verificarCamposEmBrancoAoVerHelp() throws RegraNegocioException {
    verificarSePrecoEstaVazio();
    verificarSeMaterialEstaVazio();
    verificarSeNomeEstaVazio();
    verificarSeInstrucaoEstaVazio();
    verificarSeUnidadeEstaVazio();
  }

  private void verificarSeUnidadeEstaVazio() throws RegraNegocioException {
    if (units == null || units.isEmpty()) {
      throw new RegraNegocioException("Campo unidade está vazio!");
    }
  }

  private void verificarSeInstrucaoEstaVazio() throws RegraNegocioException {
    if (instructions == null || instructions.isEmpty()) {
      throw new RegraNegocioException("Campo instrução está vazio!");
    }
  }

  public void verificarCamposEmBrancoAoFazerOrcamento() throws RegraNegocioException {
    verificarSePrecoEstaVazio();
    verificarSeMaterialEstaVazio();
    verificarSeNomeEstaVazio();
  }

  private void verificarSeNomeEstaVazio() throws RegraNegocioException {
    if (testName == null || testName.isEmpty()) {
      throw new RegraNegocioException("Campo nome está vazio!");
    }
    else {
      String noTagRegex = "&nbsp;";
      testName = testName.replaceAll(noTagRegex, " ");
    }
  }

  private void verificarSeMaterialEstaVazio() throws RegraNegocioException {
    if (material == null || material.isEmpty()) {
      throw new RegraNegocioException("Campo material está vazio!");
    }
  }

  private void verificarSePrecoEstaVazio() throws RegraNegocioException {
    if (privatePrice == null || privatePrice.isEmpty() || privatePrice.equals("R$ 0,00")) {
      throw new RegraNegocioException("Não é possível adicionar o item, pois o campo preço está vazio!");
    }
  }

  public void verificarSeExameFoiAdicionado(final List<DetalhePreparacao> parDetalhesPreparacoes)
      throws RegraParaExameJaAdicionadoException {
    if (parDetalhesPreparacoes.contains(this)) {
      throw new RegraParaExameJaAdicionadoException("Exame já foi adicionado!");
    }
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + (materialId == null ? 0 : materialId.hashCode());
    result = prime * result + (testId == null ? 0 : testId.hashCode());
    return result;
  }

  @Override
  public boolean equals(final Object obj) {
    if (this == obj) {
      return true;
    }
    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    final DetalhePreparacao other = (DetalhePreparacao) obj;
    if (materialId == null) {
      if (other.materialId != null) {
        return false;
      }
    } else if (!materialId.equals(other.materialId)) {
      return false;
    }
    if (testId == null) {
      if (other.testId != null) {
        return false;
      }
    } else if (!testId.equals(other.testId)) {
      return false;
    }
    return true;
  }

}
