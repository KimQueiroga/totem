package br.com.hermespardini.passelivre.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@SuppressWarnings("serial")
public class ExamesPedidos extends ArrayList<ExamePedido> {

	public ExamesPedidos() {
		super();
	}

	public ExamesPedidos(final Collection<? extends ExamePedido> parExames) {
		super(parExames);
	}

	public final List<ExamePedido> getExamesPedidos() {
		return this;
	}

	public final void setExamesPedidos(final List<ExamePedido> parExames) {
		this.addAll(parExames);
	}

}
