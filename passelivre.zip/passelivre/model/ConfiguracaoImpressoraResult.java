package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

public class ConfiguracaoImpressoraResult implements Serializable {

	private String ip;
	private String mensagem;
	private String modelo;
	private String nome;
	private Integer porta;
	private String status;

	public String getIp() {
		return ip;
	}

	public void setIp(final String parIp) {
		ip = parIp;
	}

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(final String parMensagem) {
		mensagem = parMensagem;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(final String parModelo) {
		modelo = parModelo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(final String parNome) {
		nome = parNome;
	}

	public Integer getPorta() {
		return porta;
	}

	public void setPorta(final Integer parPorta) {
		porta = parPorta;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(final String parStatus) {
		status = parStatus;
	}

}
