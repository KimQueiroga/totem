package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

@SuppressWarnings("serial")
public class ConsultaMaterialPendenteResult implements Serializable {

	private String mensagem;
	private String status;
	private Pedidos pedidos;

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(final String parMensagem) {
		mensagem = parMensagem;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(final String parStatus) {
		status = parStatus;
	}

	public Pedidos getPedidos() {
		return pedidos;
	}

	public void setPedidos(final Pedidos parPedidos) {
		pedidos = parPedidos;
	}

}
