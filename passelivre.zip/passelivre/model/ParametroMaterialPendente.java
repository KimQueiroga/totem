package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

import org.wdelmaschio.base.model.ValueObject;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.utils.TotemUtil;

@SuppressWarnings("serial")
public class ParametroMaterialPendente extends ValueObject implements Serializable {

	private String empresa;
	private String pedido;
	private String codigocliente;
	private String cpf;
	private String exibirrecoleta;
	private String unidade;
	private String origem;
	private String datanascimento;
	private String token;

	public ParametroMaterialPendente(final ClienteUnidadePasseLivre parClienteUnidadePasseLivre,
			final TokenResult parTokenResult) {
		codigocliente = parClienteUnidadePasseLivre.getCodigoCliente();
		cpf = parClienteUnidadePasseLivre.getCpf();
		datanascimento = "";
		// empresa = TotemUtil.buscarSiglaEmpresa();
		empresa = Constantes.EMPRESA;
		exibirrecoleta = Constantes.SIM;
		token = parTokenResult.getToken();
		origem = Constantes.ORIGEM_PADRAO;
	}

	public ParametroMaterialPendente(final String parPedido, final TokenResult parTokenResult) {
		unidade = parPedido.substring(2, 5).startsWith("0") ? parPedido.substring(3, 5) : parPedido.substring(2, 5);
		pedido = parPedido.substring(5, 12);
		datanascimento = "";
		empresa = Constantes.EMPRESA;
		// empresa = TotemUtil.buscarSiglaEmpresa();
		exibirrecoleta = Constantes.SIM;
		token = parTokenResult.getToken();
		origem = Constantes.ORIGEM_PADRAO;
	}

	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(final String parEmpresa) {
		empresa = parEmpresa;
	}

	public String getPedido() {
		return pedido;
	}

	public void setPedido(final String parPedido) {
		pedido = parPedido;
	}

	public String getCodigocliente() {
		return codigocliente;
	}

	public void setCodigocliente(final String parCodigocliente) {
		codigocliente = parCodigocliente;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(final String parCpf) {
		cpf = parCpf;
	}

	public String getExibirrecoleta() {
		return exibirrecoleta;
	}

	public void setExibirrecoleta(final String parExibirrecoleta) {
		exibirrecoleta = parExibirrecoleta;
	}

	public String getUnidade() {
		return unidade;
	}

	public void setUnidade(final String parUnidade) {
		unidade = parUnidade;
	}

	public String getOrigem() {
		return origem;
	}

	public void setOrigem(final String parOrigem) {
		origem = parOrigem;
	}

	public String getDatanascimento() {
		return datanascimento;
	}

	public void setDatanascimento(final String parDatanascimento) {
		datanascimento = parDatanascimento;
	}

	public String getToken() {
		return token;
	}

	public void setToken(final String parToken) {
		token = parToken;
	}

}
