package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

public class UnimedBH implements Serializable {

	private String codigoPrestadorUnimed;
	private Long unbh;

	public String getCodigoPrestadorUnimed() {
		return codigoPrestadorUnimed;
	}

	public void setCodigoPrestadorUnimed(final String parCodigoPrestadorUnimed) {
		codigoPrestadorUnimed = parCodigoPrestadorUnimed;
	}

	public Long getUnbh() {
		return unbh;
	}

	public void setUnbh(final Long parUnbh) {
		unbh = parUnbh;
	}

}
