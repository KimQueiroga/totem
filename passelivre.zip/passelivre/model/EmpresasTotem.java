package br.com.hermespardini.passelivre.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class EmpresasTotem extends ArrayList<EmpresaTotem> {
	public EmpresasTotem() {
		super();
	}

	public EmpresasTotem(final Collection<? extends EmpresaTotem> parEmpresas) {
		super(parEmpresas);
	}

	public final List<EmpresaTotem> getEmpresasTotem() {
		return this;
	}

	public final void setEmpresasTotem(final List<EmpresaTotem> parEmpresas) {
		this.addAll(parEmpresas);
	}

}
