package br.com.hermespardini.passelivre.model;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.utils.TotemUtil;

public class ParametroRegistraCliente {

	private String codigo;
	private String nomeCompleto;
	private String genero;
	private String cpf;
	private String dataNascimento;
	private String email;
	private String novaSenha;
	private String celular;
	private String telefone;
	private String uf;
	private String cidade;
	private String bairro;
	private String cep;
	private String logradouro;
	private String numeroLogradouro;
	private String complementoLogradouro;
	private String nomeMae;
	private String nomePai;
	private String nomeResponsavel;
	private String tipoDocumentoIdentificacao;
	private String nroDocumentoIdentificacao;
	private String estadoCivil;
	private String nacionalidade;
	private String estrangeiro;
	private String usuarioAlteracao;
	private String notificaViaEmail;
	private String origem;
	private String token;

	public ParametroRegistraCliente(ClienteUnidadePasseLivre parCLiClienteUnidadePasseLivre) {
		codigo = parCLiClienteUnidadePasseLivre.getCodigoCliente();
		nomeCompleto = parCLiClienteUnidadePasseLivre.getNomeCliente();
		genero = parCLiClienteUnidadePasseLivre.getSexo();
		cpf = parCLiClienteUnidadePasseLivre.getCpf();
		dataNascimento = parCLiClienteUnidadePasseLivre.getDataNascimento();
		email = parCLiClienteUnidadePasseLivre.getEmail();
		novaSenha = parCLiClienteUnidadePasseLivre.getNewPass();
		celular = parCLiClienteUnidadePasseLivre.getCelular();
		telefone = parCLiClienteUnidadePasseLivre.getTelefone();
		uf = parCLiClienteUnidadePasseLivre.getUf();
		cidade = parCLiClienteUnidadePasseLivre.getCidade();
		bairro = parCLiClienteUnidadePasseLivre.getBairro();
		cep = parCLiClienteUnidadePasseLivre.getCep();
		logradouro = parCLiClienteUnidadePasseLivre.getLogradouro();
		numeroLogradouro = parCLiClienteUnidadePasseLivre.getNumero();
		complementoLogradouro = parCLiClienteUnidadePasseLivre.getComplemento();
		nomeMae = parCLiClienteUnidadePasseLivre.getNomeMae();
		estadoCivil = parCLiClienteUnidadePasseLivre.getEstadoCivil();
		nacionalidade = parCLiClienteUnidadePasseLivre.getNacionalidade();
		usuarioAlteracao = Constantes.USUARIO_PADRAO;
		origem = Constantes.ORIGEM_PADRAO;
		token = TotemUtil.buscarToken().getToken();
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getNomeCompleto() {
		return nomeCompleto;
	}

	public void setNomeCompleto(String nomeCompleto) {
		this.nomeCompleto = nomeCompleto;
	}

	public String getGenero() {
		return genero;
	}

	public void setGenero(String genero) {
		this.genero = genero;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getDataNascimento() {
		return dataNascimento;
	}

	public void setDataNascimento(String dataNascimento) {
		this.dataNascimento = dataNascimento;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCelular() {
		return celular;
	}

	public void setCelular(String celular) {
		this.celular = celular;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getLogradouro() {
		return logradouro;
	}

	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}

	public String getNumeroLogradouro() {
		return numeroLogradouro;
	}

	public void setNumeroLogradouro(String numeroLogradouro) {
		this.numeroLogradouro = numeroLogradouro;
	}

	public String getComplementoLogradouro() {
		return complementoLogradouro;
	}

	public void setComplementoLogradouro(String complementoLogradouro) {
		this.complementoLogradouro = complementoLogradouro;
	}

	public String getNomeMae() {
		return nomeMae;
	}

	public void setNomeMae(String nomeMae) {
		this.nomeMae = nomeMae;
	}

	public String getNomePai() {
		return nomePai;
	}

	public void setNomePai(String nomePai) {
		this.nomePai = nomePai;
	}

	public String getNomeResponsavel() {
		return nomeResponsavel;
	}

	public void setNomeResponsavel(String nomeResponsavel) {
		this.nomeResponsavel = nomeResponsavel;
	}

	public String getTipoDocumentoIdentificacao() {
		return tipoDocumentoIdentificacao;
	}

	public void setTipoDocumentoIdentificacao(String tipoDocumentoIdentificacao) {
		this.tipoDocumentoIdentificacao = tipoDocumentoIdentificacao;
	}

	public String getNroDocumentoIdentificacao() {
		return nroDocumentoIdentificacao;
	}

	public void setNroDocumentoIdentificacao(String nroDocumentoIdentificacao) {
		this.nroDocumentoIdentificacao = nroDocumentoIdentificacao;
	}

	public String getEstadoCivil() {
		return estadoCivil;
	}

	public void setEstadoCivil(String estadoCivil) {
		this.estadoCivil = estadoCivil;
	}

	public String getNacionalidade() {
		return nacionalidade;
	}

	public void setNacionalidade(String nacionalidade) {
		this.nacionalidade = nacionalidade;
	}

	public String getEstrangeiro() {
		return estrangeiro;
	}

	public void setEstrangeiro(String estrangeiro) {
		this.estrangeiro = estrangeiro;
	}

	public String getUsuarioAlteracao() {
		return usuarioAlteracao;
	}

	public void setUsuarioAlteracao(String usuarioAlteracao) {
		this.usuarioAlteracao = usuarioAlteracao;
	}

	public String getNotificaViaEmail() {
		return notificaViaEmail;
	}

	public void setNotificaViaEmail(String notificaViaEmail) {
		this.notificaViaEmail = notificaViaEmail;
	}

	public String getOrigem() {
		return origem;
	}

	public void setOrigem(String origem) {
		this.origem = origem;
	}
	
	public String getNovaSenha( ) {
		return novaSenha;
	}

}
