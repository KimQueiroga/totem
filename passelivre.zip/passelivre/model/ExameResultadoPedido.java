package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

@SuppressWarnings("serial")
public class ExameResultadoPedido implements Serializable {

	private String dataHoraMarcacao;
	private String descricaoExame;
	private String descricaoMaterial;
	private String exame;
	private String material;
	private Integer sequenciaExame;
	private String examePAI; // TESTE ELLEN MAIA
	private String materialPAI; // TESTE ELLEN MAIA

	public String getMaterialPAI() {
		return this.materialPAI;
	}

	public void setMaterialPAI(String parMaterialPAI) {
		this.materialPAI = parMaterialPAI;
	}

	public String getExamePAI() {
		return this.examePAI;
	}

	public void setExamePAI(String parExamePAI) {
		this.examePAI = parExamePAI;
	}

	public String getDataHoraMarcacao() {
		return dataHoraMarcacao;
	}

	public void setDataHoraMarcacao(final String parDataHoraMarcacao) {
		dataHoraMarcacao = parDataHoraMarcacao;
	}

	public String getDescricaoExame() {
		return descricaoExame;
	}

	public void setDescricaoExame(final String parDescricaoExame) {
		descricaoExame = parDescricaoExame;
	}

	public String getDescricaoMaterial() {
		return descricaoMaterial;
	}

	public void setDescricaoMaterial(final String parDescricaoMaterial) {
		descricaoMaterial = parDescricaoMaterial;
	}

	public String getExame() {
		return exame;
	}

	public void setExame(final String parExame) {
		exame = parExame;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(final String parMaterial) {
		material = parMaterial;
	}

	public Integer getSequenciaExame() {
		return sequenciaExame;
	}

	public void setSequenciaExame(final Integer parSequenciaExame) {
		sequenciaExame = parSequenciaExame;
	}
}
