package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

public class QuestionarioResult implements Serializable {

	private String mensagem;
	private Integer status;

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(final String parMensagem) {
		mensagem = parMensagem;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(final Integer parStatus) {
		status = parStatus;
	}

}
