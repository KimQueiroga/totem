package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.util.List;

import br.com.hermespardini.passelivre.to.ProcedimentoComExamesTO;
import br.com.unimedbh.www.Ct_dadosAutorizacao;

@SuppressWarnings("serial")
public class Guia implements Serializable {

	private String numeroGuiaOperadora;
	private String numeroGuiaPrestador;
	private String data;
	private String cid;
	private Autorizacao autorizacao;
	private ExamesPedidos exames;
	private Solicitante solicitante;

	public Guia(final Ct_dadosAutorizacao parCt_dadosAutorizacao,
			final List<ProcedimentoComExamesTO> parProcedimentosComExamesSelecionados,
			final List<ConsultaQuestionarioExameResult> parQuestionarios, final List<PerguntaEntrega> parPerguntas,
			final InformacaoTotem parInformacaoTotem) {
		numeroGuiaOperadora = parCt_dadosAutorizacao.getIdentificacaoAutorizacao().getNumeroGuiaOperadora();
		numeroGuiaPrestador = parCt_dadosAutorizacao.getIdentificacaoAutorizacao().getNumeroGuiaPrestador();
		data = parCt_dadosAutorizacao.getIdentificacaoAutorizacao().getDataEmissaoGuia();
		autorizacao = new Autorizacao(parCt_dadosAutorizacao);
		exames = new ExamesPedidos();
		for (final ProcedimentoComExamesTO locProcedimento : parProcedimentosComExamesSelecionados) {
			if (locProcedimento.getExame().getEPacote() == 1) {
				exames.add(new ExamePedido(locProcedimento, parQuestionarios, parPerguntas, exames,
						locProcedimento.getExame().getComposicaoPacote(), parCt_dadosAutorizacao, parInformacaoTotem));
			} else {
				exames.add(new ExamePedido(locProcedimento, parQuestionarios, parPerguntas, exames,
						parCt_dadosAutorizacao, parInformacaoTotem));
			}
		}
	}

	public Guia(final Ct_dadosAutorizacao parCt_dadosAutorizacao,
			final List<ProcedimentoComExamesTO> parProcedimentosComExamesSelecionados,
			final List<ConsultaQuestionarioExameResult> parQuestionarios, final List<PerguntaEntrega> parPerguntas) {
		numeroGuiaOperadora = parCt_dadosAutorizacao.getIdentificacaoAutorizacao().getNumeroGuiaOperadora();
		numeroGuiaPrestador = parCt_dadosAutorizacao.getIdentificacaoAutorizacao().getNumeroGuiaPrestador();
		data = parCt_dadosAutorizacao.getIdentificacaoAutorizacao().getDataEmissaoGuia();
		autorizacao = new Autorizacao(parCt_dadosAutorizacao);
		exames = new ExamesPedidos();
		for (final ProcedimentoComExamesTO locProcedimento : parProcedimentosComExamesSelecionados) {
			if (locProcedimento.getExame().getEPacote() == 1) {
				exames.add(new ExamePedido(locProcedimento, parQuestionarios, parPerguntas, exames,
						locProcedimento.getExame().getComposicaoPacote(), parCt_dadosAutorizacao));
			} else {
				exames.add(new ExamePedido(locProcedimento, parQuestionarios, parPerguntas, exames,
						parCt_dadosAutorizacao));
			}
		}
	}

	public static Guia criarGuiaParaCheckup(final DetalhePreparacao detalhePreparacao,
			final EPacoteResult ePacoteResult, final List<ConsultaQuestionarioExameResult> parQuestionarios,
			final List<PerguntaEntrega> parPerguntas) {
		return new Guia(detalhePreparacao, ePacoteResult, parQuestionarios, parPerguntas);
	}

	private Guia(final DetalhePreparacao detalhePreparacao, final EPacoteResult ePacoteResult,
			final List<ConsultaQuestionarioExameResult> parQuestionarios, final List<PerguntaEntrega> parPerguntas) {
		numeroGuiaOperadora = null;
		numeroGuiaPrestador = null;
		data = null;
		autorizacao = null;
		exames = new ExamesPedidos();
		exames.add(ExamePedido.criarExameCheckup(detalhePreparacao, ePacoteResult, parQuestionarios, parPerguntas));
	}

	public Guia(final Guia parGuia, final List<ProcedimentoComExamesTO> parProcedimentosComExamesSelecionados,
			final List<ConsultaQuestionarioExameResult> parQuestionarios, final List<PerguntaEntrega> parPerguntas,
			final Solicitante parSolicitante) {
		numeroGuiaOperadora = parGuia.getNumeroGuiaOperadora();
		numeroGuiaPrestador = parGuia.getNumeroGuiaPrestador();
		data = parGuia.getData();
		autorizacao = parGuia.getAutorizacao();
		exames = new ExamesPedidos();
		for (final ProcedimentoComExamesTO locProcedimento : parProcedimentosComExamesSelecionados) {
			if (locProcedimento.getGuia().equals(parGuia.getNumeroGuiaOperadora())) {
				if (!locProcedimento.getExcluido()) {
					if (locProcedimento.getExame().getEPacote() == 1) {
						exames.add(new ExamePedido(locProcedimento, parQuestionarios, parPerguntas, exames,
								locProcedimento.getExame().getComposicaoPacote(), parSolicitante));
					} else {
						exames.add(new ExamePedido(locProcedimento, parQuestionarios, parPerguntas, exames,
								parSolicitante));
					}
				}
			}
		}

	}

	public Guia(final Guia parGuia, final List<ProcedimentoComExamesTO> parProcedimentosComExamesSelecionados,
			final List<ConsultaQuestionarioExameResult> parQuestionarios, final List<PerguntaEntrega> parPerguntas,
			final Solicitante parSolicitante, final boolean particular) {
		numeroGuiaOperadora = parGuia.getNumeroGuiaOperadora();
		numeroGuiaPrestador = parGuia.getNumeroGuiaPrestador();
		data = parGuia.getData();
		autorizacao = parGuia.getAutorizacao();
		exames = new ExamesPedidos();
		solicitante = parGuia.getSolicitante();
		if (solicitante != null) {
			solicitante.setNomeSolicitante(solicitante.getNome());
		}
		for (final ProcedimentoComExamesTO locProcedimento : parProcedimentosComExamesSelecionados) {
			if (!locProcedimento.getExcluido()) {
				if (numeroGuiaOperadora != null && !locProcedimento.getGuia().equals(numeroGuiaOperadora)) {
					continue;
				}
				if (locProcedimento.getExame().getEPacote() == 1) {
					exames.add(new ExamePedido(locProcedimento, parQuestionarios, parPerguntas, exames,
							locProcedimento.getExame().getComposicaoPacote(), solicitante));
				} else {
					exames.add(new ExamePedido(locProcedimento, parQuestionarios, parPerguntas, exames, solicitante));
				}
			}
		}

	}

	public List<Guia> retornarGuias() {
		return null;
	}

	public String getNumeroGuiaOperadora() {
		return numeroGuiaOperadora;
	}

	public void setNumeroGuiaOperadora(final String parNumeroGuiaOperadora) {
		numeroGuiaOperadora = parNumeroGuiaOperadora;
	}

	public String getNumeroGuiaPrestador() {
		return numeroGuiaPrestador;
	}

	public void setNumeroGuiaPrestador(final String parNumeroGuiaPrestador) {
		numeroGuiaPrestador = parNumeroGuiaPrestador;
	}

	public String getData() {
		return data;
	}

	public void setData(final String parData) {
		data = parData;
	}

	public String getCid() {
		return cid;
	}

	public void setCid(final String parCid) {
		cid = parCid;
	}

	public Autorizacao getAutorizacao() {
		return autorizacao;
	}

	public void setAutorizacao(final Autorizacao parAutorizacao) {
		autorizacao = parAutorizacao;
	}

	public ExamesPedidos getExames() {
		return exames;
	}

	public void setExames(final ExamesPedidos parExames) {
		exames = parExames;
	}

	public Solicitante getSolicitante() {
		return solicitante;
	}

	public void setSolicitante(Solicitante solicitante) {
		this.solicitante = solicitante;
	}

}
