package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

import br.com.hermespardini.passelivre.constantsenum.Constantes;

public class Pagante implements Serializable {

	private String codigo;
	private String nome;
	private String dataNascimento;
	private String estadoCivil;
	private String nacionalidade;
	private String genero;
	private String identificacao;
	private String telefone;
	private String celular;
	private String email;
	private Endereco endereco;
	private String nomeMae;
	private String nomePai;
	private String tipoDocumento;

	public Pagante(final ClienteUnidadePasseLivre parClienteUnidadePasseLivre, final DadosCartao parDadosCartao) {
		codigo = parClienteUnidadePasseLivre.getCodigoCliente();
		nome = parClienteUnidadePasseLivre.getNomeCliente();
		dataNascimento = parClienteUnidadePasseLivre.getDataNascimento();
		estadoCivil = parClienteUnidadePasseLivre.getEstadoCivil();
		nacionalidade = parClienteUnidadePasseLivre.getNacionalidade();
		genero = parClienteUnidadePasseLivre.getSexo();
		identificacao = parClienteUnidadePasseLivre.getCpf();
		telefone = parClienteUnidadePasseLivre.getTelefone();
		celular = parClienteUnidadePasseLivre.getCelular();
		email = parClienteUnidadePasseLivre.getEmail();
		endereco = new Endereco(parClienteUnidadePasseLivre);
		nomeMae = parClienteUnidadePasseLivre.getNomeMae();
		nomePai = "";
		tipoDocumento = Constantes.TIPO_DOCUMENTO;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(final String parCodigo) {
		codigo = parCodigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(final String parNome) {
		nome = parNome;
	}

	public String getDataNascimento() {
		return dataNascimento;
	}

	public void setDataNascimento(final String parDataNascimento) {
		dataNascimento = parDataNascimento;
	}

	public String getEstadoCivil() {
		return estadoCivil;
	}

	public void setEstadoCivil(final String parEstadoCivil) {
		estadoCivil = parEstadoCivil;
	}

	public String getNacionalidade() {
		return nacionalidade;
	}

	public void setNacionalidade(final String parNacionalidade) {
		nacionalidade = parNacionalidade;
	}

	public String getGenero() {
		return genero;
	}

	public void setGenero(final String parGenero) {
		genero = parGenero;
	}

	public String getIdentificacao() {
		return identificacao;
	}

	public void setIdentificacao(final String parIdentificacao) {
		identificacao = parIdentificacao;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(final String parTelefone) {
		telefone = parTelefone;
	}

	public String getCelular() {
		return celular;
	}

	public void setCelular(final String parCelular) {
		celular = parCelular;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(final String parEmail) {
		email = parEmail;
	}

	public Endereco getEndereco() {
		return endereco;
	}

	public void setEndereco(final Endereco parEndereco) {
		endereco = parEndereco;
	}

	public String getNomeMae() {
		return nomeMae;
	}

	public void setNomeMae(final String parNomeMae) {
		nomeMae = parNomeMae;
	}

	public String getNomePai() {
		return nomePai;
	}

	public void setNomePai(final String parNomePai) {
		nomePai = parNomePai;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(final String parTipoDocumento) {
		tipoDocumento = parTipoDocumento;
	}

}
