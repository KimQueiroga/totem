package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

public class Recibo implements Serializable {

	private String numeroRecibo;
	private String valorAcrescimo;
	private String valorDesconto;
	private String valorPagoCartao;
	private String valorPagoCheque;
	private String valorPagoDeposito;
	private String valorPagoDinheiro;

	public String getNumeroRecibo() {
		return numeroRecibo;
	}

	public void setNumeroRecibo(final String parNumeroRecibo) {
		numeroRecibo = parNumeroRecibo;
	}

	public String getValorAcrescimo() {
		return valorAcrescimo;
	}

	public void setValorAcrescimo(final String parValorAcrescimo) {
		valorAcrescimo = parValorAcrescimo;
	}

	public String getValorDesconto() {
		return valorDesconto;
	}

	public void setValorDesconto(final String parValorDesconto) {
		valorDesconto = parValorDesconto;
	}

	public String getValorPagoCartao() {
		return valorPagoCartao;
	}

	public void setValorPagoCartao(final String parValorPagoCartao) {
		valorPagoCartao = parValorPagoCartao;
	}

	public String getValorPagoCheque() {
		return valorPagoCheque;
	}

	public void setValorPagoCheque(final String parValorPagoCheque) {
		valorPagoCheque = parValorPagoCheque;
	}

	public String getValorPagoDeposito() {
		return valorPagoDeposito;
	}

	public void setValorPagoDeposito(final String parValorPagoDeposito) {
		valorPagoDeposito = parValorPagoDeposito;
	}

	public String getValorPagoDinheiro() {
		return valorPagoDinheiro;
	}

	public void setValorPagoDinheiro(final String parValorPagoDinheiro) {
		valorPagoDinheiro = parValorPagoDinheiro;
	}

}
