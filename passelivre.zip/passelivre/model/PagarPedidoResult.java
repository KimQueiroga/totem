package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.util.List;

public class PagarPedidoResult implements Serializable {

	private String mensagem;
	private String status;
	private List<Recibo> recibos;
	private String saldoAPagar;
	private String valorAcrescimo;
	private String valorCliente;
	private String valorConvenio;
	private String valorDesconto;
	private String valorExames;
	private String valorPagoCartao;
	private String valorPagoCheque;
	private String valorPagoDeposito;
	private String valorPagoDinheiro;
	private String valorPedido;

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(final String parMensagem) {
		mensagem = parMensagem;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(final String parStatus) {
		status = parStatus;
	}

	public List<Recibo> getRecibos() {
		return recibos;
	}

	public void setRecibos(final List<Recibo> parRecibos) {
		recibos = parRecibos;
	}

	public String getSaldoAPagar() {
		return saldoAPagar;
	}

	public void setSaldoAPagar(final String parSaldoAPagar) {
		saldoAPagar = parSaldoAPagar;
	}

	public String getValorAcrescimo() {
		return valorAcrescimo;
	}

	public void setValorAcrescimo(final String parValorAcrescimo) {
		valorAcrescimo = parValorAcrescimo;
	}

	public String getValorCliente() {
		return valorCliente;
	}

	public void setValorCliente(final String parValorCliente) {
		valorCliente = parValorCliente;
	}

	public String getValorConvenio() {
		return valorConvenio;
	}

	public void setValorConvenio(final String parValorConvenio) {
		valorConvenio = parValorConvenio;
	}

	public String getValorDesconto() {
		return valorDesconto;
	}

	public void setValorDesconto(final String parValorDesconto) {
		valorDesconto = parValorDesconto;
	}

	public String getValorExames() {
		return valorExames;
	}

	public void setValorExames(final String parValorExames) {
		valorExames = parValorExames;
	}

	public String getValorPagoCartao() {
		return valorPagoCartao;
	}

	public void setValorPagoCartao(final String parValorPagoCartao) {
		valorPagoCartao = parValorPagoCartao;
	}

	public String getValorPagoCheque() {
		return valorPagoCheque;
	}

	public void setValorPagoCheque(final String parValorPagoCheque) {
		valorPagoCheque = parValorPagoCheque;
	}

	public String getValorPagoDeposito() {
		return valorPagoDeposito;
	}

	public void setValorPagoDeposito(final String parValorPagoDeposito) {
		valorPagoDeposito = parValorPagoDeposito;
	}

	public String getValorPagoDinheiro() {
		return valorPagoDinheiro;
	}

	public void setValorPagoDinheiro(final String parValorPagoDinheiro) {
		valorPagoDinheiro = parValorPagoDinheiro;
	}

	public String getValorPedido() {
		return valorPedido;
	}

	public void setValorPedido(final String parValorPedido) {
		valorPedido = parValorPedido;
	}

}
