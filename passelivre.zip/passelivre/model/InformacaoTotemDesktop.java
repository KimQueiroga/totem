package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.util.Date;

import br.com.hermespardini.corebusiness.util.SessionIdElement;

@SessionIdElement(separator = "-")
public class InformacaoTotemDesktop implements Serializable {

	private static final long serialVersionUID = 1L;
	private Boolean podeAlterar;
	private Boolean podeIncluir;
	private Boolean podevisualizar;
	private Boolean podeExcluir;
	private String ativo;
	private String descricao;
	private Date dataHoraUltAtualizacao;
	@SessionIdElement(order = 1)
	private Long id;
	private Long idAplicacao;
	private String nome;
	private String tipo;
	private String urlRecurso;
	private String usuUltAtualizacao;
	private String observacao;
	private String funcionalidadeLog;

	public Boolean getPodeAlterar() {
		return podeAlterar;
	}

	public void setPodeAlterar(final Boolean parPodeAlterar) {
		podeAlterar = parPodeAlterar;
	}

	public Boolean getPodeIncluir() {
		return podeIncluir;
	}

	public void setPodeIncluir(final Boolean parPodeIncluir) {
		podeIncluir = parPodeIncluir;
	}

	public Boolean getPodevisualizar() {
		return podevisualizar;
	}

	public void setPodevisualizar(final Boolean parPodevisualizar) {
		podevisualizar = parPodevisualizar;
	}

	public Boolean getPodeExcluir() {
		return podeExcluir;
	}

	public void setPodeExcluir(final Boolean parPodeExcluir) {
		podeExcluir = parPodeExcluir;
	}

	public String getAtivo() {
		return ativo;
	}

	public void setAtivo(final String parAtivo) {
		ativo = parAtivo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(final String parDescricao) {
		descricao = parDescricao;
	}

	public Date getDataHoraUltAtualizacao() {
		return dataHoraUltAtualizacao;
	}

	public void setDataHoraUltAtualizacao(final Date parDataHoraUltAtualizacao) {
		dataHoraUltAtualizacao = parDataHoraUltAtualizacao;
	}

	public Long getId() {
		return id;
	}

	public void setId(final Long parId) {
		id = parId;
	}

	public Long getIdAplicacao() {
		return idAplicacao;
	}

	public void setIdAplicacao(final Long parIdAplicacao) {
		idAplicacao = parIdAplicacao;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(final String parNome) {
		nome = parNome;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(final String parTipo) {
		tipo = parTipo;
	}

	public String getUrlRecurso() {
		return urlRecurso;
	}

	public void setUrlRecurso(final String parUrlRecurso) {
		urlRecurso = parUrlRecurso;
	}

	public String getUsuUltAtualizacao() {
		return usuUltAtualizacao;
	}

	public void setUsuUltAtualizacao(final String parUsuUltAtualizacao) {
		usuUltAtualizacao = parUsuUltAtualizacao;
	}

	public String getObservacao() {
		return observacao;
	}

	public void setObservacao(final String parObservacao) {
		observacao = parObservacao;
	}

	public String getFuncionalidadeLog() {
		return funcionalidadeLog;
	}

	public void setFuncionalidadeLog(final String parFuncionalidadeLog) {
		funcionalidadeLog = parFuncionalidadeLog;
	}

}
