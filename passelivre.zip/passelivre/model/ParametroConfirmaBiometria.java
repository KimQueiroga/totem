package br.com.hermespardini.passelivre.model;

public class ParametroConfirmaBiometria {

	private String numeroCarteira;
	private String unbh;
	private String dataAtendimento;

	public String getNumeroCarteira() {
		return numeroCarteira;
	}

	public void setNumeroCarteira(String numeroCarteira) {
		this.numeroCarteira = numeroCarteira;
	}

	public String getUnbh() {
		return unbh;
	}

	public void setUnbh(String unbh) {
		this.unbh = unbh;
	}

	public String getDataAtendimento() {
		return dataAtendimento;
	}

	public void setDataAtendimento(String dataAtendimento) {
		this.dataAtendimento = dataAtendimento;
	}

}
