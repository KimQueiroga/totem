package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

import br.com.hermespardini.passelivre.to.ProcedimentoComExamesTO;

public class ExameMaterialParaQuestionario implements Serializable {
	private String exame;
	private String material;

	public ExameMaterialParaQuestionario(final ProcedimentoComExamesTO parProcedimentosComExames) {
		exame = parProcedimentosComExames.getExame().getExame();
		material = parProcedimentosComExames.getExame().getMaterial();
	}

	public String getExame() {
		return exame;
	}

	public void setExame(final String parExame) {
		exame = parExame;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(final String parMaterial) {
		material = parMaterial;
	}

}
