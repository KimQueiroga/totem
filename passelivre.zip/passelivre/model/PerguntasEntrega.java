package br.com.hermespardini.passelivre.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@SuppressWarnings("serial")
public class PerguntasEntrega extends ArrayList<PerguntaEntrega> {
	public PerguntasEntrega() {
		super();
	}

	public PerguntasEntrega(final Collection<? extends PerguntaEntrega> parQuestionario) {
		super(parQuestionario);
	}

	public final List<PerguntaEntrega> getPerguntasEntrega() {
		return this;
	}

	public final void setPerguntasEntrega(final List<PerguntaEntrega> parPerguntasEntrega) {
		this.addAll(parPerguntasEntrega);
	}
}
