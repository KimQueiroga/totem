package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

import br.com.hermespardini.corebusiness.util.SessionIdElement;

@SessionIdElement(separator = "-")
public class SessionIdDesktop implements Serializable {

	private static final long serialVersionUID = 1L;
	@SessionIdElement(order = 1)
	private String sigla;
	@SessionIdElement(order = 3)
	private String nomeMaquina;
	@SessionIdElement(order = 2)
	private Long idUnidade;

	public SessionIdDesktop() {
	}

	public SessionIdDesktop(final String nomeMaquina, final String sigla, final Long idUnidade) {
		this.nomeMaquina = nomeMaquina;
		this.sigla = sigla;
		this.idUnidade = idUnidade;
	}

}
