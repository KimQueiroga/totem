package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.util.List;

public class EPacoteResult implements Serializable {

	private String dataHoraMarcacao;
	private List<Composicao> composicao;
	private String descricaoPacote;
	private String ePacote;
	private String mensagem;
	private String status;

	public String getDataHoraMarcacao() {
		return dataHoraMarcacao;
	}

	public void setDataHoraMarcacao(final String parDataHoraMarcacao) {
		dataHoraMarcacao = parDataHoraMarcacao;
	}

	public List<Composicao> getComposicao() {
		return composicao;
	}

	public void setComposicao(final List<Composicao> parComposicao) {
		composicao = parComposicao;
	}

	public String getDescricaoPacote() {
		return descricaoPacote;
	}

	public void setDescricaoPacote(final String parDescricaoPacote) {
		descricaoPacote = parDescricaoPacote;
	}

	public String getePacote() {
		return ePacote;
	}

	public void setePacote(final String parEPacote) {
		ePacote = parEPacote;
	}

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(final String parMensagem) {
		mensagem = parMensagem;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(final String parStatus) {
		status = parStatus;
	}

}
