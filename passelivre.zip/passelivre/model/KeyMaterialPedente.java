package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

@SuppressWarnings("serial")
public class KeyMaterialPedente implements Serializable {
	private String pedido;
	private String unidade;

	public KeyMaterialPedente(final ExameMaterialPendente parExameMaterialPendente) {
		pedido = parExameMaterialPendente.getPedido();
		unidade = parExameMaterialPendente.getUnidade();
	}

	public String getPedido() {
		return pedido;
	}

	public void setPedido(final String parPedido) {
		pedido = parPedido;
	}

	public String getUnidade() {
		return unidade;
	}

	public void setUnidade(final String parUnidade) {
		unidade = parUnidade;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (pedido == null ? 0 : pedido.hashCode());
		result = prime * result + (unidade == null ? 0 : unidade.hashCode());
		return result;
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final KeyMaterialPedente other = (KeyMaterialPedente) obj;
		if (pedido == null) {
			if (other.pedido != null) {
				return false;
			}
		} else if (!pedido.equals(other.pedido)) {
			return false;
		}
		if (unidade == null) {
			if (other.unidade != null) {
				return false;
			}
		} else if (!unidade.equals(other.unidade)) {
			return false;
		}
		return true;
	}

}
