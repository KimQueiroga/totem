package br.com.hermespardini.passelivre.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class Localizacoes extends ArrayList<Localizacao> {
	public Localizacoes() {
		super();
	}

	public Localizacoes(final Collection<? extends Localizacao> parLocalizacoes) {
		super(parLocalizacoes);
	}

	public final List<Localizacao> getLocalizacoes() {
		return this;
	}

	public final void setLocalizacoes(final List<Localizacao> parLocalizacoes) {
		this.addAll(parLocalizacoes);
	}

}
