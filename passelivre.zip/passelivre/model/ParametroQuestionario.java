package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.wdelmaschio.base.model.ValueObject;

import com.owlike.genson.annotation.JsonIgnore;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.to.ProcedimentoComExamesTO;
import br.com.hermespardini.passelivre.utils.TotemUtil;

@SuppressWarnings("serial")
public class ParametroQuestionario extends ValueObject implements Serializable {
	private String empresa;
	private String exame;
	@JsonIgnore
	private String examePAI;
	private String material;
	private String genero;
	private String nascimento;
	private String dataReferencia;
	private String token;
	private String origem;
	private String faseProcesso;
	@JsonIgnore
	private Integer sequenciaExame;
	private String sessionId;

	public ParametroQuestionario(final ProcedimentoComExamesTO parProcedimento,
			final ClienteUnidadePasseLivre parClienteUnidadePasseLivre, final TokenResult parTokenResult) {
		empresa = Constantes.EMPRESA;
		material = parProcedimento.getExame().getMaterial();
		exame = parProcedimento.getExame().getExame();
		genero = parClienteUnidadePasseLivre.getSexo();
		nascimento = parClienteUnidadePasseLivre.getDataNascimento();
		dataReferencia = retornarDataAtual();
		token = parTokenResult.getToken();
		if (TotemUtil.isDesktop()) {
			origem = Constantes.ORIGEM_DESKTOP;
		} else {
			origem = Constantes.ORIGEM_PADRAO;
		}
		faseProcesso = Constantes.PERGUNTA_ATENDIMENTO;
	}

	public ParametroQuestionario(final ProcedimentoComExamesTO parProcedimento,
			final ClienteUnidadePasseLivre parClienteUnidadePasseLivre, final TokenResult parTokenResult,
			final String tipo, final String parSessionId) {
		empresa = Constantes.EMPRESA;
		material = parProcedimento.getExame().getMaterial();
		exame = parProcedimento.getExame().getExame();
		genero = parClienteUnidadePasseLivre.getSexo();
		nascimento = parClienteUnidadePasseLivre.getDataNascimento();
		dataReferencia = retornarDataAtual();
		token = parTokenResult.getToken();
		origem = Constantes.ORIGEM_DESKTOP;
		faseProcesso = Constantes.PERGUNTA_ATENDIMENTO;
		sessionId = parSessionId;
	}

	public ParametroQuestionario(final ExameMaterialPendente parExameMaterialPendente,
			final ClienteUnidadePasseLivre parClienteUnidadePasseLivre, final TokenResult parTokenResult) {
		empresa = Constantes.EMPRESA;
		material = parExameMaterialPendente.getMaterial();
		exame = parExameMaterialPendente.getExame();
		genero = parClienteUnidadePasseLivre.getSexo();
		nascimento = parClienteUnidadePasseLivre.getDataNascimento();
		dataReferencia = retornarDataAtual();
		token = parTokenResult.getToken();
		origem = Constantes.ORIGEM_PADRAO;
		faseProcesso = Constantes.PERGUNTA_ATENDIMENTO;
		sequenciaExame = parExameMaterialPendente.getSequencia();
	}

	public ParametroQuestionario(final ExameMaterialPendente parExameMaterialPendente,
			final ClienteUnidadePasseLivre parClienteUnidadePasseLivre, final TokenResult parTokenResult,
			final String tipo) {
		empresa = Constantes.EMPRESA;
		material = parExameMaterialPendente.getMaterial();
		exame = parExameMaterialPendente.getExame();
		genero = parClienteUnidadePasseLivre.getSexo();
		nascimento = parClienteUnidadePasseLivre.getDataNascimento();
		dataReferencia = retornarDataAtual();
		token = parTokenResult.getToken();
		origem = Constantes.ORIGEM_DESKTOP;
		faseProcesso = Constantes.PERGUNTA_ATENDIMENTO;
		sequenciaExame = parExameMaterialPendente.getSequencia();
	}

	public ParametroQuestionario(final ExameHermesPardini parExame, final ExameHermesPardini parComposicaoPacote,
			final ClienteUnidadePasseLivre parClienteUnidadePasseLivre, final TokenResult parTokenResult) {
		empresa = Constantes.EMPRESA;
		material = parExame.getMaterial();
		exame = parExame.getExame();
		examePAI = parComposicaoPacote.getExame();
		genero = parClienteUnidadePasseLivre.getSexo();
		nascimento = parClienteUnidadePasseLivre.getDataNascimento();
		dataReferencia = retornarDataAtual();
		token = parTokenResult.getToken();
		if (TotemUtil.isDesktop()) {
			origem = Constantes.ORIGEM_DESKTOP;
		} else {
			origem = Constantes.ORIGEM_PADRAO;
		}
		faseProcesso = Constantes.PERGUNTA_ATENDIMENTO;
	}

	public ParametroQuestionario(final ExameHermesPardini parExame, final ExameHermesPardini parComposicaoPacote,
			final ClienteUnidadePasseLivre parClienteUnidadePasseLivre, final TokenResult parTokenResult,
			final String tipo, final String parSessionId) {
		empresa = Constantes.EMPRESA;
		material = parExame.getMaterial();
		exame = parExame.getExame();
		examePAI = parComposicaoPacote.getExame();
		genero = parClienteUnidadePasseLivre.getSexo();
		nascimento = parClienteUnidadePasseLivre.getDataNascimento();
		dataReferencia = retornarDataAtual();
		token = parTokenResult.getToken();
		origem = Constantes.ORIGEM_DESKTOP;
		faseProcesso = Constantes.PERGUNTA_ATENDIMENTO;
		sessionId = parSessionId;
	}

	public ParametroQuestionario(final Composicao parComposicao,
			final ClienteUnidadePasseLivre parClienteUnidadePasseLivre, final TokenResult parTokenResult,
			final String parExamePai) {
		empresa = Constantes.EMPRESA;
		material = parComposicao.getMaterial();
		exame = parComposicao.getExame();
		examePAI = parExamePai;
		genero = parClienteUnidadePasseLivre.getSexo();
		nascimento = parClienteUnidadePasseLivre.getDataNascimento();
		dataReferencia = retornarDataAtual();
		token = parTokenResult.getToken();
		origem = Constantes.ORIGEM_PADRAO;
		faseProcesso = Constantes.PERGUNTA_ATENDIMENTO;
	}

	private String retornarDataAtual() {
		final SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
		final String dataFormatada = formato.format(new Date());
		return dataFormatada;
	}

	public static ParametroQuestionario criarBuscarParaCheckup(final Composicao parComposicao,
			final ClienteUnidadePasseLivre parClienteUnidadePasseLivre, final TokenResult parTokenResult,
			final String parExamePai) {
		return new ParametroQuestionario(parComposicao, parClienteUnidadePasseLivre, parTokenResult, parExamePai);
	}

	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(final String parEmpresa) {
		empresa = parEmpresa;
	}

	public String getExame() {
		return exame;
	}

	public void setExame(final String parExame) {
		exame = parExame;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(final String parMaterial) {
		material = parMaterial;
	}

	public String getGenero() {
		return genero;
	}

	public void setGenero(final String parGenero) {
		genero = parGenero;
	}

	public String getNascimento() {
		return nascimento;
	}

	public void setNascimento(final String parNascimento) {
		nascimento = parNascimento;
	}

	public String getDataReferencia() {
		return dataReferencia;
	}

	public void setDataReferencia(final String parDataReferencia) {
		dataReferencia = parDataReferencia;
	}

	public String getToken() {
		return token;
	}

	public void setToken(final String parToken) {
		token = parToken;
	}

	public String getOrigem() {
		return origem;
	}

	public void setOrigem(final String parOrigem) {
		origem = parOrigem;
	}

	public String getExamePAI() {
		return examePAI;
	}

	public Integer getSequenciaExame() {
		return sequenciaExame;
	}

	public void setSequenciaExame(final Integer parSequenciaExame) {
		sequenciaExame = parSequenciaExame;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(final String parSessionId) {
		sessionId = parSessionId;
	}

}
