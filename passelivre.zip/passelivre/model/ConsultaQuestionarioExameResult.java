package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

import org.wdelmaschio.base.model.ValueObject;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.owlike.genson.annotation.JsonIgnore;

@SuppressWarnings("serial")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ConsultaQuestionarioExameResult extends ValueObject implements Serializable {

	private String descricaoExame;
	private String descricaoMaterial;
	private String exame;
	@JsonIgnore
	private String examePAI;
	private String material;
	private String mensagem;
	private Questionarios questionarios;
	private Integer status;

	public ConsultaQuestionarioExameResult() {
	}

	public ConsultaQuestionarioExameResult(final ConsultaQuestionarioExameResult parValueObject,
			final ParametroQuestionario parParametroQuestionario) {
		descricaoExame = parValueObject.getDescricaoExame();
		descricaoMaterial = parValueObject.getDescricaoMaterial();
		exame = parValueObject.getExame();
		examePAI = parParametroQuestionario.getExamePAI();
		material = parValueObject.getMaterial();
		mensagem = parValueObject.getMensagem();
		questionarios = parValueObject.getQuestionarios();
		status = parValueObject.getStatus();
	}

	@Override
	public int hashCode() {
		return exame.hashCode() + 31 * material.hashCode();
	}

	@Override
	public boolean equals(final Object obj) {
		if (!(obj instanceof ConsultaQuestionarioExameResult)) {
			return false;
		}
		final ConsultaQuestionarioExameResult other = (ConsultaQuestionarioExameResult) obj;
		return other.getExame().equals(exame) && other.getMaterial().equals(material);
	}

	public String getDescricaoExame() {
		return descricaoExame;
	}

	public void setDescricaoExame(final String parDescricaoExame) {
		descricaoExame = parDescricaoExame;
	}

	public String getDescricaoMaterial() {
		return descricaoMaterial;
	}

	public void setDescricaoMaterial(final String parDescricaoMaterial) {
		descricaoMaterial = parDescricaoMaterial;
	}

	public String getExame() {
		return exame;
	}

	public void setExame(final String parExame) {
		exame = parExame;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(final String parMaterial) {
		material = parMaterial;
	}

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(final String parMensagem) {
		mensagem = parMensagem;
	}

	public Questionarios getQuestionarios() {
		return questionarios;
	}

	public void setQuestionarios(final Questionarios parQuestionarios) {
		questionarios = parQuestionarios;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(final Integer parStatus) {
		status = parStatus;
	}

	public String getExamePAI() {
		return examePAI;
	}

	public void setExamePAI(final String parExamePAI) {
		examePAI = parExamePAI;
	}
}
