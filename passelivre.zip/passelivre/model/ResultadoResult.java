package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

public class ResultadoResult implements Serializable {

	private static final long serialVersionUID = 7059497483800956115L;

	private String status;
	private String mensagem;
	private Integer qtdePaginas;
	private String codigoCliente;

	public String getStatus() {
		return status;
	}

	public void setStatus(final String parStatus) {
		status = parStatus;
	}

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(final String parMensagem) {
		mensagem = parMensagem;
	}

	public Integer getQtdePaginas() {
		return qtdePaginas;
	}

	public void setQtdePaginas(final Integer parQtdePaginas) {
		qtdePaginas = parQtdePaginas;
	}

	public String getCodigoCliente() {
		return codigoCliente;
	}

	public void setCodigoCliente(final String parCodigoCliente) {
		codigoCliente = parCodigoCliente;
	}
}
