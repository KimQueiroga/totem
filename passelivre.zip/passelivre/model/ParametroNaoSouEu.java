package br.com.hermespardini.passelivre.model;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.utils.TotemUtil;

public class ParametroNaoSouEu {

	private String codigoCliente;
	private String matricula;
	private String origem;
	private String token;

	public ParametroNaoSouEu(ClienteUnidadePasseLivre parCLiClienteUnidadePasseLivre, String parNumeroCarteira) {
		codigoCliente = parCLiClienteUnidadePasseLivre.getCodigoCliente();
		matricula = parNumeroCarteira;
		origem = Constantes.ORIGEM_PADRAO;
		token = TotemUtil.buscarToken().getToken();
	}

	public String getCodigoCliente() {
		return codigoCliente;
	}

	public void setCodigoCliente(String codigoCliente) {
		this.codigoCliente = codigoCliente;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getOrigem() {
		return origem;
	}

	public void setOrigem(String origem) {
		this.origem = origem;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

}
