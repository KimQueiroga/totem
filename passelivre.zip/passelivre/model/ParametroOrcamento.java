package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import br.com.hermespardini.passelivre.constantsenum.Constantes;

public class ParametroOrcamento implements Serializable {

	private String unidade;
	private String total;
	private String origem;
	private List<ExameOrcamento> exames;

	public ParametroOrcamento(final InformacaoTotem parInformacaoTotem,
			final List<DetalhePreparacao> parDetalhesPreparacao, final String parValorTotal,
			final Preparacao parPreparacaoSelecionada) {
		exames = new ArrayList<ExameOrcamento>();
		total = parValorTotal;
		unidade = parInformacaoTotem.getNomeUnd();
		origem = Constantes.ORIGEM_ORCAMENTO;
		for (final DetalhePreparacao locDetalhePreparacao : parDetalhesPreparacao) {
			exames.add(new ExameOrcamento(locDetalhePreparacao, parPreparacaoSelecionada));
		}
	}

	public String getUnidade() {
		return unidade;
	}

	public void setUnidade(final String parUnidade) {
		unidade = parUnidade;
	}

	public String getTotal() {
		return total;
	}

	public void setTotal(final String parTotal) {
		total = parTotal;
	}

	public String getOrigem() {
		return origem;
	}

	public void setOrigem(final String parOrigem) {
		origem = parOrigem;
	}

	public List<ExameOrcamento> getExames() {
		return exames;
	}

	public void setExames(final List<ExameOrcamento> parExames) {
		exames = parExames;
	}

}
