package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

public class UsuarioIHP implements Serializable {
	private Long id;
	private Long chapa;
	private String nome;
	private String sigla;
	private String situacao;
	private String empresa;
	private String usuarioad;

	public Long getChapa() {
		return chapa;
	}

	public void setChapa(final Long parChapa) {
		chapa = parChapa;
	}

	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(final String parEmpresa) {
		empresa = parEmpresa;
	}

	public Long getId() {
		return id;
	}

	public void setId(final Long parId) {
		id = parId;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(final String parNome) {
		nome = parNome;
	}

	public String getSigla() {
		return sigla;
	}

	public void setSigla(final String parSigla) {
		sigla = parSigla;
	}

	public String getSituacao() {
		return situacao;
	}

	public void setSituacao(final String parSituacao) {
		situacao = parSituacao;
	}

	public String getUsuarioad() {
		return usuarioad;
	}

	public void setUsuarioad(final String parUsuarioad) {
		usuarioad = parUsuarioad;
	}

}
