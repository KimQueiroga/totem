package br.com.hermespardini.passelivre.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@SuppressWarnings("serial")
public class Servicos extends ArrayList<Servico> {
	public Servicos() {
		super();
	}

	public Servicos(final Collection<? extends Servico> parServicos) {
		super(parServicos);
	}

	public final List<Servico> getServicos() {
		return this;
	}

	public final void setServicos(final List<Servico> parServicos) {
		this.addAll(parServicos);
	}
}
