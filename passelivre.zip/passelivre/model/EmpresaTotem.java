package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

public class EmpresaTotem implements Serializable {

	private Long codigo;
	private String apelido;
	private Long codigoERP;
	private String nome;
	private String sigla;
	private String situacao;
	private Unidades unidades;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(final Long parCodigo) {
		codigo = parCodigo;
	}

	public String getApelido() {
		return apelido;
	}

	public void setApelido(final String parApelido) {
		apelido = parApelido;
	}

	public Long getCodigoERP() {
		return codigoERP;
	}

	public void setCodigoERP(final Long parCodigoERP) {
		codigoERP = parCodigoERP;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(final String parNome) {
		nome = parNome;
	}

	public String getSigla() {
		return sigla;
	}

	public void setSigla(final String parSigla) {
		sigla = parSigla;
	}

	public String getSituacao() {
		return situacao;
	}

	public void setSituacao(final String parSituacao) {
		situacao = parSituacao;
	}

	public Unidades getUnidades() {
		return unidades;
	}

	public void setUnidades(final Unidades parUnidades) {
		unidades = parUnidades;
	}

}
