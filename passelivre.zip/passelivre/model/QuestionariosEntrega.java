package br.com.hermespardini.passelivre.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@SuppressWarnings("serial")
public class QuestionariosEntrega extends ArrayList<QuestionarioEntrega> {

	public QuestionariosEntrega() {
		super();
	}

	public QuestionariosEntrega(final Collection<? extends QuestionarioEntrega> parQuestionariosEntrega) {
		super(parQuestionariosEntrega);
	}

	public final List<QuestionarioEntrega> getQuestionariosEntrega() {
		return this;
	}

	public final void setQuestionariosEntrega(final List<QuestionarioEntrega> parQuestionariosEntrega) {
		this.addAll(parQuestionariosEntrega);
	}
}
