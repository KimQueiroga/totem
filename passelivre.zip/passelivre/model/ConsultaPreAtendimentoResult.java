package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.util.List;

@SuppressWarnings("serial")
public class ConsultaPreAtendimentoResult implements Serializable {

	private String mensagem;
	private String status;
	private List<PreAtendimento> preAtendimentos;

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(final String parMensagem) {
		mensagem = parMensagem;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(final String parStatus) {
		status = parStatus;
	}

	public List<PreAtendimento> getPreAtendimentos() {
		return preAtendimentos;
	}

	public void setPreAtendimentos(final List<PreAtendimento> parPreAtendimentos) {
		preAtendimentos = parPreAtendimentos;
	}

}
