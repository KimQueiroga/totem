package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

import org.wdelmaschio.base.model.ValueObject;

@SuppressWarnings("serial")
public class UserAuth extends ValueObject implements Serializable {

	private String authKey;
	private String authKeyType;
	private String authPass;
	private String birthDate;
	private String email;
	private String token;
	private String password;
	private String newPass;
	private String confirmAuthPass;

	public String getAuthKey() {
		return authKey;
	}

	public String getAuthPass() {
		return authPass;
	}

	public String getAuthKeyType() {
		return authKeyType;
	}

	public String getBirthDate() {
		return birthDate;
	}

	public void setAuthKey(final String authKey) {
		this.authKey = authKey;
	}

	public void setAuthPass(final String authPass) {
		this.authPass = authPass;
	}

	public void setAuthKeyType(final String authKeyType) {
		this.authKeyType = authKeyType;
	}

	public void setBirthDate(final String birthDate) {
		this.birthDate = birthDate;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(final String parEmail) {
		email = parEmail;
	}

	public String getToken() {
		return token;
	}

	public void setToken(final String parToken) {
		token = parToken;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(final String parPassword) {
		password = parPassword;
	}

	public String getNewPass() {
		return newPass;
	}

	public String getConfirmAuthPass() {
		return confirmAuthPass;
	}

	public void setNewPass(final String parNewPass) {
		newPass = parNewPass;
	}

	public void setConfirmAuthPass(final String parConfirmAuthPass) {
		confirmAuthPass = parConfirmAuthPass;
	}

}
