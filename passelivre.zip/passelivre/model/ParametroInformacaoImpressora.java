package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

import br.com.hermespardini.passelivre.constantsenum.Constantes;

public class ParametroInformacaoImpressora implements Serializable {

	private String impressora;
	private String origem;
	private String token;

	public ParametroInformacaoImpressora(final InformacaoTotem parInformacaoTotem, final TokenResult parTokenResult) {
		impressora = parInformacaoTotem.getImpressoraDefault();
		origem = Constantes.ORIGEM_PADRAO;
		token = parTokenResult.getToken();
	}

	public ParametroInformacaoImpressora(final TokenResult parTokenResult, final String parImpresora) {
		impressora = parImpresora;
		origem = Constantes.ORIGEM_DESKTOP;
		token = parTokenResult.getToken();
	}

	public String getImpressora() {
		return impressora;
	}

	public void setImpressora(final String parImpressora) {
		impressora = parImpressora;
	}

	public String getOrigem() {
		return origem;
	}

	public void setOrigem(final String parOrigem) {
		origem = parOrigem;
	}

	public String getToken() {
		return token;
	}

	public void setToken(final String parToken) {
		token = parToken;
	}

}
