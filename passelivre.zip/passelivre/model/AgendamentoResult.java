package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.Expose;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AgendamentoResult implements Serializable {

	private List<AgendamentoUnidade> agenda;
	private String mensagem;
	private String status;

	public List<AgendamentoUnidade> getAgendamentos() {
		return this.agenda;
	}

	public void setAgendamentos(List<AgendamentoUnidade> parAgenda) {
		this.agenda = parAgenda;
	}

	public String getMensagem() {
		return this.mensagem;
	}

	public void setMensagem(String parMensagem) {
		this.mensagem = parMensagem;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String parStatus) {
		this.status = parStatus;
	}
}
