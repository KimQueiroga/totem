package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.Expose;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ConsultaResult implements Serializable {

	@Expose
	@JsonProperty("cliente")
	private List<ClienteUnidadePasseLivre> clientes;

	@Expose
	@JsonProperty("mensagem")
	private String mensagem;

	@Expose
	@JsonProperty("status")
	private String status;

	public List<ClienteUnidadePasseLivre> getClientes() {
		return clientes;
	}

	public void setClientes(final List<ClienteUnidadePasseLivre> parClientes) {
		clientes = parClientes;
	}

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(final String parMensagem) {
		mensagem = parMensagem;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(final String parStatus) {
		status = parStatus;
	}

}
