package br.com.hermespardini.passelivre.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@SuppressWarnings("serial")
public class Profissionais extends ArrayList<Profissional> {
	public Profissionais() {
		super();
	}

	public Profissionais(final Collection<? extends Profissional> parProfissionai) {
		super(parProfissionai);
	}

	public final List<Profissional> getProfissionais() {
		return this;
	}

	public final void setProfissionais(final List<Profissional> parProfissionai) {
		this.addAll(parProfissionai);
	}
}
