package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.math.BigDecimal;

import org.wdelmaschio.base.model.ValueObject;

@SuppressWarnings("serial")
public class ConsultaPreparoResult extends ValueObject implements Serializable {

	private String comentarios;
	private String condicoes;
	private String conservacao;
	private String criteriosDeRejeicao;
	private String departamento;
	private String descricaoExame;
	private String descricaoMaterial;
	private String exame;
	private String examesRelacionados;
	private String marcacaoDiaria;
	private String material;
	private String mensagem;
	private String palavrasChaves;
	private String prazoExecucao;
	private BigDecimal precoParticular;
	private String questionario;
	private Integer ramalAreaTecnica;
	private String status;
	private String tempoJejum;
	private String volumeMinimo;
	private String volumeRecomendavel;
	private String instrucoes;
	private String lojasRealizam;
	private String necessitaAgendamento;

	public String getComentarios() {
		return comentarios;
	}

	public void setComentarios(final String parComentarios) {
		comentarios = parComentarios;
	}

	public String getCondicoes() {
		return condicoes;
	}

	public void setCondicoes(final String parCondicoes) {
		condicoes = parCondicoes;
	}

	public String getConservacao() {
		return conservacao;
	}

	public void setConservacao(final String parConservacao) {
		conservacao = parConservacao;
	}

	public String getCriteriosDeRejeicao() {
		return criteriosDeRejeicao;
	}

	public void setCriteriosDeRejeicao(final String parCriteriosDeRejeicao) {
		criteriosDeRejeicao = parCriteriosDeRejeicao;
	}

	public String getDepartamento() {
		return departamento;
	}

	public void setDepartamento(final String parDepartamento) {
		departamento = parDepartamento;
	}

	public String getDescricaoExame() {
		return descricaoExame;
	}

	public void setDescricaoExame(final String parDescricaoExame) {
		descricaoExame = parDescricaoExame;
	}

	public String getDescricaoMaterial() {
		return descricaoMaterial;
	}

	public void setDescricaoMaterial(final String parDescricaoMaterial) {
		descricaoMaterial = parDescricaoMaterial;
	}

	public String getExame() {
		return exame;
	}

	public void setExame(final String parExame) {
		exame = parExame;
	}

	public String getExamesRelacionados() {
		return examesRelacionados;
	}

	public void setExamesRelacionados(final String parExamesRelacionados) {
		examesRelacionados = parExamesRelacionados;
	}

	public String getMarcacaoDiaria() {
		return marcacaoDiaria;
	}

	public void setMarcacaoDiaria(final String parMarcacaoDiaria) {
		marcacaoDiaria = parMarcacaoDiaria;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(final String parMaterial) {
		material = parMaterial;
	}

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(final String parMensagem) {
		mensagem = parMensagem;
	}

	public String getPalavrasChaves() {
		return palavrasChaves;
	}

	public void setPalavrasChaves(final String parPalavrasChaves) {
		palavrasChaves = parPalavrasChaves;
	}

	public String getPrazoExecucao() {
		return prazoExecucao;
	}

	public void setPrazoExecucao(final String parPrazoExecucao) {
		prazoExecucao = parPrazoExecucao;
	}

	public BigDecimal getPrecoParticular() {
		return precoParticular;
	}

	public void setPrecoParticular(final BigDecimal parPrecoParticular) {
		precoParticular = parPrecoParticular;
	}

	public String getQuestionario() {
		return questionario;
	}

	public void setQuestionario(final String parQuestionario) {
		questionario = parQuestionario;
	}

	public Integer getRamalAreaTecnica() {
		return ramalAreaTecnica;
	}

	public void setRamalAreaTecnica(final Integer parRamalAreaTecnica) {
		ramalAreaTecnica = parRamalAreaTecnica;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(final String parStatus) {
		status = parStatus;
	}

	public String getTempoJejum() {
		return tempoJejum;
	}

	public void setTempoJejum(final String parTempoJejum) {
		tempoJejum = parTempoJejum;
	}

	public String getVolumeMinimo() {
		return volumeMinimo;
	}

	public void setVolumeMinimo(final String parVolumeMinimo) {
		volumeMinimo = parVolumeMinimo;
	}

	public String getVolumeRecomendavel() {
		return volumeRecomendavel;
	}

	public void setVolumeRecomendavel(final String parVolumeRecomendavel) {
		volumeRecomendavel = parVolumeRecomendavel;
	}

	public String getInstrucoes() {
		return instrucoes != null ? instrucoes.replace("\\n", "") : instrucoes;
	}

	public void setInstrucoes(String instrucoes) {
		this.instrucoes = instrucoes;
	}

	public String getLojasRealizam() {
		return lojasRealizam;
	}

	public void setLojasRealizam(String lojasRealizam) {
		this.lojasRealizam = lojasRealizam;
	}

	public String getNecessitaAgendamento() {
		return necessitaAgendamento;
	}

	public void setNecessitaAgendamento(String necessitaAgendamento) {
		this.necessitaAgendamento = necessitaAgendamento;
	}

}
