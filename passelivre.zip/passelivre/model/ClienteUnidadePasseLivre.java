package br.com.hermespardini.passelivre.model;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.wdelmaschio.base.model.ValueObject;
import org.wdelmaschio.base.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.exception.SenhaDefinitivaException;
import br.com.hermespardini.passelivre.login.ValidacaoSenha;
import br.com.hermespardini.passelivre.utils.Util;

@SuppressWarnings("serial")
public class ClienteUnidadePasseLivre extends ValueObject {

	@Expose
	@SerializedName("id")
	@JsonProperty("id")
	private String id;

	private String senhaUsuario;

	@Expose
	@SerializedName("clienteId")
	@JsonProperty("clienteId")
	private String codigoCliente;

	@Expose
	@SerializedName("streetAndComplement")
	@JsonProperty("streetAndComplement")
	private String endereco;

	@Expose
	@SerializedName("city")
	@JsonProperty("city")
	private String cidade;

	@Expose
	@SerializedName("postalCode")
	@JsonProperty("postalCode")
	private String cep;

	@Expose
	private String uf;

	@Expose
	@SerializedName("homePhoneNumber")
	@JsonProperty("homePhoneNumber")
	private String telefone;

	@Expose
	@SerializedName("mobilePhoneNumber")
	@JsonProperty("mobilePhoneNumber")
	private String celular;

	@Expose
	@SerializedName("cpf")
	@JsonProperty("cpf")
	private String cpf;

	@Expose
	@SerializedName("neighbourhood")
	@JsonProperty("neighbourhood")
	private String bairro;

	private String dataCadastro;

	@Expose
	@SerializedName("birthDate")
	@JsonProperty("birthDate")
	private String dataNascimento;

	@Expose
	@SerializedName("gender")
	@JsonProperty("gender")
	private String sexo;

	@Expose
	private String estadoCivil;
	@Expose
	private String nacionalidade;

	@Expose
	@SerializedName("fullName")
	@JsonProperty("fullName")
	private String nomeCliente;

	@Expose
	private String email;
	@Expose
	private String logradouro;

	@Expose
	@SerializedName("numberStreet")
	@JsonProperty("numberStreet")
	private String numero;

	@Expose
	@SerializedName("complement")
	@JsonProperty("complement")
	private String complemento;

	@Expose
	private String tipoLogradouro;

	@Expose
	@SerializedName("motherName")
	@JsonProperty("motherName")
	private String nomeMae;

	@Expose
	@SerializedName("type")
	@JsonProperty("type")
	private String tipo;

	@Expose
	private String operadora;

	@Expose
	@SerializedName("street")
	@JsonProperty("street")
	private String rua;

	@Expose
	private String unidade;

	@Expose
	private String currentPass;

	@Expose
	private String newPass;

	@Expose
	private String newPassConfirm;

	@Expose
	@SerializedName("temporaryPassword")
	@JsonProperty("temporaryPassword")
	private String senhaTemporaria;

	public ClienteUnidadePasseLivre(final UserAuth parUser,
			final ClienteUnidadePasseLivre parClienteUnidadePasseLivre) {
		currentPass = parUser.getAuthPass();
		newPass = parUser.getNewPass();
		id = parClienteUnidadePasseLivre.getId();
	}

	public ClienteUnidadePasseLivre(final String novaSenha,
			final ClienteUnidadePasseLivre parClienteUnidadePasseLivre) {
		currentPass = parClienteUnidadePasseLivre.getCurrentPass();
		newPass = novaSenha;
		id = parClienteUnidadePasseLivre.getId();
	}

	public ClienteUnidadePasseLivre() {

	}

	public String retirarCaracteriosInvalidosNoComplemento() {
		if (complemento != null) {
			return complemento.replace("/", " ");
		} else {
			return "";
		}
	}

	public String retornarNumeroValido() {
		if (numero != null && (possuiApenasZero() || numero.isEmpty())) {
			return "sn";
		} else {
			return retirarZeroAEsquerda();
		}
	}

	private String retirarZeroAEsquerda() {
		if (StringUtils.isNumeric(numero)) {
			numero = Integer.toString(Integer.parseInt(numero));
		}
		return numero;
	}

	private boolean possuiApenasZero() {
		return StringUtils.countMatches(numero, "0") == numero.length();
	}

	public String getLogradouro() {
		return logradouro != null ? logradouro.toUpperCase() : logradouro;
	}

	public String getNumero() {
		return numero != null ? numero.toUpperCase() : numero;
	}

	public String getComplemento() {
		return complemento != null ? complemento.toUpperCase() : complemento;
	}

	public String getTipoLogradouro() {
		return tipoLogradouro != null ? tipoLogradouro.toUpperCase() : tipoLogradouro;
	}

	public String getNomeMae() {
		return nomeMae != null ? nomeMae.toUpperCase() : nomeMae;
	}

	public void setLogradouro(final String logradouro) {
		this.logradouro = logradouro;
	}

	public void setNumero(final String numero) {
		this.numero = numero;
	}

	public void setComplemento(final String complemento) {
		this.complemento = complemento;
	}

	public void setTipoLogradouro(final String tipoLogradouro) {
		this.tipoLogradouro = tipoLogradouro;
	}

	public void setNomeMae(final String nomeMae) {
		this.nomeMae = nomeMae;
	}

	public Boolean isClienteNotNull() {
		return this != null;
	}

	public Boolean isNumeroNull() {
		return StringUtils.isEmpty(getNumero()) || getNumero() == null || StringUtils.isBlank(getNumero());
	}

	public Boolean isEnderecoNull() {
		return getEndereco() == null || StringUtils.isEmpty(getEndereco()) || StringUtils.isBlank(getEndereco());
	}

	public Boolean isCepValido() {
		return getCep().replace("-", "").length() == 8;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(final String tipo) {
		this.tipo = tipo;
	}

	public void verificarCamposEmBranco() throws RegraNegocioException {
		verificarSeNomeEstaVazio();
		verificarSeNomeMaeEstaVazio();
		verificarSeCpfEstaVazio();
		verificarSeDataNascimentoEstaVazio();
		verificarSeLogradouroEstaVazio();
		verificarSeCepEstaVazio();
		verificarSeCepEValido();
		verificarSeCidadeEstaVazio();
		verificarSeUfEstaVazio();
		verificarSeEmailEstaVazio();
		verificarSeSexoEstaVazio();
	}

	public void verificarCamposEmBrancoAoAtualizar() throws Exception {
		verificarSeNomeEstaVazio();
		verificarSeNomeMaeEstaVazio();
		verificarSeDataNascimentoEstaVazio();
		verificarSeCepEstaVazio();
		verificarSeCepEValido();
		verificarSeLogradouroEstaVazio();
		verificarSeBairroEstaVazio();
		verificarSeNumeroEstaVazio();
		verificarSeCidadeEstaVazio();
		verificarSeUfEstaVazio();
		verificarSeSexoEstaVazio();
		verificarSeEmailEstaVazio();
	}

	private void verificarSeLogradouroEstaVazio() throws RegraNegocioException {
		if (isLogradouroNull()) {
			throw new RegraNegocioException("Campo endereo não pode ser vazio!");
		}
	}

	private void verificarSeBairroEstaVazio() throws RegraNegocioException {
		if (isBairroNull()) {
			throw new RegraNegocioException("Campo bairro não pode ser vazio!");
		}
	}

	private void verificarSeEnderecoEstaVazio() throws RegraNegocioException {
		if (isEnderecoNull()) {
			throw new RegraNegocioException("Campo endereo não pode ser vazio!");
		}
	}

	private void verificarSeNomeMaeEstaVazio() throws RegraNegocioException {
		if (isMaeNull()) {
			throw new RegraNegocioException("Campo nome me não pode ser vazio!");
		}
	}

	private Boolean isLogradouroNull() {
		return StringUtils.isEmpty(getLogradouro()) || getLogradouro() == null || StringUtils.isBlank(getLogradouro());
	}

	public Boolean isBairroNull() {
		return getBairro() == null || StringUtils.isEmpty(getBairro()) || StringUtils.isBlank(getBairro());
	}

	private boolean isMaeNull() {
		return StringUtils.isEmpty(getNomeMae()) || getNomeMae() == null || StringUtils.isBlank(getNomeMae());
	}

	private void verificarSeNumeroEstaVazio() throws RegraNegocioException {
		if (isNumeroNull()) {
			throw new RegraNegocioException("Campo número não pode ser vazio!");
		}
	}

	public Boolean isNomeNull() {
		return StringUtils.isEmpty(getNomeCliente()) || getNomeCliente() == null
				|| StringUtils.isBlank(getNomeCliente());
	}

	public Boolean isCpfNull() {
		return StringUtils.isEmpty(getCpf()) || getCpf() == null || StringUtils.isBlank(getCpf());
	}

	public Boolean isDataNascimentoNull() {
		return StringUtils.isEmpty(getDataNascimento()) || getDataNascimento() == null
				|| StringUtils.isBlank(getDataNascimento());
	}

	public Boolean isCepNull() {
		return StringUtils.isEmpty(getCep()) || getCep() == null || StringUtils.isBlank(getCep());
	}

	public Boolean isCidadeNull() {
		return StringUtils.isEmpty(getCidade()) || getCidade() == null || StringUtils.isBlank(getCidade());
	}

	public Boolean isUfNull() {
		return StringUtils.isEmpty(getUf()) || getUf() == null || StringUtils.isBlank(getUf());
	}

	public Boolean isTelefoneNull() {
		return StringUtils.isEmpty(getTelefone()) || getTelefone() == null || StringUtils.isBlank(getTelefone());
	}

	public Boolean isCelularNull() {
		return StringUtils.isEmpty(getCelular()) || getCelular() == null || StringUtils.isBlank(getCelular());
	}

	public Boolean isEmailNull() {
		return StringUtils.isEmpty(getEmail()) || getEmail() == null || StringUtils.isBlank(getEmail());
	}

	public Boolean isSexoNull() {
		return StringUtils.isEmpty(getSexo()) || getSexo() == null || StringUtils.isBlank(getSexo());
	}

	private void verificarSeSexoEstaVazio() throws RegraNegocioException {
		if (isSexoNull()) {
			throw new RegraNegocioException("Campo gênero no pode ser vazio!");
		}
	}

	private void verificarSeEmailEstaVazio() throws RegraNegocioException {
		if (isEmailNull()) {
			throw new RegraNegocioException(
					"Campo email não pode ser vazio! \nEsta informação é obrigatória por motivos de segurança. \nO endereço de e-mail será utilizado somente para integração com o sistema. ");
		}
	}

	private void verificarSeUfEstaVazio() throws RegraNegocioException {
		if (isUfNull()) {
			throw new RegraNegocioException("Campo uf não pode ser vazio!");
		}
	}

	private void verificarSeCidadeEstaVazio() throws RegraNegocioException {
		if (isCidadeNull()) {
			throw new RegraNegocioException("Campo cidade não pode ser vazio!");
		}
	}

	private void verificarSeCepEstaVazio() throws RegraNegocioException {
		if (isCepNull()) {
			throw new RegraNegocioException("Campo CEP não pode ser vazio!");
		}
	}

	private void verificarSeCepEValido() throws RegraNegocioException {
		if (!isCepValido()) {
			throw new RegraNegocioException("Campo CEP precisa ter um valor válido de 8 dgitos!");
		}
	}

	private void verificarSeDataNascimentoEstaVazio() throws RegraNegocioException {
		if (isDataNascimentoNull()) {
			throw new RegraNegocioException("Campo data nascimento não pode ser vazio!");
		}
		Date dataDascimento = null;
		try {
			dataDascimento = new Date().parseDate("dd/MM/yyyy", getDataNascimento());
		} catch (Exception e) {
		}
		if (dataDascimento != null && dataDascimento.after(new Date())) {
			throw new RegraNegocioException("Campo data nascimento não pode ser maior que a data atual!");
		}
	}

	private void verificarSeCpfEstaVazio() throws RegraNegocioException {
		if (isCpfNull()) {
			throw new RegraNegocioException("Campo cpf não pode ser vazio!");
		}
	}

	private void verificarSeNomeEstaVazio() throws RegraNegocioException {
		if (isNomeNull()) {
			throw new RegraNegocioException("Campo nome não pode ser vazio!");
		}
	}

	public void verificarSeSenhaTemporaria() throws SenhaDefinitivaException {
		if (isSenhaTemporaria()) {
			throw new SenhaDefinitivaException("Usuário possui senha temporária, favor criar senha definitiva");
		}
	}

	public boolean isEmailValid() {
		if (isEmailNull()) {
			return false;
		}
		final String emailPattern = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
		final Pattern pattern = Pattern.compile(emailPattern, Pattern.CASE_INSENSITIVE);
		final Matcher matcher = pattern.matcher(getEmail());
		return matcher.matches();
	}

	public void validarEmail() throws Exception {
		if (!isEmailValid()) {
			throw new RegraNegocioException("Email não é válido!");
		}
	}
	
	public void validarSenhas() throws Exception {
		ValidacaoSenha.validaSenhasDigitadas(getNewPass(), getNewPassConfirm());
  }

	public void validarCpfComIdade() throws RegraNegocioException {
		if (!isDataNascimentoNull() && isCpfNull() && Util.retornaIdade(getDataNascimentoFormatada()) > 12) {
			this.cpf = null;
			throw new RegraNegocioException("Para maiores de 12 anos, o CPF é obrigatrio!");
		}
	}

	public void validarTelefone() throws RegraNegocioException {
		if (isTelefoneNull() || getTelefone().length() < 10) {
			throw new RegraNegocioException("Tamanho mínimo do telefone é 10!");
		}
	}

	public void validarCelular() throws RegraNegocioException {
		if (isCelularNull() || getCelular().length() < 11) {
			throw new RegraNegocioException("Tamanho mínimo do celular é 11!");
		}
	}

	public String getOperadora() {
		return operadora;
	}

	public void setOperadora(final String parOperadora) {
		operadora = parOperadora;
	}

	public String getRua() {
		return rua;
	}

	public void setRua(final String parRua) {
		rua = parRua;
	}

	public String getUnidade() {
		return unidade;
	}

	public void setUnidade(final String parUnidade) {
		unidade = parUnidade;
	}

	public String getCurrentPass() {
		return currentPass;
	}

	public String getNewPass() {
		return newPass;
	}

	public void setCurrentPass(final String parCurrentPass) {
		currentPass = parCurrentPass;
	}

	public void setNewPass(final String parNewPass) {
		newPass = parNewPass;
	}

	public String getNewPassConfirm() {
		return newPassConfirm;
	}

	public void setNewPassConfirm(String newPassConfirm) {
		this.newPassConfirm = newPassConfirm;
	}

	public String getId() {
		return id;
	}

	public void setId(final String parId) {
		id = parId;
	}

	public String getSenhaUsuario() {
		return senhaUsuario;
	}

	public void setSenhaUsuario(final String parSenhaUsuario) {
		senhaUsuario = parSenhaUsuario;
	}

	public String getCodigoCliente() {
		return codigoCliente;
	}

	public void setCodigoCliente(final String parCodigoCliente) {
		codigoCliente = parCodigoCliente;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(final String parEndereco) {
		endereco = parEndereco;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(final String parCidade) {
		cidade = parCidade;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(final String parCep) {
		cep = parCep;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(final String parUf) {
		uf = parUf;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(final String parTelefone) {
		telefone = parTelefone;
	}

	public String getCelular() {
		return celular;
	}

	public void setCelular(final String parCelular) {
		celular = parCelular;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(final String parCpf) {
		cpf = parCpf;
	}

	public String getBairro() {
		if (bairro != null && bairro.length() > 30) {
			return bairro.substring(0, 29);
		} else {
			return bairro;
		}
	}

	public void setBairro(final String parBairro) {
		bairro = parBairro;
	}

	public String getDataCadastro() {
		return dataCadastro;
	}

	public void setDataCadastro(final String parDataCadastro) {
		dataCadastro = parDataCadastro;
	}

	public String getDataNascimentoFormatada() {
		if (isDataNascimentoNull())
			return "";
		return Util.localDateToString(Util.stringToLocalDateCustomPattern(this.dataNascimento, "yyyy-MM-dd"),
				"dd/MM/yyyy");
	}

	public String getDataNascimento() {
		return dataNascimento;
	}

	public void setDataNascimento(final String parDataNascimento) {
		dataNascimento = parDataNascimento;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(final String parSexo) {
		sexo = parSexo;
	}

	public String getEstadoCivil() {
		return estadoCivil;
	}

	public void setEstadoCivil(final String parEstadoCivil) {
		estadoCivil = parEstadoCivil;
	}

	public String getNacionalidade() {
		return nacionalidade;
	}

	public void setNacionalidade(final String parNacionalidade) {
		nacionalidade = parNacionalidade;
	}

	public String getNomeCliente() {
		return nomeCliente;
	}

	public void setNomeCliente(final String parNomeCliente) {
		nomeCliente = parNomeCliente;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(final String parEmail) {
		email = parEmail;
	}

	public String getSenhaTemporaria() {
		return senhaTemporaria;
	}

	public void setSenhaTemporaria(String senhaTemporaria) {
		this.senhaTemporaria = senhaTemporaria;
	}

	public boolean isSenhaTemporaria() {
		return "1".equals(getSenhaTemporaria());
	}

	public void limparCamposEndereco() {
		setUf("");
		setEndereco("");
		setBairro("");
		setCidade("");
		setUf("");
		setLogradouro("");
		setNumero("");
		setComplemento("");
	}

}
