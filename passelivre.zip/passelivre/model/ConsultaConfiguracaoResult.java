package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

public class ConsultaConfiguracaoResult implements Serializable {

	private String mensagem;
	private String status;
	private Totens totens;

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(final String parMensagem) {
		mensagem = parMensagem;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(final String parStatus) {
		status = parStatus;
	}

	public Totens getTotens() {
		return totens;
	}

	public void setTotens(final Totens parTotens) {
		totens = parTotens;
	}

}
