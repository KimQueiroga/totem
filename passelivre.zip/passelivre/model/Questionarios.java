package br.com.hermespardini.passelivre.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@SuppressWarnings("serial")
public class Questionarios extends ArrayList<Questionario> {

	public Questionarios() {
		super();
	}

	public Questionarios(final Collection<? extends Questionario> parQuestionario) {
		super(parQuestionario);
	}

	public final List<Questionario> getQuestionarios() {
		return this;
	}

	public final void setQuestionarios(final List<Questionario> parQuestionarios) {
		this.addAll(parQuestionarios);
	}
}
