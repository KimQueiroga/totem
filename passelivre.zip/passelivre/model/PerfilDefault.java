package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

public class PerfilDefault implements Serializable {
	private String ativo;
	private String dataHoraUltAtualizacao;
	private String descricao;
	private Long id;
	private String nome;
	private String tipo;
	private String usuUltAtualizacao;

	public String getAtivo() {
		return ativo;
	}

	public void setAtivo(final String parAtivo) {
		ativo = parAtivo;
	}

	public String getDataHoraUltAtualizacao() {
		return dataHoraUltAtualizacao;
	}

	public void setDataHoraUltAtualizacao(final String parDataHoraUltAtualizacao) {
		dataHoraUltAtualizacao = parDataHoraUltAtualizacao;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(final String parDescricao) {
		descricao = parDescricao;
	}

	public Long getId() {
		return id;
	}

	public void setId(final Long parId) {
		id = parId;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(final String parNome) {
		nome = parNome;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(final String parTipo) {
		tipo = parTipo;
	}

	public String getUsuUltAtualizacao() {
		return usuUltAtualizacao;
	}

	public void setUsuUltAtualizacao(final String parUsuUltAtualizacao) {
		usuUltAtualizacao = parUsuUltAtualizacao;
	}
}
