package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

public class Composicao implements Serializable {

	private String dataHoraMarcacao;
	private String descricaoExame;
	private String descricaoMaterial;
	private String exame;
	private String material;

	public String getDataHoraMarcacao() {
		return dataHoraMarcacao;
	}

	public void setDataHoraMarcacao(final String parDataHoraMarcacao) {
		dataHoraMarcacao = parDataHoraMarcacao;
	}

	public String getDescricaoExame() {
		return descricaoExame;
	}

	public void setDescricaoExame(final String parDescricaoExame) {
		descricaoExame = parDescricaoExame;
	}

	public String getDescricaoMaterial() {
		return descricaoMaterial;
	}

	public void setDescricaoMaterial(final String parDescricaoMaterial) {
		descricaoMaterial = parDescricaoMaterial;
	}

	public String getExame() {
		return exame;
	}

	public void setExame(final String parExame) {
		exame = parExame;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(final String parMaterial) {
		material = parMaterial;
	}
}
