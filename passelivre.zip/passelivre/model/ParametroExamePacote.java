package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.util.Date;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.utils.DataUtil;

public class ParametroExamePacote implements Serializable {

	private String operadora;
	private String empresa;
	private String material;
	private String exame;
	private String idadePaciente;
	private String generoPaciente;
	private String dataReferencia;
	private String token;
	private String origem;

	private ParametroExamePacote(final DetalhePreparacao parDetalhePreparacao, final TokenResult parTokenResult) {
		operadora = Constantes.OPERADORA_PARTICULAR;
		empresa = Constantes.EMPRESA;
		material = parDetalhePreparacao.getMaterialId();
		exame = retornarExame(parDetalhePreparacao);
		token = parTokenResult.getToken();
		origem = Constantes.ORIGEM_PADRAO;
		dataReferencia = retornarDataAtual();
	}

	public static ParametroExamePacote criarParametrosParaRetornarExamesFilhos(
			final DetalhePreparacao parDetalhePreparacao, final TokenResult parTokenResult) {
		return new ParametroExamePacote(parDetalhePreparacao, parTokenResult);
	}

	private String retornarDataAtual() {
		try {
			return new DataUtil().formatarDateParaString(new Date());
		} catch (final Exception locExc) {
			return "";
		}
	}

	private String retornarExame(final DetalhePreparacao parDetalhePreparacao) {
		try {
			return parDetalhePreparacao.getId().substring(parDetalhePreparacao.getId().indexOf("||") + 2,
					parDetalhePreparacao.getId().length());
		} catch (final Exception locExc) {
			return "";
		}

	}

	public String getOperadora() {
		return operadora;
	}

	public void setOperadora(final String parOperadora) {
		operadora = parOperadora;
	}

	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(final String parEmpresa) {
		empresa = parEmpresa;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(final String parMaterial) {
		material = parMaterial;
	}

	public String getExame() {
		return exame;
	}

	public void setExame(final String parExame) {
		exame = parExame;
	}

	public String getIdadePaciente() {
		return idadePaciente;
	}

	public void setIdadePaciente(final String parIdadePaciente) {
		idadePaciente = parIdadePaciente;
	}

	public String getGeneroPaciente() {
		return generoPaciente;
	}

	public void setGeneroPaciente(final String parGeneroPaciente) {
		generoPaciente = parGeneroPaciente;
	}

	public String getDataReferencia() {
		return dataReferencia;
	}

	public void setDataReferencia(final String parDataReferencia) {
		dataReferencia = parDataReferencia;
	}

	public String getToken() {
		return token;
	}

	public void setToken(final String parToken) {
		token = parToken;
	}

	public String getOrigem() {
		return origem;
	}

	public void setOrigem(final String parOrigem) {
		origem = parOrigem;
	}

}
