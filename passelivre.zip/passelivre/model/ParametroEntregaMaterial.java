package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.utils.DataUtil;
import br.com.hermespardini.passelivre.utils.TotemUtil;

@SuppressWarnings("serial")
public class ParametroEntregaMaterial implements Serializable {

	private String empresa;
	private String pedido;
	private String unidade;
	private String dataColeta;
	private String horaColeta;
	private String localEntrega;
	private String token;
	private Timestamp marcacao;
	private String origem;
	private String unidadeEntrega;
	private String tipoImpressao;
	private ExamesEntrega exames;

	public ParametroEntregaMaterial(final ExameMaterialPendente parExameMaterialPendente,
			final List<InformacaoTotem> parInformacoesTotem, final ParametroEntregaMaterial parPedidoEntrega) {
	}

	public ParametroEntregaMaterial(final ExameMaterialPendente parExameMaterialPendente,
			final List<InformacaoTotem> parInformacoesTotem, final TokenResult parTokenResult) {
		setEmpresa(parExameMaterialPendente.getEmpresa());
		setMarcacao(parExameMaterialPendente.getMarcacao());
		setUnidade(parExameMaterialPendente.getUnidade());
		setPedido(parExameMaterialPendente.getPedido());
		setDataColeta(parExameMaterialPendente.getDataColeta());
		setHoraColeta(parExameMaterialPendente.getHoraColeta());
		setLocalEntrega(parInformacoesTotem.get(0).getLocalImpressao());
		setToken(parTokenResult.getToken());
		setTipoImpressao(parExameMaterialPendente.getTipoImpressao());
		setUnidadeEntrega(parInformacoesTotem.get(0).getIdUnidade());
		setOrigem(parExameMaterialPendente.getOrigem());

	}

	public ParametroEntregaMaterial(final ExameMaterialPendente parExameMaterialPendente,
			final TokenResult parTokenResult, final Long idUnidade, final Long idLocalizacao) {
		setEmpresa(parExameMaterialPendente.getEmpresa());
		setMarcacao(parExameMaterialPendente.getMarcacao());
		setUnidade(parExameMaterialPendente.getUnidade());
		setPedido(parExameMaterialPendente.getPedido());
		setDataColeta(parExameMaterialPendente.getDataColeta());
		setHoraColeta(parExameMaterialPendente.getHoraColeta());
		setLocalEntrega(idLocalizacao.toString());
		setToken(parTokenResult.getToken());
		setTipoImpressao(parExameMaterialPendente.getTipoImpressao());
		setUnidadeEntrega(idUnidade.toString());
		setOrigem(parExameMaterialPendente.getOrigem());

	}

	public ParametroEntregaMaterial(final ParametroEntregaMaterial parValue,
			final List<ConsultaQuestionarioExameResult> parQuestionariosExamesResult,
			final List<InformacaoTotem> parInformacoesTotem, final List<PerguntaEntrega> parPerguntas,
			final TokenResult parTokenResult) {
		setEmpresa(parValue.getEmpresa());
		setUnidade(parValue.getUnidade());
		setMarcacao(parValue.getMarcacao());
		setPedido(parValue.getPedido());
		setDataColeta(parValue.getDataColeta());
		setHoraColeta(parValue.getHoraColeta());
		setLocalEntrega(parInformacoesTotem.get(0).getLocalImpressao());
		setToken(parTokenResult.getToken());
		setTipoImpressao(parValue.getTipoImpressao());
		setUnidadeEntrega(parInformacoesTotem.get(0).getIdUnidade());
		setOrigem(Constantes.ORIGEM_PADRAO);
		exames = new ExamesEntrega();
		for (final ExameEntrega locExameEntrega : parValue.getExames()) {
			exames.add(new ExameEntrega(locExameEntrega, parQuestionariosExamesResult, parPerguntas));
		}
	}

	public ParametroEntregaMaterial(final ParametroEntregaMaterial material,
			final List<ConsultaQuestionarioExameResult> parQuestionariosExamesResult,
			final List<PerguntaEntrega> parPerguntas, final TokenResult parTokenResult, final Long idUnidade,
			final Long idLocalizacao) {
		setEmpresa(material.getEmpresa());
		setUnidade(material.getUnidade());
		setMarcacao(material.getMarcacao());
		setPedido(material.getPedido());
		setDataColeta(material.getDataColeta());
		setHoraColeta(material.getHoraColeta());
		setLocalEntrega(idLocalizacao.toString());
		setToken(parTokenResult.getToken());
		setTipoImpressao(material.getTipoImpressao());
		setUnidadeEntrega(idUnidade.toString());
		setOrigem(Constantes.ORIGEM_PADRAO);
		exames = new ExamesEntrega();
		for (final ExameEntrega locExameEntrega : material.getExames()) {
			exames.add(new ExameEntrega(locExameEntrega, parQuestionariosExamesResult, parPerguntas));
		}
	}

	private ParametroEntregaMaterial(final CriarPedidoResult parCriaPedidoResult, final TokenResult parTokenResult,
			final InformacaoTotem parInformacaoTotem, final DetalhePreparacao parDetalhePreparacao,
			final EPacoteResult parEPacoteResult,
			final List<ConsultaQuestionarioExameResult> parQuestionariosExamesResult,
			final List<PerguntaEntrega> parPerguntas) {
		// empresa = TotemUtil.buscarSiglaEmpresa();
		empresa = Constantes.EMPRESA;
		unidade = parInformacaoTotem.getIdUnidade();
		pedido = parCriaPedidoResult.getPedido().toString();
		token = parTokenResult.getToken();
		localEntrega = parInformacaoTotem.getLocalImpressao();
		dataColeta = retornarDataColeta();
		marcacao = null;
		horaColeta = retornarHoraColta();
		unidadeEntrega = parInformacaoTotem.getIdUnidade();
		tipoImpressao = Constantes.TIPO_IMPRESSAO_DEFAULT;
		origem = Constantes.ORIGEM_PADRAO;
		exames = new ExamesEntrega();
		for (final Composicao parComposicao : parEPacoteResult.getComposicao()) {
			exames.add(new ExameEntrega(parComposicao, parQuestionariosExamesResult, parPerguntas));
		}
	}

	private String retornarHoraColta() {
		try {
			return new DataUtil().retornarApenasHora(new Date());
		} catch (final Exception locExc) {
			return "";
		}
	}

	private String retornarDataColeta() {
		try {
			return new DataUtil().formatarDateParaString(new Date());
		} catch (final Exception locExc) {
			return "";
		}
	}

	public static ParametroEntregaMaterial criarParametroEntregaParaPagamento(
			final CriarPedidoResult parCriaPedidoResult, final TokenResult parTokenResult,
			final InformacaoTotem parInformacaoTotem, final DetalhePreparacao parDetalhePreparacao,
			final EPacoteResult parEPacoteResult,
			final List<ConsultaQuestionarioExameResult> parQuestionariosExamesResult,
			final List<PerguntaEntrega> parPerguntas) {
		return new ParametroEntregaMaterial(parCriaPedidoResult, parTokenResult, parInformacaoTotem,
				parDetalhePreparacao, parEPacoteResult, parQuestionariosExamesResult, parPerguntas);
	}

	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(final String parEmpresa) {
		empresa = parEmpresa;
	}

	public String getUnidade() {
		return unidade;
	}

	public void setUnidade(final String parUnidade) {
		unidade = parUnidade;
	}

	public String getPedido() {
		return pedido;
	}

	public void setPedido(final String parPedido) {
		pedido = parPedido;
	}

	public String getDataColeta() {
		return dataColeta;
	}

	public void setDataColeta(final String parDataColeta) {
		dataColeta = parDataColeta;
	}

	public String getHoraColeta() {
		return horaColeta;
	}

	public void setHoraColeta(final String parHoraColeta) {
		horaColeta = parHoraColeta;
	}

	public String getLocalEntrega() {
		return localEntrega;
	}

	public void setLocalEntrega(final String parLocalEntrega) {
		localEntrega = parLocalEntrega;
	}

	public String getUnidadeEntrega() {
		return unidadeEntrega;
	}

	public void setUnidadeEntrega(final String parUnidadeEntrega) {
		unidadeEntrega = parUnidadeEntrega;
	}

	public String getTipoImpressao() {
		return tipoImpressao;
	}

	public void setTipoImpressao(final String parTipoImpressao) {
		tipoImpressao = parTipoImpressao;
	}

	public String getToken() {
		return token;
	}

	public void setToken(final String parToken) {
		token = parToken;
	}

	public String getOrigem() {
		return origem;
	}

	public void setOrigem(final String parOrigem) {
		origem = parOrigem;
	}

	public ExamesEntrega getExames() {
		return exames;
	}

	public void setExames(final ExamesEntrega parExames) {
		exames = parExames;
	}

	public Timestamp getMarcacao() {
		return marcacao;
	}

	public void setMarcacao(final Timestamp parMarcacao) {
		marcacao = parMarcacao;
	}

}
