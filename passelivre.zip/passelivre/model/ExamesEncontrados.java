package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

public class ExamesEncontrados implements Serializable {

	private static final long serialVersionUID = 1L;
	private String Exame;
	private String ExameServico;
	private String ID;
	private String IdModalidade;
	private String Material;
	private String Nome;
	private String TipoSearch;

	public String getExame() {
		return Exame;
	}

	public String getExameServico() {
		return ExameServico;
	}

	public String getIdModalidade() {
		return IdModalidade;
	}

	public String getMaterial() {
		return Material;
	}

	public String getNome() {
		return Nome;
	}

	public String getTipoSearch() {
		return TipoSearch;
	}

	public void setExame(String Exame) {
		this.Exame = Exame;
	}

	public void setExameServico(String ExameServico) {
		this.ExameServico = ExameServico;
	}

	public void setIdModalidade(String IdModalidade) {
		this.IdModalidade = IdModalidade;
	}

	public void setMaterial(String Material) {
		this.Material = Material;
	}

	public void setNome(String Nome) {
		this.Nome = Nome;
	}

	public void setTipoSearch(String TipoSearch) {
		this.TipoSearch = TipoSearch;
	}

	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}
}
