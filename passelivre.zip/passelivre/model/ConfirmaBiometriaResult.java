package br.com.hermespardini.passelivre.model;

public class ConfirmaBiometriaResult {

	private String localCertificado;
	private String validacaoBiometrica;
	private String certificacao;

	public String getLocalCertificado() {
		return localCertificado;
	}

	public void setLocalCertificado(String localCertificado) {
		this.localCertificado = localCertificado;
	}

	public String getValidacaoBiometrica() {
		return validacaoBiometrica;
	}

	public void setValidacaoBiometrica(String validacaoBiometrica) {
		this.validacaoBiometrica = validacaoBiometrica;
	}

	public String getCertificacao() {
		return certificacao;
	}

	public void setCertificacao(String certificacao) {
		this.certificacao = certificacao;
	}
}
