package br.com.hermespardini.passelivre.model;

import br.com.hermespardini.passelivre.constantsenum.Constantes;

public class ParametroCancelaPedido {
	private String empresa;
	private String unidade;
	private String pedido;
	private String motivoExclusao;
	private String origem;
	private String token;
	private String usuario;

	public ParametroCancelaPedido(final InformacaoTotem parInformacaoTotem, final String parSessionId,
			final CriarPedidoResult parCriaPedidoResult, final String parMessage, final TokenResult parTokenReult) {
		empresa = Constantes.EMPRESA;
		unidade = parInformacaoTotem.getIdUnidade();
		origem = Constantes.ORIGEM_PADRAO;
		usuario = Constantes.USUARIO_PADRAO;
		pedido = parCriaPedidoResult.getPedido().toString();
		motivoExclusao = parMessage;
		token = parTokenReult.getToken();
	}

	public static ParametroCancelaPedido criarParametrosParaCancelarPedido(final InformacaoTotem parInformacaoTotem,
			final String parSessionId, final CriarPedidoResult parCriaPedidoResult, final String parMessage,
			final TokenResult parTokenReult) {
		return new ParametroCancelaPedido(parInformacaoTotem, parSessionId, parCriaPedidoResult, parMessage,
				parTokenReult);
	}

	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(final String parEmpresa) {
		empresa = parEmpresa;
	}

	public String getUnidade() {
		return unidade;
	}

	public void setUnidade(final String parUnidade) {
		unidade = parUnidade;
	}

	public String getPedido() {
		return pedido;
	}

	public void setPedido(final String parPedido) {
		pedido = parPedido;
	}

	public String getMotivoExclusao() {
		return motivoExclusao;
	}

	public void setMotivoExclusao(final String parMotivoExclusao) {
		motivoExclusao = parMotivoExclusao;
	}

	public String getOrigem() {
		return origem;
	}

	public void setOrigem(final String parOrigem) {
		origem = parOrigem;
	}

	public String getToken() {
		return token;
	}

	public void setToken(final String parToken) {
		token = parToken;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(final String parUsuario) {
		usuario = parUsuario;
	}

}
