package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

public class Success implements Serializable {

	private Message message;
	private String code;

	public Message getMessage() {
		return message;
	}

	public void setMessage(final Message parMessage) {
		message = parMessage;
	}

	public String getCode() {
		return code;
	}

	public void setCode(final String parCode) {
		code = parCode;
	}

}
