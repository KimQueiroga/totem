package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import org.wdelmaschio.base.model.ValueObject;

import br.com.hermespardini.corebusiness.util.SessionIdElement;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;

@XmlAccessorType(XmlAccessType.FIELD)
@SessionIdElement(separator = "-")
public class InformacaoTotem extends ValueObject implements Serializable {

	private static final long serialVersionUID = 1L;
	@SessionIdElement(order = 1)
	private Long id;
	private Long idService;
	private String ip;
	@SessionIdElement(order = 2)
	private String idUnidade;
	private String descricao;
	private String tipoImpressao;
	private String ativo;
	private String nomeUnd;
	private String localImpressao;
	private String impressoraDefault;
	private String numeroPatrimonio;
	private String leitorCodigoBarras;
	private String nomeEmpresa;
	private Long idEmpresa;
	private String cnesUnidade;
	private String ufUnidade;
	private String cidadeUnidade;
	private String impressoraIP;
	private String impressoraPorta;

	public InformacaoTotem(final Map<?, ?> pObjectMapping) {
		super(pObjectMapping);
	}

	public InformacaoTotem() {
	}

	public InformacaoTotem(final Totem parTotem, final Servico parServico) throws RegraNegocioException {
		ip = parTotem.getIp();
		id = parTotem.getIdTotem();
		nomeUnd = parTotem.getNomeUnidade();
		descricao = parServico.getDescricao();
		numeroPatrimonio = parTotem.getNumeroPatrimonio();
		impressoraDefault = parTotem.getImpressoraDefault();
		localImpressao = parTotem.getLocalImpressao().toString();
		tipoImpressao = parTotem.getTipoImpressao();
		idUnidade = parTotem.getIdUnidade().toString();
		ativo = verificarSeEstaAtivo(parServico);
		idService = parServico.getIdServico();
		leitorCodigoBarras = parTotem.getLeitorCodigoBarras();
		nomeEmpresa = parTotem.getNomeEmpresa();
		idEmpresa = parTotem.getIdEmpresa();
		cnesUnidade = parTotem.getCnesUnidade();
		impressoraIP = parTotem.getImpressoraIP();
		impressoraPorta = parTotem.getImpressoraPorta();
		ufUnidade = parTotem.getUfUnidade();
	}

	private String verificarSeEstaAtivo(final Servico parServico) {
		try {
			if (parServico.getAtivo().equals("S") && ehHorarioDeFuncionamento(parServico)) {
				return "S";
			} else {
				return "N";
			}
		} catch (final Exception locExc) {
			return "N";
		}
	}

	private boolean ehHorarioDeFuncionamento(final Servico parServico) throws RegraNegocioException {
		try {
			final Calendar horaInicio = Calendar.getInstance();
			horaInicio.set(Calendar.HOUR_OF_DAY,
					Integer.parseInt(parServico.getHoraInicioFuncionamento().substring(0, 2)));
			horaInicio.set(Calendar.MINUTE, Integer.parseInt(parServico.getHoraInicioFuncionamento().substring(3, 5)));
			horaInicio.set(Calendar.SECOND, Integer.parseInt(parServico.getHoraInicioFuncionamento().substring(6, 8)));

			final Calendar horaFim = Calendar.getInstance();
			horaFim.set(Calendar.HOUR_OF_DAY, Integer.parseInt(parServico.getHoraFimFuncionamento().substring(0, 2)));
			horaFim.set(Calendar.MINUTE, Integer.parseInt(parServico.getHoraFimFuncionamento().substring(3, 5)));
			horaFim.set(Calendar.SECOND, Integer.parseInt(parServico.getHoraFimFuncionamento().substring(6, 8)));

			final Date horaAtual = new Date();

			final Date dataHoraInicio = horaInicio.getTime();
			final Date dataHoraFim = horaFim.getTime();

			return horaAtual.after(dataHoraInicio) && horaAtual.before(dataHoraFim);
		} catch (final Exception locExc) {
			throw new RegraNegocioException(locExc.getMessage());
		}
	}

	public boolean totemEstaAtivo() {
		return ativo.equals("S");
	}

	public Long getId() {
		return id;
	}

	public void setId(final Long parId) {
		id = parId;
	}

	public Long getIdService() {
		return idService;
	}

	public void setIdService(final Long parIdService) {
		idService = parIdService;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(final String parIp) {
		ip = parIp;
	}

	public String getIdUnidade() {
		return idUnidade;
	}

	public void setIdUnidade(final String parUnidade) {
		idUnidade = parUnidade;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(final String parDescricao) {
		descricao = parDescricao;
	}

	public String getTipoImpressao() {
		return tipoImpressao;
	}

	public void setTipoImpressao(final String parTipoImpressao) {
		tipoImpressao = parTipoImpressao;
	}

	public String getAtivo() {
		return ativo;
	}

	public void setAtivo(final String parAtivo) {
		ativo = parAtivo;
	}

	public String getNomeUnd() {
		return nomeUnd;
	}

	public void setNomeUnd(final String parNomeUnd) {
		nomeUnd = parNomeUnd;
	}

	public String getLocalImpressao() {
		return localImpressao;
	}

	public void setLocalImpressao(final String parLocalImpressao) {
		localImpressao = parLocalImpressao;
	}

	public String getImpressoraDefault() {
		return impressoraDefault;
	}

	public void setImpressoraDefault(final String parImpressoraDefault) {
		impressoraDefault = parImpressoraDefault;
	}

	public String getNumeroPatrimonio() {
		return numeroPatrimonio;
	}

	public void setNumeroPatrimonio(final String parNumeroPatrimonio) {
		numeroPatrimonio = parNumeroPatrimonio;
	}

	public String getLeitorCodigoBarras() {
		return leitorCodigoBarras;
	}

	public void setLeitorCodigoBarras(final String parLeitorCodigoBarras) {
		leitorCodigoBarras = parLeitorCodigoBarras;
	}

	public String getNomeEmpresa() {
		return nomeEmpresa;
	}

	public void setNomeEmpresa(String nomeEmpresa) {
		this.nomeEmpresa = nomeEmpresa;
	}

	public Long getIdEmpresa() {
		return idEmpresa;
	}

	public void setIdEmpresa(Long idEmpresa) {
		this.idEmpresa = idEmpresa;
	}

	public String getUfUnidade() {
		return ufUnidade;
	}

	public void setUfUnidade(String ufUnidade) {
		this.ufUnidade = ufUnidade;
	}

	public String getCidadeUnidade() {
		return cidadeUnidade;
	}

	public void setCidadeUnidade(String cidadeUnidade) {
		this.cidadeUnidade = cidadeUnidade;
	}

	public String getImpressoraIP() {
		return impressoraIP;
	}

	public void setImpressoraIP(String impressoraIP) {
		this.impressoraIP = impressoraIP;
	}

	public String getImpressoraPorta() {
		return impressoraPorta;
	}

	public void setImpressoraPorta(String impressoraPorta) {
		this.impressoraPorta = impressoraPorta;
	}

	public String getCnesUnidade() {
		return cnesUnidade;
	}

	public void setCnesUnidade(String cnesUnidade) {
		this.cnesUnidade = cnesUnidade;
	}

}
