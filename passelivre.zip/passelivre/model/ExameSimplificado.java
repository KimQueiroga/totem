package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import br.com.hermespardini.corebusiness.coreenum.EnumValueOfHelper;
import br.com.hermespardini.passelivre.to.ProcedimentoComExamesTO;
import br.gov.ans.www.padroes.tiss.schemas.Ct_itemSolicitacao;

public class ExameSimplificado implements Serializable {
		
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer idExameGuia;
	private String codigo;
	private String descricao;
	private String guia;
	private List<ExameHermesPardini> exames;
	private String observacao;
	private Integer quantidadeAutorizada;
	private Integer quantidadeSolicitada;
	private MotivosGlosas glosas;
	private String informacoesClinica;
	private Long idComposicao;
	private ExameHermesPardini exame;
	//private Ct_itemSolicitacao item;	
	//private ExamePreCalculado examePreCalculado;
	
	private TypeCalculo tipoCalculo;
	
	
	public enum TypeCalculo {
		INCLUI("Deseja incluir esse(s) exame(s) filho(s) na guia ?"), DESMEMBRA("Deseja desmembrar esse exame nos filhos acima ?"), SUBSTITUI("Deseja substituir esses exames da guia no pai acima ?");
		
		private String descricao;

		TypeCalculo(final String descricao) {
			this.descricao = descricao;
		}
		
		public static TypeCalculo valueOfDescricao(final String parDescricao) {
			return EnumValueOfHelper.valueOf(TypeCalculo.class, "descricao", parDescricao);
		}
		
		public String getDescricao() {
			return this.descricao;
		}

	}
	
	public ExameSimplificado() {
		
	}
	
	public ExameSimplificado(String codigo, String descricao, String material) {
		this.codigo = codigo;
		this.descricao = descricao;
		//this.examePreCalculado = new ExamePreCalculado(material, descricao, codigo, descricao);
	}
	
	public ExameSimplificado(String codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
		//this.examePreCalculado = new ExamePreCalculado(descricao, codigo, new BigDecimal(0));
	}
	
	public ExameSimplificado(String codigo, String descricao, Ct_itemSolicitacao item, TypeCalculo tipoCalculo) {
		this.codigo = codigo;
		this.descricao = descricao;
		//this.item = item;
		this.tipoCalculo = tipoCalculo;
		//this.examePreCalculado = new ExamePreCalculado(descricao, codigo, item.getQuantidadeAutorizada());
	}
	
	public ExameSimplificado(String codigo, String descricao, Ct_itemSolicitacao item, ExamePreCalculado examePreCalculado) {
		this.codigo = codigo;
		this.descricao = descricao;
		//this.item = item;
		//this.examePreCalculado = examePreCalculado;
	}

	public ExameSimplificado(ProcedimentoComExamesTO procedimento) {
		// TODO Auto-generated constructor stub
		this.codigo = procedimento.getProcedimento();
		this.descricao = procedimento.getExame().getDescricaoExame();
		this.exame = procedimento.getExame();
		this.exames = procedimento.getExames();
		this.quantidadeAutorizada = procedimento.getQuantidadeAutorizadas().intValue();
		this.quantidadeSolicitada = procedimento.getQuantidadeSolicitacadas().intValue();
		this.glosas = procedimento.getGlosas();
		this.informacoesClinica = procedimento.getInformacoesClinica();
		this.observacao = procedimento.getObservacaoGuiche();
		this.idComposicao = procedimento.getIdComposicao();
		this.guia = procedimento.getGuia();
		this.idExameGuia = procedimento.getId();
	}

	public Integer getIdExameGuia() {
		return idExameGuia;
	}

	public void setIdExameGuia(Integer idExameGuia) {
		this.idExameGuia = idExameGuia;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
//	public Ct_itemSolicitacao getItem() {
//		return item;
//	}
//	
//	public void setItem(Ct_itemSolicitacao item) {
//		this.item = item;
//	}
//
//	public ExamePreCalculado getExamePreCalculado() {
//		return examePreCalculado;
//	}
//
//	public void setExamePreCalculado(ExamePreCalculado examePreCalculado) {
//		this.examePreCalculado = examePreCalculado;
//	}
	
	public String getGuia() {
		return guia;
	}

	public void setGuia(String guia) {
		this.guia = guia;
	}

	public List<ExameHermesPardini> getExames() {
		return exames;
	}

	public void setExames(List<ExameHermesPardini> exames) {
		this.exames = exames;
	}	

	public String getObservacao() {
		return observacao;
	}

	public void setObservacao(String observacao) {
		this.observacao = observacao;
	}
	
	public Integer getQuantidadeAutorizada() {
		return quantidadeAutorizada;
	}

	public void setQuantidadeAutorizada(Integer quantidadeAutorizada) {
		this.quantidadeAutorizada = quantidadeAutorizada;
	}

	public Integer getQuantidadeSolicitada() {
		return quantidadeSolicitada;
	}

	public void setQuantidadeSolicitada(Integer quantidadeSolicitada) {
		this.quantidadeSolicitada = quantidadeSolicitada;
	}

	public MotivosGlosas getGlosas() {
		return glosas;
	}

	public void setGlosas(MotivosGlosas glosas) {
		this.glosas = glosas;
	}

	public String getInformacoesClinica() {
		return informacoesClinica;
	}

	public void setInformacoesClinica(String informacoesClinica) {
		this.informacoesClinica = informacoesClinica;
	}

	public Long getIdComposicao() {
		return idComposicao;
	}

	public void setIdComposicao(Long idComposicao) {
		this.idComposicao = idComposicao;
	}

	public ExameHermesPardini getExame() {
		return exame;
	}

	public void setExame(ExameHermesPardini exame) {
		this.exame = exame;
	}

	public TypeCalculo getTipoCalculo() {
		return tipoCalculo;
	}

	public void setTipoCalculo(TypeCalculo tipoCalculo) {
		this.tipoCalculo = tipoCalculo;
	}
	
	public String getDescricaoCompleta() {
		return this.exame.getMnemonicoConcat() + " - " + this.descricao;
	}
	
}
