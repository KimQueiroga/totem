package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

import br.com.hermespardini.passelivre.constantsenum.TipoCartao;

public class Payment implements Serializable {

	private String cc_type;
	private String cc_number;
	private String cc_cid;
	private String cc_owner;
	private String cc_exp_month;
	private String cc_exp_year;
	private String parcels_number;

	public Payment() {
	}

	private Payment(final DadosCartao dadosCartao) {
		cc_owner = dadosCartao.getName();
		cc_exp_month = retornarMesValido(dadosCartao).toString();
		cc_exp_year = "20" + dadosCartao.getExpiry().split("/")[1].trim();
		cc_cid = dadosCartao.getCvc();
		cc_number = dadosCartao.getNumber().replace(" ", "");
		cc_type = TipoCartao.getCartaoPorNumero(String.valueOf(dadosCartao.getNumber().replace(" ", "")))
				.getNomeCartao();
		parcels_number = "1";
	}

	private Integer retornarMesValido(final DadosCartao dadosCartao) {
		try {
			final Integer mes = 0;
			final String mesValida = dadosCartao.getExpiry().split("/")[0].trim();
			return Integer.parseInt(mesValida);
		} catch (final Exception locExc) {
			return 0;
		}
	}

	public static Payment criarDadosPagemento(final DadosCartao dadosCartao) {
		return new Payment(dadosCartao);
	}

	public final String getCc_type() {
		return cc_type;
	}

	public final void setCc_type(final String parCc_type) {
		cc_type = parCc_type;
	}

	public final String getCc_number() {
		return cc_number;
	}

	public final void setCc_number(final String parCc_number) {
		cc_number = parCc_number;
	}

	public final String getCc_cid() {
		return cc_cid;
	}

	public final void setCc_cid(final String parCc_cid) {
		cc_cid = parCc_cid;
	}

	public final String getCc_owner() {
		return cc_owner;
	}

	public final void setCc_owner(final String parCc_owner) {
		cc_owner = parCc_owner;
	}

	public final String getCc_exp_month() {
		return cc_exp_month;
	}

	public final void setCc_exp_month(final String parCc_exp_month) {
		cc_exp_month = parCc_exp_month;
	}

	public final String getCc_exp_year() {
		return cc_exp_year;
	}

	public final void setCc_exp_year(final String parCc_exp_year) {
		cc_exp_year = parCc_exp_year;
	}

	public final String getParcels_number() {
		return parcels_number;
	}

	public final void setParcels_number(final String parParcels_number) {
		parcels_number = parParcels_number;
	}

}
