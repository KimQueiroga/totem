package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.util.List;

import com.owlike.genson.annotation.JsonIgnore;

@SuppressWarnings("serial")
public class QuestionarioEntrega implements Serializable {

	@JsonIgnore
	private String codigoQuestionario;
	private PerguntasEntrega perguntas;

	public QuestionarioEntrega(final Questionario parQuestionario, final List<PerguntaEntrega> parPerguntas) {
		setCodigoQuestionario(parQuestionario.getCodigoQuestionario());
		perguntas = new PerguntasEntrega();
		for (final PerguntaEntrega locPerguntaEntrega : parPerguntas) {
			if (locPerguntaEntrega.getCodigoQuestionario().equals(parQuestionario.getCodigoQuestionario())) {
				if (locPerguntaEntrega.getResposta().getDescricao() != null
						&& !locPerguntaEntrega.getResposta().getDescricao().isEmpty()) {
					final PerguntaEntrega perguntaEntrega = new PerguntaEntrega(locPerguntaEntrega);
					if (!perguntas.contains(perguntaEntrega)) {
						perguntas.add(perguntaEntrega);
					}
				}
			}
		}
	}

	public String getCodigoQuestionario() {
		return codigoQuestionario;
	}

	public void setCodigoQuestionario(final String parCodigoQuestionario) {
		codigoQuestionario = parCodigoQuestionario;
	}

	public PerguntasEntrega getPerguntas() {
		return perguntas;
	}

	public void setPerguntas(final PerguntasEntrega parPerguntas) {
		perguntas = parPerguntas;
	}

}
