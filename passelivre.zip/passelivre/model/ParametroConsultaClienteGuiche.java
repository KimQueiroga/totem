package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.gson.annotations.Expose;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;

public class ParametroConsultaClienteGuiche implements Serializable {
	@Expose
	private String authKey;
	@Expose
	private Date birthDate;
	@Expose
	private String authKeyType;
	@Expose
	private String token;
	@Expose
	private String origem;
	@Expose
	private String name;
	@Expose
	private String nameMother;
	@Expose
	private String senhaOrigem;
	@Expose
	private String zipCode;
	@Expose
	private String pedido;
	@Expose
	private String unidade;
	@JsonIgnore
	private String cpf;
	@JsonIgnore
	private String codigo;
	@Expose
	private String sessionId;

	public ParametroConsultaClienteGuiche() {
	}

	public ParametroConsultaClienteGuiche(final TokenResult parTokenResult,
			final ParametroConsultaClienteGuiche parParametroConsultaCliente) throws RegraNegocioException {
		birthDate = parParametroConsultaCliente.getBirthDate();
		authKey = retornarChave(parParametroConsultaCliente);
		authKeyType = retornarTipoChave(parParametroConsultaCliente);
		token = parTokenResult.getToken();
		origem = Constantes.ORIGEM_PADRAO;
		name = parParametroConsultaCliente.getName();
		nameMother = parParametroConsultaCliente.getNameMother();
		senhaOrigem = parParametroConsultaCliente.getSenhaOrigem();
		zipCode = parParametroConsultaCliente.getZipCode();
		cpf = parParametroConsultaCliente.getCpf();
		codigo = parParametroConsultaCliente.getCodigo();
		pedido = parParametroConsultaCliente.getPedido();
		unidade = parParametroConsultaCliente.getUnidade();
		sessionId = parParametroConsultaCliente.getSessionId();
	}

	private String retornarChave(final ParametroConsultaClienteGuiche parParametroConsultaCliente)
			throws RegraNegocioException {
		if (cpfNaoEstaVazio(parParametroConsultaCliente)) {
			verificarSeCamposForamPreenchidos();
			return retornarApenasNumero(parParametroConsultaCliente.getCpf());
		} else {
			if (codigoNaoEstaVazio(parParametroConsultaCliente)) {
				return parParametroConsultaCliente.getCodigo();
			} else {
				verificarSeCamposForamPreenchidos();
				return "";
			}
		}
	}

	private boolean cpfNaoEstaVazio(final ParametroConsultaClienteGuiche parParametroConsultaCliente) {
		return parParametroConsultaCliente.getCpf() != null && !parParametroConsultaCliente.getCpf().isEmpty();
	}

	private String retornarApenasNumero(final String parValor) {
		return parValor.replace(".", "").replaceAll("-", "");
	}

	private String retornarTipoChave(final ParametroConsultaClienteGuiche parParametroConsultaCliente) {
		if (cpfNaoEstaVazio(parParametroConsultaCliente)) {
			return Constantes.CPFAUTHKEYTYPE;
		} else {
			if (codigoNaoEstaVazio(parParametroConsultaCliente)) {
				return Constantes.CODEAUTHKEYTYPE;
			} else {
				return Constantes.OUTROAUTHKEYTYPE;
			}
		}
	}

	private boolean codigoNaoEstaVazio(final ParametroConsultaClienteGuiche parParametroConsultaCliente) {
		return parParametroConsultaCliente.getCodigo() != null && !parParametroConsultaCliente.getCodigo().isEmpty();
	}

	public void verificarSeCamposForamPreenchidos() throws RegraNegocioException {
		if (birthDate == null) {
			throw new RegraNegocioException("Campo Data Nascimento não pode ser vazio!");
		}
	}

	public String getAuthKey() {
		return authKey;
	}

	public void setAuthKey(final String parAuthKey) {
		authKey = parAuthKey;
	}

	public String getName() {
		return name;
	}

	public void setName(final String parName) {
		name = parName;
	}

	public String getNameMother() {
		return nameMother;
	}

	public void setNameMother(final String parNameMother) {
		nameMother = parNameMother;
	}

	public String getSenhaOrigem() {
		return senhaOrigem;
	}

	public void setSenhaOrigem(final String parSenhaOrigem) {
		senhaOrigem = parSenhaOrigem;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(final String parZipCode) {
		zipCode = parZipCode;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(final String parCpf) {
		cpf = parCpf;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(final String parCodigo) {
		codigo = parCodigo;
	}

	public String getAuthKeyType() {
		return authKeyType;
	}

	public void setAuthKeyType(final String parAuthKeyType) {
		authKeyType = parAuthKeyType;
	}

	public String getToken() {
		return token;
	}

	public void setToken(final String parToken) {
		token = parToken;
	}

	public String getOrigem() {
		return origem;
	}

	public void setOrigem(final String parOrigem) {
		origem = parOrigem;
	}

	public Date getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(final Date parBirthDate) {
		birthDate = parBirthDate;
	}

	public String getPedido() {
		return pedido;
	}

	public void setPedido(final String parPedido) {
		pedido = parPedido;
	}

	public String getUnidade() {
		return unidade;
	}

	public void setUnidade(final String parUnidade) {
		unidade = parUnidade;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(final String parSessionId) {
		sessionId = parSessionId;
	}

}
