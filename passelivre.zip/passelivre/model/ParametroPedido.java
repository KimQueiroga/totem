package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.util.List;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.to.ProcedimentoComExamesTO;
import br.com.unimedbh.www.Ct_dadosAutorizacao;
import br.com.unimedbh.www.ws.tipos.Ws_respostaCobertura;

@SuppressWarnings("serial")
public class ParametroPedido implements Serializable {

	private String empresa;
	private String unidade;
	private String tipoImpressao;
	private Paciente paciente;
	private Guias guias;
	private String termoAnuencia;
	private String observacao;
	private String autorizaEntregaTerceiros;
	private String usuario;
	private String token;
	private String origem;
	private String providencia;
	private String senhaFilaAtendimento;
	private String localizacao;
	private String impressora;
	private String sessionIDAplicacao;
	private Long idTotem;
	private Agenda agenda;
	private PreAtendimento preAtendimento;

	public ParametroPedido() {
	}

	public ParametroPedido(final Ct_dadosAutorizacao parGuiasAutorizadaSelecionada,
			final List<ProcedimentoComExamesTO> parProcedimentosComExamesSelecionados,
			final List<ConsultaQuestionarioExameResult> parQuestionariosExamesResult,
			final InformacaoTotem parInformacaoTotem, final List<PerguntaEntrega> parPerguntas,
			final ClienteUnidadePasseLivre parClienteUnidadePasseLivre,
			final Ws_respostaCobertura parWs_respostaCobertura, final TokenResult parTokenResult) throws Exception {
		empresa = Constantes.EMPRESA;
		localizacao = parInformacaoTotem.getLocalImpressao();
		tipoImpressao = parInformacaoTotem.getTipoImpressao();
		origem = Constantes.ORIGEM_PADRAO;
		usuario = Constantes.USUARIO_PADRAO;
		token = parTokenResult.getToken();
		unidade = parInformacaoTotem.getIdUnidade();
		idTotem = parInformacaoTotem.getId();
		paciente = new Paciente(parClienteUnidadePasseLivre, parGuiasAutorizadaSelecionada, parWs_respostaCobertura);
		guias = new Guias();
		guias.add(new Guia(parGuiasAutorizadaSelecionada, parProcedimentosComExamesSelecionados,
				parQuestionariosExamesResult, parPerguntas, parInformacaoTotem));
	}

	public ParametroPedido(final Ct_dadosAutorizacao parGuiasAutorizadaSelecionada,
			final List<ProcedimentoComExamesTO> parProcedimentosComExamesSelecionados,
			final List<ConsultaQuestionarioExameResult> parQuestionariosExamesResult,
			final InformacaoTotem parInformacaoTotem, final List<PerguntaEntrega> parPerguntas,
			final ClienteUnidadePasseLivre parClienteUnidadePasseLivre,
			final Ws_respostaCobertura parWs_respostaCobertura, final TokenResult parTokenResult, String sessionId,
			final String parProvidencia) throws Exception {
		empresa = Constantes.EMPRESA;
		localizacao = parInformacaoTotem.getLocalImpressao();
		tipoImpressao = parInformacaoTotem.getTipoImpressao();
		origem = Constantes.ORIGEM_PADRAO;
		usuario = Constantes.USUARIO_PADRAO;
		token = parTokenResult.getToken();
		providencia = parProvidencia;
		unidade = parInformacaoTotem.getIdUnidade();
		idTotem = parInformacaoTotem.getId();
		paciente = new Paciente(parClienteUnidadePasseLivre, parGuiasAutorizadaSelecionada, parWs_respostaCobertura);
		sessionIDAplicacao = sessionId;
		guias = new Guias();
		guias.add(new Guia(parGuiasAutorizadaSelecionada, parProcedimentosComExamesSelecionados,
				parQuestionariosExamesResult, parPerguntas, parInformacaoTotem));
	}

	public ParametroPedido(final Ct_dadosAutorizacao parGuiasAutorizadaSelecionada,
			final List<ProcedimentoComExamesTO> parProcedimentosComExamesSelecionados,
			final List<ConsultaQuestionarioExameResult> parQuestionariosExamesResult,
			final List<PerguntaEntrega> parPerguntas, final ClienteUnidadePasseLivre parClienteUnidadePasseLivre,
			final Ws_respostaCobertura parWs_respostaCobertura, final TokenResult parTokenResult,
			final String paramUsuario, final Unidade paramUnidade, final Long idLocalizacao, final String parSessionId,
			final String parProvidencia) throws Exception {
		empresa = Constantes.EMPRESA;
		localizacao = idLocalizacao.toString();
		tipoImpressao = Constantes.TIPO_IMPRESSAO_DEFAULT;
		origem = Constantes.ORIGEM_DESKTOP;
		usuario = paramUsuario;
		providencia = parProvidencia;
		token = parTokenResult.getToken();
		unidade = paramUnidade.getCodigo().toString();
		paciente = new Paciente(parClienteUnidadePasseLivre, parGuiasAutorizadaSelecionada, parWs_respostaCobertura);
		sessionIDAplicacao = parSessionId;
		guias = new Guias();
		guias.add(new Guia(parGuiasAutorizadaSelecionada, parProcedimentosComExamesSelecionados,
				parQuestionariosExamesResult, parPerguntas));
	}

	public static ParametroPedido criarPedidoParaCheckup(final InformacaoTotem parInformacaoTotem,
			final ClienteUnidadePasseLivre parClienteUnidadePasseLivre, final TokenResult parTokenResult,
			final DetalhePreparacao detalhePreparacao, final EPacoteResult ePacoteResult,
			final List<ConsultaQuestionarioExameResult> parQuestionarios, final List<PerguntaEntrega> parPerguntas) {
		return new ParametroPedido(parInformacaoTotem, parClienteUnidadePasseLivre, parTokenResult, detalhePreparacao,
				ePacoteResult, parQuestionarios, parPerguntas);
	}

	private ParametroPedido(final InformacaoTotem parInformacaoTotem,
			final ClienteUnidadePasseLivre parClienteUnidadePasseLivre, final TokenResult parTokenResult,
			final DetalhePreparacao detalhePreparacao, final EPacoteResult ePacoteResult,
			final List<ConsultaQuestionarioExameResult> parQuestionarios, final List<PerguntaEntrega> parPerguntas) {
		empresa = Constantes.EMPRESA;
		localizacao = parInformacaoTotem.getLocalImpressao();
		tipoImpressao = Constantes.TIPO_IMPRESSAO_CHECKUP;
		origem = Constantes.ORIGEM_PADRAO;
		usuario = Constantes.USUARIO_PADRAO;
		token = parTokenResult.getToken();
		unidade = parInformacaoTotem.getIdUnidade();
		idTotem = parInformacaoTotem.getId();
		paciente = Paciente.criarPacienteParticular(parClienteUnidadePasseLivre);
		guias = new Guias();
		guias.add(Guia.criarGuiaParaCheckup(detalhePreparacao, ePacoteResult, parQuestionarios, parPerguntas));
	}

	public ParametroPedido(final InformacaoTotem parInformacaoTotem,
			final ClienteUnidadePasseLivre parClienteUnidadePasseLivre, final TokenResult parTokenResult,
			final List<ProcedimentoComExamesTO> parProcedimentoComExamesTO, final PreAtendimento parPreAtendimento,
			final List<ConsultaQuestionarioExameResult> parQuestionarios, final List<PerguntaEntrega> parPerguntas,
			final Solicitante parSolicitante, final boolean particular) {
		empresa = Constantes.EMPRESA;
		localizacao = parInformacaoTotem.getLocalImpressao();
		tipoImpressao = Constantes.TIPO_IMPRESSAO_DEFAULT;
		origem = Constantes.ORIGEM_PADRAO;
		usuario = parPreAtendimento.getUsuario();
		token = parTokenResult.getToken();
		unidade = parInformacaoTotem.getIdUnidade();
		idTotem = parInformacaoTotem.getId();
		paciente = Paciente.criarPacientePreAtendimento(parClienteUnidadePasseLivre, parPreAtendimento);
		preAtendimento = new PreAtendimento();
		preAtendimento.setNumeroPreAtendimento(parPreAtendimento.getNumeroPreAtendimento());
		guias = new Guias();
		for (final Guia guia : parPreAtendimento.getGuias()) {
			guias.add(new Guia(guia, parProcedimentoComExamesTO, parQuestionarios, parPerguntas, parSolicitante,
					particular));
		}
	}

	public ParametroPedido(final InformacaoTotem parInformacaoTotem,
			final ClienteUnidadePasseLivre parClienteUnidadePasseLivre, final TokenResult parTokenResult,
			final List<ProcedimentoComExamesTO> parProcedimentoComExamesTO, final PreAtendimento parPreAtendimento,
			final List<ConsultaQuestionarioExameResult> parQuestionarios, final List<PerguntaEntrega> parPerguntas,
			final Solicitante parSolicitante, String parProvidencia, final boolean particular) {
		empresa = Constantes.EMPRESA;
		localizacao = parInformacaoTotem.getLocalImpressao();
		tipoImpressao = Constantes.TIPO_IMPRESSAO_DEFAULT;
		origem = Constantes.ORIGEM_PADRAO;
		usuario = parPreAtendimento.getUsuario();
		token = parTokenResult.getToken();
		unidade = parInformacaoTotem.getIdUnidade();
		idTotem = parInformacaoTotem.getId();
		providencia = parProvidencia;
		paciente = Paciente.criarPacientePreAtendimento(parClienteUnidadePasseLivre, parPreAtendimento);
		preAtendimento = new PreAtendimento();
		preAtendimento.setNumeroPreAtendimento(parPreAtendimento.getNumeroPreAtendimento());
		guias = new Guias();
		for (final Guia guia : parPreAtendimento.getGuias()) {
			guias.add(new Guia(guia, parProcedimentoComExamesTO, parQuestionarios, parPerguntas, parSolicitante,
					particular));
		}
	}

	public ParametroPedido(final InformacaoTotem parInformacaoTotem,
			final ClienteUnidadePasseLivre parClienteUnidadePasseLivre, final TokenResult parTokenResult,
			final List<ProcedimentoComExamesTO> parProcedimentoComExamesTO, final PreAtendimento parPreAtendimento,
			final List<ConsultaQuestionarioExameResult> parQuestionarios, final List<PerguntaEntrega> parPerguntas,
			final Solicitante parSolicitante, final boolean particular, String sessionId) {
		empresa = Constantes.EMPRESA;
		localizacao = parInformacaoTotem.getLocalImpressao();
		tipoImpressao = Constantes.TIPO_IMPRESSAO_DEFAULT;
		origem = Constantes.ORIGEM_PADRAO;
		usuario = Constantes.USUARIO_PADRAO;
		token = parTokenResult.getToken();
		unidade = parInformacaoTotem.getIdUnidade();
		idTotem = parInformacaoTotem.getId();
		paciente = Paciente.criarPacientePreAtendimento(parClienteUnidadePasseLivre, parPreAtendimento);
		preAtendimento = new PreAtendimento();
		preAtendimento.setNumeroPreAtendimento(parPreAtendimento.getNumeroPreAtendimento());
		sessionIDAplicacao = sessionId;
		guias = new Guias();
		for (final Guia guia : parPreAtendimento.getGuias()) {
			guias.add(new Guia(guia, parProcedimentoComExamesTO, parQuestionarios, parPerguntas, parSolicitante,
					particular));
		}
	}

	public ParametroPedido(final ClienteUnidadePasseLivre parClienteUnidadePasseLivre, final TokenResult parTokenResult,
			final List<ProcedimentoComExamesTO> parProcedimentoComExamesTO, final PreAtendimento parPreAtendimento,
			final List<ConsultaQuestionarioExameResult> parQuestionarios, final List<PerguntaEntrega> parPerguntas,
			final Solicitante parSolicitante, final String paramUsuario, final Unidade paramUnidade,
			final Long idLocalizacao, final String parSessionId, final String parProvidencia) {
		empresa = Constantes.EMPRESA;
		localizacao = idLocalizacao.toString();
		tipoImpressao = Constantes.TIPO_IMPRESSAO_DEFAULT;
		origem = Constantes.ORIGEM_DESKTOP;
		usuario = parPreAtendimento.getUsuario();
		token = parTokenResult.getToken();
		unidade = paramUnidade.getCodigo().toString();
		paciente = Paciente.criarPacientePreAtendimento(parClienteUnidadePasseLivre, parPreAtendimento);
		preAtendimento = new PreAtendimento();
		preAtendimento.setNumeroPreAtendimento(parPreAtendimento.getNumeroPreAtendimento());
		sessionIDAplicacao = parSessionId;
		guias = new Guias();
		for (final Guia guia : parPreAtendimento.getGuias()) {
			guias.add(new Guia(guia, parProcedimentoComExamesTO, parQuestionarios, parPerguntas, parSolicitante));
		}
	}

	public Long getIdTotem() {
		return idTotem;
	}

	public void setIdTotem(final Long idTotem) {
		this.idTotem = idTotem;
	}

	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(final String parEmpresa) {
		empresa = parEmpresa;
	}

	public String getUnidade() {
		return unidade;
	}

	public void setUnidade(final String parUnidade) {
		unidade = parUnidade;
	}

	public Paciente getPaciente() {
		return paciente;
	}

	public void setPaciente(final Paciente parPaciente) {
		paciente = parPaciente;
	}

	public Guias getGuias() {
		return guias;
	}

	public void setGuias(final Guias parGuias) {
		guias = parGuias;
	}

	public String getTermoAnuencia() {
		return termoAnuencia;
	}

	public void setTermoAnuencia(final String parTermoAnuencia) {
		termoAnuencia = parTermoAnuencia;
	}

	public String getObservacao() {
		return observacao;
	}

	public void setObservacao(final String parObservacao) {
		observacao = parObservacao;
	}

	public String getAutorizaEntregaTerceiros() {
		return autorizaEntregaTerceiros;
	}

	public void setAutorizaEntregaTerceiros(final String parAutorizaEntregaTerceiros) {
		autorizaEntregaTerceiros = parAutorizaEntregaTerceiros;
	}

	public String getToken() {
		return token;
	}

	public void setToken(final String parToken) {
		token = parToken;
	}

	public String getOrigem() {
		return origem;
	}

	public void setOrigem(final String parOrigem) {
		origem = parOrigem;
	}

	public String getSenhaFilaAtendimento() {
		return senhaFilaAtendimento;
	}

	public void setSenhaFilaAtendimento(final String parSenhaFilaAtendimento) {
		senhaFilaAtendimento = parSenhaFilaAtendimento;
	}

	public String getLocalizacao() {
		return localizacao;
	}

	public void setLocalizacao(final String parLocalizacao) {
		localizacao = parLocalizacao;
	}

	public String getImpressora() {
		return impressora;
	}

	public void setImpressora(final String parImpressora) {
		impressora = parImpressora;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(final String parUsuario) {
		usuario = parUsuario;
	}

	public String getProvidencia() {
		return providencia;
	}

	public void setProvidencia(final String parProvidencia) {
		providencia = parProvidencia;
	}

	public Agenda getAgenda() {
		return agenda;
	}

	public void setAgenda(final Agenda parAgenda) {
		agenda = parAgenda;
	}

	public PreAtendimento getPreAtendimento() {
		return preAtendimento;
	}

	public void setPreAtendimento(final PreAtendimento parPreAtendimento) {
		preAtendimento = parPreAtendimento;
	}
}
