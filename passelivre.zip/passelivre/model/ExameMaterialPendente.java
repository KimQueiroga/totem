package br.com.hermespardini.passelivre.model;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.google.gson.annotations.SerializedName;
import com.owlike.genson.annotation.JsonIgnore;

import br.com.hermespardini.passelivre.constantsenum.Constantes;

@SuppressWarnings("serial")
public class ExameMaterialPendente implements Comparable<ExameMaterialPendente> {

	private String chave;
	private Date data;
	private int status;
	private String exame;
	@SerializedName("sequenciaExame")
	private int sequencia;
	private Timestamp marcacao;
	private String empresa;
	private String token;
	private String pedido;
	private String unidade;
	private String origem;
	private String material;
	private String dataColeta;
	@JsonIgnore
	private String observacao;
	private String horaColeta;
	private String localEntrega;
	private String departamento;
	private String tipoImpressao;
	private String descricaoExame;
	private String unidadeEntrega;
	private String condicaoAmostra;
	private String descricaoUnidade;
	private String descricaoMaterial;

	private transient Timestamp marcacaoTemp;

	public ExameMaterialPendente() {
	}

	public ExameMaterialPendente(final Pedido parPedido, final ExameMaterialPendente parExame,
			final ClienteUnidadePasseLivre clienteUnidadePasseLivre, final InformacaoTotem parInformacaoTotem,
			final TokenResult parTokenResult) {
		setDescricaoExame(parExame.getDescricaoExame());
		setDescricaoMaterial(parExame.getDescricaoMaterial());
		setExame(parExame.getExame());
		setDepartamento(parExame.getDepartamento());
		setMarcacaoTemp(parExame.getMarcacao());
		setMaterial(parExame.getMaterial());
		setUnidade(parPedido.getUnidade());
		setPedido(parPedido.getPedido());
		setData(parPedido.getDataPedido());
		setSequencia(parExame.getSequencia());
		setDescricaoUnidade(parPedido.getDescricaoUnidade());
		setEmpresa(Constantes.EMPRESA);
		setToken(parTokenResult.getToken());
		setCondicaoAmostra(parExame.getCondicaoAmostra());
		setLocalEntrega(parInformacaoTotem.getNomeUnd());
		setUnidadeEntrega(parInformacaoTotem.getNomeUnd());
		setDataColeta(formatarDataParaString());
		setHoraColeta(retornarHoraAtual());
		setOrigem(Constantes.USUARIO_PADRAO);
		setTipoImpressao(parInformacaoTotem.getTipoImpressao());
		setChave(getExame()+getSequencia()+getMaterial());
	}

	public ExameMaterialPendente(final Pedido parPedido, final ExameMaterialPendente parExame,
			final ClienteUnidadePasseLivre clienteUnidadePasseLivre, final TokenResult parTokenResult,
			final Long idUnidade, final Long idLocalizacao) {
		setDescricaoExame(parExame.getDescricaoExame());
		setDescricaoMaterial(parExame.getDescricaoMaterial());
		setExame(parExame.getExame());
		setDepartamento(parExame.getDepartamento());
		setMarcacaoTemp(parExame.getMarcacao());
		setMaterial(parExame.getMaterial());
		setUnidade(parPedido.getUnidade());
		setPedido(parPedido.getPedido());
		setData(parPedido.getDataPedido());
		setSequencia(parExame.getSequencia());
		setDescricaoUnidade(parPedido.getDescricaoUnidade());
		setEmpresa(Constantes.EMPRESA);
		setToken(parTokenResult.getToken());
		setCondicaoAmostra(parExame.getCondicaoAmostra());
		setLocalEntrega(idLocalizacao.toString());
		setUnidadeEntrega(idUnidade.toString());
		setDataColeta(formatarDataParaString());
		setHoraColeta(retornarHoraAtual());
		setOrigem(Constantes.USUARIO_PADRAO);
		setTipoImpressao(Constantes.TIPO_IMPRESSAO_DEFAULT);
		setChave(getExame()+getSequencia()+getMaterial());
	}

	public String getChave() {
		return chave;
	}

	public void setChave(String chave) {
		this.chave = chave;
	}

	private String retornarHoraAtual() {
		final SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
		final Date hora = Calendar.getInstance().getTime();
		final String horaFormatada = sdf.format(hora);
		return horaFormatada;
	}

	private String formatarDataParaString() {
		final SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd");
		return f.format(new Date());
	}

	public String getExame() {
		return exame;
	}

	public void setExame(final String parExame) {
		exame = parExame;
	}

	public String getDescricaoExame() {
		return descricaoExame;
	}

	public void setDescricaoExame(final String parDescricaoExame) {
		descricaoExame = parDescricaoExame;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(final String parMaterial) {
		material = parMaterial;
	}

	public String getDescricaoMaterial() {
		return descricaoMaterial;
	}

	public void setDescricaoMaterial(final String parDescricaoMaterial) {
		descricaoMaterial = parDescricaoMaterial;
	}

	public int getSequencia() {
		return sequencia;
	}

	public void setSequencia(final int parSequencia) {
		sequencia = parSequencia;
	}

	public Date getData() {
		return data;
	}

	public void setData(final Date parDate) {
		data = parDate;
	}

	public Timestamp getMarcacao() {
		return marcacao;
	}

	public void setMarcacao(final Timestamp parMarcacao) {
		marcacao = parMarcacao;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(final int parStatus) {
		status = parStatus;
	}

	public String getDataColeta() {
		return dataColeta;
	}

	public void setDataColeta(final String parDataColeta) {
		dataColeta = parDataColeta;
	}

	public String getHoraColeta() {
		return horaColeta;
	}

	public void setHoraColeta(final String parHoraColeta) {
		horaColeta = parHoraColeta;
	}

	public String getDescricaoUnidade() {
		return descricaoUnidade;
	}

	public void setDescricaoUnidade(final String parDescricaoUnidade) {
		descricaoUnidade = parDescricaoUnidade;
	}

	public Timestamp getMarcacaoTemp() {
		return marcacaoTemp;
	}

	public void setMarcacaoTemp(final Timestamp parMarcacaoTemp) {
		marcacaoTemp = parMarcacaoTemp;
	}

	public String getOrigem() {
		return origem;
	}

	public void setOrigem(final String parOrigem) {
		origem = parOrigem;
	}

	public String getLocalEntrega() {
		return localEntrega;
	}

	public void setLocalEntrega(final String parLocalEntrega) {
		localEntrega = parLocalEntrega;
	}

	public String getUnidadeEntrega() {
		return unidadeEntrega;
	}

	public void setUnidadeEntrega(final String parUnidadeEntrega) {
		unidadeEntrega = parUnidadeEntrega;
	}

	public String getTipoImpressao() {
		return tipoImpressao;
	}

	public void setTipoImpressao(final String parTipoImpressao) {
		tipoImpressao = parTipoImpressao;
	}

	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(final String parEmpresa) {
		empresa = parEmpresa;
	}

	public String getToken() {
		return token;
	}

	public void setToken(final String parToken) {
		token = parToken;
	}

	public String getPedido() {
		return pedido;
	}

	public void setPedido(final String parPedido) {
		pedido = parPedido;
	}

	public String getUnidade() {
		return unidade;
	}

	public void setUnidade(final String parUnidade) {
		unidade = parUnidade;
	}

	public String getCondicaoAmostra() {
		return condicaoAmostra;
	}

	public void setCondicaoAmostra(final String parCondicaoAmostra) {
		condicaoAmostra = parCondicaoAmostra;
	}

	@Override
	public int hashCode() {
		return exame.hashCode() + 31 * sequencia;
	}

	@Override
	public boolean equals(final Object obj) {
		if (!(obj instanceof ExameMaterialPendente)) {
		      return false;
		    }
		    final ExameMaterialPendente other = (ExameMaterialPendente) obj;
	    return other.getChave().equals(chave);
	}

	@Override
	public int compareTo(final ExameMaterialPendente exameMaterialPendente) {
		int cod = exameMaterialPendente.getData().compareTo(getData());
		  if (cod == 0) {
			  return exameMaterialPendente.getPedido().compareTo(getPedido());
		  } else {
			  return cod;  
		  }
	}

	@Override
	public String toString() {
		return exame + "-" + material + "-" + descricaoUnidade + "-" + pedido + "-" + sequencia;
	}

	public String getDepartamento() {
		return departamento;
	}

	public void setDepartamento(final String parDepartamento) {
		departamento = parDepartamento;
	}

	public String getObservacao() {
		return observacao;
	}

	public void setObservacao(final String parObservacao) {
		observacao = parObservacao;
	}

}
