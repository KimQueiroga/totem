package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import br.com.hermespardini.passelivre.constantsenum.Constantes;

public class Pagamento implements Serializable {

	private String formaPagamento;
	private List<Cartao> dadosCartao;

	public Pagamento(final DadosCartao parDadosCartao, final DetalhePreparacao parDetalhePreparacao,
			final PagamentoResult parPagamentoResult) {
		formaPagamento = Constantes.PAGAMENTO_CARTAO;
		dadosCartao = new ArrayList<>();
		dadosCartao.add(new Cartao(parDadosCartao, parDetalhePreparacao, parPagamentoResult));
	}

	public String getFormaPagamento() {
		return formaPagamento;
	}

	public void setFormaPagamento(final String parFormaPagamento) {
		formaPagamento = parFormaPagamento;
	}

	public List<Cartao> getDadosCartao() {
		return dadosCartao;
	}

	public void setDadosCartao(final List<Cartao> parDadosCartao) {
		dadosCartao = parDadosCartao;
	}
}
