package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.util.List;

import com.google.gson.annotations.SerializedName;

import br.com.hermespardini.passelivre.constantsenum.Constantes;

@SuppressWarnings("serial")
public class PedidoCliente implements Serializable {

	@SerializedName("orderId")
	private String id;

	@SerializedName("orderLabel")
	private String numeroPedido;

	@SerializedName("unitName")
	private String descricaoUnidade;

	@SerializedName("unitId")
	private Integer codigoUnidade;

	@SerializedName("doctorName")
	private String nomeMedico;

	@SerializedName("orderDate")
	private String dataPedido;

	@SerializedName("resultScheduledDate")
	private String dataPrevisaoResultado;

	@SerializedName("orderStatus")
	private String situacaoPedido;

	@SerializedName("resultPdfUrl")
	private String resultPdfUrl;

	private String descricaoSituacaoPedido;

	public Boolean exibirPdf(final List<DetalhePedidoCliente> parDetalhesPedido) {
		for (final DetalhePedidoCliente locDetalhePedidoCliente : parDetalhesPedido) {
			if (locDetalhePedidoCliente.getTestStatus() == Constantes.STATUS_LIBERADO) {
				return true;
			}
		}
		return false;
	}

	public String getId() {
		return id;
	}

	public void setId(final String parId) {
		id = parId;
	}

	public String getNumeroPedido() {
		return numeroPedido;
	}

	public void setNumeroPedido(final String parNumeroPedido) {
		numeroPedido = parNumeroPedido;
	}

	public String getNomeMedico() {
		return nomeMedico;
	}

	public void setNomeMedico(final String parNomeMedico) {
		nomeMedico = parNomeMedico;
	}

	public String getDataPedido() {
		return dataPedido;
	}

	public void setDataPedido(final String parDataPedido) {
		dataPedido = parDataPedido;
	}

	public String getDataPrevisaoResultado() {
		return dataPrevisaoResultado;
	}

	public void setDataPrevisaoResultado(final String parDataPrevisaoResultado) {
		dataPrevisaoResultado = parDataPrevisaoResultado;
	}

	public String getSituacaoPedido() {
		return situacaoPedido;
	}

	public void setSituacaoPedido(final String parSituacaoPedido) {
		situacaoPedido = parSituacaoPedido;
	}

	public String getDescricaoSituacaoPedido() {
		return descricaoSituacaoPedido;
	}

	public void setDescricaoSituacaoPedido(final String parDescricaoSituacaoPedido) {
		descricaoSituacaoPedido = parDescricaoSituacaoPedido;
	}

	public String getResultPdfUrl() {
		return resultPdfUrl;
	}

	public void setResultPdfUrl(final String parResultPdfUrl) {
		resultPdfUrl = parResultPdfUrl;
	}

	public String getDescricaoUnidade() {
		return descricaoUnidade;
	}

	public void setDescricaoUnidade(final String parDescricaoUnidade) {
		descricaoUnidade = parDescricaoUnidade;
	}

	public Integer getCodigoUnidade() {
		return codigoUnidade;
	}

	public void setCodigoUnidade(final Integer parCodigoUnidade) {
		codigoUnidade = parCodigoUnidade;
	}
}
