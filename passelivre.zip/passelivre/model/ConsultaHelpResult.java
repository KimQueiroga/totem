package br.com.hermespardini.passelivre.model;

import java.util.ArrayList;

public class ConsultaHelpResult {

	private ArrayList<ExamesEncontrados> ExamesEncontrados = new ArrayList<ExamesEncontrados>();
	private String Html;
	private float Sucesso;
	private String TextoProcura;

	public String getHtml() {
		return Html;
	}

	public float getSucesso() {
		return Sucesso;
	}

	public String getTextoProcura() {
		return TextoProcura;
	}

	public void setHtml(String Html) {
		this.Html = Html;
	}

	public void setSucesso(float Sucesso) {
		this.Sucesso = Sucesso;
	}

	public void setTextoProcura(String TextoProcura) {
		this.TextoProcura = TextoProcura;
	}

	public ArrayList<ExamesEncontrados> getExamesEncontrados() {
		return ExamesEncontrados;
	}

	public void setExamesEncontrados(ArrayList<ExamesEncontrados> examesEncontrados) {
		ExamesEncontrados = examesEncontrados;
	}
}
