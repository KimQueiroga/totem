package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.to.ProcedimentoComExamesTO;
import br.com.hermespardini.passelivre.utils.DataUtil;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.unimedbh.www.Ct_dadosAutorizacao;

@SuppressWarnings("serial")
public class ExamePedido implements Serializable {

	private static final int TAMANHO_MAXIMO_DESCRICAO_MATERIAL = 30;
	private String exame;
	private String material;
	private String descricaoMaterial;
	private Integer sequenciaExame;
	private String codigoExame;
	private String particular;
	private String dataHoraMarcacao;
	private String dataHoraColeta;
	private String localColeta;
	private String qtdeGabarito;
	private String condicaoAmostra;
	private String ampola;
	private String observacao;
	private String kit;
	private Solicitante solicitante;
	private String equipe;
	private Profissionais profissionais;
	private ExamesPedidoFilhos examesFilhos;
	private QuestionariosEntrega questionarios;
	private String descricaoExame;

	public ExamePedido(final ExameHermesPardini parExameHermesPardini) {
		exame = parExameHermesPardini.getExame();
		material = parExameHermesPardini.getMaterial();
	}

	public ExamePedido(final ProcedimentoComExamesTO parProcedimento,
			final List<ConsultaQuestionarioExameResult> parQuestionarios, final List<PerguntaEntrega> parPerguntas,
			final ExamesPedidos parExames, final Ct_dadosAutorizacao parCt_dadosAutorizacao,
			final InformacaoTotem parInformacaoTotem) {
		exame = parProcedimento.getExame().getExame();
		codigoExame = parProcedimento.getProcedimento();
		dataHoraMarcacao = retornarHoraDataMarcacao(parProcedimento);
		sequenciaExame = parProcedimento.getSequenciaExame();
		material = parProcedimento.getExame().getMaterial();
		solicitante = new Solicitante(parCt_dadosAutorizacao);
		verificarSeProcedimentoEhVt(parProcedimento);
		condicaoAmostra = retornarCodigoAmostraValido(parProcedimento.getCondicaoAmostra());
		questionarios = new QuestionariosEntrega();
		descricaoMaterial = retornarDescricaoMaterial(parProcedimento);
		localColeta = Constantes.LOCAL_COLETA_PADRAO;
		particular = parProcedimento.getParticular();
		observacao = retornarObservacaoValida(parProcedimento.getObservacaoGuiche());
		for (final ConsultaQuestionarioExameResult locConsultaQuestionarioExameResult : parQuestionarios) {
			if (locConsultaQuestionarioExameResult.getQuestionarios() != null
					&& parProcedimento.getExame().getExame().equals(locConsultaQuestionarioExameResult.getExame())) {
				for (final Questionario questionario : locConsultaQuestionarioExameResult.getQuestionarios()) {
					if (!questionario.getImpresso().equals("S")) {
						questionarios.add(new QuestionarioEntrega(questionario, parPerguntas));
					}
				}
			}
		}
	}

	private String retornarObservacaoValida(final String parObservacaoGuiche) {
		return Util.cortarCaractere(parObservacaoGuiche, 50);
	}

	private String retornarCodigoAmostraValido(final String parCondicaoAmostra) {
		return Util.cortarCaractere(parCondicaoAmostra, 50);
	}

	// private String cortarCaractere(final String parDescricaoASerCortada, final
	// int tamanhoLimite) {
	// try {
	// if (parDescricaoASerCortada.length() > tamanhoLimite) {
	// return parDescricaoASerCortada.substring(0, tamanhoLimite);
	// } else {
	// return parDescricaoASerCortada;
	// }
	// } catch (final Exception locExc) {
	// return "";
	// }
	// }

	public ExamePedido(final ProcedimentoComExamesTO parProcedimento,
			final List<ConsultaQuestionarioExameResult> parQuestionarios, final List<PerguntaEntrega> parPerguntas,
			final ExamesPedidos parExames, final Ct_dadosAutorizacao parCt_dadosAutorizacao) {
		exame = parProcedimento.getExame().getExame();
		codigoExame = parProcedimento.getProcedimento();
		dataHoraMarcacao = retornarHoraDataMarcacao(parProcedimento);
		sequenciaExame = parProcedimento.getSequenciaExame();
		material = parProcedimento.getExame().getMaterial();
		solicitante = new Solicitante(parCt_dadosAutorizacao);
		verificarSeProcedimentoEhVt(parProcedimento);
		condicaoAmostra = retornarCodigoAmostraValido(parProcedimento.getCondicaoAmostra());
		questionarios = new QuestionariosEntrega();
		descricaoMaterial = retornarDescricaoMaterial(parProcedimento);
		localColeta = Constantes.LOCAL_COLETA_PADRAO;
		particular = parProcedimento.getParticular();
		observacao = retornarObservacaoValida(parProcedimento.getObservacaoGuiche());
		for (final ConsultaQuestionarioExameResult locConsultaQuestionarioExameResult : parQuestionarios) {
			if (locConsultaQuestionarioExameResult.getQuestionarios() != null
					&& parProcedimento.getExame().getExame().equals(locConsultaQuestionarioExameResult.getExame())
					&& parProcedimento.getExame().getMaterial()
							.equals(locConsultaQuestionarioExameResult.getMaterial())) {
				for (final Questionario questionario : locConsultaQuestionarioExameResult.getQuestionarios()) {
					if (!questionario.getImpresso().equals("S")) {
						questionarios.add(new QuestionarioEntrega(questionario, parPerguntas));
					}
				}
			}
		}
	}

	public ExamePedido(final ProcedimentoComExamesTO parProcedimento,
			final List<ConsultaQuestionarioExameResult> parQuestionarios, final List<PerguntaEntrega> parPerguntas,
			final ExamesPedidos parExames, final Solicitante parSolicitante) {
		exame = parProcedimento.getExame().getExame();
		codigoExame = parProcedimento.getProcedimento();
		dataHoraMarcacao = retornarHoraDataMarcacao(parProcedimento);
		sequenciaExame = parProcedimento.getSequenciaExame();
		material = parProcedimento.getExame().getMaterial();
		solicitante = parSolicitante;
		verificarSeProcedimentoEhVt(parProcedimento);
		condicaoAmostra = retornarCodigoAmostraValido(parProcedimento.getCondicaoAmostra());
		questionarios = new QuestionariosEntrega();
		descricaoMaterial = retornarDescricaoMaterial(parProcedimento);
		localColeta = Constantes.LOCAL_COLETA_PADRAO;
		particular = parProcedimento.getParticular();
		observacao = retornarObservacaoValida(parProcedimento.getObservacaoGuiche());
		for (final ConsultaQuestionarioExameResult locConsultaQuestionarioExameResult : parQuestionarios) {
			if (locConsultaQuestionarioExameResult.getQuestionarios() != null
					&& parProcedimento.getExame().getExame().equals(locConsultaQuestionarioExameResult.getExame())) {
				for (final Questionario questionario : locConsultaQuestionarioExameResult.getQuestionarios()) {
					if (!questionario.getImpresso().equals("S")) {
						questionarios.add(new QuestionarioEntrega(questionario, parPerguntas));
					}
				}
			}
		}
	}

	public ExamePedido(final ProcedimentoComExamesTO parProcedimento,
			final List<ConsultaQuestionarioExameResult> parQuestionarios, final List<PerguntaEntrega> parPerguntas,
			final ExamesPedidos parExames, final List<ExameHermesPardini> parExamesFilhos,
			final Solicitante parSolicitante) {
		exame = parProcedimento.getExame().getExame();
		codigoExame = parProcedimento.getProcedimento();
		dataHoraMarcacao = retornarHoraDataMarcacao(parProcedimento);
		sequenciaExame = parProcedimento.getSequenciaExame();
		material = parProcedimento.getExame().getMaterial();
		solicitante = parSolicitante;
		verificarSeProcedimentoEhVt(parProcedimento);
		condicaoAmostra = retornarCodigoAmostraValido(parProcedimento.getCondicaoAmostra());
		descricaoMaterial = retornarDescricaoMaterial(parProcedimento);
		localColeta = Constantes.LOCAL_COLETA_PADRAO;
		particular = parProcedimento.getParticular();
		examesFilhos = new ExamesPedidoFilhos();
		observacao = retornarObservacaoValida(parProcedimento.getObservacaoGuiche());
		for (final ExameHermesPardini locExameHermesPardini : parExamesFilhos) {
			examesFilhos.add(new ExamePedidoFilho(locExameHermesPardini, parQuestionarios, parPerguntas,
					retornarHoraDataMarcacao(parProcedimento), parProcedimento));
		}
	}

	private void verificarSeProcedimentoEhVt(final ProcedimentoComExamesTO parProcedimento) {
		if (parProcedimento.getVt()) {
			dataHoraColeta = "";
		} else {
			dataHoraColeta = new DataUtil().formatarDateParaStringoComHoraSegundo(new Date());
		}
	}

	private String retornarHoraDataMarcacao(final ProcedimentoComExamesTO parProcedimento) {
		try {
			if (parProcedimento.getExame().getDataHoraMarcacao() == null) {
				return "";
			} else {
				final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				return sdf.format(parProcedimento.getExame().getDataHoraMarcacao());
			}
		} catch (final Exception locExc) {
			return "";
		}
	}

	private String retornarDescricaoMaterial(final ProcedimentoComExamesTO parProcedimento) {
		try {
			if (parProcedimento.getExame().getMaterial().equals("DIV")
					&& (parProcedimento.getInformacoesAdicionais() == null
							|| parProcedimento.getInformacoesAdicionais().isEmpty())) {
				return "*****";
			} else {
				return retornarDescricaoComTamanhoValido(parProcedimento.getInformacoesAdicionais());
			}
		} catch (final Exception locExc) {
			return "*****";
		}
	}

	private String retornarDescricaoComTamanhoValido(final String parInformacoesAdicionais) {
		try {
			return Util.cortarCaractere(parInformacoesAdicionais, 30);
		} catch (final Exception locExc) {
			return "";
		}
	}

	public ExamePedido(final ProcedimentoComExamesTO parProcedimento,
			final List<ConsultaQuestionarioExameResult> parQuestionarios, final List<PerguntaEntrega> parPerguntas,
			final ExamesPedidos parExames, final List<ExameHermesPardini> parExamesFilhos,
			final Ct_dadosAutorizacao parCt_dadosAutorizacao, final InformacaoTotem parInformacaoTotem) {
		exame = parProcedimento.getExame().getExame();
		codigoExame = parProcedimento.getProcedimento();
		dataHoraMarcacao = retornarHoraDataMarcacao(parProcedimento);
		sequenciaExame = parProcedimento.getSequenciaExame();
		material = parProcedimento.getExame().getMaterial();
		solicitante = new Solicitante(parCt_dadosAutorizacao);
		verificarSeProcedimentoEhVt(parProcedimento);
		condicaoAmostra = retornarCodigoAmostraValido(parProcedimento.getCondicaoAmostra());
		descricaoMaterial = retornarDescricaoMaterial(parProcedimento);
		localColeta = Constantes.LOCAL_COLETA_PADRAO;
		particular = parProcedimento.getParticular();
		examesFilhos = new ExamesPedidoFilhos();
		observacao = retornarObservacaoValida(parProcedimento.getObservacaoGuiche());
		for (final ExameHermesPardini locExameHermesPardini : parExamesFilhos) {
			examesFilhos.add(new ExamePedidoFilho(locExameHermesPardini, parQuestionarios, parPerguntas,
					parInformacaoTotem, retornarHoraDataMarcacao(parProcedimento), parProcedimento));
		}
	}

	public ExamePedido(final ProcedimentoComExamesTO parProcedimento,
			final List<ConsultaQuestionarioExameResult> parQuestionarios, final List<PerguntaEntrega> parPerguntas,
			final ExamesPedidos parExames, final List<ExameHermesPardini> parExamesFilhos,
			final Ct_dadosAutorizacao parCt_dadosAutorizacao) {
		exame = parProcedimento.getExame().getExame();
		codigoExame = parProcedimento.getProcedimento();
		dataHoraMarcacao = retornarHoraDataMarcacao(parProcedimento);
		sequenciaExame = parProcedimento.getSequenciaExame();
		material = parProcedimento.getExame().getMaterial();
		solicitante = new Solicitante(parCt_dadosAutorizacao);
		verificarSeProcedimentoEhVt(parProcedimento);
		condicaoAmostra = retornarCodigoAmostraValido(parProcedimento.getCondicaoAmostra());
		descricaoMaterial = retornarDescricaoMaterial(parProcedimento);
		localColeta = Constantes.LOCAL_COLETA_PADRAO;
		particular = parProcedimento.getParticular();
		examesFilhos = new ExamesPedidoFilhos();
		observacao = retornarObservacaoValida(parProcedimento.getObservacaoGuiche());
		for (final ExameHermesPardini locExameHermesPardini : parExamesFilhos) {
			examesFilhos.add(new ExamePedidoFilho(locExameHermesPardini, parQuestionarios, parPerguntas,
					retornarHoraDataMarcacao(parProcedimento), parProcedimento));
		}
	}

	private ExamePedido(final DetalhePreparacao parDetalhePreparacao, final EPacoteResult ePacoteResult,
			final List<ConsultaQuestionarioExameResult> parQuestionarios, final List<PerguntaEntrega> parPerguntas) {
		exame = retornarExame(parDetalhePreparacao);
		codigoExame = "";
		dataHoraMarcacao = retornarHoraDataMarcacao();
		sequenciaExame = 1;
		material = parDetalhePreparacao.getMaterialId();
		solicitante = null;
		dataHoraColeta = "";
		condicaoAmostra = "";
		descricaoMaterial = parDetalhePreparacao.getMaterial();
		localColeta = Constantes.LOCAL_COLETA_CHECKUP;
		particular = Constantes.PARTICULAR;
		examesFilhos = new ExamesPedidoFilhos();
		for (final Composicao locComposicao : ePacoteResult.getComposicao()) {
			examesFilhos.add(new ExamePedidoFilho(parDetalhePreparacao, locComposicao, parQuestionarios, parPerguntas));
		}
		observacao = "Exame Particular.";
	}

	private String retornarHoraDataMarcacao() {
		try {
			return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
		} catch (final Exception locExc) {
			return "";
		}
	}

	private String retornarExame(final DetalhePreparacao parDetalhePreparacao) {
		try {
			return parDetalhePreparacao.getId().substring(parDetalhePreparacao.getId().indexOf("||") + 2,
					parDetalhePreparacao.getId().length());
		} catch (final Exception locExc) {
			return "";
		}
	}

	private Integer retornarSequencia(final ExamesPedidos parExames, final ExameHermesPardini exameHermesPardini) {
		return Collections.frequency(parExames, new ExamePedido(exameHermesPardini)) + 1;
	}

	public static ExamePedido criarExameCheckup(final DetalhePreparacao parDetalhePreparacao,
			final EPacoteResult ePacoteResult, final List<ConsultaQuestionarioExameResult> parQuestionarios,
			final List<PerguntaEntrega> parPerguntas) {
		return new ExamePedido(parDetalhePreparacao, ePacoteResult, parQuestionarios, parPerguntas);
	}

	public String getExame() {
		return exame;
	}

	public void setExame(final String parExame) {
		exame = parExame;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(final String parMaterial) {
		material = parMaterial;
	}

	public String getDescricaoMaterial() {
		return descricaoMaterial;
	}

	public void setDescricaoMaterial(final String parDescricaoMaterial) {
		descricaoMaterial = parDescricaoMaterial;
	}

	public Integer getSequenciaExame() {
		return sequenciaExame;
	}

	public void setSequenciaExame(final Integer parSequenciaExame) {
		sequenciaExame = parSequenciaExame;
	}

	public String getParticular() {
		return particular;
	}

	public void setParticular(final String parParticular) {
		particular = parParticular;
	}

	public String getDataHoraMarcacao() {
		return dataHoraMarcacao;
	}

	public void setDataHoraMarcacao(final String parDataHoraMarcacao) {
		dataHoraMarcacao = parDataHoraMarcacao;
	}

	public String getDataHoraColeta() {
		return dataHoraColeta;
	}

	public void setDataHoraColeta(final String parDataHoraColeta) {
		dataHoraColeta = parDataHoraColeta;
	}

	public String getLocalColeta() {
		return localColeta;
	}

	public void setLocalColeta(final String parLocalColeta) {
		localColeta = parLocalColeta;
	}

	public String getQtdeGabarito() {
		return qtdeGabarito;
	}

	public void setQtdeGabarito(final String parQtdeGabarito) {
		qtdeGabarito = parQtdeGabarito;
	}

	public String getCondicaoAmostra() {
		return condicaoAmostra;
	}

	public void setCondicaoAmostra(final String parCondicaoAmostra) {
		condicaoAmostra = parCondicaoAmostra;
	}

	public String getAmpola() {
		return ampola;
	}

	public void setAmpola(final String parAmpola) {
		ampola = parAmpola;
	}

	public String getObservacao() {
		return observacao;
	}

	public void setObservacao(final String parObservacao) {
		observacao = parObservacao;
	}

	public String getKit() {
		return kit;
	}

	public void setKit(final String parKit) {
		kit = parKit;
	}

	public Solicitante getSolicitante() {
		return solicitante;
	}

	public void setSolicitante(final Solicitante parSolicitante) {
		solicitante = parSolicitante;
	}

	public String getEquipe() {
		return equipe;
	}

	public void setEquipe(final String parEquipe) {
		equipe = parEquipe;
	}

	public Profissionais getProfissionais() {
		return profissionais;
	}

	public void setProfissionais(final Profissionais parProfissionais) {
		profissionais = parProfissionais;
	}

	public String getCodigoExame() {
		return codigoExame;
	}

	public void setCodigoExame(final String parCodigoExame) {
		codigoExame = parCodigoExame;
	}

	public String getDescricaoExame() {
		return descricaoExame;
	}

	public void setDescricaoExame(final String parDescricaoExame) {
		descricaoExame = parDescricaoExame;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (exame == null ? 0 : exame.hashCode());
		result = prime * result + (material == null ? 0 : material.hashCode());
		return result;
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final ExamePedido other = (ExamePedido) obj;
		if (exame == null) {
			if (other.exame != null) {
				return false;
			}
		} else if (!exame.equals(other.exame)) {
			return false;
		}
		if (material == null) {
			if (other.material != null) {
				return false;
			}
		} else if (!material.equals(other.material)) {
			return false;
		}
		return true;
	}

}
