package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

public class Perfil implements Serializable {

	private static final long serialVersionUID = 1L;

	private String siglaUsuario;
	private String siglaAplicacao;
	private String nomePerfil;
	private String ativo;
	private String descricaoPerfil;
	private String tipoPerfil;
	private Long id;
	private Long idAplicacao;
	private Long idPerfil;
	private Long idUsuario;
	private Long idEmpresa;

	public String getSiglaUsuario() {
		return siglaUsuario;
	}

	public void setSiglaUsuario(final String parSiglaUsuario) {
		siglaUsuario = parSiglaUsuario;
	}

	public String getSiglaAplicacao() {
		return siglaAplicacao;
	}

	public void setSiglaAplicacao(final String parSiglaAplicacao) {
		siglaAplicacao = parSiglaAplicacao;
	}

	public String getNomePerfil() {
		return nomePerfil;
	}

	public void setNomePerfil(final String parNomePerfil) {
		nomePerfil = parNomePerfil;
	}

	public String getAtivo() {
		return ativo;
	}

	public void setAtivo(final String parAtivo) {
		ativo = parAtivo;
	}

	public String getDescricaoPerfil() {
		return descricaoPerfil;
	}

	public void setDescricaoPerfil(final String parDescricaoPerfil) {
		descricaoPerfil = parDescricaoPerfil;
	}

	public String getTipoPerfil() {
		return tipoPerfil;
	}

	public void setTipoPerfil(final String parTipoPerfil) {
		tipoPerfil = parTipoPerfil;
	}

	public Long getId() {
		return id;
	}

	public void setId(final Long parId) {
		id = parId;
	}

	public Long getIdAplicacao() {
		return idAplicacao;
	}

	public void setIdAplicacao(final Long parIdAplicacao) {
		idAplicacao = parIdAplicacao;
	}

	public Long getIdPerfil() {
		return idPerfil;
	}

	public void setIdPerfil(final Long parIdPerfil) {
		idPerfil = parIdPerfil;
	}

	public Long getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(final Long parIdUsuario) {
		idUsuario = parIdUsuario;
	}

	public Long getIdEmpresa() {
		return idEmpresa;
	}

	public void setIdEmpresa(final Long parIdEmpresa) {
		idEmpresa = parIdEmpresa;
	}

}
