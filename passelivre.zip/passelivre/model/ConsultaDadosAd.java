package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

public class ConsultaDadosAd implements Serializable {

	private String mensagem;
	private String status;
	private Integer tipoUsuario;
	private UsuarioAd usuarioAd;
	private String usuarioAtivo;
	private UsuarioIHP usuarioIHP;
	private PerfilDefault perfilDefault;
	private PerfilUsuario perfilUsuario;
	private EmpresasTotem empresas;

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(final String parMensagem) {
		mensagem = parMensagem;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(final String parStatus) {
		status = parStatus;
	}

	public Integer getTipoUsuario() {
		return tipoUsuario;
	}

	public void setTipoUsuario(final Integer parTipoUsuario) {
		tipoUsuario = parTipoUsuario;
	}

	public UsuarioAd getUsuarioAd() {
		return usuarioAd;
	}

	public void setUsuarioAd(final UsuarioAd parUsuarioAd) {
		usuarioAd = parUsuarioAd;
	}

	public String getUsuarioAtivo() {
		return usuarioAtivo;
	}

	public void setUsuarioAtivo(final String parUsuarioAtivo) {
		usuarioAtivo = parUsuarioAtivo;
	}

	public UsuarioIHP getUsuarioIHP() {
		return usuarioIHP;
	}

	public void setUsuarioIHP(final UsuarioIHP parUsuarioIHP) {
		usuarioIHP = parUsuarioIHP;
	}

	public PerfilDefault getPerfilDefault() {
		return perfilDefault;
	}

	public void setPerfilDefault(final PerfilDefault parPerfilDefault) {
		perfilDefault = parPerfilDefault;
	}

	public PerfilUsuario getPerfilUsuario() {
		return perfilUsuario;
	}

	public void setPerfilUsuario(final PerfilUsuario parPerfilUsuario) {
		perfilUsuario = parPerfilUsuario;
	}

	public EmpresasTotem getEmpresas() {
		return empresas;
	}

	public void setEmpresas(final EmpresasTotem parEmpresas) {
		empresas = parEmpresas;
	}

}
