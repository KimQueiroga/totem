package br.com.hermespardini.passelivre.model;

public class Atributos {

	private String Descricao;
	private String Tipo;
	private String Valor;

	public String getDescricao() {
		return Descricao;
	}

	public String getTipo() {
		return Tipo;
	}

	public String getValor() {
		return Valor;
	}

	public void setDescricao(String Descricao) {
		this.Descricao = Descricao;
	}

	public void setTipo(String Tipo) {
		this.Tipo = Tipo;
	}

	public void setValor(String Valor) {
		this.Valor = Valor;
	}
}
