package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import br.com.hermespardini.passelivre.constantsenum.Constantes;

public class ParametroPagarPedido implements Serializable {
	private Integer unidade;
	private String empresa;
	private Integer pedido;
	private Pagante pagante;
	private List<Pagamento> pagamentos;
	private String origem;
	private String token;
	private String usuario;

	private ParametroPagarPedido(final ClienteUnidadePasseLivre parClienteUnidadePasseLivre,
			final DadosCartao parDadosCartao, final CriarPedidoResult parCriaPedidoResult, final TokenResult parToken,
			final DetalhePreparacao parDetalhePreparacao, final PagamentoResult parPagamentoResult) {
		unidade = parCriaPedidoResult.getUnidade();
		empresa = Constantes.EMPRESA;
		pedido = parCriaPedidoResult.getPedido();
		pagante = new Pagante(parClienteUnidadePasseLivre, parDadosCartao);
		origem = Constantes.ORIGEM_PADRAO;
		token = parToken.getToken();
		usuario = Constantes.USUARIO_PADRAO;
		pagamentos = new ArrayList<>();
		pagamentos.add(new Pagamento(parDadosCartao, parDetalhePreparacao, parPagamentoResult));
	}

	public static ParametroPagarPedido criarParametroPagarPedido(
			final ClienteUnidadePasseLivre parClienteUnidadePasseLivre, final DadosCartao parDadosCartao,
			final CriarPedidoResult parCriaPedidoResult, final TokenResult parToken,
			final DetalhePreparacao parDetalhePreparacao, final PagamentoResult parPagamentoResult) {
		return new ParametroPagarPedido(parClienteUnidadePasseLivre, parDadosCartao, parCriaPedidoResult, parToken,
				parDetalhePreparacao, parPagamentoResult);
	}

	public Integer getUnidade() {
		return unidade;
	}

	public void setUnidade(final Integer parUnidade) {
		unidade = parUnidade;
	}

	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(final String parEmpresa) {
		empresa = parEmpresa;
	}

	public Integer getPedido() {
		return pedido;
	}

	public void setPedido(final Integer parPedido) {
		pedido = parPedido;
	}

	public Pagante getPagante() {
		return pagante;
	}

	public void setPagante(final Pagante parPagante) {
		pagante = parPagante;
	}

	public List<Pagamento> getPagamentos() {
		return pagamentos;
	}

	public void setPagamentos(final List<Pagamento> parPagamentos) {
		pagamentos = parPagamentos;
	}

	public String getOrigem() {
		return origem;
	}

	public void setOrigem(final String parOrigem) {
		origem = parOrigem;
	}

	public String getToken() {
		return token;
	}

	public void setToken(final String parToken) {
		token = parToken;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(final String parUsuario) {
		usuario = parUsuario;
	}

}
