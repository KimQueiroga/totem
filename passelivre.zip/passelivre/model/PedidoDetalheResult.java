package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.util.List;

public class PedidoDetalheResult implements Serializable {

	private static final long serialVersionUID = 6466646637925556655L;
	
	private String status;
	private String mensagem;
	private Integer statusExamesPedido;
	private ClienteUnidadePasseLivre cliente;
	private PedidoCliente pedido;
	private List<DetalhePedidoCliente> detalhes;	

	public Integer getStatusExamesPedido() {
		return statusExamesPedido;
	}

	public void setStatusExamesPedido(Integer statusExamesPedido) {
		this.statusExamesPedido = statusExamesPedido;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}

	public List<DetalhePedidoCliente> getDetalhes() {
		return detalhes;
	}

	public void setDetalhes(List<DetalhePedidoCliente> detalhes) {
		this.detalhes = detalhes;
	}

	public ClienteUnidadePasseLivre getCliente() {
		return cliente;
	}

	public void setCliente(ClienteUnidadePasseLivre cliente) {
		this.cliente = cliente;
	}

	public PedidoCliente getPedido() {
		return pedido;
	}

	public void setPedido(PedidoCliente pedido) {
		this.pedido = pedido;
	}	
}
