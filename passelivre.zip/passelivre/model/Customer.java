package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

public class Customer implements Serializable {

	private String birthDate;
	private String city;
	private String clienteId;
	private String cpf;
	private String complement;
	private String email;
	private String fullName;
	private String gender;
	private String homePhoneNumber;
	private String mobilePhoneNumber;
	private String motherName;
	private String neighbourhood;
	private String numberStreet;
	private String postalCode;
	private String street;
	private String streetAndComplement;
	private String uf;

	public Customer() {
	}

	private Customer(final ClienteUnidadePasseLivre clienteUnidadePasseLivre) {
		birthDate = clienteUnidadePasseLivre.getDataNascimento();
		city = clienteUnidadePasseLivre.getCidade();
		clienteId = clienteUnidadePasseLivre.getCodigoCliente();
		complement = clienteUnidadePasseLivre.getComplemento();
		cpf = clienteUnidadePasseLivre.getCpf();
		email = clienteUnidadePasseLivre.getEmail();
		fullName = clienteUnidadePasseLivre.getNomeCliente();
		gender = clienteUnidadePasseLivre.getSexo();
		homePhoneNumber = clienteUnidadePasseLivre.getTelefone();
		mobilePhoneNumber = clienteUnidadePasseLivre.getCelular();
		motherName = clienteUnidadePasseLivre.getNomeMae();
		neighbourhood = "";
		numberStreet = clienteUnidadePasseLivre.getNumero();
		postalCode = clienteUnidadePasseLivre.getCep();
		street = clienteUnidadePasseLivre.getRua();
		streetAndComplement = clienteUnidadePasseLivre.getComplemento();
		uf = clienteUnidadePasseLivre.getUf();
	}

	public static Customer criarClienteCheckup(final ClienteUnidadePasseLivre clienteUnidadePasseLivre) {
		return new Customer(clienteUnidadePasseLivre);
	}

	public String getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(final String parBirthDate) {
		birthDate = parBirthDate;
	}

	public String getCity() {
		return city;
	}

	public void setCity(final String parCity) {
		city = parCity;
	}

	public String getClienteId() {
		return clienteId;
	}

	public void setClienteId(final String parClienteId) {
		clienteId = parClienteId;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(final String parCpf) {
		cpf = parCpf;
	}

	public String getComplement() {
		return complement;
	}

	public void setComplement(final String parComplement) {
		complement = parComplement;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(final String parEmail) {
		email = parEmail;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(final String parFullName) {
		fullName = parFullName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(final String parGender) {
		gender = parGender;
	}

	public String getHomePhoneNumber() {
		return homePhoneNumber;
	}

	public void setHomePhoneNumber(final String parHomePhoneNumber) {
		homePhoneNumber = parHomePhoneNumber;
	}

	public String getMobilePhoneNumber() {
		return mobilePhoneNumber;
	}

	public void setMobilePhoneNumber(final String parMobilePhoneNumber) {
		mobilePhoneNumber = parMobilePhoneNumber;
	}

	public String getMotherName() {
		return motherName;
	}

	public void setMotherName(final String parMotherName) {
		motherName = parMotherName;
	}

	public String getNeighbourhood() {
		return neighbourhood;
	}

	public void setNeighbourhood(final String parNeighbourhood) {
		neighbourhood = parNeighbourhood;
	}

	public String getNumberStreet() {
		return numberStreet;
	}

	public void setNumberStreet(final String parNumberStreet) {
		numberStreet = parNumberStreet;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(final String parPostalCode) {
		postalCode = parPostalCode;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(final String parStreet) {
		street = parStreet;
	}

	public String getStreetAndComplement() {
		return streetAndComplement;
	}

	public void setStreetAndComplement(final String parStreetAndComplement) {
		streetAndComplement = parStreetAndComplement;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(final String parUf) {
		uf = parUf;
	}

}
