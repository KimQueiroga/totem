package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

public class DadosSessao implements Serializable {

	private Long idUnidade;
	private String sessionId;
	private Localizacao localizacao;
	private TokenResult tokenResult;
	private ConsultaDadosAd consultaDadosAd;

	public DadosSessao() {
	}

	public DadosSessao(final Long parIdUnidade, final String parSessionId, final Localizacao parLocalizacao,
			final TokenResult parTokenResult, final ConsultaDadosAd parConsultaDadosAd) {
		idUnidade = parIdUnidade;
		sessionId = parSessionId;
		localizacao = parLocalizacao;
		tokenResult = parTokenResult;
		consultaDadosAd = parConsultaDadosAd;
	}

	public Long getIdUnidade() {
		return idUnidade;
	}

	public void setIdUnidade(final Long parIdUnidade) {
		idUnidade = parIdUnidade;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(final String parSessionId) {
		sessionId = parSessionId;
	}

	public TokenResult getTokenResult() {
		return tokenResult;
	}

	public void setTokenResult(final TokenResult parTokenResult) {
		tokenResult = parTokenResult;
	}

	public ConsultaDadosAd getConsultaDadosAd() {
		return consultaDadosAd;
	}

	public void setConsultaDadosAd(final ConsultaDadosAd parConsultaDadosAd) {
		consultaDadosAd = parConsultaDadosAd;
	}

	public Localizacao getLocalizacao() {
		return localizacao;
	}

	public void setLocalizacao(final Localizacao parLocalizacao) {
		localizacao = parLocalizacao;
	}

}
