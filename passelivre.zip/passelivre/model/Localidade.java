package br.com.hermespardini.passelivre.model;

import java.util.Map;

import org.wdelmaschio.base.model.ValueObject;

public class Localidade extends ValueObject {

	private String codigounimed;
	private String codigounidade;
	private String piece3;
	private String piece4;
	private String ip;
	private Integer filial;
	private Integer localizacao;

	public Localidade() {
	}

	public Localidade(final Map<?, ?> pObjectMapping) {
		super(pObjectMapping);
	}

	public String getCodigounimed() {
		return codigounimed;
	}

	public void setCodigounimed(final String codigounimed) {
		this.codigounimed = codigounimed;
	}

	public String getCodigounidade() {
		return codigounidade;
	}

	public void setCodigounidade(final String codigounidade) {
		this.codigounidade = codigounidade;
	}

	public String getPiece3() {
		return piece3;
	}

	public void setPiece3(final String piece3) {
		this.piece3 = piece3;
	}

	public String getPiece4() {
		return piece4;
	}

	public void setPiece4(final String piece4) {
		this.piece4 = piece4;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(final String ip) {
		this.ip = ip;
	}

	public Integer getFilial() {
		return filial;
	}

	public void setFilial(final Integer filial) {
		this.filial = filial;
	}

	public Integer getLocalizacao() {
		return localizacao;
	}

	public void setLocalizacao(final Integer localizacao) {
		this.localizacao = localizacao;
	}

	public String retornarCodigoLocal(final String codigoUnidadeParam) {
		return "unbh" + codigoUnidadeParam;
	}

}
