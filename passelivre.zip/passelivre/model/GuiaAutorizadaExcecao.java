package br.com.hermespardini.passelivre.model;

import br.com.unimedbh.www.Ct_dadosAutorizacao;
import br.gov.ans.www.padroes.tiss.schemas.Ct_itemSolicitacao;

public class GuiaAutorizadaExcecao {

	private String senhaAutorizacao;
	private String numeroGuiaOperadora;
	private String observacao;

	public GuiaAutorizadaExcecao(final Ct_dadosAutorizacao parCt_dadosAutorizacao,
			final Ct_itemSolicitacao parCt_itemSolicitacao) {
		senhaAutorizacao = parCt_dadosAutorizacao.getDadosAutorizacao().getSenhaAutorizacao();
		numeroGuiaOperadora = parCt_dadosAutorizacao.getIdentificacaoAutorizacao().getNumeroGuiaOperadora();
		observacao = parCt_itemSolicitacao.getObservacao();
	}

	private GuiaAutorizadaExcecao(final Ct_dadosAutorizacao parCt_dadosAutorizacao) {
		senhaAutorizacao = parCt_dadosAutorizacao.getDadosAutorizacao().getSenhaAutorizacao();
		numeroGuiaOperadora = parCt_dadosAutorizacao.getIdentificacaoAutorizacao().getNumeroGuiaOperadora();
		observacao = "Guia perdeu a validade!";
	}

	public GuiaAutorizadaExcecao(final Ct_dadosAutorizacao parCt_dadosAutorizacao, final String mensagem) {
		senhaAutorizacao = parCt_dadosAutorizacao.getDadosAutorizacao().getSenhaAutorizacao();
		numeroGuiaOperadora = parCt_dadosAutorizacao.getIdentificacaoAutorizacao().getNumeroGuiaOperadora();
		observacao = mensagem;
	}

	public static GuiaAutorizadaExcecao retornarGuiaForaDaValidade(final Ct_dadosAutorizacao parCt_dadosAutorizacao) {
		return new GuiaAutorizadaExcecao(parCt_dadosAutorizacao);
	}

	public static GuiaAutorizadaExcecao retornarGuiasEmGlosa(final Ct_dadosAutorizacao parCt_dadosAutorizacao) {
		return new GuiaAutorizadaExcecao(parCt_dadosAutorizacao, "Guia não atendida no totem!");
	}

	public String getSenhaAutorizacao() {
		return senhaAutorizacao;
	}

	public void setSenhaAutorizacao(final String parSenhaAutorizacao) {
		senhaAutorizacao = parSenhaAutorizacao;
	}

	public String getNumeroGuiaOperadora() {
		return numeroGuiaOperadora;
	}

	public void setNumeroGuiaOperadora(final String parNumeroGuiaOperadora) {
		numeroGuiaOperadora = parNumeroGuiaOperadora;
	}

	public String getObservacao() {
		return observacao;
	}

	public void setObservacao(final String parObservacao) {
		observacao = parObservacao;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (numeroGuiaOperadora == null ? 0 : numeroGuiaOperadora.hashCode());
		result = prime * result + (senhaAutorizacao == null ? 0 : senhaAutorizacao.hashCode());
		return result;
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final GuiaAutorizadaExcecao other = (GuiaAutorizadaExcecao) obj;
		if (numeroGuiaOperadora == null) {
			if (other.numeroGuiaOperadora != null) {
				return false;
			}
		} else if (!numeroGuiaOperadora.equals(other.numeroGuiaOperadora)) {
			return false;
		}
		if (senhaAutorizacao == null) {
			if (other.senhaAutorizacao != null) {
				return false;
			}
		} else if (!senhaAutorizacao.equals(other.senhaAutorizacao)) {
			return false;
		}
		return true;
	}

}
