package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.util.List;

import br.com.hermespardini.passelivre.to.DepartamentoFiltroTO;
import br.com.hermespardini.passelivre.to.ExameFiltroTO;
import br.com.hermespardini.passelivre.to.OperadoraFiltroTO;
import br.com.hermespardini.passelivre.to.ProcedimentoFiltroTO;

public class ExcecaoAtendimentoResult implements Serializable {

	private String mensagem;
	private List<ExameFiltroTO> exames;
	private List<OperadoraFiltroTO> operadoras;
	private List<ProcedimentoFiltroTO> procedimentos;
	private List<DepartamentoFiltroTO> departamentos;
	private String status;

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(final String parMensagem) {
		mensagem = parMensagem;
	}

	public List<ExameFiltroTO> getExames() {
		return exames;
	}

	public void setExames(final List<ExameFiltroTO> parExames) {
		exames = parExames;
	}

	public List<ProcedimentoFiltroTO> getProcedimentos() {
		return procedimentos;
	}

	public void setProcedimentos(final List<ProcedimentoFiltroTO> parProcedimentos) {
		procedimentos = parProcedimentos;
	}

	public List<DepartamentoFiltroTO> getDepartamentos() {
		return departamentos;
	}

	public void setDepartamentos(final List<DepartamentoFiltroTO> parDepartamentos) {
		departamentos = parDepartamentos;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(final String parStatus) {
		status = parStatus;
	}

	public List<OperadoraFiltroTO> getOperadoras() {
		return operadoras;
	}

	public void setOperadoras(final List<OperadoraFiltroTO> parOperadoras) {
		operadoras = parOperadoras;
	}

}
