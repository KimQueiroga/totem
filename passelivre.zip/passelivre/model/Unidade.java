package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

import com.google.gson.annotations.SerializedName;

public class Unidade implements Serializable, Comparable<Unidade> {

	private Long codigo;
	private String nome;
	private String sigla;
	private String uf;
	private String situacao;
	private UnimedBH unimedBH;
	private Localizacoes localizacoes;

	@SerializedName("default")
	private Integer valueDefault;

	public Unidade() {
		valueDefault = 0;
	}

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(final Long parCodigo) {
		codigo = parCodigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(final String parNome) {
		nome = parNome;
	}

	public String getSigla() {
		return sigla;
	}

	public void setSigla(final String parSigla) {
		sigla = parSigla;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(final String parUf) {
		uf = parUf;
	}

	public String getSituacao() {
		return situacao;
	}

	public void setSituacao(final String parSituacao) {
		situacao = parSituacao;
	}

	public UnimedBH getUnimedBH() {
		return unimedBH;
	}

	public void setUnimedBH(final UnimedBH parUnimedBH) {
		unimedBH = parUnimedBH;
	}

	public Localizacoes getLocalizacoes() {
		return localizacoes;
	}

	public void setLocalizacoes(final Localizacoes parLocalizacoes) {
		localizacoes = parLocalizacoes;
	}

	public Integer getValueDefault() {
		return valueDefault;
	}

	public void setValueDefault(final Integer parValueDefault) {
		valueDefault = parValueDefault;
	}

	@Override
	public String toString() {
		return nome;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (codigo == null ? 0 : codigo.hashCode());
		result = prime * result + (nome == null ? 0 : nome.hashCode());
		return result;
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final Unidade other = (Unidade) obj;
		if (codigo == null) {
			if (other.codigo != null) {
				return false;
			}
		} else if (!codigo.equals(other.codigo)) {
			return false;
		}
		if (nome == null) {
			if (other.nome != null) {
				return false;
			}
		} else if (!nome.equals(other.nome)) {
			return false;
		}
		return true;
	}

	@Override
	public int compareTo(final Unidade unidade) {
		if (unidade != null && nome != null) {
			return nome.compareTo(unidade.getNome());
		} else {
			return 0;
		}
	}

}
