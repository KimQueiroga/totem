package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Map;

import org.wdelmaschio.base.model.ValueObject;

import br.com.hermespardini.passelivre.constantsenum.Constantes;

@SuppressWarnings("serial")
public class ControleEstatistico extends ValueObject implements Serializable {

	private Long id;
	private String sigla;
	private Long idTotem;
	private String origem;
	private String codigo;
	private String unidade;
	private Timestamp data;
	private Long idServico;
	private String matricula;
	private String codigoCliente;
	private String planoConvenio;
	private String operadoraConvenio;
	private String usuUltAtualizacao;
	private Timestamp dataHoraUltAtualizacao;

	public ControleEstatistico(final String parCodigoCliente, final String parOperadoraConvenio,
			final String parDescricaoServico, final Long parIdTotem, final String parMatricula,
			final String parPlanoConvenio, final String parUnidade) {
		codigoCliente = parCodigoCliente;
		operadoraConvenio = parOperadoraConvenio;
		data = new Timestamp(System.currentTimeMillis());
		dataHoraUltAtualizacao = new Timestamp(System.currentTimeMillis());
		usuUltAtualizacao = Constantes.USUARIO_PADRAO;
		origem = Constantes.ORIGEM_ESTATISTICO_PADRAO;
		codigo = parDescricaoServico;
		idTotem = parIdTotem;
		matricula = parMatricula;
		idServico = Constantes.SERVICO_PADRAO;
		planoConvenio = parPlanoConvenio;
		unidade = parUnidade;
	}

	public ControleEstatistico(final String parCodigoCliente, final String parOperadoraConvenio,
			final String parDescricaoServico, final String parSiglaCliente, final String parMatricula,
			final String parPlanoConvenio, final String parUnidade) {
		codigoCliente = parCodigoCliente;
		operadoraConvenio = parOperadoraConvenio;
		data = new Timestamp(System.currentTimeMillis());
		dataHoraUltAtualizacao = new Timestamp(System.currentTimeMillis());
		usuUltAtualizacao = parSiglaCliente;
		origem = Constantes.ORIGEM_ESTATISTICO_DESKTOP;
		codigo = parDescricaoServico;
		sigla = parSiglaCliente;
		matricula = parMatricula;
		idServico = Constantes.SERVICO_PADRAO;
		planoConvenio = parPlanoConvenio;
		unidade = parUnidade;
	}

	public ControleEstatistico() {

	}

	@SuppressWarnings("rawtypes")
	public ControleEstatistico(final Map paramObjectMap) {
		super(paramObjectMap);
	}

	public Long getId() {
		return id;
	}

	public void setId(final Long parId) {
		id = parId;
	}

	public String getCodigoCliente() {
		return codigoCliente;
	}

	public void setCodigoCliente(final String parCodigoCliente) {
		codigoCliente = parCodigoCliente;
	}

	public String getOperadoraConvenio() {
		return operadoraConvenio;
	}

	public void setOperadoraConvenio(final String parOperadoraConvenio) {
		operadoraConvenio = parOperadoraConvenio;
	}

	public Timestamp getData() {
		return data;
	}

	public void setData(final Timestamp parData) {
		data = parData;
	}

	public Long getIdServico() {
		return idServico;
	}

	public void setIdServico(final Long parIdServico) {
		idServico = parIdServico;
	}

	public Timestamp getDataHoraUltAtualizacao() {
		return dataHoraUltAtualizacao;
	}

	public void setDataHoraUltAtualizacao(final Timestamp parDataHoraUltAtualizacao) {
		dataHoraUltAtualizacao = parDataHoraUltAtualizacao;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(final String parCodigo) {
		codigo = parCodigo;
	}

	public Long getIdTotem() {
		return idTotem;
	}

	public void setIdTotem(final Long parIdTotem) {
		idTotem = parIdTotem;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(final String parMatricula) {
		matricula = parMatricula;
	}

	public String getPlanoConvenio() {
		return planoConvenio;
	}

	public void setPlanoConvenio(final String parPlanoConvenio) {
		planoConvenio = parPlanoConvenio;
	}

	public String getUsuUltAtualizacao() {
		return usuUltAtualizacao;
	}

	public void setUsuUltAtualizacao(final String parUsuUltAtualizacao) {
		usuUltAtualizacao = parUsuUltAtualizacao;
	}

	public String getSigla() {
		return sigla;
	}

	public void setSigla(final String parSigla) {
		sigla = parSigla;
	}

	public String getOrigem() {
		return origem;
	}

	public void setOrigem(final String parOrigem) {
		origem = parOrigem;
	}

	public String getUnidade() {
		return unidade;
	}

	public void setUnidade(final String parUnidade) {
		unidade = parUnidade;
	}

}
