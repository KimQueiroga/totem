package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.unimedbh.www.Ct_dadosAutorizacao;
import br.com.unimedbh.www.ws.tipos.Ws_respostaCobertura;

@SuppressWarnings("serial")
public class Paciente implements Serializable {

	private String operadora;
	private String carteira;
	private String dataValidadeCarteira;
	private String codigo;
	private String nome;
	private String dataNascimento;
	private String estadoCivil;
	private String genero;
	private String nacionalidade;
	private String cpf;
	private String telefone;
	private String celular;
	private String email;
	private Endereco endereco;
	private String nomeMae;
	private String nomePai;
	private String nomeResponsavel;
	private String tipoDocumento;
	private String documento;
	private String plano;
	private String descricaoOperadora;

	public Paciente(final ClienteUnidadePasseLivre parClienteUnidadePasseLivre,
			final Ct_dadosAutorizacao parGuiasAutorizadaSelecionada, final Ws_respostaCobertura parWs_respostaCobertura)
			throws Exception {
		carteira = parGuiasAutorizadaSelecionada.getBeneficiario().getNumeroCarteira();
		dataNascimento = parClienteUnidadePasseLivre.getDataNascimento();
		codigo = parClienteUnidadePasseLivre.getCodigoCliente();
		nome = parClienteUnidadePasseLivre.getNomeCliente();
		estadoCivil = parClienteUnidadePasseLivre.getEstadoCivil();
		genero = parClienteUnidadePasseLivre.getSexo();
		nacionalidade = parClienteUnidadePasseLivre.getNacionalidade();
		cpf = parClienteUnidadePasseLivre.getCpf();
		telefone = retornarTelefoneValido(parClienteUnidadePasseLivre.getTelefone());
		celular = retornarTelefoneValido(parClienteUnidadePasseLivre.getCelular());
		email = parClienteUnidadePasseLivre.getEmail();
		endereco = new Endereco(parClienteUnidadePasseLivre);
		nomeMae = parClienteUnidadePasseLivre.getNomeMae();
		tipoDocumento = Constantes.TIPO_DOCUMENTO;
		plano = parWs_respostaCobertura.getRespostaCobertura().getSituacaoBeneficiario().getProdutoBeneficiario();
		operadora = parClienteUnidadePasseLivre.getOperadora();
		dataValidadeCarteira = parGuiasAutorizadaSelecionada.getBeneficiario().getValidadeCarteira();
	}

	public Paciente(final ClienteUnidadePasseLivre parClienteUnidadePasseLivre) {
		carteira = "";
		dataNascimento = parClienteUnidadePasseLivre.getDataNascimento();
		codigo = parClienteUnidadePasseLivre.getCodigoCliente();
		nome = parClienteUnidadePasseLivre.getNomeCliente();
		estadoCivil = parClienteUnidadePasseLivre.getEstadoCivil();
		genero = parClienteUnidadePasseLivre.getSexo();
		nacionalidade = parClienteUnidadePasseLivre.getNacionalidade();
		cpf = parClienteUnidadePasseLivre.getCpf();
		telefone = retornarTelefoneValido(parClienteUnidadePasseLivre.getTelefone());
		celular = retornarTelefoneValido(parClienteUnidadePasseLivre.getCelular());
		email = parClienteUnidadePasseLivre.getEmail();
		endereco = new Endereco(parClienteUnidadePasseLivre);
		nomeMae = parClienteUnidadePasseLivre.getNomeMae();
		tipoDocumento = Constantes.TIPO_DOCUMENTO;
		plano = "";
		operadora = Constantes.OPERADORA_PARTICULAR;
		dataValidadeCarteira = "";
	}

	private String retornarTelefoneValido(final String parTelefone) {
		if (parTelefone != null && !parTelefone.isEmpty()) {
			return parTelefone.replace("-", "").replace("(", "").replace(")", "");
		} else {
			return "";
		}
	}

	public static Paciente criarPacienteParticular(final ClienteUnidadePasseLivre parClienteUnidadePasseLivre) {
		return new Paciente(parClienteUnidadePasseLivre);
	}

	public static Paciente criarPacienteCheckup(final ClienteUnidadePasseLivre parClienteUnidadePasseLivre) {
		Paciente paciente = new Paciente(parClienteUnidadePasseLivre);
		paciente.setOperadora(Constantes.OPERADORA_CAMPANHA);
		return paciente;
	}

	public static Paciente criarPacientePreAtendimento(final ClienteUnidadePasseLivre parClienteUnidadePasseLivre,
			PreAtendimento parPreAtendimento) {
		Paciente p = new Paciente(parClienteUnidadePasseLivre);
		p.setCarteira(parPreAtendimento.getPaciente().getCarteira());
		p.setDataValidadeCarteira(parPreAtendimento.getPaciente().getDataValidadeCarteira());
		p.setPlano(parPreAtendimento.getPaciente().getPlano());
		p.setOperadora(parPreAtendimento.getPaciente().getOperadora());
		return p;
	}

	public String getCarteira() {
		return carteira;
	}

	public void setCarteira(final String parCarteira) {
		carteira = parCarteira;
	}

	public String getDataValidadeCarteira() {
		return dataValidadeCarteira;
	}

	public void setDataValidadeCarteira(final String parDataValidadeCarteira) {
		dataValidadeCarteira = parDataValidadeCarteira;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(final String parCodigo) {
		codigo = parCodigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(final String parNome) {
		nome = parNome;
	}

	public String getDataNascimento() {
		return dataNascimento;
	}

	public void setDataNascimento(final String parDataNascimento) {
		dataNascimento = parDataNascimento;
	}

	public String getEstadoCivil() {
		return estadoCivil;
	}

	public void setEstadoCivil(final String parEstadoCivil) {
		estadoCivil = parEstadoCivil;
	}

	public String getGenero() {
		return genero;
	}

	public void setGenero(final String parGenero) {
		genero = parGenero;
	}

	public String getNacionalidade() {
		return nacionalidade;
	}

	public void setNacionalidade(final String parNacionalidade) {
		nacionalidade = parNacionalidade;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(final String parCpf) {
		cpf = parCpf;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(final String parTelefone) {
		telefone = parTelefone;
	}

	public String getCelular() {
		return celular;
	}

	public void setCelular(final String parCelular) {
		celular = parCelular;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(final String parEmail) {
		email = parEmail;
	}

	public Endereco getEndereco() {
		return endereco;
	}

	public void setEndereco(final Endereco parEndereco) {
		endereco = parEndereco;
	}

	public String getNomeMae() {
		return nomeMae;
	}

	public void setNomeMae(final String parNomeMae) {
		nomeMae = parNomeMae;
	}

	public String getNomePai() {
		return nomePai;
	}

	public void setNomePai(final String parNomePai) {
		nomePai = parNomePai;
	}

	public String getNomeResponsavel() {
		return nomeResponsavel;
	}

	public void setNomeResponsavel(final String parNomeResponsavel) {
		nomeResponsavel = parNomeResponsavel;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(final String parTipoDocumento) {
		tipoDocumento = parTipoDocumento;
	}

	public String getDocumento() {
		return documento;
	}

	public void setDocumento(final String parDocumento) {
		documento = parDocumento;
	}

	public String getPlano() {
		return plano;
	}

	public void setPlano(final String parPlano) {
		plano = parPlano;
	}

	public String getOperadora() {
		return operadora;
	}

	public void setOperadora(final String parOperadora) {
		operadora = parOperadora;
	}

	public String getDescricaoOperadora() {
		return descricaoOperadora;
	}

	public void setDescricaoOperadora(final String parDescricaoOperadora) {
		descricaoOperadora = parDescricaoOperadora;
	}
}
