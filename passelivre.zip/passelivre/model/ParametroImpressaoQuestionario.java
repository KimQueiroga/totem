package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.wdelmaschio.base.model.ValueObject;

import br.com.hermespardini.passelivre.to.ProcedimentoComExamesTO;

public class ParametroImpressaoQuestionario extends ValueObject implements Serializable {

	private List<ExameMaterialParaQuestionario> exames;
	private String token;
	private String origem;
	private String impressora;

	public ParametroImpressaoQuestionario(final ParametroQuestionario parParametroQuestionario,
			final List<ProcedimentoComExamesTO> parProcedimentosComExames, final String parImpressoraDefault) {
		exames = new ArrayList<>();
		for (final ProcedimentoComExamesTO locProcedimentoComExamesTO : parProcedimentosComExames) {
			if (locProcedimentoComExamesTO.getExame().getMaterial().equals("VIVO")) {
				exames.add(new ExameMaterialParaQuestionario(locProcedimentoComExamesTO));
			}
		}
		token = parParametroQuestionario.getToken();
		origem = parParametroQuestionario.getOrigem();
		impressora = parImpressoraDefault;
	}

	public List<ExameMaterialParaQuestionario> getExames() {
		return exames;
	}

	public void setExames(final List<ExameMaterialParaQuestionario> parExames) {
		exames = parExames;
	}

	public String getToken() {
		return token;
	}

	public void setToken(final String parToken) {
		token = parToken;
	}

	public String getOrigem() {
		return origem;
	}

	public void setOrigem(final String parOrigem) {
		origem = parOrigem;
	}

	public String getImpressora() {
		return impressora;
	}

	public void setImpressora(final String parImpressora) {
		impressora = parImpressora;
	}

}
