package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.Expose;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ConsultaCepResult implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Expose
	@JsonProperty("bairro")
	private String bairro;

	@Expose
	@JsonProperty("bairroAbreviado")
	private String bairroAbreviado;

	@Expose
	@JsonProperty("localidade")
	private String localidade;
	
	@Expose
	@JsonProperty("logradouro")
	private String logradouro;
	
	@Expose
	@JsonProperty("logradouroAbreviado")
	private String logradouroAbreviado;
	
	@Expose
	@JsonProperty("tipoEndereco")
	private String tipoEndereco;
	
	@Expose
	@JsonProperty("uf")
	private String uf;

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public String getBairroAbreviado() {
		return bairroAbreviado;
	}

	public void setBairroAbreviado(String bairroAbreviado) {
		this.bairroAbreviado = bairroAbreviado;
	}

	public String getLocalidade() {
		return localidade;
	}

	public void setLocalidade(String localidade) {
		this.localidade = localidade;
	}

	public String getLogradouro() {
		return logradouro;
	}

	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}

	public String getLogradouroAbreviado() {
		return logradouroAbreviado;
	}

	public void setLogradouroAbreviado(String logradouroAbreviado) {
		this.logradouroAbreviado = logradouroAbreviado;
	}

	public String getTipoEndereco() {
		return tipoEndereco;
	}

	public void setTipoEndereco(String tipoEndereco) {
		this.tipoEndereco = tipoEndereco;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}
}
