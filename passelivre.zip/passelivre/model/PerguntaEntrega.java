package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

import com.owlike.genson.annotation.JsonIgnore;

@SuppressWarnings("serial")
public class PerguntaEntrega implements Serializable {

	private String codigoPergunta;
	@JsonIgnore
	private String codigoQuestionario;
	private Resposta resposta;

	public PerguntaEntrega(final String parRetornarCodigoPergunta, final String parCodigoQuestionario,
			final String parValue) {
		codigoPergunta = parRetornarCodigoPergunta;
		codigoQuestionario = parCodigoQuestionario;
		resposta = new Resposta(parValue);
	}

	public PerguntaEntrega(final PerguntaEntrega parPerguntaEntrega) {
		codigoPergunta = parPerguntaEntrega.getCodigoPergunta();
		resposta = new Resposta(parPerguntaEntrega.getResposta().getDescricao());
		codigoQuestionario = parPerguntaEntrega.getCodigoQuestionario();
	}

	public String getCodigoPergunta() {
		return codigoPergunta;
	}

	public void setCodigoPergunta(final String parCodigoPergunta) {
		codigoPergunta = parCodigoPergunta;
	}

	public Resposta getResposta() {
		return resposta;
	}

	public void setResposta(final Resposta parResposta) {
		resposta = parResposta;
	}

	public String getCodigoQuestionario() {
		return codigoQuestionario;
	}

	public void setCodigoQuestionario(final String parCodigoQuestionario) {
		codigoQuestionario = parCodigoQuestionario;
	}

	@Override
	public boolean equals(final Object parObj) {
		final PerguntaEntrega pergunta = (PerguntaEntrega) parObj;
		if (codigoPergunta.equals(pergunta.getCodigoPergunta())
				&& codigoQuestionario.equals(pergunta.getCodigoQuestionario())) {
			return true;
		}
		return super.equals(parObj);
	}
}
