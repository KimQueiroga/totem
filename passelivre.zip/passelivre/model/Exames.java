/**
 * 
 */
package br.com.hermespardini.passelivre.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * @author igor.pessanha
 *
 */
@SuppressWarnings("serial")
public class Exames extends ArrayList<ExameMaterialPendente> {

	public Exames() {
		super();
	}

	public Exames(final Collection<? extends ExameMaterialPendente> parExames) {
		super(parExames);
	}

	public final List<ExameMaterialPendente> getExames() {
		return this;
	}

	public final void setExames(final List<ExameMaterialPendente> parExames) {
		this.addAll(parExames);
	}
}
