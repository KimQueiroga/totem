package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Totem implements Serializable {

	private String ip;
	private Long idUnidade;
	private Long idTotem;
	private String descricao;
	private String macAdress;
	private String observacao;
	private Servicos servicos;
	private String nomeUnidade;
	private Long localImpressao;
	private String tipoImpressao;
	private String numeroPatrimonio;
	private String impressoraDefault;
	private String leitorCodigoBarras;
	private String nomeEmpresa;
	private Long idEmpresa;
	private String cnesUnidade;
	private String ufUnidade;
	private String cidadeUnidade;
	private String impressoraIP;
	private String impressoraPorta;

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(final String parDescricao) {
		descricao = parDescricao;
	}

	public String getImpressoraDefault() {
		return impressoraDefault;
	}

	public void setImpressoraDefault(final String parImpressoraDefault) {
		impressoraDefault = parImpressoraDefault;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(final String parIp) {
		ip = parIp;
	}

	public Long getIdTotem() {
		return idTotem;
	}

	public void setIdTotem(final Long parIdTotem) {
		idTotem = parIdTotem;
	}

	public Long getLocalImpressao() {
		return localImpressao;
	}

	public void setLocalImpressao(final Long parLocalImpressao) {
		localImpressao = parLocalImpressao;
	}

	public String getMacAdress() {
		return macAdress;
	}

	public void setMacAdress(final String parMacAdress) {
		macAdress = parMacAdress;
	}

	public String getObservacao() {
		return observacao;
	}

	public void setObservacao(final String parObservacao) {
		observacao = parObservacao;
	}

	public Servicos getServicos() {
		return servicos;
	}

	public void setServicos(final Servicos parServicos) {
		servicos = parServicos;
	}

	public String getNomeUnidade() {
		return nomeUnidade;
	}

	public void setNomeUnidade(final String parNomeUnidade) {
		nomeUnidade = parNomeUnidade;
	}

	public String getTipoImpressao() {
		return tipoImpressao;
	}

	public void setTipoImpressao(final String parTipoImpressao) {
		tipoImpressao = parTipoImpressao;
	}

	public Long getIdUnidade() {
		return idUnidade;
	}

	public void setIdUnidade(final Long parUnidade) {
		idUnidade = parUnidade;
	}

	public String getNumeroPatrimonio() {
		return numeroPatrimonio;
	}

	public void setNumeroPatrimonio(final String parNumeroPatrimonio) {
		numeroPatrimonio = parNumeroPatrimonio;
	}

	public String getLeitorCodigoBarras() {
		return leitorCodigoBarras;
	}

	public void setLeitorCodigoBarras(final String parLeitorCodigoBarras) {
		leitorCodigoBarras = parLeitorCodigoBarras;
	}

	public String getNomeEmpresa() {
		return nomeEmpresa;
	}

	public void setNomeEmpresa(String nomeEmpresa) {
		this.nomeEmpresa = nomeEmpresa;
	}

	public String getCnesUnidade() {
		return cnesUnidade;
	}

	public void setCnesUnidade(String cnesUnidade) {
		this.cnesUnidade = cnesUnidade;
	}

	public Long getIdEmpresa() {
		return idEmpresa;
	}

	public void setIdEmpresa(Long idEmpresa) {
		this.idEmpresa = idEmpresa;
	}

	public String getUfUnidade() {
		return ufUnidade;
	}

	public void setUfUnidade(String ufUnidade) {
		this.ufUnidade = ufUnidade;
	}

	public String getCidadeUnidade() {
		return cidadeUnidade;
	}

	public void setCidadeUnidade(String cidadeUnidade) {
		this.cidadeUnidade = cidadeUnidade;
	}

	public String getImpressoraIP() {
		return impressoraIP;
	}

	public void setImpressoraIP(String impressoraIP) {
		this.impressoraIP = impressoraIP;
	}

	public String getImpressoraPorta() {
		return impressoraPorta;
	}

	public void setImpressoraPorta(String impressoraPorta) {
		this.impressoraPorta = impressoraPorta;
	}

}
