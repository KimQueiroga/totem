package br.com.hermespardini.passelivre.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.google.gson.annotations.Expose;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ConsultaDataPrevisaoResultadoResult {
	
	@Expose
	private String mensagens;
	
	@Expose
	private String dataHoraMarcacao;
	
	@Expose
	private int status;

	public String getMensagens() {
		return mensagens;
	}

	public void setMensagens(String mensagens) {
		this.mensagens = mensagens;
	}

	public String getDataHoraMarcacao() {
		return dataHoraMarcacao;
	}

	public void setDataHoraMarcacao(String dataHoraMarcacao) {
		this.dataHoraMarcacao = dataHoraMarcacao;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}
	
	
}
