package br.com.hermespardini.passelivre.model;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.List;

public class PreAtendimento {

	private String autorizaEntregaTerceiros;
	private String dataAlteracao;
	private String dataPreAtendimento;
	private String dataPrevista;
	private String dataValidade;
	private List<Guia> guias;
	private String numeroPreAtendimento;
	private String origem;
	private Paciente paciente;
	private String tipoAtendimento;
	private String usuario;
	private String tipo;

	public String getAutorizaEntregaTerceiros() {
		return autorizaEntregaTerceiros;
	}

	public void setAutorizaEntregaTerceiros(final String parAutorizaEntregaTerceiros) {
		autorizaEntregaTerceiros = parAutorizaEntregaTerceiros;
	}

	public String getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(final String parDataAlteracao) {
		dataAlteracao = parDataAlteracao;
	}

	public String getDataPreAtendimento() {
		return dataPreAtendimento;
	}

	public void setDataPreAtendimento(final String parDataPreAtendimento) {
		dataPreAtendimento = parDataPreAtendimento;
	}

	public String getDataPrevista() {
		return dataPrevista;
	}

	public void setDataPrevista(final String parDataPrevista) {
		dataPrevista = parDataPrevista;
	}

	public String getDataValidade() {
		return dataValidade;
	}

	public void setDataValidade(final String parDataValidade) {
		dataValidade = parDataValidade;
	}

	public List<Guia> getGuias() {
		return guias;
	}

	public void setGuias(final List<Guia> parGuias) {
		guias = parGuias;
	}

	public String getNumeroPreAtendimento() {
		return numeroPreAtendimento;
	}

	public void setNumeroPreAtendimento(final String parNumeroPreAtendimento) {
		numeroPreAtendimento = parNumeroPreAtendimento;
	}

	public String getOrigem() {
		return origem;
	}

	public void setOrigem(final String parOrigem) {
		origem = parOrigem;
	}

	public Paciente getPaciente() {
		return paciente;
	}

	public void setPaciente(final Paciente parPaciente) {
		paciente = parPaciente;
	}

	public String getTipoAtendimento() {
		return tipoAtendimento;
	}

	public void setTipoAtendimento(final String parTipoAtendimento) {
		tipoAtendimento = parTipoAtendimento;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(final String parUsuario) {
		usuario = parUsuario;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(final String parTipo) {
		tipo = parTipo;
	}

	public String getTodosSolicitantes() {
		String todosSolicitantes = "";
		if (guias != null && !guias.isEmpty()) {
			for (int i = 0; i < guias.size(); i++) {
				if (guias.get(i).getSolicitante() != null) {
					todosSolicitantes += guias.get(i).getSolicitante().getNome();
				}
				if (guias.size() > ++i) {
					todosSolicitantes += "<br/>";
				}
			}
		}
		return todosSolicitantes;
	}

	public String getDataFormatada() {
		Date data = Date.valueOf(dataPreAtendimento);
		SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
		return formato.format(data);
	}

}
