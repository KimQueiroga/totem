package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

public class Message implements Serializable {

	private String status;
	private String nsu;
	private String order;

	public String getStatus() {
		return status;
	}

	public void setStatus(final String parStatus) {
		status = parStatus;
	}

	public String getNsu() {
		return nsu;
	}

	public void setNsu(final String parNsu) {
		nsu = parNsu;
	}

	public String getOrder() {
		return order;
	}

	public void setOrder(final String parOrder) {
		order = parOrder;
	}

}
