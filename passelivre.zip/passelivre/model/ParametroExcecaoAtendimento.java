package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.util.List;

import br.com.hermespardini.passelivre.constantsenum.Constantes;

public class ParametroExcecaoAtendimento implements Serializable {
	private String unidade;
	private String totem;
	private String origem;
	private String token;
	private Long servico;
	private String sessionId;

	public ParametroExcecaoAtendimento(final List<InformacaoTotem> informacoesTotem, final Long parServico,
			final TokenResult tokenResult) {
		unidade = retornarUnidade(informacoesTotem);
		totem = informacoesTotem.get(0).getIp();
		origem = Constantes.ORIGEM_PADRAO;
		token = tokenResult.getToken();
		servico = parServico;
	}

	public ParametroExcecaoAtendimento(final Long idUnidade, final String ip, final Long parServico,
			final TokenResult tokenResult, final String parSessionId) {
		unidade = idUnidade.toString();
		totem = ip;
		origem = Constantes.ORIGEM_DESKTOP;
		token = tokenResult.getToken();
		servico = parServico;
		sessionId = parSessionId;
	}

	public ParametroExcecaoAtendimento(final Long parServico, final TokenResult tokenResult, final Long idUnidade,
			final String ip, final String parSessionId) {
		unidade = idUnidade.toString();
		totem = ip;
		origem = Constantes.ORIGEM_DESKTOP;
		token = tokenResult.getToken();
		servico = parServico;
		sessionId = parSessionId;
	}

	private String retornarUnidade(final List<InformacaoTotem> informacoesTotem) {
		if (!informacoesTotem.isEmpty()) {
			return informacoesTotem.get(0).getIdUnidade();
		} else {
			return "";
		}
	}

}
