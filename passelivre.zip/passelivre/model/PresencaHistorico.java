package br.com.hermespardini.passelivre.model;

import java.util.Date;
import java.util.Map;

import org.wdelmaschio.base.model.ValueObject;

public class PresencaHistorico extends ValueObject {

	private Long id;
	private String carteira;
	private String filial;
	private Date datahora;
	private String status;
	private Date datacadastro;
	private Date datamodificacao;
	private Integer versao;

	public PresencaHistorico() {
	}

	public PresencaHistorico(final Map<?, ?> pObjectMapping) {
		super(pObjectMapping);
	}

	public PresencaHistorico(final Presenca presenca, final Long parId) {
		id = parId;
		carteira = presenca.getCarteira();
		filial = presenca.getFilial();
		datahora = presenca.getDatahora();
		status = presenca.getStatus();
		datacadastro = presenca.getDatacadastro();
		datamodificacao = presenca.getDatamodificacao();
		versao = presenca.getVersao();
	}

	public Long getId() {
		return id;
	}

	public void setId(final Long parId) {
		id = parId;
	}

	public String getCarteira() {
		return carteira;
	}

	public void setCarteira(final String parCarteira) {
		carteira = parCarteira;
	}

	public String getFilial() {
		return filial;
	}

	public void setFilial(final String parFilial) {
		filial = parFilial;
	}

	public Date getDatahora() {
		return datahora;
	}

	public void setDatahora(final Date parDatahora) {
		datahora = parDatahora;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(final String parStatus) {
		status = parStatus;
	}

	public Date getDatacadastro() {
		return datacadastro;
	}

	public void setDatacadastro(final Date parDatacadastro) {
		datacadastro = parDatacadastro;
	}

	public Date getDatamodificacao() {
		return datamodificacao;
	}

	public void setDatamodificacao(final Date parDatamodificacao) {
		datamodificacao = parDatamodificacao;
	}

	public Integer getVersao() {
		return versao;
	}

	public void setVersao(final Integer parVersao) {
		versao = parVersao;
	}

}
