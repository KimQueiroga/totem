package br.com.hermespardini.passelivre.model;

import java.io.Serializable;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.unimedbh.www.Ct_solicitante;

public class ParametroConsultaSolicitante implements Serializable {

	private String numeroConselho;
	private String siglaConselho;
	private String ufConselho;
	private String situacao;
	private String origem;
	private String token;

	public ParametroConsultaSolicitante(TokenResult parTokenResult, Ct_solicitante parSolicitante) {
		token = parTokenResult.getToken();
		numeroConselho = parSolicitante.getNumeroConselho().toString();
		siglaConselho = parSolicitante.getSiglaConselho();
		ufConselho = parSolicitante.getUfConselho();
		situacao = Constantes.SITUACAO_A;
		origem = Constantes.ORIGEM_PADRAO;
	}

	public String getNumeroConselho() {
		return numeroConselho;
	}

	public void setNumeroConselho(String numeroConselho) {
		this.numeroConselho = numeroConselho;
	}

	public String getSiglaConselho() {
		return siglaConselho;
	}

	public void setSiglaConselho(String siglaConselho) {
		this.siglaConselho = siglaConselho;
	}

	public String getUfConselho() {
		return ufConselho;
	}

	public void setUfConselho(String ufConselho) {
		this.ufConselho = ufConselho;
	}

	public String getSituacao() {
		return situacao;
	}

	public void setSituacao(String situacao) {
		this.situacao = situacao;
	}

	public String getOrigem() {
		return origem;
	}

	public void setOrigem(String origem) {
		this.origem = origem;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

}
