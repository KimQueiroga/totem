package br.com.hermespardini.passelivre.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import br.com.hermespardini.passelivre.dao.ExamesCalculadosDAO;

@SuppressWarnings("serial")
public class ExamePreCalculado implements Serializable, Comparable<ExamePreCalculado> {
	
	private String material;
	private String descricao;
	private String descricaoCompleta;
	private String codigo;
	private BigDecimal quantidade;
	
	public ExamePreCalculado(String material, String descricao, String codigo, String descricaoCompleta) {
		this.material = material;
		this.descricao = descricao;
		this.codigo = codigo;
		this.descricaoCompleta = descricaoCompleta;
	}
	
	public ExamePreCalculado(String textoNaoFormatado, String codigo, BigDecimal quantidade) {
		this.codigo = codigo;
		this.quantidade = quantidade != null ? quantidade : new BigDecimal(0);
		this.descricaoCompleta = textoNaoFormatado;
		if (textoNaoFormatado != null && textoNaoFormatado.contains("-")) {
			
			String mat = ExamesCalculadosDAO.getMaterialByDescExame(textoNaoFormatado);
			
			if (mat.isEmpty()) {
				setaDescricaoConcatenando(textoNaoFormatado.toUpperCase());
			}
			else {
				this.material = mat;
				this.descricao = textoNaoFormatado.toUpperCase();
			}
			
		} else if (textoNaoFormatado != null && !textoNaoFormatado.contains("-") ) {
			this.material = "";
			this.descricao = textoNaoFormatado.toUpperCase();
		}
		
		
	}
	
	private void setaDescricaoConcatenando(String textoNaoFormatado) {
		String[] textoFormatado = textoNaoFormatado.split("-");
		
		this.descricao = textoFormatado[0].trim().toUpperCase();
		
		if (textoFormatado.length > 1) 
			this.material = String.valueOf(textoFormatado[1].trim()).toUpperCase();
		else
			this.material = "";
	}
	
	@Override
	public String toString() {
		return String.format("%s (%s) - %s", descricao, codigo, material);
	}
	
	@Override
	public int compareTo(ExamePreCalculado o) {
		return this.codigo.compareTo(o.codigo);
	}
	
	
//	@Override
//	public boolean equals(Object obj) {
//		boolean equals = false;
//		if (obj instanceof ExamePreCalculado) {
//			ExamePreCalculado examePreCalcComp = (ExamePreCalculado) obj;
//			equals = String.valueOf(this.codigo + this.material).equals(String.valueOf(examePreCalcComp.getCodigo() + examePreCalcComp.getMaterial()));
//			equals = equals ? equals : (analisaSeMaterialPreenchido(examePreCalcComp));
//		}
//		return equals;
//	}
//	
//	private boolean analisaSeMaterialPreenchido(ExamePreCalculado obj) {
//		if (this.getCodigo().equals(obj.getCodigo()) 
//				&& (obj.getMaterial().isEmpty() || this.getMaterial().isEmpty() 
////						|| this.getMaterial().contains(obj.getMaterial()) || obj.getMaterial().contains(this.getMaterial())
//						|| this.getMaterial().contains(obj.getDescricaoCompleta()) || obj.getMaterial().contains(this.getDescricaoCompleta()))) {
//			return true;
//		}
//		return false;
//	}
	
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		int hash = 7;
        hash = 17 * hash + (this.codigo != null && this.material != null ? (this.codigo + this.material).hashCode() : 0);
        return hash;
	}
//	
//	public boolean contains(List<ExamePreCalculado> examesPreCalculados) {
//		return examesPreCalculados.stream().allMatch(examePC -> examePC.equals(this));
//	}
	
//	public boolean equals(ExamePreCalculado examePreCalculado) {
//		return String.valueOf(examePreCalculado.getMaterial()+examePreCalculado.codigo).equals(this.material+this.codigo);		
//	}


	public String getMaterial() {
		return material;
	}


	public void setMaterial(String material) {
		this.material = material;
	}


	public String getDescricao() {
		return descricao;
	}


	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	
	public String getDescricaoCompleta() {
		return descricaoCompleta;
	}

	public void setDescricaoCompleta(String descricaoCompleta) {
		this.descricaoCompleta = descricaoCompleta;
	}

	public BigDecimal getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(BigDecimal quantidade) {
		this.quantidade = quantidade;
	}

	public String getCodigo() {
		return codigo;
	}


	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
}
