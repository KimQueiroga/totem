package br.com.hermespardini.passelivre.factory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import org.primefaces.component.panel.Panel;
import org.primefaces.component.panelgrid.PanelGrid;
import org.primefaces.extensions.component.masterdetail.MasterDetail;
import org.primefaces.extensions.component.masterdetail.MasterDetailLevel;

import br.com.hermespardini.passelivre.components.ComponenteDate;
import br.com.hermespardini.passelivre.components.ComponenteHour;
import br.com.hermespardini.passelivre.components.ComponenteLaboratorioCasaOutros;
import br.com.hermespardini.passelivre.components.ComponenteLocalOral;
import br.com.hermespardini.passelivre.components.ComponenteNulo;
import br.com.hermespardini.passelivre.components.ComponenteNumeric;
import br.com.hermespardini.passelivre.components.ComponenteNumeric_2;
import br.com.hermespardini.passelivre.components.ComponenteNumeric_3_2;
import br.com.hermespardini.passelivre.components.ComponenteNumeric_4;
import br.com.hermespardini.passelivre.components.ComponenteNumeric_4_1;
import br.com.hermespardini.passelivre.components.ComponenteOralLocalAmbosNA;
import br.com.hermespardini.passelivre.components.ComponenteRadioChoice;
import br.com.hermespardini.passelivre.components.ComponenteText;
import br.com.hermespardini.passelivre.constantsenum.ComponentesEnum;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.to.PerguntaComExameTO;

public class ComponenteFactory {

	private Panel pnlQuestionario;
	private PanelGrid pngQuestionario;
	private MasterDetail mtdQuestionario;
	private MasterDetailLevel mdlQuestionario;
	private List<MasterDetailLevel> mdlsQuestionario;

	public ComponenteFactory(final Panel parPnlQuestionario, final List<MasterDetailLevel> parMdlsQuestionario,
			final MasterDetail parMtdQuestionario, final MasterDetailLevel parMdlQuestionario,
			final PanelGrid parPngQuestionario) {
		pnlQuestionario = parPnlQuestionario;
		mdlsQuestionario = parMdlsQuestionario;
		mtdQuestionario = parMtdQuestionario;
		mdlQuestionario = parMdlQuestionario;
		pngQuestionario = parPngQuestionario;

	}

	public UIComponent createComponentMaterialPendente(final PerguntaComExameTO pergunta) {
		try {
			switch (ComponentesEnum.valueOfDescricao(pergunta.getTipoResposta())) {
			case SIM_NAO:
				return new ComponenteRadioChoice(pergunta, pngQuestionario).createForMaterialPendente();
			case HORA:
				return new ComponenteHour(pergunta, pngQuestionario).createForMaterialPendente();
			case DESCRITIVA:
				return new ComponenteText(pergunta, pngQuestionario).createForMaterialPendente();
			case RESPOSTAS_SINTOMAS_PROVAS:
				return new ComponenteText(pergunta, pngQuestionario).createForMaterialPendente();
			case NUMERICA:
				return new ComponenteNumeric(pergunta, pngQuestionario).createForMaterialPendente();
			case DATA:
				return new ComponenteDate(pergunta, pngQuestionario).createForMaterialPendente();
			case NUMERICO2:
				return new ComponenteNumeric_2(pergunta, pngQuestionario).createForMaterialPendente();
			case NUMERICO4:
				return new ComponenteNumeric_4(pergunta, pngQuestionario).createForMaterialPendente();
			case NUMERICO41:
				return new ComponenteNumeric_4_1(pergunta, pngQuestionario).createForMaterialPendente();
			case NUMERICO32:
				return new ComponenteNumeric_3_2(pergunta, pngQuestionario).createForMaterialPendente();
			case LOCAL_ORAL:
				return new ComponenteLocalOral(pergunta, pngQuestionario).createForMaterialPendente();
			case LABORATORIO_CASA_OUTROS:
				return new ComponenteLaboratorioCasaOutros(pergunta, pngQuestionario).createForMaterialPendente();
			case RESPOSTA_NULA:
				return new ComponenteNulo(pergunta, pngQuestionario).createForMaterialPendente();
			case ORAL_LOCAL_AMBOS_NA:
				return new ComponenteOralLocalAmbosNA(pergunta, pngQuestionario).createForMaterialPendente();
			}
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
		return null;
	}

	public UIComponent createComponentUnimed(final PerguntaComExameTO pergunta) {
		try {
			switch (ComponentesEnum.valueOfDescricao(pergunta.getTipoResposta())) {
			case SIM_NAO:
				return new ComponenteRadioChoice(pergunta, pngQuestionario).createForUnimed();
			case HORA:
				return new ComponenteHour(pergunta, pngQuestionario).createForUnimed();
			case DESCRITIVA:
				return new ComponenteText(pergunta, pngQuestionario).createForUnimed();
			case RESPOSTAS_SINTOMAS_PROVAS:
				return new ComponenteText(pergunta, pngQuestionario).createForUnimed();
			case NUMERICA:
				return new ComponenteNumeric(pergunta, pngQuestionario).createForUnimed();
			case DATA:
				return new ComponenteDate(pergunta, pngQuestionario).createForUnimed();
			case NUMERICO2:
				return new ComponenteNumeric_2(pergunta, pngQuestionario).createForUnimed();
			case NUMERICO4:
				return new ComponenteNumeric_4(pergunta, pngQuestionario).createForUnimed();
			case NUMERICO41:
				return new ComponenteNumeric_4_1(pergunta, pngQuestionario).createForUnimed();
			case NUMERICO32:
				return new ComponenteNumeric_3_2(pergunta, pngQuestionario).createForUnimed();
			case LOCAL_ORAL:
				return new ComponenteLocalOral(pergunta, pngQuestionario).createForUnimed();
			case LABORATORIO_CASA_OUTROS:
				return new ComponenteLaboratorioCasaOutros(pergunta, pngQuestionario).createForUnimed();
			case RESPOSTA_NULA:
				return new ComponenteNulo(pergunta, pngQuestionario).createForUnimed();
			case ORAL_LOCAL_AMBOS_NA:
				return new ComponenteOralLocalAmbosNA(pergunta, pngQuestionario).createForUnimed();
			}
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
		return null;
	}

	public UIComponent createComponentUnimedGuiche(final PerguntaComExameTO pergunta) {
		try {
			switch (ComponentesEnum.valueOfDescricao(pergunta.getTipoResposta())) {
			case SIM_NAO:
				return new ComponenteRadioChoice(pergunta, pngQuestionario).createForUnimedGuiche();
			case HORA:
				return new ComponenteHour(pergunta, pngQuestionario).createForUnimedGuiche();
			case DESCRITIVA:
				return new ComponenteText(pergunta, pngQuestionario).createForUnimedGuiche();
			case RESPOSTAS_SINTOMAS_PROVAS:
				return new ComponenteText(pergunta, pngQuestionario).createForUnimedGuiche();
			case NUMERICA:
				return new ComponenteNumeric(pergunta, pngQuestionario).createForUnimedGuiche();
			case DATA:
				return new ComponenteDate(pergunta, pngQuestionario).createForUnimedGuiche();
			case NUMERICO2:
				return new ComponenteNumeric_2(pergunta, pngQuestionario).createForUnimedGuiche();
			case NUMERICO4:
				return new ComponenteNumeric_4(pergunta, pngQuestionario).createForUnimedGuiche();
			case NUMERICO41:
				return new ComponenteNumeric_4_1(pergunta, pngQuestionario).createForUnimedGuiche();
			case NUMERICO32:
				return new ComponenteNumeric_3_2(pergunta, pngQuestionario).createForUnimedGuiche();
			case LOCAL_ORAL:
				return new ComponenteLocalOral(pergunta, pngQuestionario).createForUnimedGuiche();
			case LABORATORIO_CASA_OUTROS:
				return new ComponenteLaboratorioCasaOutros(pergunta, pngQuestionario).createForUnimedGuiche();
			case RESPOSTA_NULA:
				return new ComponenteNulo(pergunta, pngQuestionario).createForUnimedGuiche();
			case ORAL_LOCAL_AMBOS_NA:
				return new ComponenteOralLocalAmbosNA(pergunta, pngQuestionario).createForUnimedGuiche();
			}
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
		return null;
	}

	public UIComponent createComponentQuestionario(final PerguntaComExameTO pergunta) {
		try {
			switch (ComponentesEnum.valueOfDescricao(pergunta.getTipoResposta())) {
			case SIM_NAO:
				return new ComponenteRadioChoice(pergunta, pngQuestionario).createForQuestionario();
			case HORA:
				return new ComponenteHour(pergunta, pngQuestionario).createForQuestionario();
			case DESCRITIVA:
				return new ComponenteText(pergunta, pngQuestionario).createForQuestionario();
			case RESPOSTAS_SINTOMAS_PROVAS:
				return new ComponenteText(pergunta, pngQuestionario).createForQuestionario();
			case NUMERICA:
				return new ComponenteNumeric(pergunta, pngQuestionario).createForQuestionario();
			case DATA:
				return new ComponenteDate(pergunta, pngQuestionario).createForQuestionario();
			case NUMERICO2:
				return new ComponenteNumeric_2(pergunta, pngQuestionario).createForQuestionario();
			case NUMERICO4:
				return new ComponenteNumeric_4(pergunta, pngQuestionario).createForQuestionario();
			case NUMERICO41:
				return new ComponenteNumeric_4_1(pergunta, pngQuestionario).createForQuestionario();
			case NUMERICO32:
				return new ComponenteNumeric_3_2(pergunta, pngQuestionario).createForQuestionario();
			case LOCAL_ORAL:
				return new ComponenteLocalOral(pergunta, pngQuestionario).createForQuestionario();
			case LABORATORIO_CASA_OUTROS:
				return new ComponenteLaboratorioCasaOutros(pergunta, pngQuestionario).createForQuestionario();
			case RESPOSTA_NULA:
				return new ComponenteNulo(pergunta, pngQuestionario).createForQuestionario();
			case ORAL_LOCAL_AMBOS_NA:
				return new ComponenteOralLocalAmbosNA(pergunta, pngQuestionario).createForQuestionario();
			}
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
		return null;
	}

	public Boolean construirComponentesMaterialPendente(Map<String, String> mapQuestionarios,
			final Map<String, List<PerguntaComExameTO>> todasPerguntasAgrupadas) throws RegraNegocioException {
		Integer level = 0;
		try {
			mapQuestionarios = new HashMap<>();
			if (todasPerguntasAgrupadas != null && !todasPerguntasAgrupadas.isEmpty()) {
				for (final Map.Entry<String, List<PerguntaComExameTO>> locMapMaterialPedente : todasPerguntasAgrupadas
						.entrySet()) {
					level += 1;
					mdlQuestionario = new MasterDetailLevel();
					mdlQuestionario.setId(locMapMaterialPedente.getKey().replace("+", ""));
					mdlQuestionario.setLevel(level);
					for (final PerguntaComExameTO locPerguntaComExameTO : locMapMaterialPedente.getValue()) {
						mdlQuestionario.setLevelLabel(locPerguntaComExameTO.getDescricaoExame());
						mdlQuestionario.getChildren().add(createComponentMaterialPendente(locPerguntaComExameTO));
					}
					adicionarCaracteristicasAosComponentes();
				}
				return true;
			} else {
				return false;
			}
		} catch (final Exception locExc) {
			throw new RegraNegocioException(locExc.getMessage());
		}
	}

	public Boolean construirComponentesUnimed(Map<String, String> mapQuestionarios,
			final Map<String, List<PerguntaComExameTO>> todasPerguntasAgrupadas) {
		Integer level = 0;
		try {
			mapQuestionarios = new HashMap<>();
			if (!todasPerguntasAgrupadas.isEmpty()) {
				for (final Map.Entry<String, List<PerguntaComExameTO>> locMapMaterialPedente : todasPerguntasAgrupadas
						.entrySet()) {
					level += 1;
					mdlQuestionario = new MasterDetailLevel();
					mdlQuestionario.setId(locMapMaterialPedente.getKey());
					mdlQuestionario.setLevel(level);
					for (final PerguntaComExameTO locPerguntaComExameTO : locMapMaterialPedente.getValue()) {
						mdlQuestionario.setLevelLabel(retornarNomeExamePai(locPerguntaComExameTO.getExamePAI())
								+ locPerguntaComExameTO.getDescricaoExame());
						mdlQuestionario.getChildren().add(createComponentUnimed(locPerguntaComExameTO));
					}
					adicionarCaracteristicasAosComponentes();
				}
				return true;
			} else {
				return false;
			}
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return false;
		}
	}

	public Boolean construirComponentesUnimedGuiche(Map<String, String> mapQuestionarios,
			final Map<String, List<PerguntaComExameTO>> todasPerguntasAgrupadas) {
		Integer level = 0;
		try {
			mapQuestionarios = new HashMap<>();
			if (!todasPerguntasAgrupadas.isEmpty()) {
				for (final Map.Entry<String, List<PerguntaComExameTO>> locMapMaterialPedente : todasPerguntasAgrupadas
						.entrySet()) {
					level += 1;
					mdlQuestionario = new MasterDetailLevel();
					mdlQuestionario.setId(locMapMaterialPedente.getKey());
					mdlQuestionario.setLevel(level);
					for (final PerguntaComExameTO locPerguntaComExameTO : locMapMaterialPedente.getValue()) {
						mdlQuestionario.setLevelLabel(retornarNomeExamePai(locPerguntaComExameTO.getExamePAI())
								+ locPerguntaComExameTO.getDescricaoExame());
						mdlQuestionario.getChildren().add(createComponentUnimedGuiche(locPerguntaComExameTO));
					}
					adicionarCaracteristicasAosComponentes();
				}
				return true;
			} else {
				return false;
			}
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return false;
		}
	}

	private String retornarNomeExamePai(final String examePai) {
		return examePai == null ? "" : examePai + "-";
	}

	private void adicionarCaracteristicasAosComponentes() {
		mtdQuestionario.getChildren().add(mdlQuestionario);
		mdlsQuestionario.add(mdlQuestionario);
		pnlQuestionario.getChildren().add(mtdQuestionario);
		pngQuestionario = new PanelGrid();
		pngQuestionario.setStyleClass("pngQuestionario");
		pngQuestionario.setStyle("height: 250px;");
		pngQuestionario.setColumns(3);
	}

	public Boolean construirComponentesQuestionario(Map<String, String> parMapQuestionarios,
			final Map<String, List<PerguntaComExameTO>> parTodasPerguntasAgrupadas, final boolean isDesktop) {
		Integer level = 1;
		try {
			final Map<String, Integer> mapPerguntaLevel = new HashMap<>();
			final Map<String, Integer> mapExameLevel = new HashMap<>();
			parMapQuestionarios = new HashMap<>();
			if (!parTodasPerguntasAgrupadas.isEmpty()) {
				for (final Map.Entry<String, List<PerguntaComExameTO>> locMapMaterialPedente : parTodasPerguntasAgrupadas
						.entrySet()) {
					mdlQuestionario = new MasterDetailLevel();
					String id = locMapMaterialPedente.getKey().replace("+", "_").replace("-", "_").replace(".", "_");
					id = id.replace("__", "_");
					if (Character.isDigit(id.charAt(0))) {
						id = "X_" + id;
					}
					mdlQuestionario.setId(id);
					mdlQuestionario.setLevel(level);
					for (final PerguntaComExameTO locPerguntaComExameTO : locMapMaterialPedente.getValue()) {
						if (!mapPerguntaLevel.containsKey(locPerguntaComExameTO.getDescricao())) {
							mdlQuestionario.setLevelLabel(retornarNomeExamePai(locPerguntaComExameTO.getExamePAI())
									+ locPerguntaComExameTO.getDescricaoExame());
							if (isDesktop) {
								mdlQuestionario.getChildren().add(createComponentQuestionario(locPerguntaComExameTO));
							} else {
								mdlQuestionario.getChildren().add(createComponentUnimed(locPerguntaComExameTO));
							}
							mapPerguntaLevel.put(locPerguntaComExameTO.getDescricao(), level);
							if (!mapExameLevel.containsKey(locPerguntaComExameTO.getDescricaoExame())
									|| !mapExameLevel.containsValue(locPerguntaComExameTO.getDescricao())) {
								mapExameLevel.put(locPerguntaComExameTO.getDescricaoExame(), level);
							}
						} else {
							if (!mapExameLevel.containsKey(locPerguntaComExameTO.getDescricaoExame())) {
								final Integer mdlLevel = mapPerguntaLevel.get(locPerguntaComExameTO.getDescricao());
								mapExameLevel.put(locPerguntaComExameTO.getDescricaoExame(), mdlLevel);
							}
						}
					}
					if (!mdlQuestionario.getChildren().isEmpty()) {
						adicionarCaracteristicasAosComponentes();
						level += 1;
					}
				}
				final HttpSession session = getSession();
				session.setAttribute("mapExameLevel", mapExameLevel);
				return true;
			} else {
				return false;
			}
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return false;
		}
	}

	private HttpSession getSession() {
		final HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext()
				.getSession(true);
		return session;
	}

	public Boolean construirComponentesCheckup(Map<String, String> parMapQuestionarios,
			final Map<String, List<PerguntaComExameTO>> parTodasPerguntasAgrupadas) {
		Integer level = 0;
		try {
			parMapQuestionarios = new HashMap<>();
			if (!parTodasPerguntasAgrupadas.isEmpty()) {
				for (final Map.Entry<String, List<PerguntaComExameTO>> locMapMaterialPedente : parTodasPerguntasAgrupadas
						.entrySet()) {
					level += 1;
					mdlQuestionario = new MasterDetailLevel();
					mdlQuestionario.setId(locMapMaterialPedente.getKey());
					mdlQuestionario.setLevel(level);
					for (final PerguntaComExameTO locPerguntaComExameTO : locMapMaterialPedente.getValue()) {
						mdlQuestionario.setLevelLabel(retornarNomeExamePai(locPerguntaComExameTO.getExamePAI())
								+ locPerguntaComExameTO.getDescricaoExame());
						mdlQuestionario.getChildren().add(createComponentCheckup(locPerguntaComExameTO));
					}
					adicionarCaracteristicasAosComponentes();
				}
				return true;
			} else {
				return false;
			}
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return false;
		}

	}

	private UIComponent createComponentCheckup(final PerguntaComExameTO parPerguntaComExameTO) {
		try {
			switch (ComponentesEnum.valueOfDescricao(parPerguntaComExameTO.getTipoResposta())) {
			case SIM_NAO:
				return new ComponenteRadioChoice(parPerguntaComExameTO, pngQuestionario).createForQuestionarioCheckup();
			case HORA:
				return new ComponenteHour(parPerguntaComExameTO, pngQuestionario).createForQuestionarioCheckup();
			case DESCRITIVA:
				return new ComponenteText(parPerguntaComExameTO, pngQuestionario).createForQuestionarioCheckup();
			case RESPOSTAS_SINTOMAS_PROVAS:
				return new ComponenteText(parPerguntaComExameTO, pngQuestionario).createForQuestionarioCheckup();
			case NUMERICA:
				return new ComponenteNumeric(parPerguntaComExameTO, pngQuestionario).createForQuestionarioCheckup();
			case DATA:
				return new ComponenteDate(parPerguntaComExameTO, pngQuestionario).createForQuestionarioCheckup();
			case NUMERICO2:
				return new ComponenteNumeric_2(parPerguntaComExameTO, pngQuestionario).createForQuestionarioCheckup();
			case NUMERICO4:
				return new ComponenteNumeric_4(parPerguntaComExameTO, pngQuestionario).createForQuestionarioCheckup();
			case NUMERICO41:
				return new ComponenteNumeric_4_1(parPerguntaComExameTO, pngQuestionario).createForQuestionarioCheckup();
			case NUMERICO32:
				return new ComponenteNumeric_3_2(parPerguntaComExameTO, pngQuestionario).createForQuestionarioCheckup();
			case LOCAL_ORAL:
				return new ComponenteLocalOral(parPerguntaComExameTO, pngQuestionario).createForQuestionarioCheckup();
			case LABORATORIO_CASA_OUTROS:
				return new ComponenteLaboratorioCasaOutros(parPerguntaComExameTO, pngQuestionario)
						.createForQuestionarioCheckup();
			case RESPOSTA_NULA:
				return new ComponenteNulo(parPerguntaComExameTO, pngQuestionario).createForQuestionarioCheckup();
			case ORAL_LOCAL_AMBOS_NA:
				return new ComponenteOralLocalAmbosNA(parPerguntaComExameTO, pngQuestionario)
						.createForQuestionarioCheckup();
			}
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
		return null;
	}

}
