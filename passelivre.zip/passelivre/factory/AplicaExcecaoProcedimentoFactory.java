package br.com.hermespardini.passelivre.factory;

import java.util.ArrayList;
import java.util.List;

import br.com.hermespardini.passelivre.filtro.AutorizacaoFiltro;
import br.com.hermespardini.passelivre.interfaces.RegraExcecaoParaProcedimento;
import br.com.hermespardini.passelivre.model.ExcecaoAtendimentoResult;
import br.com.hermespardini.passelivre.to.ProcedimentoComExamesTO;
import br.com.hermespardini.passelivre.to.ProcedimentoComExamesTOExcecao;

public class AplicaExcecaoProcedimentoFactory {
	private List<RegraExcecaoParaProcedimento> regras = new ArrayList<>();

	public List<ProcedimentoComExamesTO> retornarProcedimentosFiltrados(
			final List<ProcedimentoComExamesTO> procedimentosComExamesTO, final ExcecaoAtendimentoResult excecao) {
		List<ProcedimentoComExamesTO> procedimentosFiltrados = new ArrayList<>();
		adiciconarRegrasASeremExecutadas();
		for (final RegraExcecaoParaProcedimento locRegraExcecaoParaProcedimento : regras) {
			procedimentosFiltrados = locRegraExcecaoParaProcedimento
					.retornarProcedimentosFiltradas(procedimentosComExamesTO, excecao);
		}
		return procedimentosFiltrados;
	}

	private void adiciconarRegrasASeremExecutadas() {
		regras.clear();
		regras.add(new AutorizacaoFiltro());
	}

	public List<ProcedimentoComExamesTOExcecao> retornarProcedimentosFiltradosExcecao(
			final List<ProcedimentoComExamesTO> procedimentosComExamesTO, final ExcecaoAtendimentoResult excecao) {
		final List<ProcedimentoComExamesTOExcecao> procedimentosFiltradosExcecao = new ArrayList<>();
		adiciconarRegrasASeremExecutadasExcecao();
		for (final RegraExcecaoParaProcedimento locRegraExcecaoParaProcedimento : regras) {
			procedimentosFiltradosExcecao.addAll(locRegraExcecaoParaProcedimento
					.retornarProcedimentosFiltradasExcecao(procedimentosComExamesTO, excecao));
		}
		return procedimentosFiltradosExcecao;
	}

	private void adiciconarRegrasASeremExecutadasExcecao() {
		regras.clear();
		regras.add(new AutorizacaoFiltro());
	}
}
