package br.com.hermespardini.passelivre.factory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import br.com.hermespardini.passelivre.filtro.PerguntaConsolidadaFiltro;
import br.com.hermespardini.passelivre.interfaces.RegraExcecaoParaQuestionario;
import br.com.hermespardini.passelivre.to.PerguntaComExameTO;

public class AplicaExcecaoQuestionarioFactory {

	private List<RegraExcecaoParaQuestionario> regras = new ArrayList<RegraExcecaoParaQuestionario>();

	public Map<String, List<PerguntaComExameTO>> retornarQuestionariosFiltrados(
			final Map<String, List<PerguntaComExameTO>> parTodasPerguntasAgrupadas) throws RuntimeException {
		Map<String, List<PerguntaComExameTO>> todasPerguntasAgrupadasEConsolidadas = new HashMap<String, List<PerguntaComExameTO>>();
		adiciconarRegrasASeremExecutadas();
		for (final RegraExcecaoParaQuestionario locRegraExcecaoQuestionario : regras) {
			todasPerguntasAgrupadasEConsolidadas = locRegraExcecaoQuestionario
					.retornarQuestionarioFiltrados(parTodasPerguntasAgrupadas);
		}
		return todasPerguntasAgrupadasEConsolidadas;
	}

	private void adiciconarRegrasASeremExecutadas() {
		regras.clear();
		regras.add(new PerguntaConsolidadaFiltro());
	}
}
