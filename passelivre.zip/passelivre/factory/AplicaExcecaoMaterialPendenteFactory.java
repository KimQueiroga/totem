package br.com.hermespardini.passelivre.factory;

import java.util.ArrayList;
import java.util.List;

import br.com.hermespardini.passelivre.filtro.DepartamentoFiltro;
import br.com.hermespardini.passelivre.filtro.ExameFiltro;
import br.com.hermespardini.passelivre.filtro.VacinaFiltro;
import br.com.hermespardini.passelivre.interfaces.RegraExcecaoParaMaterialPendente;
import br.com.hermespardini.passelivre.model.ExameMaterialPendente;
import br.com.hermespardini.passelivre.model.ExcecaoAtendimentoResult;

public class AplicaExcecaoMaterialPendenteFactory {

	private List<RegraExcecaoParaMaterialPendente> regras = new ArrayList<RegraExcecaoParaMaterialPendente>();

	public List<ExameMaterialPendente> retornarMaterialPendenteFiltrados(
			final List<ExameMaterialPendente> materiaisPendentes, final ExcecaoAtendimentoResult parExcecao)
			throws RuntimeException {
		List<ExameMaterialPendente> materiaisPendentesFiltrados = new ArrayList<ExameMaterialPendente>();
		materiaisPendentesFiltrados.addAll(materiaisPendentes);
		adiciconarRegrasASeremExecutadas();
		for (final RegraExcecaoParaMaterialPendente locRegraExcecaoAtendimento : regras) {
			materiaisPendentesFiltrados = locRegraExcecaoAtendimento
					.retornarMaterialPendenteFiltrados(materiaisPendentesFiltrados, parExcecao);
		}
		return materiaisPendentesFiltrados;
	}

	public List<ExameMaterialPendente> retornarGuiasExcecao(final List<ExameMaterialPendente> materiaisPendentes,
			final ExcecaoAtendimentoResult parExcecao) throws RuntimeException {
		final List<ExameMaterialPendente> materiaisPendentesExcecao = new ArrayList<ExameMaterialPendente>();
		adiciconarRegrasASeremExecutadasParaExcecao();
		for (final RegraExcecaoParaMaterialPendente locRegraExcecaoAtendimento : regras) {
			materiaisPendentesExcecao
					.addAll(locRegraExcecaoAtendimento.retornarMaterialPendenteExcecao(materiaisPendentes, parExcecao));
		}
		return materiaisPendentesExcecao;
	}

	private void adiciconarRegrasASeremExecutadas() {
		regras.clear();
		regras.add(new ExameFiltro());
		regras.add(new DepartamentoFiltro());
		regras.add(new VacinaFiltro());
	}

	private void adiciconarRegrasASeremExecutadasParaExcecao() {
		regras.clear();
		regras.add(new ExameFiltro());
		regras.add(new DepartamentoFiltro());
	}
}
