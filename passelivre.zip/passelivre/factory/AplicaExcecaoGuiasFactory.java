package br.com.hermespardini.passelivre.factory;

import java.util.ArrayList;
import java.util.List;

import br.com.hermespardini.passelivre.filtro.GlosaFiltro;
import br.com.hermespardini.passelivre.filtro.ProcedimentoFiltro;
import br.com.hermespardini.passelivre.filtro.ValidadeFiltro;
import br.com.hermespardini.passelivre.interfaces.RegraExcecaoParaGuia;
import br.com.hermespardini.passelivre.model.ExcecaoAtendimentoResult;
import br.com.hermespardini.passelivre.model.GuiaAutorizadaExcecao;
import br.com.unimedbh.www.Ct_dadosAutorizacao;

public class AplicaExcecaoGuiasFactory {

	private List<RegraExcecaoParaGuia> regras = new ArrayList<>();

	public List<Ct_dadosAutorizacao> retornarGuiasFiltradas(final List<Ct_dadosAutorizacao> guias,
			final ExcecaoAtendimentoResult excecao) throws RuntimeException {
		List<Ct_dadosAutorizacao> guiasFiltradas = new ArrayList<>();
		guiasFiltradas.addAll(guias);
		adiciconarRegrasASeremExecutadas();
		for (final RegraExcecaoParaGuia locRegraExcecaoAtendimento : regras) {
			guiasFiltradas = locRegraExcecaoAtendimento.retornarGuiasFiltradas(guiasFiltradas, excecao);
		}
		return guiasFiltradas;
	}

	// public List<GuiaAutorizadaExcecao> retornarGuiasExcecao(final
	// List<Ct_dadosAutorizacao> guias,
	// final ExcecaoAtendimentoResult excecao) throws RuntimeException {
	// final List<GuiaAutorizadaExcecao> guiasExcecao = new
	// ArrayList<GuiaAutorizadaExcecao>();
	// adiciconarRegrasDeRetornoDaExcecao();
	// for (final RegraExcecaoParaGuia locRegraExcecaoAtendimento : regras) {
	// guiasExcecao.addAll(locRegraExcecaoAtendimento.retornarGuiasExcecao(guias,
	// excecao));
	// }
	// return guiasExcecao;
	// }

	public List<GuiaAutorizadaExcecao> retornarGuiasExcecao(final List<Ct_dadosAutorizacao> guias,
			final ExcecaoAtendimentoResult excecao) throws RuntimeException {
		final List<GuiaAutorizadaExcecao> guiasExcecao = new ArrayList<>();
		adiciconarRegrasDeRetornoDaExcecao();
		for (final RegraExcecaoParaGuia locRegraExcecaoAtendimento : regras) {
			guiasExcecao.addAll(locRegraExcecaoAtendimento.retornarGuiasExcecao(guias, excecao));
		}
		return guiasExcecao;
	}

	private void adiciconarRegrasASeremExecutadas() {
		regras.clear();
		regras.add(new ProcedimentoFiltro());
		regras.add(new GlosaFiltro());
		regras.add(new ValidadeFiltro());
	}

	private void adiciconarRegrasDeRetornoDaExcecao() {
		regras.clear();
		regras.add(new ProcedimentoFiltro());
		regras.add(new GlosaFiltro());
		regras.add(new ValidadeFiltro());
	}
}
