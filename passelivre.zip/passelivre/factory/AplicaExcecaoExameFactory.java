package br.com.hermespardini.passelivre.factory;

import java.util.ArrayList;
import java.util.List;

import br.com.hermespardini.passelivre.filtro.DepartamentoFiltro;
import br.com.hermespardini.passelivre.filtro.ExameFiltro;
import br.com.hermespardini.passelivre.interfaces.RegraExcecaoParaExame;
import br.com.hermespardini.passelivre.model.ExameHermesPardini;
import br.com.hermespardini.passelivre.model.ExcecaoAtendimentoResult;

public class AplicaExcecaoExameFactory {

	private List<RegraExcecaoParaExame> regras = new ArrayList<RegraExcecaoParaExame>();

	public List<ExameHermesPardini> retornarExamesFiltrados(final List<ExameHermesPardini> parExames,
			final ExcecaoAtendimentoResult parExcecao) {
		List<ExameHermesPardini> examesFiltrados = new ArrayList<ExameHermesPardini>();
		examesFiltrados.addAll(parExames);
		adiciconarRegrasASeremExecutadas();
		for (final RegraExcecaoParaExame locRegraExcecaoAtendimento : regras) {
			examesFiltrados = locRegraExcecaoAtendimento.retornarExamesFiltrados(examesFiltrados, parExcecao);
		}
		return examesFiltrados;
	}

	public List<ExameHermesPardini> retornarExamesExcecao(final List<ExameHermesPardini> parExames,
			final ExcecaoAtendimentoResult parExcecao) {
		final List<ExameHermesPardini> examesExcecao = new ArrayList<ExameHermesPardini>();
		adiciconarRegrasASeremExecutadasDaExcecao();
		for (final RegraExcecaoParaExame locRegraExcecaoAtendimento : regras) {
			examesExcecao.addAll(locRegraExcecaoAtendimento.retornarExamesExcecao(parExames, parExcecao));
		}
		return examesExcecao;
	}

	private void adiciconarRegrasASeremExecutadas() {
		regras.clear();
		regras.add(new ExameFiltro());
		regras.add(new DepartamentoFiltro());
	}

	private void adiciconarRegrasASeremExecutadasDaExcecao() {
		regras.clear();
		regras.add(new ExameFiltro());
		regras.add(new DepartamentoFiltro());
	}
}
