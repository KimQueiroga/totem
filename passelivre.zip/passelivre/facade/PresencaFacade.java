package br.com.hermespardini.passelivre.facade;

import org.wdelmaschio.base.facade.Facade;
import org.wdelmaschio.base.model.ValueObject;

import br.com.hermespardini.corebusiness.util.ConnectionCore;
import br.com.hermespardini.passelivre.dao.PresencaDAO;
import br.com.hermespardini.passelivre.model.Presenca;

public class PresencaFacade extends Facade {

	public PresencaFacade(final ValueObject parValueObject) throws Exception {
		super(PresencaDAO.class, parValueObject);
		getDao().setDBHelper(
				ConnectionCore.getInstance().getDBHelperInstance(ConnectionCore.DATASOURCE_BIOMETRIA_LOCALIDADE));
	}

	public Presenca getPresencaByCarteira() throws Exception {
		return ((PresencaDAO) getDao()).getPresencaByCarteira();
	}

	public void insert(final Presenca presenca) throws Exception {
		final PresencaDAO loDao = (PresencaDAO) getDao();
		try {
			loDao.setValueObject(presenca);
			loDao.insert();
		} catch (final Exception loE) {
			loE.printStackTrace();
			throw loE;
		}
	}

	public void update(final Presenca presenca) throws Exception {
		final PresencaDAO loDao = (PresencaDAO) getDao();
		try {
			loDao.setValueObject(presenca);
			if (presenca.getCarteira() != null) {
				loDao.update();
			}
		} catch (final Exception loE) {
			loE.printStackTrace();
			throw loE;
		}
	}
}
