package br.com.hermespardini.passelivre.facade;

import org.wdelmaschio.base.facade.Facade;
import org.wdelmaschio.base.model.ValueObject;

import br.com.hermespardini.corebusiness.util.ConnectionCore;
import br.com.hermespardini.passelivre.dao.LocalidadeDAO;
import br.com.hermespardini.passelivre.model.Localidade;

public class LocalidadeFacade extends Facade {

	public LocalidadeFacade(final ValueObject valueObject) throws Exception {
		super(LocalidadeDAO.class, valueObject);
		getDao().setDBHelper(
				ConnectionCore.getInstance().getDBHelperInstance(ConnectionCore.DATASOURCE_BIOMETRIA_LOCALIDADE));
	}

	public Localidade getLocalidadeIp() throws Exception {
		return ((LocalidadeDAO) getDao()).getLocalidadeIp();
	}

}
