package br.com.hermespardini.passelivre.facade;

import org.wdelmaschio.base.facade.Facade;
import org.wdelmaschio.base.model.ValueObject;

import br.com.hermespardini.corebusiness.util.ConnectionCore;
import br.com.hermespardini.passelivre.dao.ControleEstatisticoDAO;
import br.com.hermespardini.passelivre.model.ControleEstatistico;

public class ControleEstatisticoFacade extends Facade {

	public ControleEstatisticoFacade(final ValueObject valueObject) throws Exception {
		super(ControleEstatisticoDAO.class, valueObject);
		getDao().setDBHelper(ConnectionCore.getInstance().getDBHelperInstance(ConnectionCore.DATASOURCE_TOTEM));
	}

	public void insert(final ControleEstatistico controleEstatistico) throws Exception {
		final ControleEstatisticoDAO loDao = (ControleEstatisticoDAO) getDao();
		try {
			loDao.setValueObject(controleEstatistico);
			if (controleEstatistico.getId() == null) {
				loDao.insert();
			}
		} catch (final Exception loE) {
			loE.printStackTrace();
			throw loE;
		}
	}
}
