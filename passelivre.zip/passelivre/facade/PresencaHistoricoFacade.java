package br.com.hermespardini.passelivre.facade;

import org.wdelmaschio.base.facade.Facade;
import org.wdelmaschio.base.model.ValueObject;

import br.com.hermespardini.corebusiness.util.ConnectionCore;
import br.com.hermespardini.passelivre.dao.PresencaHistoricoDAO;
import br.com.hermespardini.passelivre.model.PresencaHistorico;

public class PresencaHistoricoFacade extends Facade {

	public PresencaHistoricoFacade(final ValueObject parValueObject) throws Exception {
		super(PresencaHistoricoDAO.class, parValueObject);
		getDao().setDBHelper(
				ConnectionCore.getInstance().getDBHelperInstance(ConnectionCore.DATASOURCE_BIOMETRIA_LOCALIDADE));
	}

	public void insert(final PresencaHistorico presencaHistorico) throws Exception {
		final PresencaHistoricoDAO loDao = (PresencaHistoricoDAO) getDao();
		try {
			loDao.setValueObject(presencaHistorico);
			loDao.insert();
		} catch (final Exception loE) {
			loE.printStackTrace();
			throw loE;
		}
	}

	public Long getId() throws Exception {
		final PresencaHistoricoDAO loDao = (PresencaHistoricoDAO) getDao();
		try {
			return loDao.getId();
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			throw locExc;
		}
	}
}
