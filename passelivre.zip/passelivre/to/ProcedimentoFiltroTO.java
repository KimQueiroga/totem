package br.com.hermespardini.passelivre.to;

import java.io.Serializable;

import br.com.hermespardini.passelivre.model.ExcecaoAtendimentoResult;

public class ProcedimentoFiltroTO implements Serializable {
	private String acao;
	private String codigo;
	private String observacao;

	public ProcedimentoFiltroTO(final String parCodigo, final String parAcao) {
		codigo = parCodigo;
		acao = parAcao;
	}

	public boolean isIniciaisExistemNaLista(final ExcecaoAtendimentoResult excecaoAtendimentoResult) {
		for (final ProcedimentoFiltroTO locProcedimentoFiltroTO : excecaoAtendimentoResult.getProcedimentos()) {
			if (locProcedimentoFiltroTO.getCodigo().contains("%")) {
				final int tamanhoAtePercente = locProcedimentoFiltroTO.getCodigo().indexOf("%");
				if (codigo.substring(0, tamanhoAtePercente)
						.equals(locProcedimentoFiltroTO.getCodigo().substring(0, tamanhoAtePercente))) {
					observacao = locProcedimentoFiltroTO.getObservacao();
					return true;
				}
			}
		}
		return false;
	}

	@Override
	public String toString() {
		return codigo;
	}

	// @Override
	// public int hashCode() {
	// final int prime = 31;
	// int result = 1;
	// result = prime * result + (codigo == null ? 0 : codigo.hashCode());
	// return result;
	// }
	//
	// @Override
	// public boolean equals(final Object obj) {
	// if (this == obj) {
	// return true;
	// }
	// if (obj == null) {
	// return false;
	// }
	// if (getClass() != obj.getClass()) {
	// return false;
	// }
	// final ProcedimentoFiltroTO other = (ProcedimentoFiltroTO) obj;
	// if (codigo == null) {
	// if (other.codigo != null) {
	// return false;
	// }
	// } else if (!codigo.equals(other.codigo)) {
	// return false;
	// }
	// return true;
	// }

	public String getAcao() {
		return acao;
	}

	public void setAcao(final String parAcao) {
		acao = parAcao;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(final String parCodigo) {
		codigo = parCodigo;
	}

	public String getObservacao() {
		return observacao;
	}

	public void setObservacao(final String parObservacao) {
		observacao = parObservacao;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (acao == null ? 0 : acao.hashCode());
		result = prime * result + (codigo == null ? 0 : codigo.hashCode());
		return result;
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final ProcedimentoFiltroTO other = (ProcedimentoFiltroTO) obj;
		if (acao == null) {
			if (other.acao != null) {
				return false;
			}
		} else if (!acao.equals(other.acao)) {
			return false;
		}
		if (codigo == null) {
			if (other.codigo != null) {
				return false;
			}
		} else if (!codigo.equals(other.codigo)) {
			return false;
		}
		return true;
	}

}
