package br.com.hermespardini.passelivre.to;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import com.owlike.genson.annotation.JsonIgnore;

import br.com.hermespardini.passelivre.factory.AplicaExcecaoExameFactory;
import br.com.hermespardini.passelivre.model.ConsultaCodigoResult;
import br.com.hermespardini.passelivre.model.ExameHermesPardini;
import br.com.hermespardini.passelivre.model.ExamePedido;
import br.com.hermespardini.passelivre.model.ExameSimplificado;
import br.com.hermespardini.passelivre.model.ExamesCalculados;
import br.com.hermespardini.passelivre.model.ExcecaoAtendimentoResult;
import br.com.hermespardini.passelivre.model.MotivosGlosas;
import br.com.hermespardini.passelivre.model.Procedimento;

public class ProcedimentoComExamesTO implements Serializable, Comparable<ProcedimentoComExamesTO> {

	private Integer id;
	private Boolean vt;
	private String guia;
	@JsonIgnore
	private Boolean excluido;
	private String descricao;
	private Long idComposicao;
	private String procedimento;
	private MotivosGlosas glosas;
	private Integer sequenciaExame;
	@JsonIgnore
	private String condicaoAmostra;
	private String observacaoGuiche;
	private ExameHermesPardini exame;
	private Boolean repetido;
	private String informacoesClinica;
	private String informacoesAdicionais;
	private List<ExameHermesPardini> exames;
	private BigDecimal quantidadeAutorizadas;
	private BigDecimal quantidadeSolicitacadas;
	private String particular;
	private Boolean removeCalculado = false;

	public ProcedimentoComExamesTO() {
	}

	public ProcedimentoComExamesTO(final Procedimento parProcedimento,
			final ConsultaCodigoResult parConsultaCodigoResult,
			final ExcecaoAtendimentoResult parExcecaoAtendimentoResult) {
		procedimento = parProcedimento.getProcedimento();
		guia = parProcedimento.getGuia();
		idComposicao = parProcedimento.getIdComposicao();
		descricao = parProcedimento.getDescricao();
		exames = retornarExamesFiltrados(parConsultaCodigoResult.getExames(), parExcecaoAtendimentoResult);
		exame = retornarExameQuandoHouverApenasUm();
		observacaoGuiche = parProcedimento.getInformacoesAdicionais();
		informacoesClinica = parProcedimento.getInformacoesClinica();
		quantidadeAutorizadas = parProcedimento.getQuantidadeAutorizadas();
		quantidadeSolicitacadas = parProcedimento.getQuantidadeSolicitacadas();
		glosas = parProcedimento.getGlosas();
	}

	public ProcedimentoComExamesTO(final Procedimento parProcedimento,
			final ConsultaCodigoResult parConsultaCodigoResult,
			final ExcecaoAtendimentoResult parExcecaoAtendimentoResult, final String desktop) {
		procedimento = parProcedimento.getProcedimento();
		guia = parProcedimento.getGuia();
		idComposicao = parProcedimento.getIdComposicao();
		descricao = parProcedimento.getDescricao();
		exames = retornarExamesComDefault(
				retornarExamesFiltrados(parConsultaCodigoResult.getExames(), parExcecaoAtendimentoResult));
		exame = retornarExameQuandoHouverApenasUm();
		observacaoGuiche = parProcedimento.getInformacoesAdicionais();
		informacoesClinica = parProcedimento.getInformacoesClinica();
		quantidadeAutorizadas = parProcedimento.getQuantidadeAutorizadas();
		quantidadeSolicitacadas = parProcedimento.getQuantidadeSolicitacadas();
		glosas = parProcedimento.getGlosas();
	}

	public ProcedimentoComExamesTO(final List<ProcedimentoComExamesTO> parProcedimentosComExamesFiltrados,
			final Procedimento parProcedimento, final ExcecaoAtendimentoResult parExcecaoAtendimentoResult,
			final ConsultaCodigoResult consultaCodigoResult) {
		procedimento = parProcedimento.getProcedimento();
		guia = parProcedimento.getGuia();
		idComposicao = parProcedimento.getIdComposicao();
		descricao = parProcedimento.getDescricao();
		exames = retornarExamesComDefault(
				retornarExamesFiltrados(consultaCodigoResult.getExames(), parExcecaoAtendimentoResult));
		exame = retornarExameQuandoHouverApenasUmDesktop();
		sequenciaExame = retornarSequencia(parProcedimentosComExamesFiltrados,
				new ProcedimentoComExamesTO(parProcedimento));
		observacaoGuiche = parProcedimento.getInformacoesAdicionais();
		informacoesClinica = parProcedimento.getInformacoesClinica();
		quantidadeAutorizadas = parProcedimento.getQuantidadeAutorizadas();
		quantidadeSolicitacadas = parProcedimento.getQuantidadeSolicitacadas();
		glosas = parProcedimento.getGlosas();
	}

	public ProcedimentoComExamesTO(final List<ProcedimentoComExamesTO> parProcedimentosComExamesFiltrados,
			final Procedimento parProcedimento, final ExcecaoAtendimentoResult parExcecaoAtendimentoResult,
			final ConsultaCodigoResult consultaCodigoResult, final String object) {
		procedimento = parProcedimento.getProcedimento();
		guia = parProcedimento.getGuia();
		idComposicao = parProcedimento.getIdComposicao();
		descricao = parProcedimento.getDescricao();
		exames = retornarExamesFiltrados(consultaCodigoResult.getExames(), parExcecaoAtendimentoResult);
		exame = retornarExameQuandoHouverApenasUmDesktop();
		sequenciaExame = retornarSequencia(parProcedimentosComExamesFiltrados,
				new ProcedimentoComExamesTO(parProcedimento));
		observacaoGuiche = parProcedimento.getInformacoesAdicionais();
		informacoesClinica = parProcedimento.getInformacoesClinica();
		quantidadeAutorizadas = parProcedimento.getQuantidadeAutorizadas();
		quantidadeSolicitacadas = parProcedimento.getQuantidadeSolicitacadas();
		glosas = parProcedimento.getGlosas();
	}

	private ProcedimentoComExamesTO(final Procedimento parProcedimento) {
		guia = parProcedimento.getGuia();
		procedimento = parProcedimento.getProcedimento();
		descricao = parProcedimento.getDescricao();
		idComposicao = parProcedimento.getIdComposicao();
		exame = parProcedimento.getExame();
		observacaoGuiche = parProcedimento.getInformacoesAdicionais();
		informacoesClinica = parProcedimento.getInformacoesClinica();
		quantidadeAutorizadas = parProcedimento.getQuantidadeAutorizadas();
		quantidadeSolicitacadas = parProcedimento.getQuantidadeSolicitacadas();
		glosas = parProcedimento.getGlosas();
	}

	public ProcedimentoComExamesTO(final Procedimento parProcedimento,
			final ConsultaCodigoResult parConsultaCodigoResult) {
		procedimento = parProcedimento.getProcedimento();
		guia = parProcedimento.getGuia();
		idComposicao = parProcedimento.getIdComposicao();
		descricao = parProcedimento.getDescricao();
		exames = retornarExamesComDefault(parConsultaCodigoResult.getExames());
		exame = retornarExameQuandoHouverApenasUmDesktop();
		observacaoGuiche = parProcedimento.getInformacoesAdicionais();
		informacoesClinica = parProcedimento.getInformacoesClinica();
		quantidadeAutorizadas = parProcedimento.getQuantidadeAutorizadas();
		quantidadeSolicitacadas = parProcedimento.getQuantidadeSolicitacadas();
		glosas = parProcedimento.getGlosas();
	}
	
	public ProcedimentoComExamesTO(final ExameSimplificado exameSimplificado, final Integer idExame) {
		this.procedimento = exameSimplificado.getCodigo();
		this.guia = exameSimplificado.getGuia();
		this.idComposicao = 0L;//a definir
		this.descricao = exameSimplificado.getDescricao();
		this.exames = retornarExamesComDefault(Arrays.asList(exameSimplificado.getExame()));
		this.exame = retornarExameQuandoHouverApenasUmDesktop();
		this.observacaoGuiche = exameSimplificado.getObservacao();
		this.informacoesClinica = exameSimplificado.getInformacoesClinica();
		this.quantidadeAutorizadas = new BigDecimal(exameSimplificado.getQuantidadeAutorizada());
		this.quantidadeSolicitacadas = new BigDecimal(exameSimplificado.getQuantidadeSolicitada());
		this.glosas = exameSimplificado.getGlosas();
		this.sequenciaExame = 1;
		this.id = idExame;
	}

	public ProcedimentoComExamesTO(final ExamePedido parExame, final String parGuia) {
		exame = new ExameHermesPardini("");
		exame.setExame(parExame.getExame());
		exame.setDescricaoExame(parExame.getDescricaoExame());
		exame.setCondicaoAmostra(parExame.getCondicaoAmostra());
		exame.setEPacote(0);
		procedimento = parExame.getCodigoExame();
		sequenciaExame = parExame.getSequenciaExame();
		exame.setMaterial(parExame.getMaterial());
		condicaoAmostra = parExame.getCondicaoAmostra();
		exame.setDescricaoMaterial(parExame.getDescricaoMaterial());
		informacoesAdicionais = parExame.getDescricaoMaterial();
		observacaoGuiche = parExame.getObservacao();
		excluido = false;
		particular = parExame.getParticular();
		exames = new ArrayList<ExameHermesPardini>();
		exames.add(exame);
		if (parExame.getDataHoraMarcacao() != null) {
			exame.setDataHoraMarcacao(new Date(parExame.getDataHoraMarcacao()));
		}
		guia = parGuia;
	}

	public ProcedimentoComExamesTO(final ExamePedido parExame, final String parGuia,
			ConsultaCodigoResult parConsultaCodigoResult) {
		exame = new ExameHermesPardini("");
		exame.setExame(parExame.getExame());
		exame.setDescricaoExame(parExame.getDescricaoExame());
		exame.setCondicaoAmostra(parExame.getCondicaoAmostra());
		exame.setEPacote(0);
		exames = retornarExamesComDefault(parConsultaCodigoResult.getExames());
		procedimento = parExame.getCodigoExame();
		sequenciaExame = parExame.getSequenciaExame();
		exame.setMaterial(parExame.getMaterial());
		condicaoAmostra = parExame.getCondicaoAmostra();
		exame.setDescricaoMaterial(parExame.getDescricaoMaterial());
		informacoesAdicionais = parExame.getDescricaoMaterial();
		observacaoGuiche = parExame.getObservacao();
		excluido = false;
		particular = parExame.getParticular();
		setDataHoraMarcacaoConsultaCodigo();
		if (parExame.getDataHoraMarcacao() != null) {
			exame.setDataHoraMarcacao(new Date(parExame.getDataHoraMarcacao()));
		}
		guia = parGuia;
	}

	private List<ExameHermesPardini> retornarExamesComDefault(
			final List<ExameHermesPardini> parRetornarExamesFiltrados) {
		final Integer posicaoExameDefault;
		Boolean temExameDefault = false;
		for (final ExameHermesPardini locExameHermesPardini : parRetornarExamesFiltrados) {
			temExameDefault = conficaoComDefault(parRetornarExamesFiltrados, temExameDefault, locExameHermesPardini);
		}
		condicaoSemDefault(parRetornarExamesFiltrados, temExameDefault);
		return parRetornarExamesFiltrados;
	}

	private Boolean conficaoComDefault(final List<ExameHermesPardini> parRetornarExamesFiltrados,
			Boolean temExameDefault, final ExameHermesPardini locExameHermesPardini) {
		Integer posicaoExameDefault;
		if (ehExameDefault(locExameHermesPardini)) {
			temExameDefault = true;
			posicaoExameDefault = parRetornarExamesFiltrados.indexOf(locExameHermesPardini);
			Collections.swap(parRetornarExamesFiltrados, 0, posicaoExameDefault);
		}
		return temExameDefault;
	}

	private void condicaoSemDefault(final List<ExameHermesPardini> parRetornarExamesFiltrados,
			final Boolean temExameDefault) {
		if (!temExameDefault && existeMaisDeUmExameParaOProcedimento(parRetornarExamesFiltrados)
				&& !parRetornarExamesFiltrados.get(0).getDescricaoExame().equals("Selecione")) {
			parRetornarExamesFiltrados.add(0, new ExameHermesPardini("Selecione"));
		}
	}

	private boolean existeMaisDeUmExameParaOProcedimento(final List<ExameHermesPardini> parRetornarExamesFiltrados) {
		return parRetornarExamesFiltrados.size() > 1;
	}

	private boolean ehExameDefault(final ExameHermesPardini locExameHermesPardini) {
		try {
			return locExameHermesPardini.getValueDefault() == 1;
		} catch (final Exception locExc) {
			return false;
		}
	}

	private ExameHermesPardini retornarExameQuandoHouverApenasUmDesktop() {
		if (exames != null && !exames.isEmpty()) {
			if (exames.size() == 1) {
				return exames.get(0);
			} else {
				if (!exames.get(0).getDescricaoExame().equals("Selecione")) {
					return exames.get(0);
				}
			}
		}
		return null;
	}

	private ExameHermesPardini retornarExameQuandoHouverApenasUm() {
		if (exames != null && !exames.isEmpty()) {
			if (exames.size() == 1) {
				return exames.get(0);
			}
		}
		return null;
	}

	public static void main(final String[] args) {
		System.out.println(Long.parseLong("12345"));
	}

	private boolean listaDeExamesSemDefault() {
		return !exames.get(0).getDescricaoExame().equals("Selecione");
	}

	private boolean ehUmaListaDeExamesValido() {
		return exames != null || !exames.isEmpty();
	}

	private boolean listaDeExamesComTamanho_1() {
		return exames.size() == 1;
	}

	private Integer retornarSequencia(final List<ProcedimentoComExamesTO> parProcedimentosComExamesCompleta,
			final ProcedimentoComExamesTO parProcedimentoComExamesTO) {
		return Collections.frequency(parProcedimentosComExamesCompleta, parProcedimentoComExamesTO);
	}

	private List<ExameHermesPardini> retornarExamesFiltrados(final List<ExameHermesPardini> parExames,
			final ExcecaoAtendimentoResult parExcecaoAtendimentoResult) {
		final AplicaExcecaoExameFactory aplicaExcecaoExameFactory = new AplicaExcecaoExameFactory();
		return aplicaExcecaoExameFactory.retornarExamesFiltrados(parExames, parExcecaoAtendimentoResult);
	}

	@Override
	public String toString() {
		return "procedimento : " + procedimento + " é vt? " + vt;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getProcedimento() {
		return procedimento;
	}

	public void setProcedimento(final String parProcedimento) {
		procedimento = parProcedimento;
	}

	public String getGuia() {
		return guia;
	}

	public void setGuia(final String parGuia) {
		guia = parGuia;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(final String parDescricao) {
		descricao = parDescricao;
	}

	public ExameHermesPardini getExame() {
		return exame;
	}

	public void setExame(final ExameHermesPardini parExame) {
		exame = parExame;
	}

	public List<ExameHermesPardini> getExames() {
		return exames;
	}

	public void setExames(final List<ExameHermesPardini> parExames) {
		exames = parExames;
	}

	public Boolean getRepetido() {
		return repetido;
	}

	public void setRepetido(Boolean repetido) {
		this.repetido = repetido;
	}

	public Long getIdComposicao() {
		return idComposicao;
	}

	public void setIdComposicao(final Long parIdComposicao) {
		idComposicao = parIdComposicao;
	}

	public Boolean getVt() {
		return vt;
	}

	public void setVt(final Boolean parVt) {
		vt = parVt;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (guia == null ? 0 : guia.hashCode());
		result = prime * result + (procedimento == null ? 0 : procedimento.hashCode());
		result = prime * result + (sequenciaExame == null ? 0 : sequenciaExame.hashCode());
		return result;
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final ProcedimentoComExamesTO other = (ProcedimentoComExamesTO) obj;
		if (guia == null) {
			if (other.guia != null) {
				return false;
			}
		} else if (!guia.equals(other.guia)) {
			return false;
		}
		if (procedimento == null) {
			if (other.procedimento != null) {
				return false;
			}
		} else if (!procedimento.equals(other.procedimento)) {
			return false;
		}
		if (sequenciaExame == null) {
			if (other.sequenciaExame != null) {
				return false;
			}
		} else if (!sequenciaExame.equals(other.sequenciaExame)) {
			return false;
		}
		return true;
	}

	public Integer getSequenciaExame() {
		return sequenciaExame;
	}

	public void setSequenciaExame(final Integer parSequenciaExame) {
		sequenciaExame = parSequenciaExame;
	}

	public String getInformacoesAdicionais() {
		return informacoesAdicionais;
	}

	public void setInformacoesAdicionais(final String parInformacoesAdicionais) {
		informacoesAdicionais = parInformacoesAdicionais;
	}

	public String getInformacoesClinica() {
		return informacoesClinica;
	}

	public void setInformacoesClinica(final String parInformacoesClinica) {
		informacoesClinica = parInformacoesClinica;
	}

	public String getComposicao() {
		try {
			if (descricao != null || !descricao.isEmpty()) {
				if (descricao.contains("Composição:")) {
					final Integer posicaoComposicao = descricao.indexOf("Composição:");
					return descricao.substring(posicaoComposicao + "Composição:".length());
				} else {
					return "";
				}
			} else {
				return "";
			}
		} catch (final Exception locExc) {
			return "";
		}
	}

	public MotivosGlosas getGlosas() {
		return glosas;
	}

	public void setGlosas(final MotivosGlosas parGlosas) {
		glosas = parGlosas;
	}

	public BigDecimal getQuantidadeAutorizadas() {
		return quantidadeAutorizadas;
	}

	public void setQuantidadeAutorizadas(final BigDecimal parQuantidadeAutorizadas) {
		quantidadeAutorizadas = parQuantidadeAutorizadas;
	}

	public BigDecimal getQuantidadeSolicitacadas() {
		return quantidadeSolicitacadas;
	}

	public void setQuantidadeSolicitacadas(final BigDecimal parQuantidadeSolicitacadas) {
		quantidadeSolicitacadas = parQuantidadeSolicitacadas;
	}

	public String getCondicaoAmostra() {
		return condicaoAmostra;
	}

	public void setCondicaoAmostra(final String parCondicaoAmostra) {
		condicaoAmostra = parCondicaoAmostra;
	}

	public String getObservacaoGuiche() {
		return observacaoGuiche;
	}

	public void setObservacaoGuiche(final String parObservacaoGuiche) {
		observacaoGuiche = parObservacaoGuiche;
	}

	public Boolean getExcluido() {
		return excluido;
	}

	public void setExcluido(final Boolean parExcluido) {
		excluido = parExcluido;
	}

	public String getParticular() {
		return particular;
	}

	public void setParticular(String particular) {
		this.particular = particular;
	}
	

	public Boolean getRemoveCalculado() {
		return removeCalculado;
	}

	public void setRemoveCalculado(Boolean removeCalculado) {
		this.removeCalculado = removeCalculado;
	}

	@Override
	public int compareTo(final ProcedimentoComExamesTO procedimentoComExamesTO) {
		try {
			if (Integer.parseInt(procedimentoComExamesTO.getProcedimento()) < Integer.parseInt(getProcedimento())) {
				return 1;
			} else {
				if (Integer.parseInt(procedimentoComExamesTO.getProcedimento()) > Integer.parseInt(getProcedimento())) {
					return -1;
				} else {
					return 0;
				}
			}
		} catch (final NumberFormatException locExc) {
			return 0;
		}
	}

	  private void setDataHoraMarcacaoConsultaCodigo() {
			for(ExameHermesPardini ex :exames) {
				String exameDescricaoExame = Optional.ofNullable(exame.getDescricaoExame()).orElse("");
				String exameExame = Optional.ofNullable(exame.getExame()).orElse("");
				String exameMaterial = Optional.ofNullable(exame.getMaterial()).orElse("");
				String exameDescricaoMaterial = exameMaterial.equals("DIV") ? "" : Optional.ofNullable(exame.getDescricaoMaterial()).orElse(""); // Quando material div não comparar pela Descrição Material
				
				String exDescricaoExame = Optional.ofNullable(ex.getDescricaoExame()).orElse("");
				String exExame = Optional.ofNullable(ex.getExame()).orElse("");
				String exMaterial = Optional.ofNullable(ex.getMaterial()).orElse("");
				String exDescricaoMaterial = exameMaterial.equals("DIV") ? "" : Optional.ofNullable(ex.getDescricaoMaterial()).orElse(""); // Quando material div não comparar pela Descrição Material
				
		    	if(exameDescricaoExame.equals(exDescricaoExame) 
		    			&& exameExame.equals(exExame)
		    			&& exameMaterial.equals(exMaterial)
		    			&& exameDescricaoMaterial.equals(exDescricaoMaterial)
		    			) {
		    		exame.setDataHoraMarcacao(ex.getDataHoraMarcacao());
		    		break;
		    	}
		    }
		}
}
