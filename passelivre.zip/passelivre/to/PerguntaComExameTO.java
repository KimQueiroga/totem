package br.com.hermespardini.passelivre.to;

import java.io.Serializable;

import br.com.hermespardini.passelivre.model.ConsultaQuestionarioExameResult;
import br.com.hermespardini.passelivre.model.Pergunta;
import br.com.hermespardini.passelivre.model.Questionario;

@SuppressWarnings("serial")
public class PerguntaComExameTO implements Serializable {

	private String codigo;
	private String exame;
	private String examePAI;
	private String descricaoExame;
	private String materiral;
	private String descricao;
	private Integer ordem;
	private String gabarito;
	private String tipoResposta;
	private String formato;
	private String genero;
	private String faixaEtaria;
	private String inviolavel;
	private String violavelComTermo;
	private String obrigatorio;
	private String usoAreaTecnica;
	private String usoAtendimento;
	private String permiteConsolidacao;
	private String usoLaudo;
	private String codigoQuestionario;

	public PerguntaComExameTO() {
	}

	public PerguntaComExameTO(final ConsultaQuestionarioExameResult parConsultaQuestionarioExameResult,
			final Questionario parQuestionario, final Pergunta parPergunta) {
		setCodigo(parPergunta.getCodigo());
		setExamePAI(parConsultaQuestionarioExameResult.getExamePAI());
		setCodigoQuestionario(parQuestionario.getCodigoQuestionario());
		setDescricao(parPergunta.getDescricao());
		setOrdem(parPergunta.getOrdem());
		setGabarito(parPergunta.getGabarito());
		setTipoResposta(parPergunta.getTipoResposta());
		setFormato(parPergunta.getFormato());
		setGenero(parPergunta.getGenero());
		setFaixaEtaria(parPergunta.getFaixaEtaria());
		setInviolavel(parPergunta.getInviolavel());
		setViolavelComTermo(parPergunta.getViolavelComTermo());
		setObrigatorio(parPergunta.getObrigatorio());
		setUsoAreaTecnica(parPergunta.getUsoAreaTecnica());
		setUsoAtendimento(parPergunta.getUsoAtendimento());
		setPermiteConsolidacao(parPergunta.getPermiteConsolidacao());
		setUsoLaudo(parPergunta.getUsoLaudo());
		setDescricaoExame(parConsultaQuestionarioExameResult.getDescricaoExame());
		setExame(parConsultaQuestionarioExameResult.getExame());
		setMateriral(parConsultaQuestionarioExameResult.getMaterial());
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(final String parCodigo) {
		codigo = parCodigo;
	}

	public String getExame() {
		return exame;
	}

	public void setExame(final String parExame) {
		exame = parExame;
	}

	public String getMateriral() {
		return materiral;
	}

	public void setMateriral(final String parMateriral) {
		materiral = parMateriral;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(final String parDescricao) {
		descricao = parDescricao;
	}

	public Integer getOrdem() {
		return ordem;
	}

	public void setOrdem(final Integer parOrdem) {
		ordem = parOrdem;
	}

	public String getGabarito() {
		return gabarito;
	}

	public void setGabarito(final String parGabarito) {
		gabarito = parGabarito;
	}

	public String getTipoResposta() {
		return tipoResposta;
	}

	public void setTipoResposta(final String parTipoResposta) {
		tipoResposta = parTipoResposta;
	}

	public String getFormato() {
		return formato;
	}

	public void setFormato(final String parFormato) {
		formato = parFormato;
	}

	public String getGenero() {
		return genero;
	}

	public void setGenero(final String parGenero) {
		genero = parGenero;
	}

	public String getFaixaEtaria() {
		return faixaEtaria;
	}

	public void setFaixaEtaria(final String parFaixaEtaria) {
		faixaEtaria = parFaixaEtaria;
	}

	public String getInviolavel() {
		return inviolavel;
	}

	public void setInviolavel(final String parInviolavel) {
		inviolavel = parInviolavel;
	}

	public String getViolavelComTermo() {
		return violavelComTermo;
	}

	public void setViolavelComTermo(final String parViolavelComTermo) {
		violavelComTermo = parViolavelComTermo;
	}

	public String getObrigatorio() {
		return obrigatorio;
	}

	public void setObrigatorio(final String parObrigatorio) {
		obrigatorio = parObrigatorio;
	}

	public String getUsoAreaTecnica() {
		return usoAreaTecnica;
	}

	public void setUsoAreaTecnica(final String parUsoAreaTecnica) {
		usoAreaTecnica = parUsoAreaTecnica;
	}

	public String getUsoAtendimento() {
		return usoAtendimento;
	}

	public void setUsoAtendimento(final String parUsoAtendimento) {
		usoAtendimento = parUsoAtendimento;
	}

	public String getPermiteConsolidacao() {
		return permiteConsolidacao;
	}

	public void setPermiteConsolidacao(final String parPermiteConsolidacao) {
		permiteConsolidacao = parPermiteConsolidacao;
	}

	public String getUsoLaudo() {
		return usoLaudo;
	}

	public void setUsoLaudo(final String parUsoLaudo) {
		usoLaudo = parUsoLaudo;
	}

	public String getCodigoQuestionario() {
		return codigoQuestionario;
	}

	public void setCodigoQuestionario(final String parCodigoQuestionario) {
		codigoQuestionario = parCodigoQuestionario;
	}

	public String getDescricaoExame() {
		return descricaoExame;
	}

	public void setDescricaoExame(final String parDescricaoExame) {
		descricaoExame = parDescricaoExame;
	}

	public String getExamePAI() {
		return examePAI;
	}

	public void setExamePAI(final String parExamePAI) {
		examePAI = parExamePAI;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (codigo == null ? 0 : codigo.hashCode());
		return result;
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final PerguntaComExameTO other = (PerguntaComExameTO) obj;
		if (codigo == null) {
			if (other.codigo != null) {
				return false;
			}
		} else if (!codigo.equals(other.codigo)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return codigo + "/" + descricaoExame;
	}

	public boolean isPermiteConsolidacao() {
		return permiteConsolidacao.equals("S");
	}
}
