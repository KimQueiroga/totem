package br.com.hermespardini.passelivre.to;

public class HabilitacaoCamposCadastroTO {

	private Boolean habilitaUF;
	private Boolean habilitaLogradouro;
	private Boolean habilitaCidade;
	private Boolean habilitaBairro;

	public Boolean getHabilitaUF() {
		return habilitaUF;
	}

	public void setHabilitaUF(final Boolean parHabilitaUF) {
		habilitaUF = parHabilitaUF;
	}

	public Boolean getHabilitaLogradouro() {
		return habilitaLogradouro;
	}

	public void setHabilitaLogradouro(final Boolean parHabilitaLogradouro) {
		habilitaLogradouro = parHabilitaLogradouro;
	}

	public Boolean getHabilitaCidade() {
		return habilitaCidade;
	}

	public void setHabilitaCidade(final Boolean parHabilitaCidade) {
		habilitaCidade = parHabilitaCidade;
	}

	public Boolean getHabilitaBairro() {
		return habilitaBairro;
	}

	public void setHabilitaBairro(final Boolean parHabilitaBairro) {
		habilitaBairro = parHabilitaBairro;
	}

}
