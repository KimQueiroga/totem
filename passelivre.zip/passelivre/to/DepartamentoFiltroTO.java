package br.com.hermespardini.passelivre.to;

import java.io.Serializable;

import br.com.hermespardini.passelivre.model.ExameHermesPardini;
import br.com.hermespardini.passelivre.model.ExameMaterialPendente;

public class DepartamentoFiltroTO implements Serializable {
	private String codigo;
	private String descricao;
	private String observacao;

	public DepartamentoFiltroTO(final ExameHermesPardini parExameHermesPardini) {
		codigo = parExameHermesPardini.getDepartamento();
	}

	public DepartamentoFiltroTO(final ExameMaterialPendente parExame) {
		codigo = parExame.getDepartamento();
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(final String parCodigo) {
		codigo = parCodigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(final String parDescricao) {
		descricao = parDescricao;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (codigo == null ? 0 : codigo.hashCode());
		return result;
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final DepartamentoFiltroTO other = (DepartamentoFiltroTO) obj;
		if (codigo == null) {
			if (other.codigo != null) {
				return false;
			}
		} else if (!codigo.equals(other.codigo)) {
			return false;
		}
		return true;
	}

	public String getObservacao() {
		return observacao;
	}

	public void setObservacao(final String parObservacao) {
		observacao = parObservacao;
	}

}
