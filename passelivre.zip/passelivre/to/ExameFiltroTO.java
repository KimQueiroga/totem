package br.com.hermespardini.passelivre.to;

import java.io.Serializable;

import br.com.hermespardini.passelivre.model.ExameHermesPardini;
import br.com.hermespardini.passelivre.model.ExameMaterialPendente;

public class ExameFiltroTO implements Serializable {
	private String material;
	private String exame;
	private String observacao;

	public ExameFiltroTO(final ExameHermesPardini parExameHermesPardini) {
		material = parExameHermesPardini.getMaterial();
		exame = parExameHermesPardini.getExame();
	}

	public ExameFiltroTO(final ExameMaterialPendente parExameMaterialPendente) {
		material = parExameMaterialPendente.getMaterial();
		exame = parExameMaterialPendente.getExame();
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(final String parMaterial) {
		material = parMaterial;
	}

	public String getExame() {
		return exame;
	}

	public void setExame(final String parExame) {
		exame = parExame;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (exame == null ? 0 : exame.hashCode());
		result = prime * result + (material == null ? 0 : material.hashCode());
		return result;
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final ExameFiltroTO other = (ExameFiltroTO) obj;
		if (exame == null) {
			if (other.exame != null) {
				return false;
			}
		} else if (!exame.equals(other.exame)) {
			return false;
		}
		if (material == null) {
			if (other.material != null) {
				return false;
			}
		} else if (!material.equals(other.material)) {
			return false;
		}
		return true;
	}

	public String getObservacao() {
		return observacao;
	}

	public void setObservacao(final String parObservacao) {
		observacao = parObservacao;
	}

}
