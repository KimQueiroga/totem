package br.com.hermespardini.passelivre.to;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class ValorParametroAplicacaoDto implements Serializable {
	private static final long serialVersionUID = 1L;
	private Long id;
	private Date inicioVigencia;
	private Date fimVigencia;
	private String valor;

	public ValorParametroAplicacaoDto(Long id, Date inicioVigencia, Date fimVigencia, String valor) {
		super();
		this.id = id;
		this.inicioVigencia = inicioVigencia;
		this.fimVigencia = fimVigencia;
		this.valor = valor;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getInicioVigencia() {
		return inicioVigencia;
	}

	public void setInicioVigencia(Date inicioVigencia) {
		this.inicioVigencia = inicioVigencia;
	}

	public Date getFimVigencia() {
		return fimVigencia;
	}

	public void setFimVigencia(Date fimVigencia) {
		this.fimVigencia = fimVigencia;
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}
}
