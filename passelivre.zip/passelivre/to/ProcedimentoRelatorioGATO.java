package br.com.hermespardini.passelivre.to;

import java.io.Serializable;
import java.util.List;

import br.com.hermespardini.passelivre.model.ConsultaQuestionarioExameResult;
import br.com.hermespardini.passelivre.model.CriarPedidoResult;
import br.gov.ans.www.padroes.tiss.schemas.Ct_itemSolicitacao;

public class ProcedimentoRelatorioGATO implements Serializable, Comparable<ProcedimentoRelatorioGATO> {

	private String tabela;
	private String codigoProcedimento;
	private String descricao;
	private String observacao;
	private String qtdSolicitada;
	private String qtdAut;
	private String informacoesAdicionais;

	public ProcedimentoRelatorioGATO() {
	}

	// ACRESCENTEI NOVO METODO
	private ProcedimentoRelatorioGATO(final Ct_itemSolicitacao parCt_itemSolicitacao,
			final List<ConsultaQuestionarioExameResult> questionariosExamesResult, int i, final int qntSolicitada) { // teste
		// ellen
		// maia
		tabela = parCt_itemSolicitacao.getIdentificacaoProcedimentos().getTipoTabela();
		codigoProcedimento = parCt_itemSolicitacao.getIdentificacaoProcedimentos().getCodigo();
		informacoesAdicionais = parCt_itemSolicitacao.getObservacao();
		observacao = "";
		descricao = parCt_itemSolicitacao.getIdentificacaoProcedimentos().getDescricao()
				+ retornarInformacoesAdicionais();
		for (int a = 0; a <= qntSolicitada; a++) {
			descricao = descricao.concat(" ( " + questionariosExamesResult.get(i).getMaterial() + "/"
					+ questionariosExamesResult.get(i).getExame() + " ) ");
			i++;
		}

		qtdSolicitada = parCt_itemSolicitacao.getQuantidadeSolicitada().toString();
		qtdAut = parCt_itemSolicitacao.getQuantidadeAutorizada().toString();
	}

	public ProcedimentoRelatorioGATO(final Ct_itemSolicitacao parCt_itemSolicitacao,
			final List<ProcedimentoComExamesTO> procedimentosComExames, final boolean procedimentosExcluidos) {

		tabela = parCt_itemSolicitacao.getIdentificacaoProcedimentos().getTipoTabela();
		informacoesAdicionais = parCt_itemSolicitacao.getObservacao();
		observacao = "";
		qtdSolicitada = parCt_itemSolicitacao.getQuantidadeSolicitada().toString();
		qtdAut = parCt_itemSolicitacao.getQuantidadeAutorizada().toString();
		codigoProcedimento = parCt_itemSolicitacao.getIdentificacaoProcedimentos().getCodigo();
		if (procedimentosExcluidos) {
			codigoProcedimento = codigoProcedimento.concat("*");
		}

		descricao = parCt_itemSolicitacao.getIdentificacaoProcedimentos().getDescricao()
				+ retornarInformacoesAdicionais();

		for (final ProcedimentoComExamesTO procedimentoComExamesTO : procedimentosComExames) {
			if (procedimentoComExamesTO.getProcedimento()
					.equals(parCt_itemSolicitacao.getIdentificacaoProcedimentos().getCodigo())) {
				descricao = descricao.concat(" ( " + procedimentoComExamesTO.getExame().getMaterial() + "/"
						+ procedimentoComExamesTO.getExame().getExame() + " ) ");
			}
		}
	}

	private ProcedimentoRelatorioGATO(final Ct_itemSolicitacao parCt_itemSolicitacao,
			final List<ConsultaQuestionarioExameResult> questionariosExamesResult, final int i,
			final CriarPedidoResult parCriarPedidoResult) { // teste ellen maia
		tabela = parCt_itemSolicitacao.getIdentificacaoProcedimentos().getTipoTabela();
		codigoProcedimento = parCt_itemSolicitacao.getIdentificacaoProcedimentos().getCodigo();
		informacoesAdicionais = parCt_itemSolicitacao.getObservacao();
		observacao = "";

		// EM HIPOTESE NENHUMA DAR ERRO DE INDEX
		if (i <= questionariosExamesResult.size()) {

			// PARA PROCEDIMENTOS QUE FORAM EXCLUIDOS VERIFICAR E PULAR... NAO PEGAREI O
			// MNEMONICO
			if (parCt_itemSolicitacao.getIdentificacaoProcedimentos().getCodigo().contains("*")) {
				descricao = parCt_itemSolicitacao.getIdentificacaoProcedimentos().getDescricao()
						+ retornarInformacoesAdicionais();
			} else {
				/*
				 * descricao =
				 * parCt_itemSolicitacao.getIdentificacaoProcedimentos().getDescricao() + " ( "
				 * + parCriarPedidoResult.getExames().get(i).getMaterial() + "/" +
				 * parCriarPedidoResult.getExames().get(i).getExame() + " ) " +
				 * retornarInformacoesAdicionais();
				 */
				descricao = parCriarPedidoResult.getExames().get(i).getDescricaoExame() + " ( "
						+ parCriarPedidoResult.getExames().get(i).getMaterial() + "/"
						+ parCriarPedidoResult.getExames().get(i).getExame() + " ) " + retornarInformacoesAdicionais();
			}

		} else {
			descricao = parCt_itemSolicitacao.getIdentificacaoProcedimentos().getDescricao()
					+ retornarInformacoesAdicionais();
		}

		qtdSolicitada = parCt_itemSolicitacao.getQuantidadeSolicitada().toString();
		qtdAut = parCt_itemSolicitacao.getQuantidadeAutorizada().toString();
	}

	private ProcedimentoRelatorioGATO(final Ct_itemSolicitacao parCt_itemSolicitacao, final String paramObservacao) {
		tabela = parCt_itemSolicitacao.getIdentificacaoProcedimentos().getTipoTabela();
		codigoProcedimento = parCt_itemSolicitacao.getIdentificacaoProcedimentos().getCodigo();
		informacoesAdicionais = parCt_itemSolicitacao.getObservacao();
		descricao = parCt_itemSolicitacao.getIdentificacaoProcedimentos().getDescricao()
				+ retornarInformacoesAdicionais();
		qtdSolicitada = parCt_itemSolicitacao.getQuantidadeSolicitada().toString();
		observacao = paramObservacao;
		qtdAut = parCt_itemSolicitacao.getQuantidadeAutorizada().toString();
	}

	public ProcedimentoRelatorioGATO criarProcedimentoExcecao(final Ct_itemSolicitacao parCt_itemSolicitacao) {
		return new ProcedimentoRelatorioGATO(parCt_itemSolicitacao, "xxxxx");
	}

	public ProcedimentoRelatorioGATO criarProcedimento(final Ct_itemSolicitacao parCt_itemSolicitacao,
			final List<ConsultaQuestionarioExameResult> questionariosExamesResult, final int i,
			final CriarPedidoResult parCriarPedidoResult) { // teste ellen maia
		return new ProcedimentoRelatorioGATO(parCt_itemSolicitacao, questionariosExamesResult, i, parCriarPedidoResult);
	}

	public ProcedimentoRelatorioGATO criarProcedimento2ouMais(final Ct_itemSolicitacao parCt_itemSolicitacao,
			final List<ConsultaQuestionarioExameResult> questionariosExamesResult, final int i,
			final int qntSolicitada) { // teste // ellen maia
		return new ProcedimentoRelatorioGATO(parCt_itemSolicitacao, questionariosExamesResult, i, qntSolicitada);
	}

	public ProcedimentoRelatorioGATO criarProcedimentoQueFoiExcluido(final Ct_itemSolicitacao parCt_itemSolicitacao,
			final List<ConsultaQuestionarioExameResult> questionariosExamesResult, final int i,
			final CriarPedidoResult parCriarPedidoResult) {
		parCt_itemSolicitacao.getIdentificacaoProcedimentos()
				.setCodigo(parCt_itemSolicitacao.getIdentificacaoProcedimentos().getCodigo() + "*");
		return new ProcedimentoRelatorioGATO(parCt_itemSolicitacao, questionariosExamesResult, i, parCriarPedidoResult); // teste
																															// ellen
																															// maia
	}

	private String retornarInformacoesAdicionais() {
		if (informacoesAdicionais != null && !informacoesAdicionais.isEmpty()) {
			return "\nInformações adicionais: \r\n" + informacoesAdicionais;
		}
		return "";
	}

	public String getTabela() {
		return tabela;
	}

	public void setTabela(final String parTabela) {
		tabela = parTabela;
	}

	public String getCodigoProcedimento() {
		return codigoProcedimento;
	}

	public void setCodigoProcedimento(final String parCodigoProcedimento) {
		codigoProcedimento = parCodigoProcedimento;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(final String parDescricao) {
		descricao = parDescricao;
	}

	public String getQtdSolicitada() {
		return qtdSolicitada;
	}

	public void setQtdSolicitada(final String parQtdSolicitada) {
		qtdSolicitada = parQtdSolicitada;
	}

	public String getQtdAut() {
		return qtdAut;
	}

	public void setQtdAut(final String parQtdAut) {
		qtdAut = parQtdAut;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (codigoProcedimento == null ? 0 : codigoProcedimento.hashCode());
		return result;
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final ProcedimentoRelatorioGATO other = (ProcedimentoRelatorioGATO) obj;
		if (codigoProcedimento == null) {
			if (other.codigoProcedimento != null) {
				return false;
			}
		} else if (!codigoProcedimento.equals(other.codigoProcedimento)) {
			return false;
		}
		return true;
	}

	@Override
	public int compareTo(final ProcedimentoRelatorioGATO procedimentoRelatorioGATO) {
		return codigoProcedimento.compareTo(procedimentoRelatorioGATO.getCodigoProcedimento());
	}

	public String getInformacoesAdicionais() {
		return informacoesAdicionais;
	}

	public void setInformacoesAdicionais(final String parInformacoesAdicionais) {
		informacoesAdicionais = parInformacoesAdicionais;
	}

	public String getObservacao() {
		return observacao;
	}

	public void setObservacao(final String parObservacao) {
		observacao = parObservacao;
	}

}
