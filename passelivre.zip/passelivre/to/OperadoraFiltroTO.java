package br.com.hermespardini.passelivre.to;

import java.io.Serializable;

public class OperadoraFiltroTO implements Serializable {
	private String codigo;
	private String plano;
	private String observacao;

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(final String parCodigo) {
		codigo = parCodigo;
	}

	public String getPlano() {
		return plano;
	}

	public void setPlano(final String parPlano) {
		plano = parPlano;
	}

	public String getObservacao() {
		return observacao;
	}

	public void setObservacao(final String parObservacao) {
		observacao = parObservacao;
	}

}
