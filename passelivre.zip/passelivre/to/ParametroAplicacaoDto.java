package br.com.hermespardini.passelivre.to;

import java.io.Serializable;

public class ParametroAplicacaoDto implements Serializable {
	private static final long serialVersionUID = 1L;
	private Long id;
	private String aplicacao;
	private String chave;
	private ValorParametroAplicacaoDto valorAplicacao;

	public ParametroAplicacaoDto(Long id, String aplicacao, String chave, ValorParametroAplicacaoDto valorAplicacao) {
		super();
		this.id = id;
		this.aplicacao = aplicacao;
		this.chave = chave;
		this.valorAplicacao = valorAplicacao;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAplicacao() {
		return aplicacao;
	}

	public void setAplicacao(String aplicacao) {
		this.aplicacao = aplicacao;
	}

	public String getChave() {
		return chave;
	}

	public void setChave(String chave) {
		this.chave = chave;
	}

	public ValorParametroAplicacaoDto getValorAplicacao() {
		return valorAplicacao;
	}

	public void setValorAplicacao(ValorParametroAplicacaoDto valorAplicacao) {
		this.valorAplicacao = valorAplicacao;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}