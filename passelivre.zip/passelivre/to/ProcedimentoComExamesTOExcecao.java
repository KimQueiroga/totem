package br.com.hermespardini.passelivre.to;

import java.math.BigDecimal;
import java.util.List;

import br.com.hermespardini.passelivre.model.ExameHermesPardini;
import br.com.hermespardini.passelivre.model.MotivosGlosas;

public class ProcedimentoComExamesTOExcecao {

	private Boolean vt;
	private String guia;
	private String descricao;
	private Long idComposicao;
	private String procedimento;
	private Integer sequenciaExame;
	private MotivosGlosas glosas;
	private BigDecimal quantidadeAutorizadas;
	private BigDecimal quantidadeSolicitacadas;
	private String informacoesAdicionais;
	private String informacoesClinica;
	private ExameHermesPardini exame;
	private List<ExameHermesPardini> exames;

	public ProcedimentoComExamesTOExcecao(final ProcedimentoComExamesTO parProcedimentoComExamesTO) {
		vt = parProcedimentoComExamesTO.getVt();
		guia = parProcedimentoComExamesTO.getGuia();
		descricao = parProcedimentoComExamesTO.getDescricao();
		idComposicao = parProcedimentoComExamesTO.getIdComposicao();
		procedimento = parProcedimentoComExamesTO.getProcedimento();
		sequenciaExame = parProcedimentoComExamesTO.getSequenciaExame();
		glosas = parProcedimentoComExamesTO.getGlosas();
		quantidadeAutorizadas = parProcedimentoComExamesTO.getQuantidadeAutorizadas();
		quantidadeSolicitacadas = parProcedimentoComExamesTO.getQuantidadeSolicitacadas();
		informacoesAdicionais = parProcedimentoComExamesTO.getInformacoesAdicionais();
		exame = parProcedimentoComExamesTO.getExame();
		exames = parProcedimentoComExamesTO.getExames();
	}

	public Boolean getVt() {
		return vt;
	}

	public void setVt(final Boolean parVt) {
		vt = parVt;
	}

	public String getGuia() {
		return guia;
	}

	public void setGuia(final String parGuia) {
		guia = parGuia;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(final String parDescricao) {
		descricao = parDescricao;
	}

	public Long getIdComposicao() {
		return idComposicao;
	}

	public void setIdComposicao(final Long parIdComposicao) {
		idComposicao = parIdComposicao;
	}

	public String getProcedimento() {
		return procedimento;
	}

	public void setProcedimento(final String parProcedimento) {
		procedimento = parProcedimento;
	}

	public Integer getSequenciaExame() {
		return sequenciaExame;
	}

	public void setSequenciaExame(final Integer parSequenciaExame) {
		sequenciaExame = parSequenciaExame;
	}

	public MotivosGlosas getGlosas() {
		return glosas;
	}

	public void setGlosas(final MotivosGlosas parGlosas) {
		glosas = parGlosas;
	}

	public BigDecimal getQuantidadeAutorizadas() {
		return quantidadeAutorizadas;
	}

	public void setQuantidadeAutorizadas(final BigDecimal parQuantidadeAutorizadas) {
		quantidadeAutorizadas = parQuantidadeAutorizadas;
	}

	public BigDecimal getQuantidadeSolicitacadas() {
		return quantidadeSolicitacadas;
	}

	public void setQuantidadeSolicitacadas(final BigDecimal parQuantidadeSolicitacadas) {
		quantidadeSolicitacadas = parQuantidadeSolicitacadas;
	}

	public String getInformacoesAdicionais() {
		return informacoesAdicionais;
	}

	public void setInformacoesAdicionais(final String parInformacoesAdicionais) {
		informacoesAdicionais = parInformacoesAdicionais;
	}

	public String getInformacoesClinica() {
		return informacoesClinica;
	}

	public void setInformacoesClinica(final String parInformacoesClinica) {
		informacoesClinica = parInformacoesClinica;
	}

	public ExameHermesPardini getExame() {
		return exame;
	}

	public void setExame(final ExameHermesPardini parExame) {
		exame = parExame;
	}

	public List<ExameHermesPardini> getExames() {
		return exames;
	}

	public void setExames(final List<ExameHermesPardini> parExames) {
		exames = parExames;
	}

}
