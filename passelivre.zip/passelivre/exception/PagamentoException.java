package br.com.hermespardini.passelivre.exception;

public class PagamentoException extends Exception {

	public PagamentoException(final String mensagem) {
		super(mensagem);
	}
}
