package br.com.hermespardini.passelivre.exception;

@SuppressWarnings("serial")
public class DownloadUnimedException extends Exception {
	public DownloadUnimedException(final String mensagem) {
		super(mensagem);
	}
}