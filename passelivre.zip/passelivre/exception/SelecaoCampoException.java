package br.com.hermespardini.passelivre.exception;

public class SelecaoCampoException extends Exception {
	public SelecaoCampoException(final String mensagem) {
		super(mensagem);
	}
}
