package br.com.hermespardini.passelivre.exception;

public class RegraParaExameJaAdicionadoException extends Exception {

	private static final long serialVersionUID = 1L;

	public RegraParaExameJaAdicionadoException(final String mensagem) {
		super(mensagem);
	}
}
