package br.com.hermespardini.passelivre.exception;

public class GuiasAutorizadasException extends Exception {
	public GuiasAutorizadasException(final String mensagem) {
		super(mensagem);
	}

}
