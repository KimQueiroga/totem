package br.com.hermespardini.passelivre.exception;

@SuppressWarnings("serial")
public class EnvioEmailException extends Exception {
	public EnvioEmailException(final String mensagem) {
		super(mensagem);
	}
}
