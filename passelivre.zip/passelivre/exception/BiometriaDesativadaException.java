package br.com.hermespardini.passelivre.exception;

@SuppressWarnings("serial")
public class BiometriaDesativadaException extends Exception {
	
	public BiometriaDesativadaException(final String msg) {
		super(msg);
	}

}
