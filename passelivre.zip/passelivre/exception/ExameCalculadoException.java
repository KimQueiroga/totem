package br.com.hermespardini.passelivre.exception;

@SuppressWarnings("serial")
public class ExameCalculadoException extends Exception {
	public ExameCalculadoException(final String mensagem) {
		super(mensagem);
	}
}
