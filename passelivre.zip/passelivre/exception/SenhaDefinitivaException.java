package br.com.hermespardini.passelivre.exception;

public class SenhaDefinitivaException extends Exception {
	public SenhaDefinitivaException(final String mensagem) {
		super(mensagem);
	}
}
