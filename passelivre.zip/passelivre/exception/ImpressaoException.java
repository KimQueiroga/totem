package br.com.hermespardini.passelivre.exception;

@SuppressWarnings("serial")
public class ImpressaoException extends Exception {

	public ImpressaoException(final String mensagem) {
		super(mensagem);
	}

}
