package br.com.hermespardini.passelivre.service;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.model.CancelarPedidoResult;
import br.com.hermespardini.passelivre.model.ClienteUnidadePasseLivre;
import br.com.hermespardini.passelivre.model.ConsultaDataPrevisaoResultadoResult;
import br.com.hermespardini.passelivre.model.CriarPedidoResult;
import br.com.hermespardini.passelivre.model.DetalhePedidoCliente;
import br.com.hermespardini.passelivre.model.PagarPedidoResult;
import br.com.hermespardini.passelivre.model.ParametroCancelaPedido;
import br.com.hermespardini.passelivre.model.ParametroDataPrevisaoResultado;
import br.com.hermespardini.passelivre.model.ParametroPagarPedido;
import br.com.hermespardini.passelivre.model.ParametroPedido;
import br.com.hermespardini.passelivre.model.PedidoCliente;
import br.com.hermespardini.passelivre.model.PedidoDetalheResult;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.service.IhpMainService;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class PedidoService extends IhpMainService {
	private String mensagem;
	private String parametroUrl;

	public PedidoService(final HttpServletRequest parRequest) throws Exception {
		super(parRequest);
	}

	public void montarUrlConsulta(Long empresa) {

		parametroUrl = "&empresa=" + empresa + "&origem=" + Constantes.ORIGEM_PADRAO;

	}

	public void consultar() throws RegraNegocioException {
		Response locResponse = null;
		final Gson gson = new Gson();
		final JSONObject locJsonObject = new JSONObject();
		final OkHttpClient client = new OkHttpClient();
		ClienteUnidadePasseLivre clienteUnidadePasseLivre = new ClienteUnidadePasseLivre();
		clienteUnidadePasseLivre = (ClienteUnidadePasseLivre) getValueObject();
		final String urlPedido = getEndPoint("ENDPOINT_IHP_PEDIDO") + clienteUnidadePasseLivre.getCodigoCliente()
				+ parametroUrl;
		final Request locRequest = new Request.Builder().addHeader("X-Hp-Auth-Token", clienteUnidadePasseLivre.getId())
				.url(urlPedido).get().build();

		try {
			locResponse = client.newCall(locRequest).execute();
			verificarRespostaAoFazerConsulta(locResponse, gson, locJsonObject);
		} catch (final Exception exc) {
			exc.printStackTrace();
			mensagem = exc.getMessage();
			throw new RegraNegocioException(mensagem);
		} finally {
			if (locResponse != null) {
				locResponse.close();
			}
			if (client != null) {
				client.connectionPool().evictAll();
			}
		}
	}

	public void cancelar(final ParametroCancelaPedido parametroCancelaPedido) throws RegraNegocioException {
		final Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
		final String input = gson.toJson(parametroCancelaPedido);
		final OkHttpClient client = new OkHttpClient.Builder()
				.connectTimeout(Constantes.TIMEOUT_CONSULTA_EXAMES, TimeUnit.SECONDS)
				.writeTimeout(Constantes.TIMEOUT_CONSULTA_EXAMES, TimeUnit.SECONDS)
				.readTimeout(Constantes.TIMEOUT_CONSULTA_EXAMES, TimeUnit.SECONDS).build();
		final MediaType json = MediaType.parse(Constantes.TYPE_JSON);
		final RequestBody body = RequestBody.create(json, input);
		final Request request = new Request.Builder().url(getEndPoint("ENDPOINT_IHP_CANCELAR_PEDIDO")).post(body)
				.build();
		Response locResponse = null;
		JSONObject locJsonObject = new JSONObject();
		try {
			locResponse = client.newCall(request).execute();
			final String locJsonData = locResponse.body().string();
			verificarSeEhUmCoteudoValido(locJsonData);
			locJsonObject = new JSONObject(locJsonData);
			final CancelarPedidoResult cancelarPedidoResult = gson.fromJson(
					locJsonObject.getJSONObject("CancelarPedidoResult").toString(), CancelarPedidoResult.class);
			final Integer status = Integer.parseInt(cancelarPedidoResult.getStatus());
			verificarRespostaAoCancelarPedido(locResponse, cancelarPedidoResult, status);
		} catch (final Exception locExc) {
			failed();
			setResponseMessage(locExc.getMessage());
			throw new RegraNegocioException(locExc.getMessage() + " unidade:" + parametroCancelaPedido.getUnidade());
		} finally {
			if (locResponse != null) {
				locResponse.close();
			}
			if (client != null) {
				client.connectionPool().evictAll();
			}
		}
	}

	public void confirmar(final ParametroPagarPedido parametroPagarPedido) throws RegraNegocioException {
		final Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
		final String input = gson.toJson(parametroPagarPedido);
		final OkHttpClient client = new OkHttpClient.Builder()
				.connectTimeout(Constantes.TIMEOUT_CONSULTA_EXAMES, TimeUnit.SECONDS)
				.writeTimeout(Constantes.TIMEOUT_CONSULTA_EXAMES, TimeUnit.SECONDS)
				.readTimeout(Constantes.TIMEOUT_CONSULTA_EXAMES, TimeUnit.SECONDS).build();
		final MediaType json = MediaType.parse(Constantes.TYPE_JSON);
		final RequestBody body = RequestBody.create(json, input);
		final Request request = new Request.Builder().url(getEndPoint("ENDPOINT_IHP_CONFIRMAR_PEDIDO")).post(body)
				.build();
		Response locResponse = null;
		JSONObject locJsonObject = new JSONObject();
		try {
			locResponse = client.newCall(request).execute();
			final String locJsonData = locResponse.body().string();
			verificarSeEhUmCoteudoValido(locJsonData);
			locJsonObject = new JSONObject(locJsonData);
			final PagarPedidoResult pagarPedidoResult = gson
					.fromJson(locJsonObject.getJSONObject("PagarPedidoResult").toString(), PagarPedidoResult.class);
			final Integer status = Integer.parseInt(pagarPedidoResult.getStatus());
			verificarRespostaAoConfirmarPedido(locResponse, pagarPedidoResult, status);
		} catch (final Exception locExc) {
			failed();
			setResponseMessage(locExc.getMessage());
			throw new RegraNegocioException(locExc.getMessage() + " unidade:" + parametroPagarPedido.getUnidade());
		} finally {
			if (locResponse != null) {
				locResponse.close();
			}
			if (client != null) {
				client.connectionPool().evictAll();
			}
		}
	}

	private void verificarRespostaAoConfirmarPedido(final Response parResponse,
			final PagarPedidoResult parPagarPedidoResult, final Integer parStatus) throws RegraNegocioException {
		if (parResponse.isSuccessful() && parStatus == 0) {
			setResponseObject(parPagarPedidoResult);
			mensagem = Util.retirarCaracterEspecial(parPagarPedidoResult.getMensagem());
			setResponseMessage(mensagem);
		} else {
			failed();
			mensagem = Util.retirarCaracterEspecial(parPagarPedidoResult.getMensagem());
			setResponseMessage(mensagem);
			throw new RegraNegocioException(mensagem);
		}
	}

	private void verificarRespostaAoCancelarPedido(final Response locResponse,
			final CancelarPedidoResult cancelaPedidoResult, final Integer status) {
		if (locResponse.isSuccessful() && status == 0) {
			setResponseObject(cancelaPedidoResult);
			mensagem = Util.retirarCaracterEspecial(cancelaPedidoResult.getMensagem());
			setResponseMessage(mensagem);
		} else {
			failed();
			mensagem = Util.retirarCaracterEspecial(cancelaPedidoResult.getMensagem());
			setResponseMessage(mensagem);
		}
	}

	private void verificarRespostaAoFazerConsulta(final Response locResponse, final Gson gson,
			final JSONObject locJsonObject) {
		if (locResponse.isSuccessful()) {
			final TypeToken<List<PedidoCliente>> token = new TypeToken<List<PedidoCliente>>() {
			};
			final List<PedidoCliente> lstPedidos = gson.fromJson(locResponse.body().charStream(), token.getType());
			setResponseObject(lstPedidos);
		} else {
			mensagem = Util.retirarCaracterEspecial(locJsonObject.getString("error"));
			setResponseMessage(mensagem);
		}
	}

	private void verificarSeEhUmCoteudoValido(final String parJsonData) throws IOException, RegraNegocioException {
		if (Util.verificarSeConteudoEhXML(parJsonData)) {
			failed();
			setResponseMessage(parJsonData);
			throw new RegraNegocioException(parJsonData);
		}
	}

	public void consultarResultado(final String id) throws RegraNegocioException {
		Response locResponse = null;
		final Gson gson = new Gson();
		final JSONObject locJsonObject = new JSONObject();
		final OkHttpClient client = new OkHttpClient();
		ClienteUnidadePasseLivre clienteUnidadePasseLivre = new ClienteUnidadePasseLivre();
		clienteUnidadePasseLivre = (ClienteUnidadePasseLivre) getValueObject();
		final String urlPedido = getEndPoint("ENDPOINT_IHP_PEDIDO_ID") + id;
		final Request locRequest = new Request.Builder().addHeader("X-Hp-Auth-Token", clienteUnidadePasseLivre.getId())
				.url(urlPedido).get().build();
		try {
			locResponse = client.newCall(locRequest).execute();
			verificarRespostaAoFazerConsultarResultado(locResponse, gson, locJsonObject);
		} catch (final IOException exc) {
			throw new RegraNegocioException(exc.getMessage());
		} catch (final Exception exc) {
			throw new RegraNegocioException(exc.getMessage());
		} finally {
			if (locResponse != null) {
				locResponse.close();
			}
			if (client != null) {
				client.connectionPool().evictAll();
			}
		}
	}

	private void verificarRespostaAoFazerConsultarResultado(final Response locResponse, final Gson gson,
			final JSONObject locJsonObject) throws RegraNegocioException {
		if (locResponse.isSuccessful()) {
			final TypeToken<List<DetalhePedidoCliente>> token = new TypeToken<List<DetalhePedidoCliente>>() {
			};
			final List<DetalhePedidoCliente> lstResultadoPedidos = gson.fromJson(locResponse.body().charStream(),
					token.getType());
			setResponseObject(lstResultadoPedidos);
		} else {
			mensagem = Util.retirarCaracterEspecial(
					locJsonObject.getJSONObject("EntregaMaterialPendenteResult").getString("error"));
			setResponseMessage(mensagem);
			throw new RegraNegocioException(mensagem);
		}
	}

	public void fazerPedido(final ParametroPedido parametroPedido) throws RegraNegocioException {
		final Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
		final String input = gson.toJson(parametroPedido);
		final OkHttpClient client = new OkHttpClient.Builder()
				.connectTimeout(Constantes.TIMEOUT_FAZER_PEDIDO, TimeUnit.SECONDS)
				.writeTimeout(Constantes.TIMEOUT_FAZER_PEDIDO, TimeUnit.SECONDS)
				.readTimeout(Constantes.TIMEOUT_FAZER_PEDIDO, TimeUnit.SECONDS).build();
		final MediaType json = MediaType.parse(Constantes.TYPE_JSON);
		final RequestBody body = RequestBody.create(json, input);
		final Request request = new Request.Builder().url(getEndPoint("ENDPOINT_IHP_FAZER_PEDIDO")).post(body).build();
		Response locResponse = null;
		JSONObject locJsonObject = new JSONObject();
		try {
			locResponse = client.newCall(request).execute();
			final String locJsonData = locResponse.body().string();
			verificarSeEhUmCoteudoValido(locJsonData);
			locJsonObject = new JSONObject(locJsonData);
			final CriarPedidoResult criarPedidoResult = gson
					.fromJson(locJsonObject.getJSONObject("CriarPedidoResult").toString(), CriarPedidoResult.class);
			final Integer status = Integer.parseInt(criarPedidoResult.getStatus());
			verificarRespostaAoFazerPedido(locResponse, criarPedidoResult, status);
		} catch (final Exception locExc) {
			failed();
			setResponseMessage(locExc.getMessage());
			throw new RegraNegocioException(locExc.getMessage() + " unidade:" + parametroPedido.getUnidade());
		} finally {
			if (locResponse != null) {
				locResponse.close();
			}
			if (client != null) {
				client.connectionPool().evictAll();
			}
		}
	}

	private void verificarRespostaAoFazerPedido(final Response locResponse, final CriarPedidoResult criarPedidoResult,
			final Integer status) throws RegraNegocioException {
		if (locResponse.isSuccessful() && status == 0) {
			setResponseObject(criarPedidoResult);
			mensagem = Util.retirarCaracterEspecial(criarPedidoResult.getMensagem());
			setResponseMessage(mensagem);
		} else {
			failed();
			mensagem = Util.retirarCaracterEspecial(criarPedidoResult.getMensagem());
			setResponseMessage(mensagem);
			throw new RegraNegocioException(mensagem);
		}
	}

	public void consultarPedidoDetalheResult(final String id, final String token) throws RegraNegocioException {
	    Response locResponse = null;
	    final Gson gson = new Gson();
	    final JSONObject locJsonObject = new JSONObject();
	    final OkHttpClient client = new OkHttpClient();
	    final String urlPedido = getEndPoint("ENDPOINT_IHP_PEDIDO_ID_DETALHES") + id;
	    
	    String origem = Constantes.ORIGEM_PADRAO;
	    final Request locRequest =
	        new Request.Builder().addHeader("token", token).addHeader("origem", origem).url(urlPedido).get()
	            .build();
	    
	    try {
	      locResponse = client.newCall(locRequest).execute();
	      verificarRespostaAoFazerConsultarResultadoPedidoDetalhe(locResponse, gson, locJsonObject);
	    } catch (final IOException exc) {
	      throw new RegraNegocioException(exc.getMessage());
	    } catch (final Exception exc) {
	      throw new RegraNegocioException(exc.getMessage());
	    } finally {
	      if (locResponse != null) {
	        locResponse.close();
	      }
	      if(client != null) {
	        client.connectionPool().evictAll();
	      }
	    }
	  }
	
	private void verificarRespostaAoFazerConsultarResultadoPedidoDetalhe(final Response locResponse, final Gson gson,
			final JSONObject locJsonObject) throws RegraNegocioException {
		if (locResponse.isSuccessful()) {
			final TypeToken<PedidoDetalheResult> token = new TypeToken<PedidoDetalheResult>() {
			};
			final PedidoDetalheResult result = gson.fromJson(locResponse.body().charStream(),
					token.getType());
			if (result != null) {
				if (result.getStatus().equals("0")) {
					setResponseObject(result);
				} else {
					failed();
					setResponseMessage(result.getMensagem());
				}
			} else {
				falhaConsultarResultadoPedidoDetalhe(locResponse);
			}
		} else {
			falhaConsultarResultadoPedidoDetalhe(locResponse);
		}
	}

	private void falhaConsultarResultadoPedidoDetalhe(final Response locResponse) throws RegraNegocioException {
		failed();
		try {
			mensagem = locResponse.message();
		} catch (Exception e) {
			mensagem = null;
		}
		mensagem = (Objects.isNull(mensagem) || mensagem.equals("")) ? "Falha ao consultar detalhes pedido" : mensagem;
		setResponseMessage(mensagem);
		throw new RegraNegocioException(mensagem);
	}
	
	public void obterDataHoraMarcacaoExamesEspeciais(ParametroDataPrevisaoResultado parDataPrevisao)
			throws RegraNegocioException, ParseException {
		final Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
		final String input = gson.toJson(parDataPrevisao);
		final OkHttpClient client =  new OkHttpClient.Builder()
			    .connectTimeout(30, TimeUnit.SECONDS)
			    .writeTimeout(30, TimeUnit.SECONDS)
			    .readTimeout(30, TimeUnit.SECONDS)
			    .build();		
		
		final MediaType json = MediaType.parse(Constantes.TYPE_JSON);
		final RequestBody body = RequestBody.create(json, input);
		final Request request = new Request.Builder().addHeader("origem", parDataPrevisao.getOrigem()).addHeader("token", parDataPrevisao.getToken())
				.url(getEndPoint("ENDPOINT_IHP_EXAME_DATA_MARCACAO")).post(body)
				.build();
		Response locResponse = null;
		try {
			locResponse = client.newCall(request).execute();	
			final String locJsonData = locResponse.body().string();
			verificarSeEhUmCoteudoValido(locJsonData);
			if (locResponse.isSuccessful()) {
				final ConsultaDataPrevisaoResultadoResult result = gson.fromJson(locJsonData, ConsultaDataPrevisaoResultadoResult.class);
				if (result.getStatus() != 0) {
					failed();
					setResponseMessage(result.getMensagens());
				}
				setResponseObject(result.getDataHoraMarcacao());
			}
		} catch (final Exception locExc) {
			failed();
			throw new RegraNegocioException(locExc.getMessage());
		} finally {
			if (locResponse != null) {
				locResponse.close();
			}
			if (client != null) {
				client.connectionPool().evictAll();
			}
		}
	}
	
}
