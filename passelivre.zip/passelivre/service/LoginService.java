package br.com.hermespardini.passelivre.service;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONObject;
import org.wdelmaschio.base.model.ValueObject;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.model.ClienteUnidadePasseLivre;
import br.com.hermespardini.passelivre.model.ConsultaDadosAd;
import br.com.hermespardini.passelivre.model.ParametroLogin;
import br.com.hermespardini.passelivre.model.UserAuth;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.service.IhpMainService;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class LoginService extends IhpMainService {
	private String mensagem;

	public LoginService(final HttpServletRequest parRequest) throws Exception {
		super(parRequest);
	}

	public ValueObject logar(final UserAuth user) throws Exception {
		setValueObject(user);
		final Gson gson = new Gson();
		final String input = gson.toJson(getValueObject());
		final OkHttpClient client = new OkHttpClient.Builder()
				.connectTimeout(Constantes.TIMEOUT_LOGIN_CODIGO, TimeUnit.SECONDS)
				.writeTimeout(Constantes.TIMEOUT_LOGIN_CODIGO, TimeUnit.SECONDS)
				.readTimeout(Constantes.TIMEOUT_LOGIN_CODIGO, TimeUnit.SECONDS).build();
		final MediaType json = MediaType.parse(Constantes.TYPE_JSON);
		final RequestBody body = RequestBody.create(json, input);
		final Request request = new Request.Builder().url(getEndPoint("ENDPOINT_IHP_TOKEN_REST")).post(body).build();
		Response locResponse = null;
		JSONObject locJsonObject = null;
		ClienteUnidadePasseLivre clienteUnidade = null;
		try {
			locResponse = client.newCall(request).execute();
			final String locJsonData = locResponse.body().string();
			verificarSeEhUmCoteudoValido(locJsonData);
			locJsonObject = new JSONObject(locJsonData);
			clienteUnidade = gson.fromJson(locJsonObject.getJSONObject("user").toString(),
					ClienteUnidadePasseLivre.class);
			final String token = locJsonObject.getString("id");
			clienteUnidade.setId(token);
			setValueObject(clienteUnidade);
			return getValueObject();
		} catch (final Exception locExc) {
			if (clienteUnidade == null) {
				failed();
				if (locJsonObject != null) {
					mensagem = Util.retirarCaracterEspecial(locJsonObject.getString("error"));
				} else {
					mensagem = locExc.getMessage();
				}
				throw new RegraNegocioException(mensagem);
			}
			throw new RegraNegocioException(locExc.getMessage());
		} finally {
			if (locResponse != null) {
				locResponse.close();
			}
			if (client != null) {
				client.connectionPool().evictAll();
			}
		}
	}

	private void verificarSeEhUmCoteudoValido(final String parJsonData) throws IOException, RegraNegocioException {
		if (Util.verificarSeConteudoEhXML(parJsonData)) {
			failed();
			setResponseMessage(parJsonData);
			throw new RegraNegocioException(parJsonData);
		}
	}

	public void logarAd(final ParametroLogin parametroLogin) {
		final Gson gson = new Gson();
		final String input = gson.toJson(parametroLogin);
		final OkHttpClient client = new OkHttpClient.Builder()
				.connectTimeout(Constantes.TIMEOUT_FAZER_LOGIN, TimeUnit.SECONDS)
				.writeTimeout(Constantes.TIMEOUT_FAZER_LOGIN, TimeUnit.SECONDS)
				.readTimeout(Constantes.TIMEOUT_FAZER_LOGIN, TimeUnit.SECONDS).build();
		final MediaType json = MediaType.parse(Constantes.TYPE_JSON);
		final RequestBody body = RequestBody.create(json, input);
		final Request request = new Request.Builder().url(getEndPoint("ENDPOINT_IHP_AUTENTICACAO")).post(body).build();
		Response locResponse = null;
		JSONObject locJsonObject = null;
		final ObjectMapper mapper = new ObjectMapper();
		try {
			locResponse = client.newCall(request).execute();
			final String locJsonData = locResponse.body().string();
			verificarSeEhUmCoteudoValido(locJsonData);
			locJsonObject = new JSONObject(locJsonData);
			final ConsultaDadosAd result = gson.fromJson(locJsonObject.toString(), ConsultaDadosAd.class);
			setResponseMessage(result.getMensagem());
			if (result == null) {
				failed();
				setResponseMessage(result.getMensagem());
			} else {
				if ("0".equals(result.getStatus())) {
					setResponseObject(result);
				} else {
					failed();
					setResponseMessage(result.getMensagem());
				}
			}
		} catch (final Exception locExc) {
			failed();
			setResponseMessage(locExc.getMessage());
		} finally {
			if (locResponse != null) {
				locResponse.close();
			}
			if (client != null) {
				client.connectionPool().evictAll();
			}
		}
	}
}
