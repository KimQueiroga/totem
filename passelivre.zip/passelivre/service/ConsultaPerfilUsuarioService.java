package br.com.hermespardini.passelivre.service;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;
import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.model.Perfis;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.service.IhpMainService;
import okhttp3.Response;

public class ConsultaPerfilUsuarioService extends IhpMainService {

	public ConsultaPerfilUsuarioService(final HttpServletRequest parRequest) throws Exception {
		super(parRequest);
	}

	public void consultar(final String usuario) throws RegraNegocioException {
		Response response = null;
		try {
			final Gson gson = new Gson();
			JSONObject locJsonObject = new JSONObject();
			response = executeGet(getEndPoint("ENDPOINT_PERFIL_USUARIO") + "?login=" + usuario + "&aplicacao="
					+ Constantes.NOME_SISTEMA_DESKTOP);
			final String locJsonData = response.body().string();
			verificarSeEhUmCoteudoValido(locJsonData);
			locJsonObject = new JSONObject(locJsonData);
			if (response.isSuccessful()) {
				final Perfis result = gson.fromJson(locJsonObject.getJSONArray("listaPerfis").toString(),
						new TypeToken<Perfis>() {
						}.getType());
				if (result != null) {
					setResponseObject(result);
				} else {
					failed();
					setResponseMessage("Problema ao buscar informações do totem desktop!");
				}
			}
		} catch (final JSONException locExc) {
			failed();
		} catch (final Exception locExc) {
			failed();
			throw new RegraNegocioException(locExc.getMessage());
		} finally {
			if (response != null) {
				response.close();
			}
		}
	}

	private void verificarSeEhUmCoteudoValido(final String parJsonData) throws IOException, RegraNegocioException {
		if (Util.verificarSeConteudoEhXML(parJsonData)) {
			failed();
			setResponseMessage(parJsonData);
			throw new RegraNegocioException(parJsonData);
		}
	}
}
