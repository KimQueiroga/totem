package br.com.hermespardini.passelivre.service;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.exception.BiometriaDesativadaException;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.model.ConfirmaBiometriaResult;
import br.com.hermespardini.passelivre.model.ParametroConfirmaBiometria;
import br.com.hermespardini.passelivre.to.ParametroAplicacaoDto;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.service.IhpMainService;
import okhttp3.Credentials;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class ConfirmaBiometriaService extends IhpMainService {

	private String mensagem;

	public ConfirmaBiometriaService(HttpServletRequest parRequest) throws Exception {
		super(parRequest);
	}

	public ConfirmaBiometriaResult consultarBiometria(ParametroConfirmaBiometria parametroConfirmaBiometria) throws BiometriaDesativadaException {
		final Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
		final String input = gson.toJson(parametroConfirmaBiometria);
		final OkHttpClient client = new OkHttpClient.Builder()
				.connectTimeout(Constantes.TIMEOUT_ENGREGA_MATERIAL_PENDENTE, TimeUnit.SECONDS)
				.writeTimeout(Constantes.TIMEOUT_ENGREGA_MATERIAL_PENDENTE, TimeUnit.SECONDS)
				.readTimeout(Constantes.TIMEOUT_ENGREGA_MATERIAL_PENDENTE, TimeUnit.SECONDS).build();
		final MediaType json = MediaType.parse(Constantes.TYPE_JSON);
		final RequestBody body = RequestBody.create(json, input);
		Response locResponse = null;
		try {
			
			ParametroService parametroService = new ParametroService(super.getRequest());
			parametroService.buscarParametro(Constantes.CHAVE_BIOMETRIA_ATIVACAO);
			ParametroAplicacaoDto biometriaAtivada = (ParametroAplicacaoDto) parametroService.getResponseObject();
			
			if (biometriaAtivada != null && !Constantes.ATIVO.equals(biometriaAtivada.getValorAplicacao().getValor())) {
				throw new BiometriaDesativadaException("Biometria unimed desativada via parametro");
			}			
			
			parametroService.buscarParametro(Constantes.CHAVE_USER_UNIMED_CERTIFICACAO);
			ParametroAplicacaoDto usuario = (ParametroAplicacaoDto) parametroService.getResponseObject();
			parametroService.buscarParametro(Constantes.CHAVE_SENHA_UNIMED_CERTIFICACAO);
			ParametroAplicacaoDto senha = (ParametroAplicacaoDto) parametroService.getResponseObject();

			final Request request = new Request.Builder()
					.url(getEndPoint("ENDPOINT_UNIMED_CONSULTA_CERTIFICACAO")).addHeader("Authorization", Credentials
							.basic(usuario.getValorAplicacao().getValor(), senha.getValorAplicacao().getValor()))
					.post(body).build();
			JSONObject locJsonObject = new JSONObject();
			locResponse = client.newCall(request).execute();
			final String locJsonData = locResponse.body().string();
			verificarSeEhUmCoteudoValido(locJsonData);
			locJsonObject = new JSONObject(locJsonData);
			if (locResponse.isSuccessful()) {
				final ConfirmaBiometriaResult result = gson.fromJson(locJsonObject.toString(),
						ConfirmaBiometriaResult.class);
				mensagem = Util.retirarCaracterEspecial(result.getValidacaoBiometrica());
				setResponseMessage(mensagem);
				if (result != null) {
					setResponseObject(result);
					return result;
				}
			}
		} catch (BiometriaDesativadaException bioEx) {
			throw bioEx;
		} catch (final Exception locExc) {
			failed();
			setResponseMessage("Erro ao consultar certificação de biometria");
		} finally {
			if (locResponse != null) {
				locResponse.close();
			}
			if (client != null) {
				client.connectionPool().evictAll();
			}
		}
		return null;
	}

	private void verificarSeEhUmCoteudoValido(final String parJsonData) throws IOException, RegraNegocioException {
		if (Util.verificarSeConteudoEhXML(parJsonData)) {
			failed();
			setResponseMessage(parJsonData);
			throw new RegraNegocioException(parJsonData);
		}
	}

}
