package br.com.hermespardini.passelivre.service;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;

import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.utils.NomeComputadorLocalUtil;
import br.com.hermespardini.passelivre.utils.TotemUtil;

public class IndexService {
	private NomeComputadorLocalUtil nomeComputadorLocalUtil;

	public IndexService() {
		nomeComputadorLocalUtil = new NomeComputadorLocalUtil();
	}

	public String retornarNomeMaquina(final HttpServletRequest paramRequest) throws NamingException, Exception {
		final HttpServletRequest request = paramRequest;
		String nomeDaMaquina = TotemUtil.retornarNomeDaMaquina();
		if (nomeDaMaquina.contains(".")) {
			final int posicao = nomeDaMaquina.indexOf(".");
			if (nomeDaMaquina.substring(0, posicao).isEmpty()) {
				throw new RegraNegocioException("Erro ao retornar nome da máquina :" + " nome" + nomeDaMaquina);
			} else {
				nomeDaMaquina = nomeDaMaquina.substring(0, posicao);
			}
		}
		return nomeDaMaquina;
	}

}
