package br.com.hermespardini.passelivre.service;

import java.io.IOException;
import java.util.Objects;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONObject;

import com.google.gson.Gson;

import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.model.ParametroUsuarioToken;
import br.com.hermespardini.passelivre.model.TokenResult;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.service.IhpMainService;
import okhttp3.Response;

public class AutenticaService extends IhpMainService {

	public AutenticaService(final HttpServletRequest parRequest) throws Exception {
		super(parRequest);
	}

	public void gerarToken(final ParametroUsuarioToken parametroUsuarioToken) throws RegraNegocioException {
		Response response = null;
		try {
			final Gson gson = new Gson();
			JSONObject locJsonObject = new JSONObject();
			response = executePost(getEndPoint("ENDPOINT_IHP_AUTENTICA_TOKEN"), parametroUsuarioToken);
			final String locJsonData = response.body().string();
			verificarSeEhUmCoteudoValido(locJsonData);
			locJsonObject = new JSONObject(locJsonData);
			if (response.isSuccessful()) {
				final TokenResult result = gson.fromJson(locJsonObject.getJSONObject("TokenResult").toString(),
						TokenResult.class);
				if (result != null) {
					if (result.getStatus().equals("0")) {
						setResponseObject(result);
					} else {
						failed();
						setResponseMessage(result.getMensagem());
					}
				} else {
					failed();
					setResponseMessage(response.message());
				}
			}
		} catch (final Exception locExc) {
			failed();
			String msgErro = Optional.ofNullable(locExc.getMessage()).orElse("");
			String msgCause = (Objects.isNull(locExc.getCause()) ? "" : locExc.getCause().getMessage());
			if(!msgErro.equals("") && !msgCause.equals("")) {
				msgErro +=  " - ";
			}
			msgErro += msgCause;
			throw new RegraNegocioException(
					"Erro ao gerar token: " + msgErro);
		} finally {
			if (response != null) {
				response.close();
			}
		}
	}

	private void verificarSeEhUmCoteudoValido(final String paramJsonData) throws IOException, RegraNegocioException {
		if (Util.verificarSeConteudoEhXML(paramJsonData)) {
			failed();
			setResponseMessage(paramJsonData);
			throw new RegraNegocioException(paramJsonData);
		}
	}
}
