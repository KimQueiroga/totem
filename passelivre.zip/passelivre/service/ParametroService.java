package br.com.hermespardini.passelivre.service;

import java.io.IOException;
import javax.servlet.http.HttpServletRequest;

import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.to.ParametroAplicacaoDto;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.service.IhpMainService;
import okhttp3.Response;

public class ParametroService extends IhpMainService {

	public ParametroService(final HttpServletRequest parRequest) throws Exception {
		super(parRequest);
	}

	public void buscarParametro(String chave) throws RegraNegocioException {
		Response response = null;
		try {
			Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
			// final Gson gson = new Gson();
			JSONObject locJsonObject = new JSONObject();
			response = executePost(getEndPoint("ENDPOINT_IHP") + "/parametros/obter/" + chave, null);
			final String locJsonData = response.body().string();
			verificarSeEhUmCoteudoValido(locJsonData);
			locJsonObject = new JSONObject(locJsonData);
			if (response.isSuccessful()) {
				ParametroAplicacaoDto result = gson.fromJson(locJsonObject.toString(), ParametroAplicacaoDto.class);
				if (result != null) {
					setResponseObject(result);
				} else {
					failed();
					setResponseMessage(response.message());
				}
			}
		} catch (final Exception locExc) {
			failed();
			throw new RegraNegocioException(
					"Erro ao gerar token: " + locExc.getMessage() + " - " + locExc.getCause().getMessage());
		} finally {
			if (response != null) {
				response.close();
			}
		}
	}

	private void verificarSeEhUmCoteudoValido(final String parJsonData) throws IOException, RegraNegocioException {
		if (Util.verificarSeConteudoEhXML(parJsonData)) {
			failed();
			setResponseMessage(parJsonData);
			throw new RegraNegocioException(parJsonData);
		}
	}
}
