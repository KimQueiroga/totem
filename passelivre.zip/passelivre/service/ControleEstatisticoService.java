package br.com.hermespardini.passelivre.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.wdelmaschio.base.view.Service;

import br.com.hermespardini.passelivre.constantsenum.FuncaoLogEstatistico;
import br.com.hermespardini.passelivre.facade.ControleEstatisticoFacade;
import br.com.hermespardini.passelivre.model.ControleEstatistico;
import br.com.hermespardini.passelivre.to.ProcedimentoComExamesTO;

public class ControleEstatisticoService extends Service {

	public ControleEstatisticoService(final HttpServletRequest parRequest) throws Exception {
		super(ControleEstatistico.class, ControleEstatisticoFacade.class, parRequest);
	}

	public void insert(final ControleEstatistico controleEstatistico) {
		try {
			((ControleEstatisticoFacade) getFacade()).insert(controleEstatistico);
		} catch (final Exception locExc) {
			failed();
			setResponseMessage(locExc.getMessage());
		}
	}

	public String retornarDescricaoParaAtendimentoUnimed(
			final List<ProcedimentoComExamesTO> procedimentosComExamesParaGerarPedido) {
		if (isExisteExameDeImagem(procedimentosComExamesParaGerarPedido)) {
			return FuncaoLogEstatistico.REALIZAR_ATENDIMENTO_IMAGEM.toString();
		} else {
			return FuncaoLogEstatistico.REALIZAR_ATENDIMENTO.toString();
		}
	}

	private boolean isExisteExameDeImagem(
			final List<ProcedimentoComExamesTO> parProcedimentosComExamesParaGerarPedido) {
		try {
			for (final ProcedimentoComExamesTO locProcedimentoComExamesTO : parProcedimentosComExamesParaGerarPedido) {
				if (locProcedimentoComExamesTO.getExame().getMaterial().equals("VIVO")) {
					return true;
				}
			}
			return false;
		} catch (final Exception e) {
			return false;
		}
	}

}
