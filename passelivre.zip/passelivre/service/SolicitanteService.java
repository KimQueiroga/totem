package br.com.hermespardini.passelivre.service;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.model.ConsultaSolicitanteResult;
import br.com.hermespardini.passelivre.model.ParametroConsultaSolicitante;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.service.IhpMainService;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class SolicitanteService extends IhpMainService {

	private String mensagem;

	public SolicitanteService(final HttpServletRequest parRequest) throws Exception {
		super(parRequest);
	}

	public boolean verificaSolicitanteCadastrado(final ParametroConsultaSolicitante parametroConsultaSolicitante) {
		final Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
		final String input = gson.toJson(parametroConsultaSolicitante);
		final OkHttpClient client = new OkHttpClient.Builder()
				.connectTimeout(Constantes.TIMEOUT_ENGREGA_MATERIAL_PENDENTE, TimeUnit.SECONDS)
				.writeTimeout(Constantes.TIMEOUT_ENGREGA_MATERIAL_PENDENTE, TimeUnit.SECONDS)
				.readTimeout(Constantes.TIMEOUT_ENGREGA_MATERIAL_PENDENTE, TimeUnit.SECONDS).build();
		final MediaType json = MediaType.parse(Constantes.TYPE_JSON);
		final RequestBody body = RequestBody.create(json, input);
		final Request request = new Request.Builder().url(getEndPoint("ENDPOINT_CONSULTA_SOLICITANTE")).post(body)
				.build();
		Response locResponse = null;
		JSONObject locJsonObject = new JSONObject();
		try {
			locResponse = client.newCall(request).execute();
			final String locJsonData = locResponse.body().string();
			verificarSeEhUmCoteudoValido(locJsonData);
			locJsonObject = new JSONObject(locJsonData);
			if (locResponse.isSuccessful()) {
				final ConsultaSolicitanteResult result = gson.fromJson(
						locJsonObject.getJSONObject("ConsultaResult").toString(), ConsultaSolicitanteResult.class);
				mensagem = Util.retirarCaracterEspecial(result.getMensagem());
				setResponseMessage(mensagem);
				if (result.getProfissionais() != null && !result.getProfissionais().isEmpty()) {
					setResponseObject(result.getProfissionais());
					return true;
				} else {
					return false;
				}
			}
		} catch (final Exception locExc) {
			failed();
			setResponseMessage("Erro ao verificar solicitante cadastro");
		} finally {
			if (locResponse != null) {
				locResponse.close();
			}
			if (client != null) {
				client.connectionPool().evictAll();
			}
		}
		return false;
	}

	private void verificarSeEhUmCoteudoValido(final String parJsonData) throws IOException, RegraNegocioException {
		if (Util.verificarSeConteudoEhXML(parJsonData)) {
			failed();
			setResponseMessage(parJsonData);
			throw new RegraNegocioException(parJsonData);
		}
	}

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(final String parMensagem) {
		mensagem = parMensagem;
	}

}
