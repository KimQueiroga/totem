package br.com.hermespardini.passelivre.service;

import java.io.InputStream;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.wdelmaschio.base.view.Service;

import br.com.hermespardini.passelivre.model.ParametroOrcamento;
import br.com.hermespardini.passelivre.utils.DataUtil;
import br.com.hermespardini.passelivre.utils.RelatorioPDF;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

public class OrcamentoService extends Service {

	private DataUtil dataUtil = new DataUtil();

	public OrcamentoService(final HttpServletRequest parRequest) throws Exception {
		super(parRequest);
	}

	public InputStream gerarRelatorio(final ParametroOrcamento parParametroOrcamento,
			final ServletContext parServletContext, final String parPathArquivoReport) throws Exception {
		try {
			final Map<String, Object> informacoesRelatorio = new HashMap<String, Object>();
			Collections.sort(parParametroOrcamento.getExames());
			informacoesRelatorio.put("unidade", parParametroOrcamento.getUnidade());
			informacoesRelatorio.put("total", parParametroOrcamento.getTotal());
			informacoesRelatorio.put("origem", parParametroOrcamento.getOrigem());
			informacoesRelatorio.put("path", parServletContext.getRealPath("/WEB-INF/relatorio/image"));
			informacoesRelatorio.put("SUBREPORT_DIR", parServletContext.getRealPath("/WEB-INF/relatorio/"));
			informacoesRelatorio.put("DATA", new JRBeanCollectionDataSource(parParametroOrcamento.getExames()));
			return new RelatorioPDF("Orcamento", informacoesRelatorio, parPathArquivoReport,
					parParametroOrcamento.getExames()).retornarRelatorio();
		} catch (final Exception exc) {
			throw new Exception(exc.getMessage());
		}
	}
}
