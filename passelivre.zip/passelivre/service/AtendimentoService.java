package br.com.hermespardini.passelivre.service;

import java.math.BigInteger;
import java.rmi.RemoteException;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.wdelmaschio.base.view.Service;

import br.com.hermespardini.commons.texto.TextoUtils;
import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.utils.DataUtil;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.service.IhpMainService;
import br.com.unimedbh.www.Ct_dadosAutorizacao;
import br.com.unimedbh.www.DestinatarioInvalido;
import br.com.unimedbh.www.HashInvalido;
import br.com.unimedbh.www.RemetenteInvalido;
import br.com.unimedbh.www.VersaoInvalida;
import br.com.unimedbh.www.schemas.CabecalhoTransacao;
import br.com.unimedbh.www.schemas.CabecalhoTransacaoDestino;
import br.com.unimedbh.www.schemas.Ct_comunicaAtendimento;
import br.com.unimedbh.www.schemas.St_tipoTransacao;
import br.com.unimedbh.www.ws.tipos.UnimedbhConfirmaAtendimento_PortTypeProxy;
import br.com.unimedbh.www.ws.tipos.Ws_confirmaAtendimento;
import br.com.unimedbh.www.ws.tipos.Ws_respostaComunicacao;
import br.gov.ans.www.padroes.tiss.schemas.Ct_contratado;
import br.gov.ans.www.padroes.tiss.schemas.Ct_identificacaoPrestadorExecutante;

public class AtendimentoService extends IhpMainService {
	private Util util = new Util();
	private DataUtil dataUtil = new DataUtil();

	public AtendimentoService(final HttpServletRequest parRequest) throws Exception {
		super(parRequest);
	}

	// public Ws_respostaComunicacao confirmarAtendimento(final
	// List<Ct_dadosAutorizacao>
	// guiasAutorizadasSelecionadas,
	// final String localAtendimento,
	// final String tipoLocalAtendimento)
	// throws HashInvalido, RemetenteInvalido, VersaoInvalida, DestinatarioInvalido,
	// RemoteException,
	// ParseException, RegraNegocioException {
	//
	// final UnimedbhConfirmaAtendimento_PortTypeProxy proxy =
	// criarProxConfirmacao();
	// return proxy.unimedbhConfirmaAtendimento_Operation(
	// adicionarValoresAoPedido(guiasAutorizadasSelecionadas, localAtendimento,
	// tipoLocalAtendimento));
	// }

	public Ws_respostaComunicacao confirmarAtendimento(final Ct_dadosAutorizacao guiaAutorizadaSelecionada,
			final String localAtendimento, final String tipoLocalAtendimento) throws HashInvalido, RemetenteInvalido,
			VersaoInvalida, DestinatarioInvalido, RemoteException, ParseException, RegraNegocioException {

		final UnimedbhConfirmaAtendimento_PortTypeProxy proxy = criarProxConfirmacao();
		return proxy.unimedbhConfirmaAtendimento_Operation(
				adicionarValoresAoPedido(guiaAutorizadaSelecionada, localAtendimento, tipoLocalAtendimento));
	}

	private UnimedbhConfirmaAtendimento_PortTypeProxy criarProxConfirmacao() {
		return new UnimedbhConfirmaAtendimento_PortTypeProxy(
				getEndPoint("ENDPOINT_SERVICE_UNIMED") + "/ws-ConfirmaAtendimento");
	}

	// public Ws_confirmaAtendimento adicionarValoresAoPedido(
	// final List<Ct_dadosAutorizacao> guiasAutorizadasSelecionadas, final String
	// localAtendimento,
	// final String tipoLocalAtendimento) throws ParseException {
	//
	// final CabecalhoTransacao cabecalho = montarCabecalhoTransacao();
	// final Ct_comunicaAtendimento[] comunicaAtendimento =
	// montarComunicaAtendimento(guiasAutorizadasSelecionadas, localAtendimento,
	// tipoLocalAtendimento);
	//
	// final Ws_confirmaAtendimento wsConfirmaAtendimento = new
	// Ws_confirmaAtendimento();
	// wsConfirmaAtendimento.setCabecalho(cabecalho);
	// wsConfirmaAtendimento.setComunicaAtendimento(comunicaAtendimento);
	// final String valorDeClasse = retornarValor(wsConfirmaAtendimento);
	// wsConfirmaAtendimento.setHash(TextoUtils.gerarHashDoTexto(valorDeClasse));
	// // wsConfirmaAtendimento.setHash("8f02a62f43bc41ff448380d0af8b46d3");
	// return wsConfirmaAtendimento;
	// }

	public Ws_confirmaAtendimento adicionarValoresAoPedido(final Ct_dadosAutorizacao guiaAutorizadaSelecionada,
			final String localAtendimento, final String tipoLocalAtendimento) throws ParseException {

		final CabecalhoTransacao cabecalho = montarCabecalhoTransacao();
		final Ct_comunicaAtendimento[] comunicaAtendimento = montarComunicaAtendimento(guiaAutorizadaSelecionada,
				localAtendimento, tipoLocalAtendimento);

		final Ws_confirmaAtendimento wsConfirmaAtendimento = new Ws_confirmaAtendimento();
		wsConfirmaAtendimento.setCabecalho(cabecalho);
		wsConfirmaAtendimento.setComunicaAtendimento(comunicaAtendimento);
		final String valorDeClasse = retornarValor(wsConfirmaAtendimento);
		wsConfirmaAtendimento.setHash(TextoUtils.gerarHashDoTexto(valorDeClasse));
		// wsConfirmaAtendimento.setHash("8f02a62f43bc41ff448380d0af8b46d3");
		return wsConfirmaAtendimento;
	}

	private String retornarValor(final Ws_confirmaAtendimento parWsConfirmaAtendimento) {
		final StringBuilder sb = new StringBuilder();
		sb.append(parWsConfirmaAtendimento.getCabecalho().getIdentificacaoTransacao().getTipoTransacao())
				.append(parWsConfirmaAtendimento.getCabecalho().getIdentificacaoTransacao().getSequencialTransacao())
				.append(dataUtil.formatarDateParaString(
						parWsConfirmaAtendimento.getCabecalho().getIdentificacaoTransacao().getDataRegistroTransacao()))
				.append(parWsConfirmaAtendimento.getCabecalho().getIdentificacaoTransacao().getHoraRegistroTransacao())
				.append(parWsConfirmaAtendimento.getCabecalho().getOrigem().getCodigoPrestadorNaOperadora()
						.getCodigoPrestadorNaOperadora())
				.append(retornarVazioSeForNulo(parWsConfirmaAtendimento.getCabecalho().getOrigem().getRegistroANS()))
				.append(parWsConfirmaAtendimento.getCabecalho().getDestino().getRegistroANS())
				.append(parWsConfirmaAtendimento.getCabecalho().getVersaoPadrao());
		for (final Ct_comunicaAtendimento ct_comunicaAtendimento : parWsConfirmaAtendimento.getComunicaAtendimento()) {
			sb.append(ct_comunicaAtendimento.getDadosBeneficiario().getNumeroCarteira())
					.append(retornarVazioSeForNulo(ct_comunicaAtendimento.getDadosBeneficiario().getValidadeCarteira()))
					.append(ct_comunicaAtendimento.getDadosExecutante().getIdentificacao()
							.getCodigoPrestadorNaOperadora())
					.append(ct_comunicaAtendimento.getLocalAtendimento())
					.append(ct_comunicaAtendimento.getTipoLocalAtendimento())
					.append(ct_comunicaAtendimento.getDadosAutorizacao().getDataAutorizacao())
					.append(ct_comunicaAtendimento.getDadosAutorizacao().getSenhaAutorizacao())
					.append(ct_comunicaAtendimento.getDadosAutorizacao().getValidadeSenha());
		}
		return sb.toString();
	}

	private Object retornarVazioSeForNulo(final String varValorASerVerificado) {
		if (varValorASerVerificado == null) {
			return "";
		} else {
			return varValorASerVerificado;
		}
	}

	// private Ct_comunicaAtendimento[] montarComunicaAtendimento(
	// final List<Ct_dadosAutorizacao> parGuiasAutorizadasSelecionadas, final String
	// parLocalAtendimento,
	// final String parTipoLocalAtendimento) {
	//
	// int index = 0;
	// final Ct_comunicaAtendimento[] ct_comunicaAtendimentos =
	// new Ct_comunicaAtendimento[parGuiasAutorizadasSelecionadas.size()];
	// for (final Ct_dadosAutorizacao ct_dadosAutorizacao :
	// parGuiasAutorizadasSelecionadas) {
	//
	// final Ct_comunicaAtendimento ct_comunicaAtendimento = new
	// Ct_comunicaAtendimento();
	// ct_comunicaAtendimento.setDadosAutorizacao(ct_dadosAutorizacao.getDadosAutorizacao());
	// ct_comunicaAtendimento.setDadosBeneficiario(ct_dadosAutorizacao.getBeneficiario());
	// ct_comunicaAtendimento.setDadosExecutante(montarDadosExecutante());
	// ct_comunicaAtendimento.setLocalAtendimento(parLocalAtendimento);
	// ct_comunicaAtendimento.setTipoLocalAtendimento(parTipoLocalAtendimento);
	// ct_comunicaAtendimentos[index] = ct_comunicaAtendimento;
	// index += 1;
	// }
	// return ct_comunicaAtendimentos;
	// }

	private Ct_comunicaAtendimento[] montarComunicaAtendimento(final Ct_dadosAutorizacao parGuiaAutorizadaSelecionada,
			final String parLocalAtendimento, final String parTipoLocalAtendimento) {

		int index = 0;
		final Ct_comunicaAtendimento[] ct_comunicaAtendimentos = new Ct_comunicaAtendimento[1];

		final Ct_comunicaAtendimento ct_comunicaAtendimento = new Ct_comunicaAtendimento();
		ct_comunicaAtendimento.setDadosAutorizacao(parGuiaAutorizadaSelecionada.getDadosAutorizacao());
		ct_comunicaAtendimento.setDadosBeneficiario(parGuiaAutorizadaSelecionada.getBeneficiario());
		ct_comunicaAtendimento.setDadosExecutante(montarDadosExecutante());
		ct_comunicaAtendimento.setLocalAtendimento(parLocalAtendimento);
		ct_comunicaAtendimento.setTipoLocalAtendimento(parTipoLocalAtendimento);
		ct_comunicaAtendimentos[index] = ct_comunicaAtendimento;
		index += 1;
		return ct_comunicaAtendimentos;
	}

	private Ct_contratado montarDadosExecutante() {
		final Ct_contratado ct_contratado = new Ct_contratado();
		ct_contratado.setEnderecoContratado(null);
		ct_contratado.setIdentificacao(new Ct_identificacaoPrestadorExecutante(null, null,
				getRequest().getSession().getAttribute("codigoPrestadorUnimed").toString()));
		ct_contratado.setNomeContratado("");
		ct_contratado.setNumeroCNES("");
		return ct_contratado;
	}

	private CabecalhoTransacao montarCabecalhoTransacao() {
		final java.util.Date dataRegistroTransacao = retornarDataCorrente();

		final BigInteger squencialTransacao = new BigInteger("1");

		final org.apache.axis.types.Time horaRegistroTransacao = new org.apache.axis.types.Time(
				Constantes.HORARIO_DEFAULT);

		final br.com.unimedbh.www.schemas.CabecalhoTransacaoIdentificacaoTransacao identificacaoTransacao = new br.com.unimedbh.www.schemas.CabecalhoTransacaoIdentificacaoTransacao(
				St_tipoTransacao.SOLIC_SITUACAO_COBERTURA, squencialTransacao, dataRegistroTransacao,
				horaRegistroTransacao);

		final br.com.unimedbh.www.schemas.CabecalhoTransacaoOrigem origem = new br.com.unimedbh.www.schemas.CabecalhoTransacaoOrigem();

		final br.gov.ans.www.padroes.tiss.schemas.Ct_identificacaoPrestadorExecutante ct_identificacaoPrestadorExecutante = new br.gov.ans.www.padroes.tiss.schemas.Ct_identificacaoPrestadorExecutante(
				null, null, getRequest().getSession().getAttribute("codigoPrestadorUnimed").toString());

		origem.setCodigoPrestadorNaOperadora(ct_identificacaoPrestadorExecutante);

		final br.gov.ans.www.padroes.tiss.schemas.Ct_identificacaoSoftwareGerador ct_identificacaoSoftwareGerador = new br.gov.ans.www.padroes.tiss.schemas.Ct_identificacaoSoftwareGerador(
				"", "", "");

		final CabecalhoTransacaoDestino destino = new CabecalhoTransacaoDestino(null, Constantes.REGISTRO_ANS, null);

		final br.com.unimedbh.www.schemas.CabecalhoTransacao cabecalho = new br.com.unimedbh.www.schemas.CabecalhoTransacao(
				identificacaoTransacao, null, origem, destino, Constantes.VERSAO_DEFAULT,
				ct_identificacaoSoftwareGerador);

		return cabecalho;
	}

	private Date retornarDataCorrente() {
		final Calendar dataAtual = Calendar.getInstance();
		dataAtual.setTime(new Date());
		dataAtual.set(Calendar.HOUR_OF_DAY, 10);
		dataAtual.set(Calendar.MINUTE, 0);
		dataAtual.set(Calendar.SECOND, 0);
		dataAtual.set(Calendar.MONTH, 6);
		dataAtual.set(Calendar.MILLISECOND, 0);

		return dataAtual.getTime();
	}

}
