package br.com.hermespardini.passelivre.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.wdelmaschio.base.view.Service;

import br.com.hermespardini.corebusiness.util.EmailCore;
import br.com.hermespardini.corebusiness.util.SendEmailCore;
import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.exception.EnvioEmailException;
import br.com.hermespardini.passelivre.model.ClienteUnidadePasseLivre;
import br.com.hermespardini.passelivre.model.ExameMaterialPendente;
import br.com.hermespardini.passelivre.model.ExameResultadoPedido;
import br.com.hermespardini.passelivre.model.ExamesResultadosPedido;
import br.com.hermespardini.passelivre.utils.DataUtil;
import br.com.hermespardini.passelivre.utils.GerarModelo;
import br.com.hermespardini.passelivre.utils.TotemUtil;

public class EnviaEmailService extends Service {

	private DataUtil dataUtil;

	public EnviaEmailService(final HttpServletRequest parRequest) throws Exception {
		super(parRequest);
		setDataUtil(new DataUtil());
	}

	public void enviarEmailEntregarMaterial(final ClienteUnidadePasseLivre clienteUnidadePasseLivre,
			final List<ExameMaterialPendente> listaExameMaterialPendenteSelecionados, final String unidade,
			final boolean parAmbienteProducao) throws EnvioEmailException {
		try {
			if (clientePossuiEmail(clienteUnidadePasseLivre)) {
				if (parAmbienteProducao || isEmailPardini(clienteUnidadePasseLivre.getEmail())) {
					final EmailCore emailCore = new EmailCore();
					emailCore.setDestinatario(clienteUnidadePasseLivre.getEmail());
					if (TotemUtil.buscarIdEmpresa().equalsIgnoreCase("8")) {
						emailCore.setRemetente(Constantes.REMETENTE_PADRAO);
						emailCore.setMensagem(new GerarModelo("montarMensagemParaEntregarMaterialPadrao.vm",
								clienteUnidadePasseLivre, listaExameMaterialPendenteSelecionados).gerarModeloEmail());
					} else if (TotemUtil.buscarIdEmpresa().equalsIgnoreCase("18")) {
						emailCore.setRemetente(Constantes.REMETENTE_ECOAR);
						emailCore.setMensagem(new GerarModelo("montarMensagemParaEntregarMaterial.vm",
								clienteUnidadePasseLivre, listaExameMaterialPendenteSelecionados).gerarModeloEmail());
					} else {
						emailCore.setRemetente(Constantes.REMETENTE_PARDINI);
						emailCore.setMensagem(new GerarModelo("montarMensagemParaEntregarMaterial.vm",
								clienteUnidadePasseLivre, listaExameMaterialPendenteSelecionados).gerarModeloEmail());
					}
					clienteUnidadePasseLivre.setUnidade(unidade);
					for (final ExameMaterialPendente locExameMaterialPendente : listaExameMaterialPendenteSelecionados) {
						locExameMaterialPendente.setDataColeta(
								getDataUtil().formatarStringParaStringBR(locExameMaterialPendente.getDataColeta()));
						getDataUtil().formatarTimeStampParaDate(locExameMaterialPendente.getMarcacao());
					}

					emailCore.setAssunto(
							"Recibo de entrega de material pendente - " + " " + retornarAmbiente(parAmbienteProducao));
					SendEmailCore.sendEmail(emailCore);
				} else {
					throw new EnvioEmailException("Homologação: e-mail não enviado!");
				}
			}
		} catch (final Exception loex) {
			throw new EnvioEmailException(
					"Erro ao Enviar o Email! " + " Destinatário: " + clienteUnidadePasseLivre.getEmail());
		}
	}

	private boolean clientePossuiEmail(ClienteUnidadePasseLivre cliente) {
		return (cliente != null && cliente.getEmail() != null && !cliente.getEmail().isEmpty());
	}

	private String retornarAmbiente(final boolean parAmbienteProducao) {
		if (parAmbienteProducao) {
			return "";
		} else {
			return "[HOMOLOGAÇÃO]";
		}
	}

	/**
	 * Verifica se está em ambiente de produção ou se o email do destinatário é
	 * do grupo Pardini antes de enviar o e-mail.
	 *
	 * @param clienteUnidadePasseLivre
	 * @param examesResultadosPedido
	 * @param parAmbienteProducao
	 * @throws EnvioEmailException
	 */
	public void enviarEmailFinalizarPedido(final ClienteUnidadePasseLivre clienteUnidadePasseLivre,
			final ExamesResultadosPedido examesResultadosPedido, final boolean parAmbienteProducao, boolean ecoar)
			throws EnvioEmailException {

		try {
			if (clientePossuiEmail(clienteUnidadePasseLivre)) {
				if (parAmbienteProducao || isEmailPardini(clienteUnidadePasseLivre.getEmail())) {
					final EmailCore emailCore = new EmailCore();
					emailCore.setDestinatario(clienteUnidadePasseLivre.getEmail());
					if (ecoar) {
						emailCore.setRemetente(Constantes.REMETENTE_ECOAR);
					} else {
						emailCore.setRemetente(Constantes.REMETENTE_PARDINI);
					}
					for (final ExameResultadoPedido locExameResultadoPedido : examesResultadosPedido) {
						if (locExameResultadoPedido.getDataHoraMarcacao() != null) {
							locExameResultadoPedido.setDataHoraMarcacao(getDataUtil()
									.formatarStringParaStringBRComHora(locExameResultadoPedido.getDataHoraMarcacao()));
						}
					}
					if (ecoar) {
						emailCore.setMensagem(new GerarModelo("montarMensagemParaFinalizacaoPedidoEcoar.vm",
								clienteUnidadePasseLivre, examesResultadosPedido).gerarModeloEmail());
					} else {
						emailCore.setMensagem(new GerarModelo("montarMensagemParaFinalizacaoPedido.vm",
								clienteUnidadePasseLivre, examesResultadosPedido).gerarModeloEmail());
					}
					emailCore.setAssunto("Recibo de pedidos" + " " + retornarAmbiente(parAmbienteProducao));
					SendEmailCore.sendEmail(emailCore);
				} else {
					throw new EnvioEmailException("Homologação: e-mail não enviado!");
				}
			}
		} catch (final Exception loex) {
			throw new EnvioEmailException("Erro ao Enviar o Email! Destinatário: " + clienteUnidadePasseLivre.getEmail()
					+ " Erro: " + loex.getMessage());
		}

	}

	public boolean isEmailPardini(final String email) {
		return email.contains("@grupopardini.com.br") || email.contains("@hermespardini.com.br");
	}

	public DataUtil getDataUtil() {
		return dataUtil;
	}

	public void setDataUtil(final DataUtil parDataUtil) {
		dataUtil = parDataUtil;
	}

}
