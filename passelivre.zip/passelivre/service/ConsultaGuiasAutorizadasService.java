package br.com.hermespardini.passelivre.service;

import java.math.BigInteger;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.wdelmaschio.base.view.Service;

import br.com.hermespardini.commons.texto.TextoUtils;
import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.utils.DataUtil;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.service.IhpMainService;
import br.com.unimedbh.www.Ct_dadosAutorizacao;
import br.com.unimedbh.www.Ws_consultaSolicitacoes;
import br.com.unimedbh.www.Ws_situacaoAutorizacao;
import br.com.unimedbh.www.schemas.St_tipoTransacao;
import br.gov.ans.www.padroes.tiss.schemas.Ct_beneficiario;

public class ConsultaGuiasAutorizadasService extends IhpMainService {
	private Util util = new Util();
	private DataUtil dataUtil = new DataUtil();

	public ConsultaGuiasAutorizadasService(final HttpServletRequest request) throws Exception {
		super(request);
	}

	public Ws_situacaoAutorizacao buscarGuiasAutorizadas(final Ct_beneficiario parBeneficiario) throws Exception {
		br.com.unimedbh.www.UnimedbhConsultaSolicitacoes_PortTypeProxy proxy = criarProxParaConsulta();
		Ws_situacaoAutorizacao wsSituacao = new Ws_situacaoAutorizacao();
		wsSituacao = proxy.unimedbhConsultaSolicitacoes_Operation(adicionarValoresAConsulta(parBeneficiario));
		proxy = null;
		return wsSituacao;
	}

	private br.com.unimedbh.www.UnimedbhConsultaSolicitacoes_PortTypeProxy criarProxParaConsulta() throws Exception {
		try {
			return new br.com.unimedbh.www.UnimedbhConsultaSolicitacoes_PortTypeProxy(
					getEndPoint("ENDPOINT_SERVICE_UNIMED") + "/ws-ConsultaSolicitacoes");
		} catch (final Exception locExc) {
			throw new Exception(locExc.getMessage());
		}
	}

	private Ws_consultaSolicitacoes adicionarValoresAConsulta(final Ct_beneficiario parBeneficiario) throws Exception {
		try {
			final br.com.unimedbh.www.schemas.CabecalhoTransacao cabecalho = montarCabecalhoTransacao();

			final br.com.unimedbh.www.schemas.Ct_consultaSolicitacoesDisponiveis consultaSolicitacoesDisponiveis = montarConsultaSolicitacaDisponiveis(
					parBeneficiario);

			final br.com.unimedbh.www.Ws_consultaSolicitacoes wsConsulta = new Ws_consultaSolicitacoes();

			wsConsulta.setCabecalho(cabecalho);

			wsConsulta.setConsultaSolicitacoesDisponiveis(consultaSolicitacoesDisponiveis);

			final String valorDeClasse = retornarValor(wsConsulta);
			wsConsulta.setHash(TextoUtils.gerarHashDoTexto(valorDeClasse));

			return wsConsulta;
		} catch (final Exception locExc) {
			throw new Exception(locExc.getMessage());
		}
	}

	private br.com.unimedbh.www.schemas.Ct_consultaSolicitacoesDisponiveis montarConsultaSolicitacaDisponiveis(
			final Ct_beneficiario parBeneficiario) {

		final br.com.unimedbh.www.schemas.Ct_identificacaoSolicitacao identificacaoSolicitacao = new br.com.unimedbh.www.schemas.Ct_identificacaoSolicitacao();

		final br.gov.ans.www.padroes.tiss.schemas.Ct_beneficiario identificacaoBeneficiario = parBeneficiario;

		final br.gov.ans.www.padroes.tiss.schemas.Ct_identificacaoPrestador identificacao = new br.gov.ans.www.padroes.tiss.schemas.Ct_identificacaoPrestador(
				null, null, getRequest().getSession().getAttribute("codigoPrestadorUnimed").toString(), null);

		final br.gov.ans.www.padroes.tiss.schemas.Ct_contratadoSolicitante profissionalSolicitante = new br.gov.ans.www.padroes.tiss.schemas.Ct_contratadoSolicitante(
				identificacao, "", null, null);

		return new br.com.unimedbh.www.schemas.Ct_consultaSolicitacoesDisponiveis(identificacaoSolicitacao,
				identificacaoBeneficiario, profissionalSolicitante);
	}

	private br.com.unimedbh.www.schemas.CabecalhoTransacao montarCabecalhoTransacao() throws ParseException {

		final java.util.Date dataRegistroTransacao = retornarDataCorrente();

		final BigInteger squencialTransacao = new BigInteger("1");

		final org.apache.axis.types.Time horaRegistroTransacao = new org.apache.axis.types.Time(
				Constantes.HORARIO_DEFAULT);

		final br.com.unimedbh.www.schemas.CabecalhoTransacaoIdentificacaoTransacao identificacaoTransacao = new br.com.unimedbh.www.schemas.CabecalhoTransacaoIdentificacaoTransacao(
				St_tipoTransacao.SOLIC_CONFIRMACAO_ATENDIMENTO, squencialTransacao, dataRegistroTransacao,
				horaRegistroTransacao);

		final br.com.unimedbh.www.schemas.CabecalhoTransacaoOrigem origem = new br.com.unimedbh.www.schemas.CabecalhoTransacaoOrigem();

		final br.gov.ans.www.padroes.tiss.schemas.Ct_identificacaoPrestadorExecutante ct_identificacaoPrestadorExecutante = new br.gov.ans.www.padroes.tiss.schemas.Ct_identificacaoPrestadorExecutante(
				null, null, getRequest().getSession().getAttribute("codigoPrestadorUnimed").toString());

		origem.setCodigoPrestadorNaOperadora(ct_identificacaoPrestadorExecutante);

		final br.gov.ans.www.padroes.tiss.schemas.Ct_identificacaoSoftwareGerador ct_identificacaoSoftwareGerador = new br.gov.ans.www.padroes.tiss.schemas.Ct_identificacaoSoftwareGerador(
				"", "", "");

		final br.com.unimedbh.www.schemas.CabecalhoTransacaoDestino destino = new br.com.unimedbh.www.schemas.CabecalhoTransacaoDestino(
				null, Constantes.REGISTRO_ANS, null);

		final br.com.unimedbh.www.schemas.CabecalhoTransacao cabecalho = new br.com.unimedbh.www.schemas.CabecalhoTransacao(
				identificacaoTransacao, null, origem, destino, Constantes.VERSAO_DEFAULT,
				ct_identificacaoSoftwareGerador);

		return cabecalho;
	}

	private String retornarValor(final Ws_consultaSolicitacoes parWsConsulta) {
		final StringBuilder sb = new StringBuilder();
		sb.append(parWsConsulta.getCabecalho().getIdentificacaoTransacao().getTipoTransacao())
				.append(parWsConsulta.getCabecalho().getIdentificacaoTransacao().getSequencialTransacao())
				.append(dataUtil.formatarDateParaString(
						parWsConsulta.getCabecalho().getIdentificacaoTransacao().getDataRegistroTransacao()))
				.append(parWsConsulta.getCabecalho().getIdentificacaoTransacao().getHoraRegistroTransacao())
				.append(parWsConsulta.getCabecalho().getOrigem().getCodigoPrestadorNaOperadora()
						.getCodigoPrestadorNaOperadora())
				.append(parWsConsulta.getCabecalho().getDestino().getRegistroANS())
				.append(parWsConsulta.getCabecalho().getVersaoPadrao())
				.append(parWsConsulta.getConsultaSolicitacoesDisponiveis().getIdentificacaoBeneficiario()
						.getNumeroCarteira())
				.append(parWsConsulta.getConsultaSolicitacoesDisponiveis().getProfissionalSolicitante()
						.getIdentificacao().getCodigoPrestadorNaOperadora());
		return sb.toString();
	}

	private java.util.Date retornarDataCorrente() {
		final Calendar dataAtual = Calendar.getInstance();
		dataAtual.setTime(new Date());
		dataAtual.set(Calendar.HOUR_OF_DAY, 10);
		dataAtual.set(Calendar.MINUTE, 0);
		dataAtual.set(Calendar.SECOND, 0);
		dataAtual.set(Calendar.MONTH, 6);

		return dataAtual.getTime();
	}

	public String retornarSolicitante(final Ct_dadosAutorizacao parCt_dadosAutorizacao) {
		final StringBuilder sb = new StringBuilder();
		sb.append(parCt_dadosAutorizacao.getSolicitante().getNomeSolicitante());
		sb.append("(");
		sb.append(parCt_dadosAutorizacao.getSolicitante().getSiglaConselho());
		sb.append("-");
		sb.append(parCt_dadosAutorizacao.getSolicitante().getUfConselho());
		sb.append(": ");
		sb.append(parCt_dadosAutorizacao.getSolicitante().getNumeroConselho());
		sb.append(")");
		return sb.toString();
	}

}
