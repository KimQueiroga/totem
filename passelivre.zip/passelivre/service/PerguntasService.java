package br.com.hermespardini.passelivre.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import br.com.hermespardini.passelivre.model.ConsultaQuestionarioExameResult;
import br.com.hermespardini.passelivre.model.Pergunta;
import br.com.hermespardini.passelivre.model.Questionario;
import br.com.hermespardini.passelivre.to.PerguntaComExameTO;

public class PerguntasService {

	private static final int TAMANHO_LIMITE_PERGUNTAS_POR_ABA = 12;
	private static final String PERMITE_CONSOLIDACAO = "S";

	public Map<String, List<PerguntaComExameTO>> agruparPerguntasPorAba(
			final List<ConsultaQuestionarioExameResult> questionariosExamesResult) throws Exception {
		String aba;
		final List<PerguntaComExameTO> pertuntasTemp = new ArrayList<>();
		final Map<String, List<PerguntaComExameTO>> peguntasComExameTO = new HashMap<>();
		for (final ConsultaQuestionarioExameResult locQuestionarioExameResult : questionariosExamesResult) {
			for (final Questionario questionario : locQuestionarioExameResult.getQuestionarios()) {
				verificarSeQuestionarioEstaRepetido(pertuntasTemp, questionario);
				for (final Pergunta pergunta : questionario.getPerguntas().listarPerguntasConsolidadas()) {
					if (limitesDePerguntasPorAbasFoiAtingido(pertuntasTemp)) {
						pertuntasTemp.add(new PerguntaComExameTO(locQuestionarioExameResult, questionario, pergunta));
						aba = retornarKeyPerguntas(locQuestionarioExameResult, questionario);
						peguntasComExameTO.put(aba,
								adicionarPerguntasComExame(locQuestionarioExameResult, questionario, pergunta,
										peguntasComExameTO
												.get(retornarKeyPerguntas(locQuestionarioExameResult, questionario))));
					} else {
						aba = retornarKeyPerguntasComAcrescimo(locQuestionarioExameResult, pergunta);
						peguntasComExameTO.put(aba, adicionarPerguntasComExame(locQuestionarioExameResult, questionario,
								pergunta, peguntasComExameTO.get(aba)));
					}
				}
			}
		}
		return peguntasComExameTO;
	}

	private void verificarSeQuestionarioEstaRepetido(final List<PerguntaComExameTO> pertuntasTemp,
			final Questionario questionario) {
		if (pertuntasTemp.size() > 0) {
			if (!questionario.getCodigoQuestionario().equals(pertuntasTemp.get(0).getCodigoQuestionario())) {
				pertuntasTemp.clear();
			}
		}
	}

	private boolean limitesDePerguntasPorAbasFoiAtingido(final List<PerguntaComExameTO> pertuntasTemp) {
		return pertuntasTemp.size() <= PerguntasService.TAMANHO_LIMITE_PERGUNTAS_POR_ABA;
	}

	private String retornarKeyPerguntas(final ConsultaQuestionarioExameResult parQuestionarioExameResult,
			final Questionario parQuestionario) {
		return parQuestionarioExameResult.getExame() + "_" + parQuestionario.getCodigoQuestionario();
	}

	private List<PerguntaComExameTO> adicionarPerguntasComExame(
			final ConsultaQuestionarioExameResult parQuestionarioExameResult, final Questionario questionario,
			final Pergunta parPergunta, List<PerguntaComExameTO> parPerguntasComExameTO) {

		final PerguntaComExameTO perguntaComExameTO = new PerguntaComExameTO(parQuestionarioExameResult, questionario,
				parPergunta);
		if (parPerguntasComExameTO == null) {
			parPerguntasComExameTO = new ArrayList<>();
		}
		parPerguntasComExameTO.add(perguntaComExameTO);
		return parPerguntasComExameTO;
	}

	private String retornarKeyPerguntasComAcrescimo(final ConsultaQuestionarioExameResult parQuestionarioExameResult,
			final Pergunta pergunta) {
		return parQuestionarioExameResult.getExame() + 1;
	}

	public Map<String, List<PerguntaComExameTO>> filtrarPerguntasConsolidadas(
			final Map<String, List<PerguntaComExameTO>> parTodasPerguntasAgrupadas) {
		final Map<String, List<PerguntaComExameTO>> todasPerguntasAgrupadasEConsolidadas = new HashMap<>();
		for (final String aba : parTodasPerguntasAgrupadas.keySet()) {
			for (final List<PerguntaComExameTO> locPerguntasComExameTO : parTodasPerguntasAgrupadas.values()) {
				for (final PerguntaComExameTO locPerguntaComExameTO : locPerguntasComExameTO) {
					if (ehPermitidoConsolidacao(locPerguntaComExameTO)) {
						todasPerguntasAgrupadasEConsolidadas.put(aba, locPerguntasComExameTO);
					} else {
						todasPerguntasAgrupadasEConsolidadas.put(aba, locPerguntasComExameTO);
					}
				}
			}
		}
		return todasPerguntasAgrupadasEConsolidadas;
	}

	private boolean ehPermitidoConsolidacao(final PerguntaComExameTO locPerguntaComExameTO) {
		return locPerguntaComExameTO.getPermiteConsolidacao().equals(PerguntasService.PERMITE_CONSOLIDACAO);
	}
}
