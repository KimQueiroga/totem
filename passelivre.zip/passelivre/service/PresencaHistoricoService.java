package br.com.hermespardini.passelivre.service;

import javax.servlet.http.HttpServletRequest;

import org.wdelmaschio.base.view.Service;

import br.com.hermespardini.corebusiness.exception.IHPCoreException;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.facade.PresencaHistoricoFacade;
import br.com.hermespardini.passelivre.model.PresencaHistorico;

public class PresencaHistoricoService extends Service {

	public PresencaHistoricoService(final HttpServletRequest parRequest) throws Exception {
		super(PresencaHistorico.class, PresencaHistoricoFacade.class, parRequest);
	}

	public void salvarHistoricoBiometria(final PresencaHistorico paramPresencaHistorico) throws RegraNegocioException {
		try {
			((PresencaHistoricoFacade) getFacade()).insert(paramPresencaHistorico);
		} catch (final IHPCoreException ihpExc) {
			setResponseMessage(ihpExc.getMotivo());
			failed();
			throw new RegraNegocioException(ihpExc.getMessage());
		} catch (final Exception loE) {
			setResponseMessage(loE.getMessage());
			failed();
			throw new RegraNegocioException(loE.getMessage());
		}
	}

	public Long getId() throws RegraNegocioException {
		try {
			return ((PresencaHistoricoFacade) getFacade()).getId();
		} catch (final IHPCoreException ihpExc) {
			setResponseMessage(ihpExc.getMotivo());
			failed();
			throw new RegraNegocioException(ihpExc.getMessage());
		} catch (final Exception loE) {
			setResponseMessage(loE.getMessage());
			failed();
			throw new RegraNegocioException(loE.getMessage());
		}
	}
}
