package br.com.hermespardini.passelivre.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.exception.PagamentoException;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.model.PagamentoResult;
import br.com.hermespardini.passelivre.model.ParametroPagamento;
import br.com.hermespardini.passelivre.model.ParametroRecibo;
import br.com.hermespardini.passelivre.utils.MensagemUtil;
import br.com.hermespardini.passelivre.utils.RelatorioPDF;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.service.IhpMainService;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class PagamentoService extends IhpMainService {

	public PagamentoService(final HttpServletRequest parRequest) throws Exception {
		super(parRequest);
	}

	public void realizarPagamento(final ParametroPagamento parametroPagamento) throws PagamentoException {
		final Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
		final String input = gson.toJson(parametroPagamento);
		final OkHttpClient client = new OkHttpClient.Builder()
				.connectTimeout(Constantes.TIMEOUT_CONSULTA_EXAMES, TimeUnit.SECONDS)
				.writeTimeout(Constantes.TIMEOUT_CONSULTA_EXAMES, TimeUnit.SECONDS)
				.readTimeout(Constantes.TIMEOUT_CONSULTA_EXAMES, TimeUnit.SECONDS).build();
		final MediaType json = MediaType.parse(Constantes.TYPE_JSON);
		final RequestBody body = RequestBody.create(json, input);
		final String urlCliente = getEndPoint("ENDPOINT_IHP_PAGAMENTO_CIELO");
		// new Util().retornarEndPoint("ENDPOINT_IHP_PAGAMENTO_CIELO", getRequest());
		final Request request = new Request.Builder().url(urlCliente).post(body)
				.addHeader("Content-Type", "application/json").addHeader("Accept", "*/*").build();
		Response locResponse = null;
		JSONObject locJsonObject = new JSONObject();
		try {
			locResponse = client.newCall(request).execute();
			final String locJsonData = locResponse.body().string();
			verificarSeEhUmCoteudoValido(locJsonData);
			locJsonObject = new JSONObject(locJsonData);
			final PagamentoResult pagamentoResult = new Gson().fromJson(locJsonData, PagamentoResult.class);
			verificarRespostaAoRealizarPagamento(locResponse, pagamentoResult);
		} catch (final Exception locExc) {
			failed();
			setResponseMessage(locExc.getMessage());
			throw new PagamentoException(locExc.getMessage());
		} finally {
			if (locResponse != null) {
				locResponse.close();
			}
			if (client != null) {
				client.connectionPool().evictAll();
			}
		}
	}

	// FIXME Colocar condição quando tiver nsu
	private void verificarRespostaAoRealizarPagamento(final Response parResponse,
			final PagamentoResult parPagamentoResult) throws PagamentoException {
		if (parResponse.isSuccessful() && retornarStatus(parPagamentoResult)) {
			setResponseObject(parPagamentoResult);
		} else {
			failed();
			final String mensagem = retornarMensagemErro(parPagamentoResult);
			setResponseMessage(mensagem);
			throw new PagamentoException(mensagem);
		}
	}

	private String retornarMensagemErro(final PagamentoResult parPagamentoResult) {
		try {
			return parPagamentoResult.getMessages().get(0).getError().get(0).getMessage();
		} catch (final Exception locExc) {
			return "";
		}

	}

	private Boolean retornarStatus(final PagamentoResult parPagamentoResult) {
		try {
			return parPagamentoResult.getMessages().get(0).getSuccess().get(0).getMessage().getStatus().equals("6");
		} catch (final Exception locExc) {
			return false;
		}
	}

	private void verificarSeEhUmCoteudoValido(final String parJsonData) throws IOException, RegraNegocioException {
		if (Util.verificarSeConteudoEhXML(parJsonData)) {
			failed();
			setResponseMessage(parJsonData);
			throw new RegraNegocioException(parJsonData);
		}
	}

	// private String getClientSecret() throws PagamentoException {
	// try {
	// final ValorParametroAplicacaoExt param = new ValorParametroAplicacaoExt();
	// param.setChave("CIELO-CHAVE");
	// final ValorParametroAplicacaoFacade facade = new
	// ValorParametroAplicacaoFacade(param);
	// final List<ValorParametroAplicacaoExt> valorChave =
	// facade.selectByChaveParametro();
	// if (!valorChave.isEmpty()) {
	// return valorChave.get(0).getValorTexto();
	// } else {
	// throw new PagamentoException(
	// MensagemUtil.retornarMensagemErroAoFazerPagamento("Erro ao buscar segredo da
	// chave cielo!"));
	// }
	// } catch (final Exception locExc) {
	// throw new PagamentoException(
	// MensagemUtil.retornarMensagemErroAoFazerPagamento(locExc.getMessage()));
	// }
	//
	// }

	public InputStream gerarRecibo(final ParametroRecibo parParametroRecibo) throws RegraNegocioException {
		try {
			final Map<String, Object> informacoesRecibo = new HashMap<>();
			informacoesRecibo.put("codigoCliente", parParametroRecibo.getCodigoCliente());
			informacoesRecibo.put("atendente", parParametroRecibo.getAtendente());
			informacoesRecibo.put("nomeCliente", parParametroRecibo.getNomeCliente());
			informacoesRecibo.put("cpf", parParametroRecibo.getCpf());
			informacoesRecibo.put("valor", parParametroRecibo.getValor());
			informacoesRecibo.put("numPedidoUnidade", parParametroRecibo.getNumPedidoUnidade());
			informacoesRecibo.put("senha", parParametroRecibo.getSenha());
			informacoesRecibo.put("unidade", parParametroRecibo.getUnidade());
			informacoesRecibo.put("descricao", parParametroRecibo.getDescricao());
			return RelatorioPDF.criarReciboPagamento("Recibo", informacoesRecibo, parParametroRecibo.getArquivoReport())
					.retornarRelatorio();
		} catch (final Exception locExc) {
			throw new RegraNegocioException(MensagemUtil.retornarErroMensagemAoImprimirRecibo(locExc.getMessage()));
		}
	}

}
