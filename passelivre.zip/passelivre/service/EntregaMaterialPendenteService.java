package br.com.hermespardini.passelivre.service;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.wdelmaschio.base.view.Service;

import br.com.hermespardini.passelivre.format.FormataDataAnoMesDia;
import br.com.hermespardini.passelivre.interfaces.FormataCampo;
import br.com.hermespardini.passelivre.model.ClienteUnidadePasseLivre;
import br.com.hermespardini.passelivre.model.ConsultaMaterialPendenteResult;
import br.com.hermespardini.passelivre.model.ExameMaterialPendente;
import br.com.hermespardini.passelivre.model.InformacaoTotem;
import br.com.hermespardini.passelivre.model.Pedido;
import br.com.hermespardini.passelivre.model.TokenResult;
import br.com.hermespardini.passelivre.utils.Util;

public class EntregaMaterialPendenteService extends Service {
	private Util util = new Util();
	private String errorMessage;

	private FormataCampo FormataCampo;

	public EntregaMaterialPendenteService(final HttpServletRequest parRequest) throws Exception {
		super(parRequest);
	}

	public String formataData(final String data) {
		FormataCampo = new FormataDataAnoMesDia(data);
		return FormataCampo.formatar();
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(final String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public List<ExameMaterialPendente> adicionarExamesMateriaisPendente(
			final ConsultaMaterialPendenteResult parConsultaMaterialPendenteResult,
			final ClienteUnidadePasseLivre clienteUnidadePasseLivre, final InformacaoTotem parInformacaoTotem,
			final TokenResult parTokenResult) {
		final List<ExameMaterialPendente> listaExameMaterialPendente = new ArrayList<>();
		for (final Pedido pedido : parConsultaMaterialPendenteResult.getPedidos()) {
			for (final ExameMaterialPendente exame : pedido.getExames()) {
				final ExameMaterialPendente exameMaterialPendente = new ExameMaterialPendente(pedido, exame,
						clienteUnidadePasseLivre, parInformacaoTotem, parTokenResult);
				listaExameMaterialPendente.add(exameMaterialPendente);
			}
		}
		return listaExameMaterialPendente;
	}

	public List<ExameMaterialPendente> adicionarExamesMateriaisPendente(
			final ConsultaMaterialPendenteResult parConsultaMaterialPendenteResult,
			final ClienteUnidadePasseLivre clienteUnidadePasseLivre, final TokenResult parTokenResult,
			final Long idUnidade, final Long idLocalizacao) {
		final List<ExameMaterialPendente> listaExameMaterialPendente = new ArrayList<>();
		for (final Pedido pedido : parConsultaMaterialPendenteResult.getPedidos()) {
			for (final ExameMaterialPendente exame : pedido.getExames()) {
				final ExameMaterialPendente exameMaterialPendente = new ExameMaterialPendente(pedido, exame,
						clienteUnidadePasseLivre, parTokenResult, idUnidade, idLocalizacao);
				listaExameMaterialPendente.add(exameMaterialPendente);
			}
		}
		return listaExameMaterialPendente;
	}

}
