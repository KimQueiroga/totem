package br.com.hermespardini.passelivre.service;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONObject;

import com.google.gson.Gson;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.model.ConsultaCepResult;
import okhttp3.Response;

public class CepService extends MainService {
	

	
	public CepService(final HttpServletRequest parRequest) throws Exception {
		super(parRequest);
	}
	
	public ConsultaCepResult consultarCep(String cep, String token) throws Exception {
		ConsultaCepResult cepResult = null;
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("origem", Constantes.ORIGEM_PADRAO);
		headers.put("token", token);
		
		String fullUrl = null;
		if(getAmbienteProducao())
			fullUrl = Constantes.URL_API_REST_BUSCAR_CEP_PRODUCAO + cep;
		else
			fullUrl = Constantes.URL_API_REST_BUSCAR_CEP_HOMOLOGACAO + cep;
		
		Response response = super.executeGet(fullUrl, headers);	
		if(response == null)
			throw new Exception("Serviço buscar CEP indisponível no momento!");
		
		if(response.code() == 200) {
			JSONObject locJsonObject = new JSONObject();
			final Gson gson = new Gson();		
			final String locJsonData = response.body().string();
			if(!locJsonData.isEmpty()) {
				locJsonObject = new JSONObject(locJsonData);		
				cepResult = gson.fromJson(locJsonObject.getJSONObject("consultaCepResult").toString(), ConsultaCepResult.class);
			}
		} else {
			if(response.code() == 400) {
				throw new Exception("CEP não encontrado!");
			} else if(response.code() == 401) {
				throw new Exception("Serviço não autenticado!");
			}else {
				throw new Exception("Serviço buscar CEP indisponível no momento!");
			}			
		}
		
		return cepResult;
	}


}
