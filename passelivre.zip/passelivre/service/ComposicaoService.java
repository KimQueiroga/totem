package br.com.hermespardini.passelivre.service;

import javax.servlet.http.HttpServletRequest;

import br.com.hermespardini.passelivre.utils.DataUtil;
import br.com.hermespardini.web.service.IhpMainService;
import br.com.unimedbh.esb.prontuario.schemas.ComposicaoDTO;
import br.com.unimedbh.esb.prontuario.schemas.ComposicaoProxy;
import br.com.unimedbh.esb.prontuario.schemas.ConsultaComposicaoSolic;

public class ComposicaoService extends IhpMainService {

	private DataUtil dataUtil = new DataUtil();

	public ComposicaoService(final HttpServletRequest parRequest) throws Exception {
		super(parRequest);
	}

	public ComposicaoDTO[] consultar(final Long idSolicitacao, final String codigoProcedimento) throws Exception {
		try {
			final ComposicaoProxy proxy = criarProxParaConsulta();
			return proxy.consultaComposicaoSolic(new ConsultaComposicaoSolic(idSolicitacao, codigoProcedimento));
		} catch (final Exception locExc) {
			throw new Exception("Erro ao fazer a consulta da composição!" + locExc.getMessage());
		}
	}

	private ComposicaoProxy criarProxParaConsulta() {
		return new ComposicaoProxy(getEndPoint("ENDPOINT_SERVICE_UNIMED") + "/ws-Composicao");
	}

}
