package br.com.hermespardini.passelivre.service;

import java.io.IOException;
import java.net.SocketTimeoutException;
import java.text.ParseException;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;

import org.apache.http.conn.ConnectTimeoutException;
import org.json.JSONObject;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.constantsenum.TimeOutErrorCodeEnum;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.model.AgendamentoResult;
import br.com.hermespardini.passelivre.model.ParametroAgendamentoCliente;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.service.IhpMainService;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class AgendamentoService extends IhpMainService {
	private Util util = new Util();

	public AgendamentoService(final HttpServletRequest parRequest) throws Exception {
		super(parRequest);
	}

	public void consultaAgendamento(final ParametroAgendamentoCliente user)
			throws RegraNegocioException, ParseException {
		String descricaoServico = Thread.currentThread().getStackTrace()[1].getMethodName();
		final Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
		final String input = gson.toJson(user);
		final OkHttpClient client =  new OkHttpClient.Builder()
			    .connectTimeout(30, TimeUnit.SECONDS)
			    .writeTimeout(30, TimeUnit.SECONDS)
			    .readTimeout(30, TimeUnit.SECONDS)
			    .build();		
		
		final MediaType json = MediaType.parse(Constantes.TYPE_JSON);
		final RequestBody body = RequestBody.create(json, input);
		final Request request = new Request.Builder().url(getEndPoint("ENDPOINT_AGENDAMENTO_IMAGEM_CLIENTE")).post(body)
				.build();
		Response locResponse = null;
		try {
			JSONObject locJsonObject = new JSONObject();
			locResponse = client.newCall(request).execute();
			if (Util.isTimeOut(locResponse.code())) {
				String origem = "Response";
				Util.msgTimeOut(TimeOutErrorCodeEnum.E003.getDescErrorCode(), origem, descricaoServico, user.getCodigoCliente(), locResponse.message());	
			}			
			final String locJsonData = locResponse.body().string();
			verificarSeEhUmCoteudoValido(locJsonData);
			locJsonObject = new JSONObject(locJsonData);
			if (locResponse.isSuccessful()) {
				final ObjectMapper jsonMapper = new ObjectMapper();

				final AgendamentoResult result = gson.fromJson(locJsonObject.getJSONObject("ConsultaResult").toString(),
						AgendamentoResult.class);
				if (result == null) {
					failed();
					setResponseMessage(result.getMensagem());
				} else {
					if ("0".equals(result.getStatus()) && result.getAgendamentos() != null
							&& !result.getAgendamentos().isEmpty()) {
						setResponseObject(result.getAgendamentos());
						setResponseMessage(result.getMensagem());
					} else if (result.getAgendamentos() == null || result.getAgendamentos().isEmpty()) { // status
																											// ==1
						setResponseObject(null);
					} else {
						failed();
						setResponseMessage(result.getMensagem());
					}
				}
			}
		} catch (ConnectTimeoutException connectTimeoutEx) {
			failed();
			try {
				String origem = "ConnectTimeoutException";
				Util.msgTimeOut(TimeOutErrorCodeEnum.E003.getDescErrorCode(), origem, descricaoServico, user.getCodigoCliente(), connectTimeoutEx.getMessage());
			} catch (final Exception e) {
				throw new RegraNegocioException(e.getMessage());	
			}			
		} catch (SocketTimeoutException socketTimeoutEx) {
			failed();
			try {
				String origem = "SocketTimeoutException";
				Util.msgTimeOut(TimeOutErrorCodeEnum.E003.getDescErrorCode(), origem, descricaoServico, user.getCodigoCliente(), socketTimeoutEx.getMessage());
			} catch (final Exception e) {
				throw new RegraNegocioException(e.getMessage());	
			}
		} catch (final Exception locExc) {
			failed();
			throw new RegraNegocioException(locExc.getMessage());
		} finally {
			if (locResponse != null) {
				locResponse.close();
			}
			if (client != null) {
				client.connectionPool().evictAll();
			}
		}
	}

	private void verificarSeEhUmCoteudoValido(final String parJsonData) throws IOException, RegraNegocioException {
		if (Util.verificarSeConteudoEhXML(parJsonData)) {
			failed();
			setResponseMessage(parJsonData);
			throw new RegraNegocioException(parJsonData);
		}
	}
}
