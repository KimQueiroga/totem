package br.com.hermespardini.passelivre.service;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.model.ConsultaCodigoResult;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.service.IhpMainService;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class ConsultaExamesAutorizadosService extends IhpMainService {
	private String mensagem;

	public ConsultaExamesAutorizadosService(final HttpServletRequest parRequest) throws Exception {
		super(parRequest);
	}

	public void consultar() throws RuntimeException {
		final Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
		final String input = gson.toJson(getValueObject());
		final OkHttpClient client = new OkHttpClient.Builder()
				.connectTimeout(Constantes.TIMEOUT_CONSULTA_EXAMES, TimeUnit.SECONDS)
				.writeTimeout(Constantes.TIMEOUT_CONSULTA_EXAMES, TimeUnit.SECONDS)
				.readTimeout(Constantes.TIMEOUT_CONSULTA_EXAMES, TimeUnit.SECONDS).build();
		final MediaType json = MediaType.parse(Constantes.TYPE_JSON);
		final RequestBody body = RequestBody.create(json, input);
		final Request request = new Request.Builder().url(getEndPoint("ENDPOINT_IHP_TABELA_PRECO_CONSULTA_CODIGO_REST"))
				.post(body).build();
		Response locResponse = null;
		JSONObject locJsonObject = new JSONObject();
		try {
			locResponse = client.newCall(request).execute();
			final String locJsonData = locResponse.body().string();
			verificarSeEhUmCoteudoValido(locJsonData);
			locJsonObject = new JSONObject(locJsonData);
			mensagem = Util
					.retirarCaracterEspecial(locJsonObject.getJSONObject("ConsultaCodigoResult").getString("mensagem"));
			setResponseMessage(mensagem);
			final ConsultaCodigoResult result = gson.fromJson(
					locJsonObject.getJSONObject("ConsultaCodigoResult").toString(), ConsultaCodigoResult.class);
			if (result == null) {
				failed();
				setResponseMessage(result.getMensagem());
			} else {
				if ("0".equals(result.getStatus())) {
					setResponseObject(result);
				} else {
					failed();
					setResponseMessage(result.getMensagem());
				}
			}
		} catch (final Exception locExc) {
			failed();
			throw new RuntimeException(locExc.getMessage());
		} finally {
			if (locResponse != null) {
				locResponse.close();
			}
			if (client != null) {
				client.connectionPool().evictAll();
			}
		}
	}

	private void verificarSeEhUmCoteudoValido(final String parJsonData) throws IOException, RegraNegocioException {
		if (Util.verificarSeConteudoEhXML(parJsonData)) {
			failed();
			setResponseMessage(parJsonData);
			throw new RegraNegocioException(parJsonData);
		}
	}
}
