package br.com.hermespardini.passelivre.service;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.model.ConsultaDetalheResult;
import br.com.hermespardini.passelivre.model.DetalhePreparacao;
import br.com.hermespardini.passelivre.model.EmpresaTotem;
import br.com.hermespardini.passelivre.model.InformacaoTotem;
import br.com.hermespardini.passelivre.model.ParametroPreparacao;
import br.com.hermespardini.passelivre.utils.TotemUtil;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.service.IhpMainService;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class DetalhePreparacaoService extends IhpMainService {

	public DetalhePreparacaoService(final HttpServletRequest parRequest) throws Exception {
		super(parRequest);
	}

	public void consultar(String exame, String token, InformacaoTotem informacaoTotem) throws RegraNegocioException {
		final Gson gson = new Gson();
		final OkHttpClient client = new OkHttpClient();
		StringBuilder urlQueryParam = new StringBuilder();
		
		urlQueryParam.append(getEndPoint("ENDPOINT_IHP_INFORMACOES_HELP_EXAME"));
		urlQueryParam.append("?empresa="+TotemUtil.buscarIdEmpresa());
		urlQueryParam.append("&exame="+exame);
		urlQueryParam.append("&uf="+informacaoTotem.getUfUnidade());
		urlQueryParam.append("&layout="+Constantes.CLIENTE_LOJA);
		urlQueryParam.append("&unidadeNegocio="+Constantes.UNIDADE_NEGOCIO_PREPARACAO);
		
		final Request request = new Request.Builder().addHeader("X-Hp-Auth-Token", token)
				.addHeader("authkey", Constantes.ORIGEM_PADRAO).url(urlQueryParam.toString()).get().build();

		Response locResponse = null;
		try {
			locResponse = client.newCall(request).execute();
			final String locJsonData = locResponse.body().string();
			verificarSeEhUmCoteudoValido(locJsonData);
			final ConsultaDetalheResult result = gson.fromJson(locJsonData, ConsultaDetalheResult.class);
			if (result == null) {
				failed();
				setResponseMessage("Dados não encontrados!" + exame);
			} else {
				setResponseObject(result);
			}
		} catch (final Exception locExc) {
			failed();
			throw new RegraNegocioException("Problema ao fazer consultar do preparo!" + locExc.getMessage());
		} finally {
			if (locResponse != null) {
				locResponse.close();
			}
			if (client != null) {
				client.connectionPool().evictAll();
			}
		}
	}

	public void consultar(final ParametroPreparacao parParametroPreparacao) throws RegraNegocioException {
		final Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
		final String input = gson.toJson(getValueObject());
		final OkHttpClient client = new OkHttpClient();
		final MediaType json = MediaType.parse(Constantes.TYPE_JSON);
		final RequestBody body = RequestBody.create(json, input);
		final String urlCliente = getEndPoint("ENDPOINT_IHP_PREPARACAO_EXAME") + "?id="
				+ parParametroPreparacao.getId();
		final Request request = new Request.Builder().url(urlCliente).get().build();
		Response locResponse = null;
		try {
			locResponse = client.newCall(request).execute();
			final String locJsonData = locResponse.body().string();
			final DetalhePreparacao result = gson.fromJson(locJsonData.replace("BR&gt;", "").replace("&lt;", ""),
					DetalhePreparacao.class);
			if (result == null) {
				failed();
				setResponseMessage("Dados não encontrados!" + parParametroPreparacao.getId());
			} else {
				setResponseObject(result);
			}
		} catch (final Exception locExc) {
			failed();
			throw new RegraNegocioException("Problema ao fazer consultar do preparo!" + locExc.getMessage());
		} finally {
			if (locResponse != null) {
				locResponse.close();
			}
			if (client != null) {
				client.connectionPool().evictAll();
			}
		}
	}

	private void verificarSeEhUmCoteudoValido(final String parJsonData) throws IOException, RegraNegocioException {
		if (Util.verificarSeConteudoEhXML(parJsonData)) {
			failed();
			setResponseMessage(parJsonData);
			throw new RegraNegocioException(parJsonData);
		}
	}
}
