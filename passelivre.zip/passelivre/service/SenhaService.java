package br.com.hermespardini.passelivre.service;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONObject;
import org.wdelmaschio.base.view.Service;

import com.google.gson.Gson;
import com.sun.corba.se.spi.legacy.connection.GetEndPointInfoAgainException;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.login.model.UserAuthVerify;
import br.com.hermespardini.passelivre.login.model.UserGetVerificationCode;
import br.com.hermespardini.passelivre.model.ClienteUnidadePasseLivre;
import br.com.hermespardini.passelivre.model.UserAuth;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.service.IhpMainService;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class SenhaService extends IhpMainService {

	private String mensagem;

	public SenhaService(final HttpServletRequest request) throws Exception {
		super(request);
	}

	public void recuperaSenha(final UserAuth user) throws Exception {
		setValueObject(user);
		final Gson gson = new Gson();
		final String input = gson.toJson(getValueObject());
		final OkHttpClient client = new OkHttpClient();
		final MediaType json = MediaType.parse(Constantes.TYPE_JSON);
		final RequestBody body = RequestBody.create(json, input);
		final Request request = new Request.Builder().url(getEndPoint("ENDPOINT_IHP_SENHA")).post(body).build();
		Response locResponse = null;
		JSONObject locJsonObject = new JSONObject();
		try {
			locResponse = client.newCall(request).execute();
			final String locJsonData = locResponse.body().string();
			verificarSeEhUmCoteudoValido(locJsonData);
			locJsonObject = new JSONObject(locJsonData);
			mensagem = Util.retirarCaracterEspecial(locJsonObject.getString("message"));
			setResponseMessage(mensagem);
		} catch (final Exception locExc) {
			if (locJsonObject.getString("error") != null && !locJsonObject.getString("error").equals(""))
				throw new Exception(locJsonObject.getString("error"));
			else
				throw new Exception("Erro, tente novamente mais tarde");
		} finally {
			if (locResponse != null) {
				locResponse.close();
			}
			if (client != null) {
				client.connectionPool().evictAll();
			}
		}
	}

	private void verificarSeEhUmCoteudoValido(final String parJsonData) throws IOException, Exception {
		if (Util.verificarSeConteudoEhXML(parJsonData)) {
			failed();
			setResponseMessage(parJsonData);
			throw new Exception(parJsonData);
		}
	}

	public void atualizarSenha() {
		ClienteUnidadePasseLivre clienteUnidadePasseLivre = new ClienteUnidadePasseLivre();
		clienteUnidadePasseLivre = (ClienteUnidadePasseLivre) getValueObject();
		final Gson gson = new Gson();
		final String input = gson.toJson(getValueObject());
		final OkHttpClient client = new OkHttpClient();
		final MediaType json = MediaType.parse(Constantes.TYPE_JSON);
		final RequestBody body = RequestBody.create(json, input);
		final Request request = new Request.Builder().addHeader("X-Hp-Auth-Token", clienteUnidadePasseLivre.getId())
				.url(getEndPoint("ENDPOINT_IHP_SENHA")).post(body).build();
		Response locResponse = null;
		JSONObject locJsonObject = new JSONObject();
		try {
			locResponse = client.newCall(request).execute();
			final String locJsonData = locResponse.body().string();
			verificarSeEhUmCoteudoValido(locJsonData);
			locJsonObject = new JSONObject(locJsonData);
			if (locResponse.isSuccessful()) {
				mensagem = Util.retirarCaracterEspecial(locJsonObject.getString("message"));
				setResponseMessage(mensagem);
			} else {
				failed();
				mensagem = Util.retirarCaracterEspecial(locJsonObject.getString("error"));
				setResponseMessage(mensagem);
			}
		} catch (final Exception locExc) {
			failed();
			setResponseMessage("Erro ao atualizar senha!");
		} finally {
			if (locResponse != null) {
				locResponse.close();
			}
			if (client != null) {
				client.connectionPool().evictAll();
			}
		}
	}
	
	public void redefinirSenha(final UserAuthVerify userAuth) throws Exception {
		setValueObject(userAuth);
		final Gson gson = new Gson();
		final String input = gson.toJson(getValueObject());
		final OkHttpClient client = new OkHttpClient();
		final MediaType json = MediaType.parse(Constantes.TYPE_JSON);
		final RequestBody body = RequestBody.create(json, input);
		final Request request = new Request.Builder().url(getEndPoint("ENDPOINT_IHP_SENHA")).post(body).build();
		Response locResponse = null;
		JSONObject locJsonObject = new JSONObject();
		try {
			locResponse = client.newCall(request).execute();
			final String locJsonData = locResponse.body().string();
			verificarSeEhUmCoteudoValido(locJsonData);
			locJsonObject = new JSONObject(locJsonData);
			mensagem = Util.retirarCaracterEspecial(locJsonObject.getString("message"));
			setResponseMessage(mensagem);
		} catch (final Exception locExc) {
			if (locJsonObject.getString("error") != null && !locJsonObject.getString("error").equals(""))
				throw new Exception(locJsonObject.getString("error"));
			else
				throw new Exception("Erro, tente novamente mais tarde");
		} finally {
			if (locResponse != null) {
				locResponse.close();
			}
			if (client != null) {
				client.connectionPool().evictAll();
			}
		}
	}
	
	public void enviarCodVerificacaoNovaSenha(final UserGetVerificationCode userAuthVC) throws Exception {
		setValueObject(userAuthVC);
		final Gson gson = new Gson();
		final String input = gson.toJson(getValueObject());
		final OkHttpClient client = new OkHttpClient();
		final MediaType json = MediaType.parse(Constantes.TYPE_JSON);
		final RequestBody body = RequestBody.create(json, input);
		final Request request = new Request.Builder().url(getEndPoint("ENDPOINT_IHP_SENHA")).post(body).build();
		Response locResponse = null;
		JSONObject locJsonObject = new JSONObject();
		try {
			locResponse = client.newCall(request).execute();
			final String locJsonData = locResponse.body().string();
			verificarSeEhUmCoteudoValido(locJsonData);
			locJsonObject = new JSONObject(locJsonData);
			mensagem = Util.retirarCaracterEspecial(locJsonObject.getString("message"));
			setResponseMessage(mensagem);
		} catch (final Exception locExc) {
			if (locJsonObject.getString("error") != null && !locJsonObject.getString("error").equals(""))
				throw new Exception(locJsonObject.getString("error"));
			else
				throw new Exception("Erro, tente novamente mais tarde");
		} finally {
			if (locResponse != null) {
				locResponse.close();
			}
			if (client != null) {
				client.connectionPool().evictAll();
			}
		}
	}

}
