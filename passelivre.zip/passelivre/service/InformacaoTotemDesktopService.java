package br.com.hermespardini.passelivre.service;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.model.InformacoesTotemDesktop;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.service.IhpMainService;
import okhttp3.Response;

public class InformacaoTotemDesktopService extends IhpMainService {

	public InformacaoTotemDesktopService(final HttpServletRequest parRequest) throws Exception {
		super(parRequest);
	}

	public void consultar(final String perfil) throws RegraNegocioException {
		Response response = null;
		try {
			final Gson gson = new Gson();
			final JSONObject locJsonObject = new JSONObject();
			response = executeGet(getEndPoint("ENDPOINT_RECURSO_APLICACAO") + "?siglaaplicacao="
					+ Constantes.NOME_SISTEMA_DESKTOP + "&nomeperfil=" + perfil);
			final String locJsonData = response.body().string();
			verificarSeEhUmCoteudoValido(locJsonData);
			if (response.isSuccessful()) {
				final InformacoesTotemDesktop result = gson.fromJson(locJsonData,
						new TypeToken<InformacoesTotemDesktop>() {
						}.getType());
				if (result != null) {
					setResponseObject(result);
				} else {
					failed();
					setResponseMessage("Problema ao buscar informações do totem desktop!");
				}
			}
		} catch (final Exception locExc) {
			failed();
			throw new RegraNegocioException(locExc.getMessage());
		} finally {
			if (response != null) {
				response.close();
			}
		}
	}

	private void verificarSeEhUmCoteudoValido(final String parJsonData) throws IOException, RegraNegocioException {
		if (Util.verificarSeConteudoEhXML(parJsonData)) {
			failed();
			setResponseMessage(parJsonData);
			throw new RegraNegocioException(parJsonData);
		}
	}

}
