package br.com.hermespardini.passelivre.service;

import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;

import javax.servlet.http.HttpServletRequest;

import org.wdelmaschio.base.view.Service;
import org.wildfly.common.annotation.Nullable;

import com.fasterxml.jackson.databind.ObjectMapper;

import br.com.hermespardini.corebusiness.dao.IhpMainDao;
import br.com.hermespardini.corebusiness.model.LogAplicacaoUsuarioFactory;
import br.com.hermespardini.passelivre.constantsenum.Constantes;
import okhttp3.Headers;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainService extends Service {

	protected static String endPointIHP;

	public MainService(final HttpServletRequest parRequest) throws Exception {
		super(parRequest);
		endPointIHP = System.getProperty("ENDPOINT_IHP", Constantes.URL_API_REST_BUSCAR_CEP_PRODUCAO);
	}

	public MainService(final Class<?> voClass, final HttpServletRequest request) throws Exception {
		super(voClass, request);
	}

	public MainService(final Class<?> voClass, final Class<?> facadeClass, final HttpServletRequest request)
			throws Exception {

		super(voClass, facadeClass, request);
		((IhpMainDao) getFacade().getDao())
				.setLogAplicacao(LogAplicacaoUsuarioFactory.newDataBaseLogUserInstance(request));

	}

	@Override
	public void setActionPage(final String parActionPage) {
		super.setActionPage(parActionPage);
		if (getFacade() != null) {
			((IhpMainDao) getFacade().getDao()).setFuncionalidadeAcesso(parActionPage);
		}
	}

//	public final void registrarLogAcessoFuncionalidade(final String parClassName, final String parMethodName)
//			throws Exception {
//		final Map<String, String> additionalMap = new HashMap<String, String>();
//		additionalMap.put("funcionalidadeAcesso", parClassName);
//		additionalMap.put("artefato", parMethodName);
//
//		registrarLogAplicacaoAcesso(additionalMap);
//	}

//	public void registrarLogAplicacaoAcesso(@Nullable final Map parAdditionalMap) throws Exception {
//		final LogAplicacaoUsuario _log = LogAplicacaoUsuarioFactory.newAcessLogToInstance(getRequest());
//
//		if (parAdditionalMap != null) {
//			_log.mergeVO(parAdditionalMap);
//
//			if (_log.getObservacao() != null) {
//				if (_log.getObservacao().startsWith("ERROR")) {
//					_log.setTipoLog(TipoLogEnum.ERRO_ACESSO.getValor());
//				}
//			}
//			setActionPage(_log.getFuncionalidadeAcesso());
//		}
//
//		Response locResponse = null;
//		try {
//			locResponse = executePost(getWebServiceLogUrl(), _log);
//		} catch (final Exception exc) {
//			exc.printStackTrace();
//		} finally {
//			if (locResponse != null) {
//				locResponse.body().close();
//			}
//		}
//
//	}

	public Response executeGet(final String parGetUrl, final Map<String, String>... parHeaders) throws Exception {
		return executePost(parGetUrl, null, parHeaders);
	}

	public Response executePost(final String parPostUrl, final Object parPostObject,
			final Map<String, String>... parHeaders) throws Exception {

		return executeRestMethod(parPostUrl, parPostObject, 30L, TimeUnit.SECONDS, parHeaders);
	}

	public Response executePost(final String parPostUrl, final Object parPostObject, Long time, TimeUnit timeUnit,
			final Map<String, String>... parHeaders) throws Exception {

		return executeRestMethod(parPostUrl, parPostObject, time, timeUnit, parHeaders);
	}

	private Response executeRestMethod(final String restUrl, final Object restObject, @Nullable Long parTime,
			@Nullable TimeUnit parTimeUnit, final Map<String, String>... parHeaders) throws Exception {

		final ObjectMapper jsonMapper = new ObjectMapper();
		final MediaType jsonMediaType = MediaType.parse("application/json; charset=utf-8");

		if (parTimeUnit == null) {
			parTimeUnit = TimeUnit.SECONDS;
		}

		if (parTime == null) {
			switch (parTimeUnit) {
			case MICROSECONDS:
				parTime = 1000000L;
				break;
			case MILLISECONDS:
				parTime = 1000L;
				break;
			case SECONDS:
				parTime = 30L;
				break;
			case HOURS:
				parTime = 1L;
				break;
			case DAYS:
				parTime = 1L;
				break;
			default:
				parTime = 30L;
				break;
			}
		}

		Headers header = null;
		if (parHeaders != null && parHeaders.length > 0) {
			final Headers.Builder headBuilder = new Headers.Builder();
			Stream.of(parHeaders).findFirst().orElse(null).entrySet()
					.forEach(m -> headBuilder.add(m.getKey(), m.getValue()));

			header = headBuilder.build();
		}

		final Request locRequest;

		// Se postObject for null a chamada eh para metodo GET
		if (restObject == null) {
			if (header == null) {
				locRequest = new Request.Builder().url(restUrl).build();
			} else {
				locRequest = new Request.Builder().url(restUrl).headers(header).build();

			}
		} else {
			final String strEntity = jsonMapper.writeValueAsString(restObject);
			final RequestBody body = RequestBody.create(jsonMediaType, strEntity);
			if (header == null) {
				locRequest = new Request.Builder().url(restUrl).post(body).build();
			} else {
				locRequest = new Request.Builder().url(restUrl).headers(header).post(body).build();
			}
		}

		Response theResponse = null;

		OkHttpClient client;
		try {
			final OkHttpClient.Builder builder = new OkHttpClient.Builder();
			builder.connectTimeout(parTime, parTimeUnit).writeTimeout(parTime, parTimeUnit).readTimeout(parTime,
					parTimeUnit);

			client = builder.build();
			theResponse = client.newCall(locRequest).execute();
		} catch (final Exception exc) {
			exc.printStackTrace();
			throw exc;
		} /*
			 * finally { if (theResponse != null) { theResponse.body().close(); } }
			 */
		return theResponse;
	}

//	protected String obterUrlLoginAd() {
//		return getEndPoint("ENDPOINT_WSLOGIN_AD_IHP");
//	}
//
//	protected String getWebServiceLogUrl() {
//		return getEndPoint("ENDPOINT_REGLOG_IHP");
//		// return
//		// "https://www.hermespardini.com.br/services/ihpwsregistralog/rest/logs/registrarlog";
//	}

	private final String getContextInitParameter(final String paramInitParameter) throws Exception {
		return System.getProperty(paramInitParameter);
	}

	protected final boolean getAmbienteProducao() {
		boolean locAmbiente = false;
		try {
			final String loStrAmbiente = getContextInitParameter("isAmbienteProducao");
			locAmbiente = loStrAmbiente == null ? false : "true".equals(loStrAmbiente);

		} catch (final Exception exc) {
			locAmbiente = false;
		}

		return locAmbiente;
	}

	protected final boolean getAmbienteHomologacao() {
		boolean locAmbiente = false;
		try {
			final String loStrAmbiente = getContextInitParameter("isAmbienteHomologa");
			locAmbiente = loStrAmbiente == null ? false : "true".equals(loStrAmbiente);

		} catch (final Exception exc) {
			locAmbiente = false;
		}

		return locAmbiente;
	}

	protected final boolean getAmbienteDesenvolvimento() {
		boolean locAmbiente = false;
		try {
			final String loStrAmbiente = getContextInitParameter("isAmbienteDesenv");
			locAmbiente = loStrAmbiente == null ? false : "true".equals(loStrAmbiente);

		} catch (final Exception exc) {
			locAmbiente = false;
		}

		return locAmbiente;
	}

//	public String getEndPoint(final String parEndPoint) {
//		String locEndpoint = null;
//
//		try {
//			final boolean locAmbienteDesenv = getAmbienteDesenvolvimento();
//			final boolean locAmbienteHomol = getAmbienteHomologacao();
//			final boolean locAmbienteProducao = getAmbienteProducao();
//			EnderecoServico webServiceUrlInt = null;
//			try {
//				webServiceUrlInt = obterEndpointBancoDados(parEndPoint);
//
//				locEndpoint = locAmbienteDesenv ? webServiceUrlInt.getWsurlDesenvJboss()
//						: locAmbienteHomol ? webServiceUrlInt.getWsurlHomologaJboss()
//								: locAmbienteProducao ? webServiceUrlInt.getWsurlProducaoJboss() : null;
//				if (locEndpoint == null) {
//					locEndpoint = locAmbienteDesenv ? webServiceUrlInt.getWsurlDesenv()
//							: locAmbienteHomol ? webServiceUrlInt.getWsurlHomologa()
//									: locAmbienteProducao ? webServiceUrlInt.getWsurlProducao() : null;
//				}
//			} catch (final Exception locExc) {
//				locExc.printStackTrace();
//				locEndpoint = null;
//			}
//
//		} catch (final Exception exc) {
//			exc.printStackTrace();
//			locEndpoint = null;
//		}
//
//		return locEndpoint;
//	}
//
//	private EnderecoServico obterEndpointBancoDados(final String parEndPoint) throws Exception {
//		final EnderecoServicoService urlwsService = new EnderecoServicoService(getRequest());
//		EnderecoServico urlws = new EnderecoServico();
//		urlws.setChave(parEndPoint);
//		urlwsService.setValueObject(urlws);
//		urlwsService.getByChave();
//		if (urlwsService.isSuccess()) {
//			urlws = (EnderecoServico) urlwsService.getResponseObject();
//		}
//		return urlws;
//	}
}
