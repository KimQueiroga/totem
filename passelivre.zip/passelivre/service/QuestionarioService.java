package br.com.hermespardini.passelivre.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.model.ConsultaQuestionarioExameResult;
import br.com.hermespardini.passelivre.model.Pergunta;
import br.com.hermespardini.passelivre.model.PerguntaEntrega;
import br.com.hermespardini.passelivre.model.Questionario;
import br.com.hermespardini.passelivre.model.QuestionarioResult;
import br.com.hermespardini.passelivre.model.Questionarios;
import br.com.hermespardini.passelivre.to.PerguntaComExameTO;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.service.IhpMainService;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class QuestionarioService extends IhpMainService {
	private List<PerguntaEntrega> perguntas;
	private String mensagem;
	private Map<String, String> mapQuestionarios;
	private Map<String, List<PerguntaComExameTO>> todasPerguntasAgrupadas;

	public QuestionarioService(final HttpServletRequest parRequest) throws Exception {
		super(parRequest);
	}

	public QuestionarioService(final HttpServletRequest parRequest, final List<PerguntaEntrega> parPerguntas,
			final Map<String, String> parMapQuestionarios) throws Exception {
		super(parRequest);
		perguntas = parPerguntas;
		mapQuestionarios = parMapQuestionarios;
	}

	public QuestionarioService(final HttpServletRequest parRequest, final List<PerguntaEntrega> parPerguntas,
			final Map<String, String> parMapQuestionarios,
			final Map<String, List<PerguntaComExameTO>> parTodasPerguntasAgrupadas) throws Exception {
		super(parRequest);
		perguntas = parPerguntas;
		mapQuestionarios = parMapQuestionarios;
		todasPerguntasAgrupadas = parTodasPerguntasAgrupadas;
	}

	// TODO Terminar de implementar.
	public void imprimir() throws RegraNegocioException {
		final Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
		final String input = gson.toJson(getValueObject());
		final OkHttpClient client = new OkHttpClient();
		final MediaType json = MediaType.parse(Constantes.TYPE_JSON);
		final RequestBody body = RequestBody.create(json, input);
		final Request request = new Request.Builder().url(getEndPoint("ENDPOINT_IHP_IMPRESSAO_QUESTIONARIO")).post(body)
				.build();
		Response locResponse = null;
		JSONObject locJsonObject = new JSONObject();
		try {
			locResponse = client.newCall(request).execute();
			final String locJsonData = locResponse.body().string();
			verificarSeEhUmCoteudoValido(locJsonData);
			locJsonObject = new JSONObject(locJsonData);
			final QuestionarioResult result = gson
					.fromJson(locJsonObject.getJSONObject("QuestionarioResult").toString(), QuestionarioResult.class);
			if (result == null) {
				failed();
				setResponseMessage(result.getMensagem());
			} else {
				if (result.getStatus() == 0) {
					setResponseObject(result);
				} else {
					failed();
					setResponseMessage(result.getMensagem());
					throw new RegraNegocioException(result.getMensagem());
				}
			}
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			failed();
			throw new RegraNegocioException(locExc.getMessage());
		} finally {
			if (locResponse != null) {
				locResponse.close();
			}
			if (client != null) {
				client.connectionPool().evictAll();
			}
		}
	}

	public void consultar() throws RegraNegocioException {
		final Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
		final String input = gson.toJson(getValueObject());
		final OkHttpClient client = new OkHttpClient();
		final MediaType json = MediaType.parse(Constantes.TYPE_JSON);
		final RequestBody body = RequestBody.create(json, input);
		final Request request = new Request.Builder().url(getEndPoint("ENDPOINT_IHP_QUESTIONARIO_CONSULTA")).post(body)
				.build();
		Response locResponse = null;
		JSONObject locJsonObject = new JSONObject();
		try {
			locResponse = client.newCall(request).execute();
			final String locJsonData = locResponse.body().string();
			verificarSeEhUmCoteudoValido(locJsonData);
			locJsonObject = new JSONObject(locJsonData);
			ConsultaQuestionarioExameResult result = new ConsultaQuestionarioExameResult();
			result = gson.fromJson(locJsonObject.getJSONObject("ConsultaQuestionarioExameResult").toString(),
					ConsultaQuestionarioExameResult.class);
			if (result == null) {
				failed();
				setResponseMessage(result.getMensagem());
			} else {
				if (result.getStatus() == 0) {
					setResponseObject(result);
				} else {
					failed();
					setResponseMessage(result.getMensagem());
					throw new RegraNegocioException(result.getMensagem());
				}
			}
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			failed();
			throw new RegraNegocioException(locExc.getMessage());
		} finally {
			if (locResponse != null) {
				locResponse.close();
			}
			if (client != null) {
				client.connectionPool().evictAll();
			}
		}
	}

	private void verificarSeEhUmCoteudoValido(final String parJsonData) throws IOException, RegraNegocioException {
		if (Util.verificarSeConteudoEhXML(parJsonData)) {
			failed();
			setResponseMessage(parJsonData);
			throw new RegraNegocioException(parJsonData);
		}
	}

	public List<PerguntaEntrega> preencherQuestionario() throws Exception {
		try {
			perguntas = new ArrayList<>();
			for (final Map.Entry<String, String> mapQuestionario : mapQuestionarios.entrySet()) {
				perguntas.add(new PerguntaEntrega(retornarCodigoPergunta(mapQuestionario.getKey()),
						retornarCodigoQuestionario(mapQuestionario.getKey()), mapQuestionario.getValue()));
			}
			return perguntas;
		} catch (final Exception locExc) {
			throw new Exception(locExc.getMessage());
		}
	}

	/**
	 * Preenche o questionário com as perguntas consolidadas.
	 *
	 * @return
	 * @throws Exception
	 */
	public List<PerguntaEntrega> preencherQuestionarioConsolidado() throws Exception {
		try {
			perguntas = new ArrayList<>();
			for (final Map.Entry<String, List<PerguntaComExameTO>> mapPergunta : todasPerguntasAgrupadas.entrySet()) {
				for (final PerguntaComExameTO pergunta : mapPergunta.getValue()) {
					for (final Map.Entry<String, String> mapQuestionario : mapQuestionarios.entrySet()) {
						final String codigoPergunta = retornarCodigoPergunta(mapQuestionario.getKey());
						final String codigoQuestionario = retornarCodigoQuestionario(mapQuestionario.getKey());
						final String resposta = mapQuestionario.getValue();
						if (codigoPergunta.equals(pergunta.getCodigo())
								&& codigoQuestionario.equals(pergunta.getCodigoQuestionario())) {
							perguntas.add(new PerguntaEntrega(codigoPergunta, codigoQuestionario, resposta));
							continue;
						}
					}
				}
			}
		} catch (final Exception locExc) {
			throw new Exception(locExc.getMessage());
		}
		return perguntas;
	}

	private String retornarCodigoPergunta(final String parKey) {
		return StringUtils.substring(parKey, parKey.lastIndexOf("_") + 1);
	}

	private String retornarCodigoQuestionario(final String parKey) {
		return parKey.substring(4, parKey.indexOf("_", 4));
	}

	public boolean validarRespostaInviolavel(final Questionarios questionarios) {
		for (final PerguntaEntrega pergunta : perguntas) {
			for (final Questionario q : questionarios.getQuestionarios()) {
				if (!validarRespostas(q,
						perguntas.stream().filter(p -> p.getCodigoQuestionario().equals(q.getCodigoQuestionario()))
								.collect(Collectors.toList()))) {
					return false;
				}
			}
		}
		return true;
	}

	public boolean validarRespostas(final Questionario questionario, final List<PerguntaEntrega> respostas) {
		for (final PerguntaEntrega resposta : respostas) {
			for (final Pergunta p : questionario.getPerguntas()) {
				if (resposta.getCodigoPergunta().equals(p.getCodigo()) && p.getInviolavel() != null
						&& p.getInviolavel().equals("S") && p.getGabarito() != null
						&& !p.getGabarito().equals(resposta.getResposta().getDescricao())) {
					return false;
				}
			}
		}
		return true;
	}
}
