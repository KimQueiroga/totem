package br.com.hermespardini.passelivre.service;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.model.ConsultaHelpResult;
import br.com.hermespardini.passelivre.model.ConsultaPreparoResult;
import br.com.hermespardini.passelivre.model.ParametroPreparacao;
import br.com.hermespardini.passelivre.utils.TotemUtil;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.service.IhpMainService;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class PreparacaoExameService extends IhpMainService {
	private Util util = new Util();
	private String mensagem;

	public PreparacaoExameService(final HttpServletRequest parRequest) throws Exception {
		super(parRequest);
	}

	public void consultar(final ParametroPreparacao parametroPreparacao, String token) throws RegraNegocioException {
		final Gson gson = new Gson();
		final OkHttpClient client = new OkHttpClient();
		final String urlCliente = getEndPoint("ENDPOINT_IHP_BUSCAR_LISTA_EXAME") + "?Empresa="
				+ TotemUtil.buscarIdEmpresa() + "&Cadeia=" + parametroPreparacao.getQ();

		final Request request = new Request.Builder().addHeader("X-Hp-Auth-Token", token)
				.addHeader("authkey", Constantes.ORIGEM_PADRAO).url(urlCliente).get().build();

		Response locResponse = null;
		try {
			locResponse = client.newCall(request).execute();
			final String locJsonData = locResponse.body().string();
			verificarSeEhUmCoteudoValido(locJsonData);
			final ConsultaHelpResult result = gson.fromJson(locJsonData, ConsultaHelpResult.class);
			if (result == null) {
				failed();
				setResponseMessage("Erro ao buscar preparação para os exames");
			} else {
				setResponseObject(result);
			}
		} catch (final Exception locExc) {
			failed();
			throw new RegraNegocioException(locExc.getMessage());
		} finally {
			if (locResponse != null) {
				locResponse.close();
			}
			if (client != null) {
				client.connectionPool().evictAll();
			}
		}
	}

	private void verificarSeEhUmCoteudoValido(final String parJsonData) throws IOException, RegraNegocioException {
		if (Util.verificarSeConteudoEhXML(parJsonData)) {
			failed();
			setResponseMessage(parJsonData);
			throw new RegraNegocioException(parJsonData);
		}
	}

	public void consultar() throws RegraNegocioException {
		final Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
		final String input = gson.toJson(getValueObject());
		final OkHttpClient client = new OkHttpClient();
		final MediaType json = MediaType.parse(Constantes.TYPE_JSON);
		final RequestBody body = RequestBody.create(json, input);
		final Request request = new Request.Builder().url(getEndPoint("ENDPOINT_IHP_EXAME_CONSULTA_PREPARACAO"))
				.post(body).build();
		Response locResponse = null;
		JSONObject locJsonObject = new JSONObject();
		try {
			locResponse = client.newCall(request).execute();
			final String locJsonData = locResponse.body().string();
			verificarSeEhUmCoteudoValido(locJsonData);
			locJsonObject = new JSONObject(locJsonData);
			final ConsultaPreparoResult result = gson.fromJson(
					locJsonObject.getJSONObject("ConsultaPreparacaoResult").toString(), ConsultaPreparoResult.class);
			mensagem = Util.retirarCaracterEspecial(result.getMensagem());
			setResponseMessage(mensagem);

			if ("0".equals(result.getStatus())) {
				setResponseObject(result);
			} else {
				failed();
				setResponseMessage(result.getMensagem());
			}
		} catch (final Exception locExc) {
			failed();
			throw new RegraNegocioException(locExc.getMessage());
		} finally {
			if (locResponse != null) {
				locResponse.close();
			}
			if (client != null) {
				client.connectionPool().evictAll();
			}
		}
	}
}
