package br.com.hermespardini.passelivre.service;

import java.io.InputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.model.ConsultaQuestionarioExameResult;
import br.com.hermespardini.passelivre.model.CriarPedidoResult;
import br.com.hermespardini.passelivre.model.Localidade;
import br.com.hermespardini.passelivre.model.Unidade;
import br.com.hermespardini.passelivre.to.ProcedimentoComExamesTO;
import br.com.hermespardini.passelivre.to.ProcedimentoRelatorioGATO;
import br.com.hermespardini.passelivre.utils.DataUtil;
import br.com.hermespardini.passelivre.utils.RelatorioPDF;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.service.IhpMainService;
import br.com.unimedbh.www.Ct_dadosAutorizacao;
import br.com.unimedbh.www.ws.tipos.Ws_respostaCobertura;
import br.gov.ans.www.padroes.tiss.schemas.Ct_itemSolicitacao;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

public class NovoAtendimentoService extends IhpMainService {
	private DataUtil dataUtil = new DataUtil();
	int i = 0;
	int examePaiAnterior = 0;
	int examePaiAtual = 0;
	int qntSolicitada = 0;

	public NovoAtendimentoService(final HttpServletRequest request) throws Exception {
		super(request);
	}

	public InputStream gerarRelatorioGA(final CriarPedidoResult parCriarPedidoResult,
			final Ws_respostaCobertura parWs_respostaCobertura, final Ct_dadosAutorizacao parLocalCt_dadosAutorizacao,
			final ServletContext parServletContext, final String pathArquivoReport,
			final List<ConsultaQuestionarioExameResult> questionariosExamesResult) throws RegraNegocioException {
		final ProcedimentoRelatorioGATO procedimentoRelatorioGATO = new ProcedimentoRelatorioGATO();
		final Map<String, Object> informacoesRelatorioGA = new HashMap<>();
		try {
			int i = 0;
			// LISTA DE EXAMES
			final List<ProcedimentoRelatorioGATO> procedimentosRelatorioGATO = new ArrayList<>();
			final List<ProcedimentoRelatorioGATO> procedimentosRelatorioGATOExcecao = new ArrayList<>();
			final List<ProcedimentoRelatorioGATO> procedimentosRelatorioGATOAux = new ArrayList<>();
			informacoesRelatorioGA.put("registroANS", parLocalCt_dadosAutorizacao.getIdentificacaoAutorizacao()
					.getIdentificacaoFontePagadora().getRegistroANS());
			informacoesRelatorioGA.put("dataAutorizacao", dataUtil.formatarStringParaStringBR(
					parLocalCt_dadosAutorizacao.getDadosAutorizacao().getDataAutorizacao()));
			informacoesRelatorioGA.put("senhaAutorizacao",
					parLocalCt_dadosAutorizacao.getDadosAutorizacao().getSenhaAutorizacao());
			informacoesRelatorioGA.put("validadeSenha", dataUtil
					.formatarStringParaStringBR(parLocalCt_dadosAutorizacao.getDadosAutorizacao().getValidadeSenha()));
			informacoesRelatorioGA.put("numeroGuiaOperadora",
					parLocalCt_dadosAutorizacao.getIdentificacaoAutorizacao().getNumeroGuiaOperadora());
			informacoesRelatorioGA.put("numeroGuiaPrincipal", "");
			informacoesRelatorioGA.put("numeroGuiaPrestador",
					parLocalCt_dadosAutorizacao.getIdentificacaoAutorizacao().getNumeroGuiaPrestador());
			informacoesRelatorioGA.put("numeroCarteira",
					parWs_respostaCobertura.getRespostaCobertura().getDadosBeneficiario().getNumeroCarteira());
			informacoesRelatorioGA.put("validadeCarteira",
					parWs_respostaCobertura.getRespostaCobertura().getDadosBeneficiario().getValidadeCarteira());
			informacoesRelatorioGA.put("nomeCliente",
					parWs_respostaCobertura.getRespostaCobertura().getDadosBeneficiario().getNomeBeneficiario());
			informacoesRelatorioGA.put("codigoSolicitante",
					parLocalCt_dadosAutorizacao.getSolicitante().getCodigoNaOperadora());
			informacoesRelatorioGA.put("numeroConselho",
					parLocalCt_dadosAutorizacao.getSolicitante().getNumeroConselho().toString());
			informacoesRelatorioGA.put("ufConselho", parLocalCt_dadosAutorizacao.getSolicitante().getUfConselho());
			informacoesRelatorioGA.put("nomeSolicitante",
					parLocalCt_dadosAutorizacao.getSolicitante().getNomeSolicitante());
			informacoesRelatorioGA.put("codigoCBO", parLocalCt_dadosAutorizacao.getSolicitante().getCodigoCBO());
			informacoesRelatorioGA.put("unidade", parCriarPedidoResult.getUnidade().toString());
			informacoesRelatorioGA.put("pedido", parCriarPedidoResult.getPedido().toString());
			informacoesRelatorioGA.put("siglaConselho",
					parLocalCt_dadosAutorizacao.getSolicitante().getSiglaConselho());
			informacoesRelatorioGA.put("dataAutorizacao", dataUtil.formatarStringParaStringBR(
					parLocalCt_dadosAutorizacao.getDadosAutorizacao().getDataAutorizacao()));
			informacoesRelatorioGA.put("indicacaoClinica", parLocalCt_dadosAutorizacao.getIndicacaoClinica());
			informacoesRelatorioGA.put("SUBREPORT_DIR", parServletContext.getRealPath("/WEB-INF/relatorio/"));
			informacoesRelatorioGA.put("path", parServletContext.getRealPath("/WEB-INF/relatorio/image"));
			procedimentosRelatorioGATO.clear();
			for (final Ct_itemSolicitacao ct_itemSolicitacao : parLocalCt_dadosAutorizacao.getProcedimentos()) {
				// if (exameFoiExcluido(ct_itemSolicitacao,)) {
				procedimentosRelatorioGATO.add(procedimentoRelatorioGATO.criarProcedimento(ct_itemSolicitacao,
						questionariosExamesResult, i, parCriarPedidoResult));
				procedimentosRelatorioGATOAux.add(procedimentoRelatorioGATO.criarProcedimento(ct_itemSolicitacao,
						questionariosExamesResult, i, parCriarPedidoResult));
				// } else {
				// procedimentosRelatorioGATOExcecao
				// .add(procedimentoRelatorioGATO.criarProcedimentoExcecao(ct_itemSolicitacao));
				// }
				i++;
			}
			Collections.sort(procedimentosRelatorioGATO);
			informacoesRelatorioGA.put("DATA", new JRBeanCollectionDataSource(procedimentosRelatorioGATO));
			return new RelatorioPDF("GuiaAtendimento", informacoesRelatorioGA, procedimentosRelatorioGATOAux,
					pathArquivoReport, procedimentosRelatorioGATOExcecao).retornarRelatorio();
		} catch (final Exception locExc) {
			throw new RegraNegocioException("Erro ao gerar o relatório de GA");
		}
	}

	public InputStream gerarRelatorioGA(final CriarPedidoResult parCriarPedidoResult,
			final Ws_respostaCobertura parWs_respostaCobertura, final Ct_dadosAutorizacao parLocalCt_dadosAutorizacao,
			final ServletContext parServletContext, final String pathArquivoReport,
			final List<ProcedimentoComExamesTO> procedimentosExcluidos,
			final List<ConsultaQuestionarioExameResult> questionariosExamesResult,
			final List<ProcedimentoComExamesTO> procedimentosComExamesParaGerarPedido, String codigoPrestador,
			String nomeContratado, String cnes) throws RegraNegocioException {
		final ProcedimentoRelatorioGATO procedimentoRelatorioGATO = new ProcedimentoRelatorioGATO();
		final Map<String, Object> informacoesRelatorioGA = new HashMap<>();
		try {
			/*
			 * int i = 0; int examePaiAnterior = 0; int examePaiAtual = 0; int qntSolicitada
			 * = 0;
			 */
			final List<ProcedimentoRelatorioGATO> procedimentosRelatorioGATO = new ArrayList<>();
			final List<ProcedimentoRelatorioGATO> procedimentosRelatorioGATOExcecao = new ArrayList<>();
			final List<ProcedimentoRelatorioGATO> procedimentosRelatorioGATOAux = new ArrayList<>();
			informacoesRelatorioGA.put("registroANS", parLocalCt_dadosAutorizacao.getIdentificacaoAutorizacao()
					.getIdentificacaoFontePagadora().getRegistroANS());
			informacoesRelatorioGA.put("dataAutorizacao", dataUtil.formatarStringParaStringBR(
					parLocalCt_dadosAutorizacao.getDadosAutorizacao().getDataAutorizacao()));
			informacoesRelatorioGA.put("senhaAutorizacao",
					parLocalCt_dadosAutorizacao.getDadosAutorizacao().getSenhaAutorizacao());
			informacoesRelatorioGA.put("validadeSenha", dataUtil
					.formatarStringParaStringBR(parLocalCt_dadosAutorizacao.getDadosAutorizacao().getValidadeSenha()));
			informacoesRelatorioGA.put("numeroGuiaOperadora",
					parLocalCt_dadosAutorizacao.getIdentificacaoAutorizacao().getNumeroGuiaOperadora());
			informacoesRelatorioGA.put("numeroGuiaPrincipal", "");
			informacoesRelatorioGA.put("numeroGuiaPrestador",
					parLocalCt_dadosAutorizacao.getIdentificacaoAutorizacao().getNumeroGuiaPrestador());
			informacoesRelatorioGA.put("numeroCarteira",
					parWs_respostaCobertura.getRespostaCobertura().getDadosBeneficiario().getNumeroCarteira());
			informacoesRelatorioGA.put("validadeCarteira",
					parWs_respostaCobertura.getRespostaCobertura().getDadosBeneficiario().getValidadeCarteira());
			informacoesRelatorioGA.put("nomeCliente",
					parWs_respostaCobertura.getRespostaCobertura().getDadosBeneficiario().getNomeBeneficiario());
			informacoesRelatorioGA.put("codigoSolicitante",
					parLocalCt_dadosAutorizacao.getSolicitante().getCodigoNaOperadora());
			informacoesRelatorioGA.put("numeroConselho",
					parLocalCt_dadosAutorizacao.getSolicitante().getNumeroConselho().toString());
			informacoesRelatorioGA.put("ufConselho", parLocalCt_dadosAutorizacao.getSolicitante().getUfConselho());
			informacoesRelatorioGA.put("nomeSolicitante",
					parLocalCt_dadosAutorizacao.getSolicitante().getNomeSolicitante());
			informacoesRelatorioGA.put("codigoCBO", parLocalCt_dadosAutorizacao.getSolicitante().getCodigoCBO());
			informacoesRelatorioGA.put("unidade", parCriarPedidoResult.getUnidade().toString());
			informacoesRelatorioGA.put("pedido", parCriarPedidoResult.getPedido().toString());
			informacoesRelatorioGA.put("siglaConselho",
					parLocalCt_dadosAutorizacao.getSolicitante().getSiglaConselho());
			informacoesRelatorioGA.put("dataAutorizacao", dataUtil.formatarStringParaStringBR(
					parLocalCt_dadosAutorizacao.getDadosAutorizacao().getDataAutorizacao()));
			informacoesRelatorioGA.put("indicacaoClinica", parLocalCt_dadosAutorizacao.getIndicacaoClinica());

			informacoesRelatorioGA.put("cnes", cnes);
			informacoesRelatorioGA.put("nomeContratado", nomeContratado);
			informacoesRelatorioGA.put("codigoOperadora", codigoPrestador);

			informacoesRelatorioGA.put("SUBREPORT_DIR", parServletContext.getRealPath("/WEB-INF/relatorio/"));
			informacoesRelatorioGA.put("path", parServletContext.getRealPath("/WEB-INF/relatorio/image"));
			procedimentosRelatorioGATO.clear();

			for (final Ct_itemSolicitacao ct_itemSolicitacao : parLocalCt_dadosAutorizacao.getProcedimentos()) {
				if (exameNaoFoiExcluido(ct_itemSolicitacao, procedimentosExcluidos)) {
					List<ProcedimentoComExamesTO> listaProcedimentosPorItem = new ArrayList<>();
					listaProcedimentosPorItem = procedimentosComExamesParaGerarPedido.stream()
							.filter(procedimento -> ct_itemSolicitacao.getIdentificacaoProcedimentos().getCodigo()
									.equals(procedimento.getProcedimento()))
							.collect(Collectors.toList());
					procedimentosRelatorioGATO
							.add(new ProcedimentoRelatorioGATO(ct_itemSolicitacao, listaProcedimentosPorItem, false));
				} else {
					List<ProcedimentoComExamesTO> listaProcedimentosExcluidosPorItem = new ArrayList<>();
					listaProcedimentosExcluidosPorItem = procedimentosExcluidos.stream()
							.filter(procedimento -> ct_itemSolicitacao.getIdentificacaoProcedimentos().getCodigo()
									.equals(procedimento.getProcedimento()))
							.collect(Collectors.toList());
					procedimentosRelatorioGATO.add(new ProcedimentoRelatorioGATO(ct_itemSolicitacao,
							listaProcedimentosExcluidosPorItem, true));
				}
				/*
				 * if (exameNaoFoiExcluido(ct_itemSolicitacao, procedimentosExcluidos)) { //
				 * Relatorio breno if (ct_itemSolicitacao.getQuantidadeAutorizada().intValue() >
				 * 1) { qntSolicitada = ct_itemSolicitacao.getQuantidadeAutorizada().intValue()
				 * - 1; procedimentosRelatorioGATO.add(procedimentoRelatorioGATO.
				 * criarProcedimento2ouMais( ct_itemSolicitacao, questionariosExamesResult, i,
				 * qntSolicitada)); // TESTE ELLEN MAIA - PASSAR AQUI P
				 * procedimentosRelatorioGATOAux.add(procedimentoRelatorioGATO
				 * .criarProcedimento2ouMais(ct_itemSolicitacao, questionariosExamesResult, i,
				 * qntSolicitada)); // teste // ellen // maia i += qntSolicitada; } else {
				 * procedimentosRelatorioGATO.add(procedimentoRelatorioGATO.criarProcedimento(
				 * ct_itemSolicitacao, questionariosExamesResult, i, parCriarPedidoResult)); //
				 * TESTE ELLEN MAIA - PASSAR // AQUI P
				 * procedimentosRelatorioGATOAux.add(procedimentoRelatorioGATO.
				 * criarProcedimento( ct_itemSolicitacao, questionariosExamesResult, i,
				 * parCriarPedidoResult)); // teste ellen maia } //
				 * procedimentosRelatorioGATO.add(procedimentoRelatorioGATO.criarProcedimento(
				 * ct_itemSolicitacao, // questionariosExamesResult, i)); // TESTE ELLEN MAIA -
				 * PASSAR AQUI P // procedimentosRelatorioGATOAux.add(procedimentoRelatorioGATO.
				 * criarProcedimento( ct_itemSolicitacao, // questionariosExamesResult, i)); //
				 * teste ellen maia } else { procedimentosRelatorioGATO
				 * .add(procedimentoRelatorioGATO.criarProcedimentoQueFoiExcluido(
				 * ct_itemSolicitacao, questionariosExamesResult, i, parCriarPedidoResult)); //
				 * teste ellen maia procedimentosRelatorioGATOAux
				 * .add(procedimentoRelatorioGATO.criarProcedimentoQueFoiExcluido(
				 * ct_itemSolicitacao, questionariosExamesResult, i, parCriarPedidoResult)); //
				 * teste ellen maia i--; } i++;
				 */

				verificarPosicaoQuandoHaPacoteDeExames(questionariosExamesResult);
			}

			Collections.sort(procedimentosRelatorioGATO);
			informacoesRelatorioGA.put("DATA", new JRBeanCollectionDataSource(procedimentosRelatorioGATO));
			return new RelatorioPDF("GuiaAtendimento", informacoesRelatorioGA, procedimentosRelatorioGATO,
					pathArquivoReport, procedimentosRelatorioGATOExcecao).retornarRelatorio();
		} catch (final Exception locExc) {
			throw new RegraNegocioException("Erro ao gerar o relatório de GA");
		}
	}

	public void verificarPosicaoQuandoHaPacoteDeExames(
			final List<ConsultaQuestionarioExameResult> questionariosExamesResult) {
		if (i < questionariosExamesResult.size()) {
			if (questionariosExamesResult.get(i).getExamePAI() != null) {
				examePaiAnterior = examePaiAtual;
				examePaiAtual = 1;
				if (examePaiAnterior == 1 && examePaiAtual == 1) {
					while (i < questionariosExamesResult.size()
							&& questionariosExamesResult.get(i).getExamePAI() != null) {
						i++;
					}
					i++; // Ele desmembra os filhos mas não coloca o valor do pai
					examePaiAnterior = 0;
					examePaiAtual = 0;
				}
			}
		}
	}

	private boolean exameNaoFoiExcluido(final Ct_itemSolicitacao parCt_itemSolicitacao,
			final List<ProcedimentoComExamesTO> procedimentos) {
		for (final ProcedimentoComExamesTO locProcedimentoComExamesTO : procedimentos) {
			if (parCt_itemSolicitacao.getIdentificacaoProcedimentos().getCodigo()
					.equals(locProcedimentoComExamesTO.getProcedimento())) {
				return false;
			}
		}
		return true;
	}

	private boolean exameFoiAutorizado(final Ct_itemSolicitacao parCt_itemSolicitacao) {
		return parCt_itemSolicitacao.getQuantidadeAutorizada().compareTo(new BigDecimal(0)) == 1;
	}

	public String retornarEnderecoBiometria(final Localidade parLocalidade) throws RegraNegocioException {
		try {
			if (parLocalidade != null) {
				final StringBuilder sb = new StringBuilder();
				sb.append(getEndPoint("ENDPOINT_IHP_BIOMETRIA_UNIMED"));
				sb.append("&codPrestador=").append(parLocalidade.getCodigounimed());
				sb.append("&codLocal=").append(retornaCodigoLocal(parLocalidade));
				sb.append("&realizarDiagnostico=").append("n");
				sb.append("&pathSslConfig=")
						.append(Constantes.PARAM_APPLET_DIRETORIO_RETORNO_WINDOWS + "/sslConfig.properties");
				sb.append("&exibirProtocolo=").append("n");
				sb.append("&urlWebService=").append(getEndPoint("ENDPOINT_IHP_BIOMETRIA_UNIMED_URL_WEBSERVICE"));
				sb.append("&diretorioRetorno=").append(Constantes.PARAM_APPLET_DIRETORIO_RETORNO_WINDOWS);
				return sb.toString();
			}
			return "";
		} catch (final Exception locExc) {
			throw new RegraNegocioException(locExc.getMessage());
		}
	}

	private String retornaCodigoLocal(final Localidade parLocalidade) {
		try {
			return parLocalidade.retornarCodigoLocal(retornarCodigoLocalidade(parLocalidade));
		} catch (final Exception e) {
			return null;
		}
	}

	@Deprecated
	public String retornarEnderecoBiometria(final Unidade parUnidade) throws RegraNegocioException {
		try {
			if (parUnidade != null) {
				final StringBuilder sb = new StringBuilder();
				sb.append(getEndPoint("ENDPOINT_IHP_BIOMETRIA_UNIMED"));
				sb.append("&codPrestador=").append(parUnidade.getUnimedBH().getCodigoPrestadorUnimed());
				sb.append("&codLocal=").append(retornaCodgioLocal(parUnidade));
				sb.append("&realizarDiagnostico=").append("n");
				sb.append("&pathSslConfig=")
						.append(Constantes.PARAM_APPLET_DIRETORIO_RETORNO_WINDOWS + "/sslConfig.properties");
				sb.append("&exibirProtocolo=").append("n");
				sb.append("&urlWebService=").append(getEndPoint("ENDPOINT_IHP_BIOMETRIA_UNIMED_URL_WEBSERVICE"));
				sb.append("&diretorioRetorno=").append(Constantes.PARAM_APPLET_DIRETORIO_RETORNO_WINDOWS);
				return sb.toString();
			}
			return "";
		} catch (final Exception locExc) {
			throw new RegraNegocioException(locExc.getMessage());
		}
	}

	private String retornaCodgioLocal(final Unidade parUnidade) {
		try {
			return Constantes.PARAM_INICAL_LOCAL_ATENDIMENTO + parUnidade.getUnimedBH().getUnbh();
		} catch (final Exception e) {
			return null;
		}
	}

	private String retornarCodigoLocalidade(Localidade parLocalidade) {
		if (parLocalidade != null) {
			if (Util.isTotemAim33()) {
				return "13667";
			} else {
				return parLocalidade.getCodigounidade();
			}
		}
		return "";
		
	}
}
