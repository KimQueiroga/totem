package br.com.hermespardini.passelivre.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import javax.servlet.http.HttpServletRequest;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.exception.DownloadUnimedException;
import br.com.hermespardini.passelivre.to.ParametroAplicacaoDto;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.service.IhpMainService;
import sun.misc.BASE64Encoder;

public class BaixarGuiaUnimedService extends IhpMainService {

	final String parGuia = "&idSolic=";
	String authString;

	public BaixarGuiaUnimedService(HttpServletRequest parRequest) throws Exception {
		super(parRequest);
		// TODO Auto-generated constructor stub
	}

	public InputStream baixarGuiaUnimed(String senhaGuia, boolean ecoar) throws Exception {

		InputStream InputFile = null;
		try {
			ParametroService parametroService = new ParametroService(super.getRequest());
			ParametroAplicacaoDto usuario = null;
			ParametroAplicacaoDto senha = null;
			if (ecoar) {
				parametroService.buscarParametro(Constantes.CHAVE_USER_ECOAR_SERVICE);
				usuario = (ParametroAplicacaoDto) parametroService.getResponseObject();
				parametroService.buscarParametro(Constantes.CHAVE_SENHA_ECOAR_SERVICE);
				senha = (ParametroAplicacaoDto) parametroService.getResponseObject();
			} else {
				parametroService.buscarParametro(Constantes.CHAVE_USER_UNIMED_SERVICE);
				usuario = (ParametroAplicacaoDto) parametroService.getResponseObject();
				parametroService.buscarParametro(Constantes.CHAVE_SENHA_UNIMED_SERVICE);
				senha = (ParametroAplicacaoDto) parametroService.getResponseObject();
			}
			authString = usuario.getValorAplicacao().getValor() + ":" + senha.getValorAplicacao().getValor();
			String authStringEnc = new BASE64Encoder().encode(authString.getBytes());

			Client restClient = Client.create();

			WebResource webResource = restClient
					.resource(getEndPoint("ENDPOINT_BAIXAR_GUIA_UNIMED") + parGuia + senhaGuia);

			ClientResponse resp = webResource.accept("application/pdf")
					.header("Authorization", "Basic " + authStringEnc).get(ClientResponse.class);

			if (resp.getStatus() == 200) {

				File file = resp.getEntity(File.class);

				InputFile = new FileInputStream(file);
			} else {
				throw new DownloadUnimedException("Status retorno: "+resp.getStatus()+". Num guia: "+senhaGuia);
			}
		} catch (Exception exe) {

			 if (exe instanceof DownloadUnimedException) {
					throw exe;
			 } else {
					throw new Exception(exe.getMessage());
			 }
		}
		return InputFile;

	}
}
