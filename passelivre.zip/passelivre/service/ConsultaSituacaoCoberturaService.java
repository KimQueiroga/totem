package br.com.hermespardini.passelivre.service;

import java.math.BigInteger;
import java.rmi.RemoteException;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.wdelmaschio.base.view.Service;

import br.com.hermespardini.commons.texto.TextoUtils;
import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.utils.DataUtil;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.service.IhpMainService;
import br.com.unimedbh.www.schemas.Ct_solicitante;
import br.com.unimedbh.www.schemas.Ct_verificacaoCobertura;
import br.com.unimedbh.www.schemas.St_tipoTransacao;
import br.com.unimedbh.www.ws.tipos.DestinatarioInvalido;
import br.com.unimedbh.www.ws.tipos.HashInvalido;
import br.com.unimedbh.www.ws.tipos.RemetenteInvalido;
import br.com.unimedbh.www.ws.tipos.UnimedbhConsultaSituacaoCobertura_PortTypeProxy;
import br.com.unimedbh.www.ws.tipos.VersaoInvalida;
import br.com.unimedbh.www.ws.tipos.Ws_consultaSituacaoCobertura;
import br.com.unimedbh.www.ws.tipos.Ws_respostaCobertura;
import br.gov.ans.www.padroes.tiss.schemas.Ct_beneficiario;
import br.gov.ans.www.padroes.tiss.schemas.Ct_contratadoSolicitante;
import br.gov.ans.www.padroes.tiss.schemas.Ct_identificacaoPrestador;

public class ConsultaSituacaoCoberturaService extends IhpMainService {

	private DataUtil dataUtil = new DataUtil();

	public ConsultaSituacaoCoberturaService(final HttpServletRequest parRequest) throws Exception {
		super(parRequest);
	}

	public Ws_respostaCobertura consultar(final Ws_consultaSituacaoCobertura parWsConsultaSituacaoCobertura)
			throws HashInvalido, RemetenteInvalido, VersaoInvalida, DestinatarioInvalido, RemoteException,
			ParseException {
		final UnimedbhConsultaSituacaoCobertura_PortTypeProxy proxy = criarProxParaConsulta();
		return proxy.unimedbhConsultaSituacaoCobertura_Operation(parWsConsultaSituacaoCobertura);
	}

	private UnimedbhConsultaSituacaoCobertura_PortTypeProxy criarProxParaConsulta() {
		return new UnimedbhConsultaSituacaoCobertura_PortTypeProxy(
				getEndPoint("ENDPOINT_SERVICE_UNIMED") + "/ws-ConsultaSituacaoCobertura");
	}

	public Ws_consultaSituacaoCobertura adicionarValoresAConsulta(final Ct_beneficiario beneficiario)
			throws ParseException {

		final br.com.unimedbh.www.schemas.CabecalhoTransacao cabecalho = montarCabecalhoTransacao();

		final Ws_consultaSituacaoCobertura wsConsulta = new Ws_consultaSituacaoCobertura();

		wsConsulta.setCabecalho(cabecalho);

		wsConsulta.setVerificaCobertura(montarVerificaCobertura(beneficiario));

		final String valorDeClasse = retornarValor(wsConsulta);

		wsConsulta.setHash(TextoUtils.gerarHashDoTexto(valorDeClasse));
		return wsConsulta;
	}

	private String retornarValor(final Ws_consultaSituacaoCobertura parWsConsulta) {
		final StringBuilder sb = new StringBuilder();

		sb.append(parWsConsulta.getCabecalho().getIdentificacaoTransacao().getTipoTransacao())
				.append(parWsConsulta.getCabecalho().getIdentificacaoTransacao().getSequencialTransacao())
				.append(dataUtil.formatarDateParaString(
						parWsConsulta.getCabecalho().getIdentificacaoTransacao().getDataRegistroTransacao()))
				.append(parWsConsulta.getCabecalho().getIdentificacaoTransacao().getHoraRegistroTransacao())
				.append(parWsConsulta.getCabecalho().getOrigem().getCodigoPrestadorNaOperadora()
						.getCodigoPrestadorNaOperadora())
				.append(parWsConsulta.getCabecalho().getDestino().getRegistroANS())
				.append(parWsConsulta.getCabecalho().getVersaoPadrao())
				.append(parWsConsulta.getVerificaCobertura().getDadosBeneficiario().getNumeroCarteira())
				.append(parWsConsulta.getVerificaCobertura().getDadosSolicitante().getContratado().getIdentificacao()
						.getCodigoPrestadorNaOperadora());
		return sb.toString();
	}

	private Ct_verificacaoCobertura montarVerificaCobertura(final Ct_beneficiario beneficiario) {
		final Ct_verificacaoCobertura verificacaoCobertura = new Ct_verificacaoCobertura(beneficiario,
				monstarDadosSolicitantes(), null);
		return verificacaoCobertura;
	}

	private Ct_solicitante monstarDadosSolicitantes() {
		final Ct_solicitante solicitante = new Ct_solicitante(montarContratoSolicitante(), null);
		return solicitante;
	}

	private Ct_contratadoSolicitante montarContratoSolicitante() {
		final Ct_contratadoSolicitante contratoSolicitante = new Ct_contratadoSolicitante(montarIdentificacao(), "",
				null, null);
		return contratoSolicitante;
	}

	private Ct_identificacaoPrestador montarIdentificacao() {
		final Ct_identificacaoPrestador identificacaoPrestador = new Ct_identificacaoPrestador(null, null,
				getRequest().getSession().getAttribute("codigoPrestadorUnimed").toString(), null);
		return identificacaoPrestador;
	}

	private br.com.unimedbh.www.schemas.CabecalhoTransacao montarCabecalhoTransacao() throws ParseException {

		final java.util.Date dataRegistroTransacao = retornarDataCorrente();

		final BigInteger squencialTransacao = new BigInteger("1");

		final org.apache.axis.types.Time horaRegistroTransacao = new org.apache.axis.types.Time(
				Constantes.HORARIO_DEFAULT);

		final br.com.unimedbh.www.schemas.CabecalhoTransacaoIdentificacaoTransacao identificacaoTransacao = new br.com.unimedbh.www.schemas.CabecalhoTransacaoIdentificacaoTransacao(
				St_tipoTransacao.SOLIC_SITUACAO_COBERTURA, squencialTransacao, dataRegistroTransacao,
				horaRegistroTransacao);

		final br.com.unimedbh.www.schemas.CabecalhoTransacaoOrigem origem = new br.com.unimedbh.www.schemas.CabecalhoTransacaoOrigem();

		final br.gov.ans.www.padroes.tiss.schemas.Ct_identificacaoPrestadorExecutante ct_identificacaoPrestadorExecutante = new br.gov.ans.www.padroes.tiss.schemas.Ct_identificacaoPrestadorExecutante(
				null, null, getRequest().getSession().getAttribute("codigoPrestadorUnimed").toString());

		origem.setCodigoPrestadorNaOperadora(ct_identificacaoPrestadorExecutante);

		final br.gov.ans.www.padroes.tiss.schemas.Ct_identificacaoSoftwareGerador ct_identificacaoSoftwareGerador = new br.gov.ans.www.padroes.tiss.schemas.Ct_identificacaoSoftwareGerador(
				"", "", "");

		final br.com.unimedbh.www.schemas.CabecalhoTransacaoDestino destino = new br.com.unimedbh.www.schemas.CabecalhoTransacaoDestino(
				null, Constantes.REGISTRO_ANS, null);

		final br.com.unimedbh.www.schemas.CabecalhoTransacao cabecalho = new br.com.unimedbh.www.schemas.CabecalhoTransacao(
				identificacaoTransacao, null, origem, destino, Constantes.VERSAO_DEFAULT,
				ct_identificacaoSoftwareGerador);

		return cabecalho;
	}

	private java.util.Date retornarDataCorrente() {
		final Calendar dataAtual = Calendar.getInstance();
		dataAtual.setTime(new Date());
		dataAtual.set(Calendar.HOUR_OF_DAY, 11);
		dataAtual.set(Calendar.MINUTE, 0);
		dataAtual.set(Calendar.SECOND, 0);
		dataAtual.set(Calendar.MILLISECOND, 0);

		return dataAtual.getTime();
	}

}
