package br.com.hermespardini.passelivre.service;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.exception.PagamentoException;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.model.EPacoteResult;
import br.com.hermespardini.passelivre.model.ParametroExamePacote;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.service.IhpMainService;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class ExamePacoteService extends IhpMainService {

	public ExamePacoteService(final HttpServletRequest parRequest) throws Exception {
		super(parRequest);
	}

	public void buscarExamesFilhosfinal(final ParametroExamePacote parametroExamePacote) throws PagamentoException {
		final Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
		final String input = gson.toJson(parametroExamePacote);
		final OkHttpClient client = new OkHttpClient.Builder()
				.connectTimeout(Constantes.TIMEOUT_CONSULTA_EXAMES, TimeUnit.SECONDS)
				.writeTimeout(Constantes.TIMEOUT_CONSULTA_EXAMES, TimeUnit.SECONDS)
				.readTimeout(Constantes.TIMEOUT_CONSULTA_EXAMES, TimeUnit.SECONDS).build();
		final MediaType json = MediaType.parse(Constantes.TYPE_JSON);
		final RequestBody body = RequestBody.create(json, input);
		final Request request = new Request.Builder().url(getEndPoint("ENDPOINT_IHP_EXAME_E_PACOTE")).post(body)
				.build();
		Response locResponse = null;
		JSONObject locJsonObject = new JSONObject();
		try {
			locResponse = client.newCall(request).execute();
			final String locJsonData = locResponse.body().string();
			verificarSeEhUmCoteudoValido(locJsonData);
			locJsonObject = new JSONObject(locJsonData);
			final EPacoteResult result = gson.fromJson(locJsonObject.getJSONObject("EPacoteResult").toString(),
					EPacoteResult.class);
			final Integer status = Integer.parseInt(result.getStatus());
			verificarRespostaAoRealizarBuscaExames(locResponse, result, status);
		} catch (final Exception locExc) {
			failed();
			setResponseMessage(locExc.getMessage());
			throw new PagamentoException(locExc.getMessage());
		} finally {
			if (locResponse != null) {
				locResponse.close();
			}
			if (client != null) {
				client.connectionPool().evictAll();
			}
		}
	}

	private void verificarSeEhUmCoteudoValido(final String parJsonData) throws IOException, RegraNegocioException {
		if (Util.verificarSeConteudoEhXML(parJsonData)) {
			failed();
			setResponseMessage(parJsonData);
			throw new RegraNegocioException(parJsonData);
		}
	}

	private void verificarRespostaAoRealizarBuscaExames(final Response parResponse, final EPacoteResult parResult,
			final Integer parStatus) throws PagamentoException {
		if (parResponse.isSuccessful() && parStatus == 0) {
			setResponseObject(parResult);
		} else {
			failed();
			final String mensagem = parResult.getMensagem();
			setResponseMessage(mensagem);
			throw new PagamentoException(mensagem);
		}
	}

}
