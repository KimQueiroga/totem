package br.com.hermespardini.passelivre.service;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONObject;
import org.wdelmaschio.base.view.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.model.ExcecaoAtendimentoResult;
import br.com.hermespardini.passelivre.model.ParametroExcecaoAtendimento;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.service.IhpMainService;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class ExcecaoAtendimentoService extends IhpMainService {

	public ExcecaoAtendimentoService(final HttpServletRequest parRequest) throws Exception {
		super(parRequest);
	}

	public void retornarExcecao(final ParametroExcecaoAtendimento parametroExcecaoAtendimento)
			throws RegraNegocioException {
		final Gson gson = new Gson();
		final String input = gson.toJson(parametroExcecaoAtendimento);
		final OkHttpClient client = new OkHttpClient();
		final MediaType json = MediaType.parse(Constantes.TYPE_JSON);
		final RequestBody body = RequestBody.create(json, input);
		final Request request = new Request.Builder().url(getEndPoint("ENDPOINT_IHP_EXCECAO_ATENDIMENTO")).post(body)
				.build();
		Response locResponse = null;
		try {
			JSONObject locJsonObject = new JSONObject();
			locResponse = client.newCall(request).execute();
			final String locJsonData = locResponse.body().string();
			verificarSeEhUmCoteudoValido(locJsonData);
			locJsonObject = new JSONObject(locJsonData);
			if (locResponse.isSuccessful()) {
				final ObjectMapper jsonMapper = new ObjectMapper();
				final ExcecaoAtendimentoResult result = gson.fromJson(
						locJsonObject.getJSONObject("ExcecaoAtendimentoResult").toString(),
						ExcecaoAtendimentoResult.class);
				if (result == null) {
					failed();
					setResponseMessage(result.getMensagem());
				} else {
					if ("0".equals(result.getStatus())) {
						setResponseObject(result);
					} else {
						failed();
						setResponseMessage(result.getMensagem());
					}
				}
			}
		} catch (final Exception locExc) {
			failed();
			throw new RegraNegocioException(locExc.getMessage());
		} finally {
			if (locResponse != null) {
				locResponse.close();
			}
			if (client != null) {
				client.connectionPool().evictAll();
			}
		}
	}

	private void verificarSeEhUmCoteudoValido(final String parJsonData) throws IOException, RegraNegocioException {
		if (Util.verificarSeConteudoEhXML(parJsonData)) {
			failed();
			setResponseMessage(parJsonData);
			throw new RegraNegocioException(parJsonData);
		}
	}
}
