package br.com.hermespardini.passelivre.service;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONObject;

import com.google.gson.Gson;

import br.com.hermespardini.passelivre.model.ParametroImpressao;
import br.com.hermespardini.passelivre.model.ResultadoResult;
import br.com.hermespardini.web.service.IhpMainService;
import okhttp3.Response;

public class FazImpressaoService extends IhpMainService {

	public FazImpressaoService(final HttpServletRequest parRequest) throws Exception {
		super(parRequest);
	}

	public void imprimirResultado(final ParametroImpressao parametroImpressao) throws Exception {
		Response response = null;
		try {
			final Gson gson = new Gson();
			final String input = gson.toJson(parametroImpressao);
			final ResultadoResult resultadoResult = new ResultadoResult();
			response = executePost(getEndPoint("ENDPOINT_IHP_IMPRESSAO_RESULTADO"), parametroImpressao);
			final String locJsonData = response.body().string();
			final JSONObject locJsonObject = new JSONObject(locJsonData);
			final ResultadoResult result = gson.fromJson(locJsonObject.getJSONObject("ResultadoResult").toString(),
					ResultadoResult.class);
			if (result != null) {
				if (result.getStatus().equals("0")) {
					setResponseObject(result);
				} else {
					failed();
					setResponseMessage(result.getMensagem());
				}
			} else {
				failed();
				setResponseMessage(response.message());
			}
		} catch (final Exception locExc) {
			setResponseMessage(locExc.getMessage());
			failed();
		} finally {
			if (response != null) {
				response.close();
			}
		}
	}

}
