package br.com.hermespardini.passelivre.service;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONObject;
import org.wdelmaschio.base.view.Service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.model.ConsultaMaterialPendenteResult;
import br.com.hermespardini.passelivre.model.EntregaMaterialPendenteResult;
import br.com.hermespardini.passelivre.model.ParametroEntregaMaterial;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.service.IhpMainService;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MaterialPendenteService extends IhpMainService {
	private Util util = new Util();
	private String mensagem;

	public MaterialPendenteService(final HttpServletRequest parRequest) throws Exception {
		super(parRequest);
	}

	public void entregar(final ParametroEntregaMaterial pedidoEntrega) throws Exception {
		final Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
		final String input = gson.toJson(pedidoEntrega);
		final OkHttpClient client = new OkHttpClient.Builder()
				.connectTimeout(Constantes.TIMEOUT_ENGREGA_MATERIAL_PENDENTE, TimeUnit.SECONDS)
				.writeTimeout(Constantes.TIMEOUT_ENGREGA_MATERIAL_PENDENTE, TimeUnit.SECONDS)
				.readTimeout(Constantes.TIMEOUT_ENGREGA_MATERIAL_PENDENTE, TimeUnit.SECONDS).build();
		final MediaType json = MediaType.parse(Constantes.TYPE_JSON);
		final RequestBody body = RequestBody.create(json, input);
		final Request request = new Request.Builder().url(getEndPoint("ENDPOINT_IHP_MATERIAL_PENDENTE_REGISTRA"))
				.post(body).build();
		Response locResponse = null;
		JSONObject locJsonObject = new JSONObject();
		try {
			locResponse = client.newCall(request).execute();
			final String locJsonData = locResponse.body().string();
			verificarSeEhUmCoteudoValido(locJsonData);
			locJsonObject = new JSONObject(locJsonData);
			final EntregaMaterialPendenteResult result = gson.fromJson(
					locJsonObject.getJSONObject("EntregaMaterialPendenteResult").toString(),
					EntregaMaterialPendenteResult.class);
			if (result == null) {
				failed();
				setResponseMessage(result.getMensagem());
			} else {
				if ("0".equals(result.getStatus())) {
					setResponseObject(result);
				} else {
					failed();
					setResponseMessage(result.getMensagem());
				}
			}
		} catch (final Exception locExc) {
			setResponseMessage(locExc.getMessage());
			failed();
			throw new Exception(locExc.getMessage());
		} finally {
			if (locResponse != null) {
				locResponse.close();
			}
			if (client != null) {
				client.connectionPool().evictAll();
			}
		}
	}

	private void verificarSeEhUmCoteudoValido(final String parJsonData) throws IOException, RegraNegocioException {
		if (Util.verificarSeConteudoEhXML(parJsonData)) {
			failed();
			setResponseMessage(parJsonData);
			throw new RegraNegocioException(parJsonData);
		}
	}

	public void consultar() throws RegraNegocioException {
		final Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
		final String input = gson.toJson(getValueObject());
		
		final OkHttpClient client = new OkHttpClient.Builder()
			    .connectTimeout(30, TimeUnit.SECONDS)
			    .writeTimeout(30, TimeUnit.SECONDS)
			    .readTimeout(30, TimeUnit.SECONDS)
			    .build();			
		
		final MediaType json = MediaType.parse(Constantes.TYPE_JSON);
		final RequestBody body = RequestBody.create(json, input);
		final Request request = new Request.Builder().url(getEndPoint("ENDPOINT_IHP_MATERIAL_PENDENTE_CONSULTA"))
				.post(body).build();
		Response locResponse = null;
		JSONObject locJsonObject = new JSONObject();
		try {
			locResponse = client.newCall(request).execute();
			final String locJsonData = locResponse.body().string();
			verificarSeEhUmCoteudoValido(locJsonData);
			locJsonObject = new JSONObject(locJsonData);
			if (locResponse.isSuccessful()) {
				final ConsultaMaterialPendenteResult result = gson.fromJson(
						locJsonObject.getJSONObject("ConsultaMaterialPendenteResult").toString(),
						ConsultaMaterialPendenteResult.class);
				mensagem = Util.retirarCaracterEspecial(result.getMensagem());
				setResponseMessage(mensagem);
				if (result == null) {
					failed();
					setResponseMessage(result.getMensagem());
				} else {
					if ("0".equals(result.getStatus())) {
						setResponseObject(result);
					} else {
						failed();
						setResponseMessage(result.getMensagem());
					}
				}
			}
		} catch (final Exception locExc) {
			failed();
			throw new RegraNegocioException(locExc.getMessage());
		} finally {
			if (locResponse != null) {
				locResponse.close();
			}
			if (client != null) {
				client.connectionPool().evictAll();
			}
		}
	}
}
