package br.com.hermespardini.passelivre.service;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONObject;

import com.google.gson.Gson;

import br.com.hermespardini.passelivre.model.ConfiguracaoImpressoraResult;
import br.com.hermespardini.passelivre.model.ParametroInformacaoImpressora;
import br.com.hermespardini.passelivre.model.ResultadoResult;
import br.com.hermespardini.web.service.IhpMainService;
import okhttp3.Response;

public class ConfiguracaoImpressoraService extends IhpMainService {

	public ConfiguracaoImpressoraService(final HttpServletRequest parRequest) throws Exception {
		super(parRequest);
	}

	public void retornarInformacoes(final ParametroInformacaoImpressora parametroInformacaoImpressora) {
		Response response = null;
		try {
			final Gson gson = new Gson();
			final String input = gson.toJson(parametroInformacaoImpressora);
			final ResultadoResult resultadoResult = new ResultadoResult();
			response = executePost(getEndPoint("ENDPOINT_IHP_CONFIGURACAO_IMPRESSORA"), parametroInformacaoImpressora);
			final String locJsonData = response.body().string();
			final JSONObject locJsonObject = new JSONObject(locJsonData);
			final ConfiguracaoImpressoraResult result = gson.fromJson(
					locJsonObject.getJSONObject("ConfiguracaoImpressoraResult").toString(),
					ConfiguracaoImpressoraResult.class);
			if (result != null) {
				if (result.getStatus().equals("0")) {
					setResponseObject(result);
				} else {
					failed();
					setResponseMessage(result.getMensagem());
				}
			} else {
				failed();
				setResponseMessage(response.message());
			}
		} catch (final Exception locExc) {
			setResponseMessage(locExc.getMessage());
			failed();
		} finally {
			if (response != null) {
				if (response != null) {
					response.close();
				}
			}
		}
	}
}
