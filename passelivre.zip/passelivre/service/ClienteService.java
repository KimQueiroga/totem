package br.com.hermespardini.passelivre.service;

import java.io.IOException;
import java.net.SocketTimeoutException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;

import org.apache.http.conn.ConnectTimeoutException;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.constantsenum.TimeOutErrorCodeEnum;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.interfaces.FormataCampo;
import br.com.hermespardini.passelivre.model.ClienteUnidadePasseLivre;
import br.com.hermespardini.passelivre.model.ConsultaMatriculaResult;
import br.com.hermespardini.passelivre.model.ConsultaResult;
import br.com.hermespardini.passelivre.model.NaoSouEuResult;
import br.com.hermespardini.passelivre.model.Paciente;
import br.com.hermespardini.passelivre.model.ParametroConsultaCliente;
import br.com.hermespardini.passelivre.model.ParametroConsultaClienteGuiche;
import br.com.hermespardini.passelivre.model.ParametroConsultaMatricula;
import br.com.hermespardini.passelivre.model.ParametroNaoSouEu;
import br.com.hermespardini.passelivre.model.ParametroRegistraCliente;
import br.com.hermespardini.passelivre.model.RegistraResult;
import br.com.hermespardini.passelivre.utils.DataUtil;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.service.IhpMainService;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class ClienteService extends IhpMainService {

	private String mensagem;
	private DataUtil dataUtil;
	private Util util = new Util();
	private FormataCampo formataCampo;

	public ClienteService(final HttpServletRequest parRequest) throws Exception {
		super(parRequest);
		dataUtil = new DataUtil();
	}

	public void atualizar() {
		ClienteUnidadePasseLivre clienteUnidadePasseLivre = new ClienteUnidadePasseLivre();
		clienteUnidadePasseLivre = (ClienteUnidadePasseLivre) getValueObject();
		final Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
		final String input = gson.toJson(getValueObject());
		final OkHttpClient client = new OkHttpClient.Builder()
				.connectTimeout(Constantes.TIMEOUT_ATUALIZAR_DADOS, TimeUnit.SECONDS)
				.writeTimeout(Constantes.TIMEOUT_ATUALIZAR_DADOS, TimeUnit.SECONDS)
				.readTimeout(Constantes.TIMEOUT_ATUALIZAR_DADOS, TimeUnit.SECONDS).build();
		final MediaType json = MediaType.parse(Constantes.TYPE_JSON);
		final RequestBody body = RequestBody.create(json, input);
		final Request request = new Request.Builder().addHeader("X-Hp-Auth-Token", clienteUnidadePasseLivre.getId())
				.url(getEndPoint("ENDPOINT_IHP_CLIENTE")).put(body).build();
		Response locResponse = null;
		JSONObject locJsonObject = new JSONObject();
		try {
			locResponse = client.newCall(request).execute();
			final String locJsonData = locResponse.body().string();
			verificarSeEhUmCoteudoValido(locJsonData);
			locJsonObject = new JSONObject(locJsonData);
			if (locResponse.isSuccessful()) {
				mensagem = Util.retirarCaracterEspecial(locJsonObject.getString("message"));
				setResponseMessage(mensagem);
			} else {
				failed();
				mensagem = Util.retirarCaracterEspecial(locJsonObject.getString("error"));
				setResponseMessage(mensagem);
			}
		} catch (final Exception locExc) {
			failed();
			setResponseMessage("Erro ao atualizar cliente! " + locExc.getMessage());
		} finally {
			if (locResponse != null) {
				locResponse.close();
			}
			if (client != null) {
				client.connectionPool().evictAll();
			}
		}
	}

	public void cadastrar() throws Exception {
		ClienteUnidadePasseLivre clienteUnidadePasseLivre = new ClienteUnidadePasseLivre();
		clienteUnidadePasseLivre = (ClienteUnidadePasseLivre) getValueObject();
		final Gson gson = new Gson();
		final String input = gson.toJson(getValueObject());
		JSONObject locJsonObject = new JSONObject();
		Response response = null;
		try {
			response = executePost(getEndPoint("ENDPOINT_IHP_CLIENTE"), clienteUnidadePasseLivre);
			final String locJsonData = response.body().string();
			verificarSeEhUmCoteudoValido(locJsonData);
			locJsonObject = new JSONObject(locJsonData);
			if (response.isSuccessful()) {
				mensagem = Util.retirarCaracterEspecial(locJsonObject.getString("message"));
				setResponseMessage(mensagem);
				clienteUnidadePasseLivre.setCodigoCliente(locJsonObject.get("idClient").toString());
				clienteUnidadePasseLivre.setId(locJsonObject.getString("idToken"));
				setResponseObject(clienteUnidadePasseLivre);
			} else {
				failed();
				mensagem = Util.retirarCaracterEspecial(locJsonObject.getString("error"));
				setResponseMessage(mensagem);
			}
		} catch (final Exception locExc) {
			mensagem = Util.retirarCaracterEspecial(locJsonObject.getString("error"));
			setResponseMessage(mensagem);
			failed();
			throw new Exception(getResponseMessage());
		} finally {
			if (response != null) {
				response.close();
			}
		}
	}

	private void verificarSeEhUmCoteudoValido(final String parJsonData) throws IOException, RegraNegocioException {
		if (Util.verificarSeConteudoEhXML(parJsonData)) {
			failed();
			setResponseMessage(parJsonData);
			throw new RegraNegocioException(parJsonData);
		}
	}

	public boolean getHappyBirthDate(final String parDataNascimento) throws ParseException, NullPointerException {
		try {
			final SimpleDateFormat dateFormatter = new SimpleDateFormat("MMdd");
			final String currentDate = dateFormatter.format(new Date());
			final String dateReturn = retornarApenaMesEDia(parDataNascimento);
			if (currentDate.equals(dateReturn)) {
				return true;
			}
			return false;
		} catch (final NullPointerException locExc) {
			return false;
		}
	}

	private String retornarApenaMesEDia(String parDataNascimento) {
		parDataNascimento = parDataNascimento.replace("-", "");
		parDataNascimento = parDataNascimento.substring(4, parDataNascimento.length());
		return parDataNascimento;
	}

	public void consultarMatricula(final ParametroConsultaMatricula parametroConsultaMatricula)
			throws RegraNegocioException, IOException {
		final Gson gson = new Gson();
		final String input = gson.toJson(parametroConsultaMatricula);
		final OkHttpClient client = new OkHttpClient();
		final MediaType json = MediaType.parse(Constantes.TYPE_JSON);
		final RequestBody body = RequestBody.create(json, input);
		final Request request = new Request.Builder().url(getEndPoint("ENDPOINT_IHP_CLIENTE_CONSULTA_MATRICULA"))
				.post(body).build();
		Response locResponse = null;
		try {
			JSONObject locJsonObject = new JSONObject();
			locResponse = client.newCall(request).execute();
			final String locJsonData = locResponse.body().string();
			verificarSeEhUmCoteudoValido(locJsonData);
			locJsonObject = new JSONObject(locJsonData);
			final ConsultaMatriculaResult result = gson.fromJson(
					locJsonObject.getJSONObject("ConsultaMatriculaResult").toString(), ConsultaMatriculaResult.class);
			if (result == null) {
				failed();
				setResponseMessage(result.getMensagem());
			} else {
				if ("0".equals(result.getStatus()) && !result.getClientes().isEmpty()) {
					setResponseObject(result.getClientes().get(0));
				} else {
					failed();
					setResponseMessage(result.getMensagem());
				}
			}
		} catch (final Exception locExc) {
			failed();
			throw new RegraNegocioException(locExc.getMessage());
		} finally {
			if (locResponse != null) {
				locResponse.close();
			}
			if (client != null) {
				client.connectionPool().evictAll();
			}
		}
	}

	public void consultaCliente(final ParametroConsultaCliente user) throws RegraNegocioException, ParseException {
		String descricaoServico = Thread.currentThread().getStackTrace()[1].getMethodName();
		final Gson gson = new Gson();
		final String input = gson.toJson(user);
		final OkHttpClient client =  new OkHttpClient.Builder()
				    .connectTimeout(30, TimeUnit.SECONDS)
				    .writeTimeout(30, TimeUnit.SECONDS)
				    .readTimeout(30, TimeUnit.SECONDS)
				    .build();			
		Logger.getLogger(OkHttpClient.class.getName()).setLevel(Level.ALL);
		final MediaType json = MediaType.parse(Constantes.TYPE_JSON);
		final RequestBody body = RequestBody.create(json, input);
		final Request request = new Request.Builder().url(getEndPoint("ENDPOINT_IHP_CONSULTA_CLIENTE_REST")).post(body)
				.build();
		Response locResponse = null;
		try {
			JSONObject locJsonObject = new JSONObject();
			locResponse = client.newCall(request).execute();
			if (Util.isTimeOut(locResponse.code())) {
				String origem = "Response";
				Util.msgTimeOut(TimeOutErrorCodeEnum.E001.getDescErrorCode(), origem, descricaoServico, user.getCodigo(), locResponse.message());	
			}			
			final String locJsonData = locResponse.body().string();
			verificarSeEhUmCoteudoValido(locJsonData);
			locJsonObject = new JSONObject(locJsonData);
			if (locResponse.isSuccessful()) {
				final ObjectMapper jsonMapper = new ObjectMapper();

				final ConsultaResult result = gson.fromJson(locJsonObject.getJSONObject("ConsultaResult").toString(),
						ConsultaResult.class);
				if (result == null) {
					failed();
					setResponseMessage(result.getMensagem());
				} else {
					if ("0".equals(result.getStatus()) && result.getClientes() != null
							&& !result.getClientes().isEmpty()) {
						setResponseObject(result.getClientes());
					} else {
						failed();
						setResponseMessage(result.getMensagem());
					}
				}
			}
		} catch (ConnectTimeoutException connectTimeoutEx) {
			failed();
			try {
				String origem = "ConnectTimeoutException";
				Util.msgTimeOut(TimeOutErrorCodeEnum.E001.getDescErrorCode(), origem, descricaoServico, user.getCodigo(), connectTimeoutEx.getMessage());
			} catch (final Exception e) {
				throw new RegraNegocioException(e.getMessage());	
			}			
		} catch (SocketTimeoutException socketTimeoutEx) {
			failed();
			try {
				String origem = "SocketTimeoutException";
				Util.msgTimeOut(TimeOutErrorCodeEnum.E001.getDescErrorCode(), origem, descricaoServico, user.getCodigo(), socketTimeoutEx.getMessage());
			} catch (final Exception e) {
				throw new RegraNegocioException(e.getMessage());	
			}			
		} catch (final Exception locExc) {
			failed();
			throw new RegraNegocioException(locExc.getMessage());
		} finally {
			if (locResponse != null) {
				locResponse.close();
			}
			if (client != null) {
				client.connectionPool().evictAll();
			}
		}
	}

	public void consultaClienteGuiche(final ParametroConsultaClienteGuiche user)
			throws RegraNegocioException, ParseException {
		final Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").excludeFieldsWithoutExposeAnnotation().create();
		final String input = gson.toJson(user);

		final OkHttpClient client = new OkHttpClient();
		final MediaType json = MediaType.parse(Constantes.TYPE_JSON);
		final RequestBody body = RequestBody.create(json, input);
		final Request request = new Request.Builder().url(getEndPoint("ENDPOINT_IHP_CONSULTA_CLIENTE_REST")).post(body)
				.build();
		Response locResponse = null;
		try {

			JSONObject locJsonObject = new JSONObject();
			locResponse = client.newCall(request).execute();
			final String locJsonData = locResponse.body().string();
			verificarSeEhUmCoteudoValido(locJsonData);
			locJsonObject = new JSONObject(locJsonData);
			if (locResponse.isSuccessful()) {
				final ObjectMapper jsonMapper = new ObjectMapper();
				final ConsultaResult result = gson.fromJson(locJsonObject.getJSONObject("ConsultaResult").toString(),
						ConsultaResult.class);
				if (result == null) {
					failed();
					setResponseMessage(result.getMensagem());
				} else {
					// && result.getClientes() != null
					// && !result.getClientes().isEmpty()
					if ("0".equals(result.getStatus())) {
						setResponseObject(result.getClientes());
					} else {
						failed();
						setResponseMessage(result.getMensagem());
					}
				}
			}
		} catch (final Exception locExc) {
			failed();
			throw new RegraNegocioException(locExc.getMessage());
		} finally {
			if (locResponse != null) {
				locResponse.close();
			}
			if (client != null) {
				client.connectionPool().evictAll();
			}
		}
	}

	public void registrarCliente(final ParametroRegistraCliente clienteUnidadePasseLivre)
			throws RegraNegocioException, ParseException {
		String descricaoServico = Thread.currentThread().getStackTrace()[1].getMethodName();
		final Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
		final String input = gson.toJson(clienteUnidadePasseLivre);

		final OkHttpClient client =  new OkHttpClient.Builder()
	    .connectTimeout(30, TimeUnit.SECONDS)
	    .writeTimeout(30, TimeUnit.SECONDS)
	    .readTimeout(30, TimeUnit.SECONDS)
	    .build();		
		
		Logger.getLogger(OkHttpClient.class.getName()).setLevel(Level.ALL);
		final MediaType json = MediaType.parse(Constantes.TYPE_JSON);
		final RequestBody body = RequestBody.create(json, input);
		final Request request = new Request.Builder().url(getEndPoint("ENDPOINT_CLIENTE_REGISTRA_REST")).post(body).build();
		Response locResponse = null;
		try {
			JSONObject locJsonObject = new JSONObject();
			locResponse = client.newCall(request).execute();
			if (Util.isTimeOut(locResponse.code())) {
				String origem = "Response";
				Util.msgTimeOut(TimeOutErrorCodeEnum.E002.getDescErrorCode(), origem, descricaoServico, clienteUnidadePasseLivre.getCodigo(), locResponse.message());	
			}
			final String locJsonData = locResponse.body().string();
			verificarSeEhUmCoteudoValido(locJsonData);
			locJsonObject = new JSONObject(locJsonData);
			if (locResponse.isSuccessful()) {
				final ObjectMapper jsonMapper = new ObjectMapper();
				final RegistraResult result = gson.fromJson(locJsonObject.getJSONObject("RegistraResult").toString(),
						RegistraResult.class);
				if (result == null) {
					failed();
					setResponseMessage(result.getMensagem());
				} else {
					// && result.getClientes() != null
					// && !result.getClientes().isEmpty()
					if ("0".equals(result.getStatus())) {
						setResponseObject(result);
					} else {
						failed();
						setResponseMessage(result.getMensagem());
					}
				}
			}
		} catch (ConnectTimeoutException connectTimeoutEx) {
			failed();
			try {
				String origem = "ConnectTimeoutException";
				Util.msgTimeOut(TimeOutErrorCodeEnum.E002.getDescErrorCode(), origem, descricaoServico, clienteUnidadePasseLivre.getCodigo(), connectTimeoutEx.getMessage());
			} catch (final Exception e) {
				throw new RegraNegocioException(e.getMessage());	
			}			
		} catch (SocketTimeoutException socketTimeoutEx) {
			failed();
			try {
				String origem = "SocketTimeoutException";
				Util.msgTimeOut(TimeOutErrorCodeEnum.E002.getDescErrorCode(), origem, descricaoServico, clienteUnidadePasseLivre.getCodigo(), socketTimeoutEx.getMessage());
			} catch (final Exception e) {
				throw new RegraNegocioException(e.getMessage());	
			}			
		} catch (final Exception locExc) {
			failed();
			throw new RegraNegocioException(locExc.getMessage());
		} finally {
			if (locResponse != null) {
				locResponse.close();
			}
			if (client != null) {
				client.connectionPool().evictAll();
			}
		}
	}

	/**
	 * Remove a associacao entre a matricula e o cliente
	 * 
	 * @param parametroNaoSouEu
	 * @throws RegraNegocioException
	 * @throws ParseException
	 */
	public void executaNaoSouEu(final ParametroNaoSouEu parametroNaoSouEu)
			throws RegraNegocioException, ParseException {
		final Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
		final String input = gson.toJson(parametroNaoSouEu);

		final OkHttpClient client = new OkHttpClient();
		final MediaType json = MediaType.parse(Constantes.TYPE_JSON);
		final RequestBody body = RequestBody.create(json, input);
		final Request request = new Request.Builder().url(getEndPoint("ENDPOINT_CLIENTE_NAOSOUEU")).post(body).build();
		Response locResponse = null;
		try {

			JSONObject locJsonObject = new JSONObject();
			locResponse = client.newCall(request).execute();
			final String locJsonData = locResponse.body().string();
			verificarSeEhUmCoteudoValido(locJsonData);
			locJsonObject = new JSONObject(locJsonData);
			if (locResponse.isSuccessful()) {
				final ObjectMapper jsonMapper = new ObjectMapper();
				final NaoSouEuResult result = gson.fromJson(locJsonObject.getJSONObject("NaoSouEuResult").toString(),
						NaoSouEuResult.class);
				if (result == null) {
					failed();
					setResponseMessage(result.getMensagem());
				} else {
					if ("0".equals(result.getStatus())) {
						setResponseObject(result);
					} else {
						failed();
						setResponseMessage(result.getMensagem());
					}
				}
			}
		} catch (final Exception locExc) {
			failed();
			throw new RegraNegocioException(locExc.getMessage());
		} finally {
			if (locResponse != null) {
				locResponse.close();
			}
			if (client != null) {
				client.connectionPool().evictAll();
			}
		}
	}

	public ClienteUnidadePasseLivre dePacienteParaCliente(final Paciente paciente) {
		final ClienteUnidadePasseLivre clienteUnidadePasseLivre = new ClienteUnidadePasseLivre();
		clienteUnidadePasseLivre.setDataNascimento(paciente.getDataNascimento());
		clienteUnidadePasseLivre.setCodigoCliente(paciente.getCodigo());
		clienteUnidadePasseLivre.setNomeCliente(paciente.getNome());
		clienteUnidadePasseLivre.setEstadoCivil(paciente.getEstadoCivil());
		clienteUnidadePasseLivre.setSexo(paciente.getGenero());
		clienteUnidadePasseLivre.setNacionalidade(paciente.getNacionalidade());
		clienteUnidadePasseLivre.setCpf(paciente.getCpf());
		clienteUnidadePasseLivre.setTelefone(paciente.getTelefone());
		clienteUnidadePasseLivre.setCelular(paciente.getCelular());
		clienteUnidadePasseLivre.setEmail(paciente.getEmail());
		clienteUnidadePasseLivre.setEndereco("");
		clienteUnidadePasseLivre.setNomeMae(paciente.getNomeMae());
		clienteUnidadePasseLivre.setOperadora(paciente.getOperadora());

		return clienteUnidadePasseLivre;
	}
}
