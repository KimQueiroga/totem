package br.com.hermespardini.passelivre.service;

import java.io.IOException;
import java.util.Objects;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.google.gson.Gson;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.model.ConsultaConfiguracaoResult;
import br.com.hermespardini.passelivre.model.ParametroConsultaConfiguracao;
import br.com.hermespardini.passelivre.model.TokenResult;
import br.com.hermespardini.passelivre.utils.TotemUtil;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.service.IhpMainService;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class InformacaoTotemService extends IhpMainService {
	
	Logger logger = Logger.getLogger(InformacaoTotemService.class);
	private TokenResult tokenResult;

	public InformacaoTotemService(final HttpServletRequest parRequest) throws Exception {
		super(parRequest);
	}

	public void consultarInformacoesTokenSessao(final ParametroConsultaConfiguracao parametrosConsultaConfiguracao) {
		final Gson gson = new Gson();
		final String input = gson.toJson(parametrosConsultaConfiguracao);
		final OkHttpClient client = new OkHttpClient();
		final MediaType json = MediaType.parse(Constantes.TYPE_JSON);
		final RequestBody body = RequestBody.create(json, input);
		final Request request = new Request.Builder().url(getEndPoint("ENDPOINT_IHP_CONSULTA_CONFIGURACAO")).post(body)
				.build();
		Response locResponse = null;
		JSONObject locJsonObject = null;
		try {
			locResponse = client.newCall(request).execute();
			final String locJsonData = locResponse.body().string();
			verificarSeEhUmCoteudoValido(locJsonData);
			locJsonObject = new JSONObject(locJsonData);
			setResponseMessage(locJsonObject.getJSONObject("ConsultaConfiguracaoResult").getString("mensagem"));
			final ConsultaConfiguracaoResult result = gson.fromJson(
					locJsonObject.getJSONObject("ConsultaConfiguracaoResult").toString(),
					ConsultaConfiguracaoResult.class);
			if (result == null) {
				failed();
				setResponseMessage(result.getMensagem());
			} else {
				if ("0".equals(result.getStatus())) {
					if(!Objects.isNull(result.getMensagem()) && result.getMensagem().contains("Erro")) {
						failed();
						setResponseMessage(result.getMensagem());
					} else {
						setResponseObject(result);
						TotemUtil.setarConsultaConfiguracaoResult(result);
					}
				} else {
					failed();
					setResponseMessage(result.getMensagem());
				}
			}
		} catch (final Exception locExc) {
			failed();
			setResponseMessage(locExc.getMessage());
		} finally {
			if (locResponse != null) {
				locResponse.close();
			}
			if (client != null) {
				client.connectionPool().evictAll();
			}
		}
	}

	public void consultar(final ParametroConsultaConfiguracao parametrosConsultaConfiguracao) throws RegraNegocioException {
		
		ConsultaConfiguracaoResult result = (TotemUtil.recuperarConsultaConfiguracaoResult(parametrosConsultaConfiguracao));
		
		if(Objects.isNull(result)) {
						
			try {
				tokenResult = TotemUtil.gerarToken();
				parametrosConsultaConfiguracao.setToken(tokenResult.getToken());
				consultarInformacoesTokenSessao(parametrosConsultaConfiguracao);
				result = (ConsultaConfiguracaoResult) getResponseObject();
			} catch (RegraNegocioException e) {
				logger.error("Erro ao buscar as informações do Totem - ConfiguracaoResult", e);
			} catch (Exception e) {
				logger.error("Erro ao buscar as informações do Totem - ConfiguracaoResult", e);
			}
		}
		setResponseObject(result);
	}	
	
	private void verificarSeEhUmCoteudoValido(final String parJsonData) throws IOException, RegraNegocioException {
		if (Util.verificarSeConteudoEhXML(parJsonData)) {
			failed();
			setResponseMessage(parJsonData);
			throw new RegraNegocioException(parJsonData);
		}
	}
}
