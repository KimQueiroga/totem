package br.com.hermespardini.passelivre.service;

import javax.servlet.http.HttpServletRequest;

import org.wdelmaschio.base.view.Service;

import br.com.hermespardini.corebusiness.exception.IHPCoreException;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.facade.LocalidadeFacade;
import br.com.hermespardini.passelivre.model.Localidade;

public class LocalidadeService extends Service {

//	public LocalidadeService(final HttpServletRequest request) throws Exception {
//		super(request);
//	}
	
	public LocalidadeService(final HttpServletRequest request) throws Exception {
		super(Localidade.class, LocalidadeFacade.class, request);
	}

	public Localidade getLocalidadeByIp() throws RegraNegocioException {
		try {
			getFacade().setValueObject(getValueObject());
			final Localidade loLocalidade = ((LocalidadeFacade) getFacade()).getLocalidadeIp();
			if (loLocalidade == null) {
				failed();
				setResponseMessage("Localidade da biometria não foi cadastrada!");
				return null;
			}
			setResponseObject(loLocalidade);
			return (Localidade) getResponseObject();
		} catch (final IHPCoreException ihpExc) {
			setResponseMessage(ihpExc.getMotivo());
			failed();
			throw new RegraNegocioException(ihpExc.getMessage());
		} catch (final Exception loE) {
			setResponseMessage(loE.getMessage());
			failed();
			throw new RegraNegocioException(loE.getMessage());
		}
	}

	public void buscarLocalidadePorId() throws RegraNegocioException {
		try {
			getFacade().setValueObject(getValueObject());
			final Localidade loLocalidade = ((LocalidadeFacade) getFacade()).getLocalidadeIp();
			if (loLocalidade == null) {
				failed();
				setResponseMessage("Localidade da biometria não foi cadastrada!");
			}
			setResponseObject(loLocalidade);
		} catch (final IHPCoreException ihpExc) {
			setResponseMessage(ihpExc.getMotivo());
			failed();
			throw new RegraNegocioException(ihpExc.getMessage());
		} catch (final Exception loE) {
			setResponseMessage(loE.getMessage());
			failed();
			throw new RegraNegocioException(loE.getMessage());
		}
	}
}
