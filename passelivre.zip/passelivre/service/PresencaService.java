package br.com.hermespardini.passelivre.service;

import javax.servlet.http.HttpServletRequest;

import org.wdelmaschio.base.view.Service;

import br.com.hermespardini.corebusiness.exception.IHPCoreException;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.facade.PresencaFacade;
import br.com.hermespardini.passelivre.model.Presenca;

public class PresencaService extends Service {

	public PresencaService(final HttpServletRequest parRequest) throws Exception {
		super(Presenca.class, PresencaFacade.class, parRequest);
	}

	public Presenca salvarBiometria(final Presenca paramPresenca) throws RegraNegocioException {
		try {
			getFacade().setValueObject(paramPresenca);
			final Presenca loPresenca = ((PresencaFacade) getFacade()).getPresencaByCarteira();
			if (loPresenca == null || loPresenca.getCarteira().isEmpty() || loPresenca.getCarteira() == null) {
				paramPresenca.inserirPresenca(paramPresenca);
				((PresencaFacade) getFacade()).insert(paramPresenca);
			} else {
				paramPresenca.atualizarPresenca(paramPresenca, loPresenca);
				((PresencaFacade) getFacade()).update(paramPresenca);
			}
			return paramPresenca;
		} catch (final IHPCoreException ihpExc) {
			setResponseMessage(ihpExc.getMotivo());
			failed();
			throw new RegraNegocioException(ihpExc.getMessage());
		} catch (final Exception loE) {
			setResponseMessage(loE.getMessage());
			failed();
			throw new RegraNegocioException(loE.getMessage());
		}
	}
}
