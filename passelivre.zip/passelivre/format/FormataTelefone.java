package br.com.hermespardini.passelivre.format;

import br.com.hermespardini.passelivre.interfaces.FormataCampo;

public class FormataTelefone implements FormataCampo {

	private String valor;

	public FormataTelefone(final String valor) {
		this.valor = valor;
	}

	@Override
	public String formatar() {
		return eliminarCaracteresDo(valor);
	}

	private String eliminarCaracteresDo(final String valor) {
		try {
			return valor.replace(")", "").replace("(", "").replace("-", "");
		} catch (final Exception locExc) {
			return valor;
		}

	}
}
