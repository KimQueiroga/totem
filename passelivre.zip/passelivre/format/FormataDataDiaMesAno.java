package br.com.hermespardini.passelivre.format;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import br.com.hermespardini.passelivre.interfaces.FormataCampo;

public class FormataDataDiaMesAno implements FormataCampo {

	private SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
	private SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
	private String valor;

	public FormataDataDiaMesAno(final String valor) {
		this.valor = valor;
	}

	@Override
	public String formatar() {
		try {
			return eliminarCaracteres(sdf.format(dateFormatter.parse(valor)));
		} catch (final ParseException exc) {
			exc.printStackTrace();
			return null;
		}
	}

	private String eliminarCaracteres(final String valor) {
		try {
			return valor.replace("-", "").replaceAll("/", "");
		} catch (final Exception locExc) {
			return valor;
		}
	}
}
