package br.com.hermespardini.passelivre.format;

import br.com.hermespardini.passelivre.interfaces.FormataCampo;

public class FormataCep implements FormataCampo {

	private String valor;

	public FormataCep(String valor) {
		this.valor = valor;
	}

	@Override
	public String formatar() {
		return eliminarCaracteresDo(valor);
	}

	private String eliminarCaracteresDo(String valor) {
		return valor.replace("-", "");
	}
}
