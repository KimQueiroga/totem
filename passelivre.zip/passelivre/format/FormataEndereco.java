package br.com.hermespardini.passelivre.format;

import br.com.hermespardini.passelivre.model.ClienteUnidadePasseLivre;

public class FormataEndereco {

	public void formataEnderecoAoLogar(final ClienteUnidadePasseLivre cliente) throws Exception {
		cliente.setLogradouro(cliente.getRua());
	}

	private String retornarNumero(final String endereco) {
		String numero = "";
		try {
			return endereco.substring(endereco.indexOf(",") + 1, endereco.lastIndexOf("-"));
		} catch (final Exception locExc) {
			numero = endereco.substring(endereco.indexOf(",") + 1, endereco.length());
			if (numero.contains("/")) {
				return endereco.substring(endereco.indexOf(",") + 1, endereco.lastIndexOf("/"));
			}
			return numero;
		}
	}

	private String retornarComplemento(final String endereco, final String complemento) {
		if (endereco.indexOf("-") != -1) {
			return endereco.substring(endereco.lastIndexOf("-") + 1, endereco.length());
		}
		if (retornarNumero(endereco).contains("/")) {
			return endereco.substring(endereco.lastIndexOf("/") + 1, endereco.length());
		}
		return complemento;
	}

	public void convertStreetAndComplement(final ClienteUnidadePasseLivre cliente) {
		final StringBuilder streetAndComplement = new StringBuilder();
		String endereco = cliente.getEndereco();
		streetAndComplement.append(cliente.getLogradouro()).append(", ").append(cliente.getNumero())
				.append(cliente.getComplemento().equals("") ? " " : " - ").append(cliente.getComplemento());
		endereco = streetAndComplement.toString();
		cliente.setEndereco(endereco);
	}

}
