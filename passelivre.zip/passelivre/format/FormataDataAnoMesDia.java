package br.com.hermespardini.passelivre.format;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import br.com.hermespardini.passelivre.interfaces.FormataCampo;

public class FormataDataAnoMesDia implements FormataCampo {

	private SimpleDateFormat dateFormatter;
	private SimpleDateFormat sdf;
	private String valor;

	public FormataDataAnoMesDia(final String valor) {
		this.valor = valor;
	}

	@Override
	public String formatar() {
		dateFormatter = new SimpleDateFormat("dd/MM/yyyy");
		sdf = new SimpleDateFormat("yyyy-MM-dd");
		try {
			return sdf.format(dateFormatter.parse(valor));
		} catch (final ParseException locExc) {
			locExc.printStackTrace();
			return "";
		}
	}

	private String eliminarCaracteres(final String valor) {
		try {
			return valor.replaceAll("/", "");
		} catch (final Exception locExc) {
			return valor;
		}
	}

}
