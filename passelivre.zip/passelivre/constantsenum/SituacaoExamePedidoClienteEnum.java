package br.com.hermespardini.passelivre.constantsenum;

import br.com.hermespardini.corebusiness.coreenum.EnumValueOfHelper;

public enum SituacaoExamePedidoClienteEnum {
	SEM_PENDENCIA_COLETA("0", "Sem Pendência de Coleta"), PENDDENTE_COLETA("1", "Pendente Coleta");

	private String situacao;
	private String descricao;

	SituacaoExamePedidoClienteEnum(final String parSituacao, final String parDescricao) {
		situacao = parSituacao;
		descricao = parDescricao;
	}

	public static SituacaoExamePedidoClienteEnum valueOfSituacao(final String parSituacao) {
		return EnumValueOfHelper.valueOf(SituacaoExamePedidoClienteEnum.class, "situacao", parSituacao);
	}

	public static SituacaoExamePedidoClienteEnum valueOfDescricao(final String parDescricao) {
		return EnumValueOfHelper.valueOf(SituacaoExamePedidoClienteEnum.class, "descricao", parDescricao);
	}

	public final String getSituacao() {
		return situacao;
	}

	public final void setSituacao(final String parSituacao) {
		situacao = parSituacao;
	}

	public final String getDescricao() {
		return descricao;
	}

	public void setDescricao(final String parDescricao) {
		descricao = parDescricao;
	}

}
