package br.com.hermespardini.passelivre.constantsenum;

public enum TipoCartao {

	VISA("^4[0-9]{12}(?:[0-9]{3})?$", "visa"), MASTERCARD("^5[1-5][0-9]{14}$", "mastercard"),
	AMEX("^3[47][0-9]{13}$", "AMEX"), DINERS("^3(?:0[0-5]|[68][0-9])[0-9]{11}$", "Diners"),
	DISCOVER("^6(?:011|5[0-9]{2})[0-9]{12}$", "DISCOVER"), JCB("^(?:2131|1800|35\\d{3})\\d{11}$", "JCB"),
	UNKNOWN("", "UNKNOWN");

	private String regex;
	private String nomeCartao;

	TipoCartao(final String regex, final String issuerName) {
		this.regex = regex;
		nomeCartao = issuerName;
	}

	public static TipoCartao getCartaoPorNumero(final String numeroCartao) {
		for (final TipoCartao cc : TipoCartao.values()) {
			if (cc.matches(numeroCartao)) {
				return cc;
			}
		}
		return UNKNOWN;
	}

	public static TipoCartao getCartaoPorNome(final String nomeCArtao) {
		for (final TipoCartao cc : TipoCartao.values()) {
			if (cc.getNomeCartao().equals(nomeCArtao)) {
				return cc;
			}
		}
		return UNKNOWN;
	}

	public boolean matches(final String card) {
		return card.matches(regex);
	}

	public String getNomeCartao() {
		return nomeCartao;
	}
}
