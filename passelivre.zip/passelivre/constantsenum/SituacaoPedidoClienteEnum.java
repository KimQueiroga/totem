package br.com.hermespardini.passelivre.constantsenum;

import br.com.hermespardini.corebusiness.coreenum.EnumValueOfHelper;

public enum SituacaoPedidoClienteEnum {
	LIBERADO("1", "Liberado"), ANDAMENTO("2", "Em andamento"), PENDENTE("3", "Pendente");

	private String situacao;
	private String descricao;

	SituacaoPedidoClienteEnum(final String parSituacao, final String parDescricao) {
		situacao = parSituacao;
		descricao = parDescricao;
	}

	public static SituacaoPedidoClienteEnum valueOfSituacao(final String parSituacao) {
		return EnumValueOfHelper.valueOf(SituacaoPedidoClienteEnum.class, "situacao", parSituacao);
	}

	public static SituacaoPedidoClienteEnum valueOfDescricao(final String parDescricao) {
		return EnumValueOfHelper.valueOf(SituacaoPedidoClienteEnum.class, "descricao", parDescricao);
	}

	public final String getSituacao() {
		return situacao;
	}

	public final void setSituacao(final String parSituacao) {
		situacao = parSituacao;
	}

	public final String getDescricao() {
		return descricao;
	}

	public void setDescricao(final String parDescricao) {
		descricao = parDescricao;
	}

}
