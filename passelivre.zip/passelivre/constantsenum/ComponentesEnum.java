package br.com.hermespardini.passelivre.constantsenum;

import br.com.hermespardini.corebusiness.coreenum.EnumValueOfHelper;

public enum ComponentesEnum {
	SIM_NAO("SIM/NAO"), HORA("HORA"), DESCRITIVA("DESCRITIVA"),
	RESPOSTAS_SINTOMAS_PROVAS("RESPOSTAS DE SINTOMAS DAS PROVAS"), NUMERICA("NUMERICA"), DATA("DATA"),
	NUMERICO2("NUMERICO2"), NUMERICO4("NUMERICO4"), NUMERICO41("NUMERICO4.1"), NUMERICO32("NUMERICO3.2"),
	LOCAL_ORAL("LOCAL/ORAL"), LABORATORIO_CASA_OUTROS("LABORATORIO/CASA/OUTROS"), RESPOSTA_NULA("RESPOSTA NULA"),
	ORAL_LOCAL_AMBOS_NA("ORAL/LOCAL/AMBOS/NA");

	private String descricao;

	private ComponentesEnum(final String descricao) {
		this.descricao = descricao;
	}

	public static ComponentesEnum valueOfDescricao(final String parDescricao) {
		return EnumValueOfHelper.valueOf(ComponentesEnum.class, "descricao", parDescricao);
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(final String parDescricao) {
		descricao = parDescricao;
	}

}
