package br.com.hermespardini.passelivre.constantsenum;

public final class Constantes {

	public static final String CPFAUTHKEYTYPE = "1";
	public static final String CODEAUTHKEYTYPE = "2";
	public static final String OUTROAUTHKEYTYPE = "3";

	public static final String TYPE_JSON = "application/json; charset=utf-8";
	public static final String EMPRESA = "IHP";
	public static final String CAMPO_OBRIGATORIO = "Campo obrigatório!";

	public static final String NOME_SISTEMA = "PASSELIVRE";
	public static final String NOME_SISTEMA_DESKTOP = "PASSELIVREDESK";
	public static final String TIPO_LOG_01 = "01";

	public static final String USUARIO_PADRAO = "%PASSELIVRE";
	public static final String EMPRESA_PADRAO = "Hermes Pardini";

	public static final String SENHA_PADRAO = "pardini123";

	public static final String IS_AMBIENTE_PRODUCAO = "isAmbienteProducao";
	public static final String AMBIENTE_HOMOLOGACAO = "HOMOL";
	public static final String AMBIENTE_PRODUCAO = "PROD";
	public static final String FUNCIONALIDADE_EMP = "Entrega de Material Pendente";
	public static final String FUNCIONALIDADE_NAU = "Novo Atendimento Unimed";
	public static final String FUNCIONALIDADE_RES = "Visualização de Resultado";
	public static final String TIPO_CLIENTE = "CUSTOMER";
	public static final String REGISTRO_ANS = "343889";
	public static final String CODIGO_CNES = "2695014";
	public static final String CODIGO_CNES_ECOAR_1 = "3351424";
	public static final String CODIGO_CNES_ECOAR_2 = "2188694";
	public static final String CODIGO_CNES_ECOAR_3 = "";
	public static final String VERSAO_DEFAULT = "1.00.00";
	public static final String APPLICATIONSVERSION = "5.1.11";
	public static final String HORARIO_DEFAULT = "11:00:00";

	public static final String NOME_COMPUTADOR_DEFAULT_DESKTOP = "ihpmgntototi2077";
	public static final String NOME_COMPUTADOR_DEFAULT_TOTEM = "ihpmgntototem1";
	public static final String IP_LOCALIDADE_DEFAULT = "192.168.25.0";
	public static final String IP_LOCALIDADE_DEFAULT_ECOAR = "10.31.114.54";
	// 192.168.14.203
	// 172.19.111.95
	// 172.19.111.64 minha máquina
	// 10.31.114.54 ecoar
	public static final String IP_COMPUTADOR_DEFAULT_DESKTOP = "172.19.111.64";// 192.168.42.139
																				// guiche 5

	/**
	 * Configurações applet unimed
	 */
	public static final String ARQUIVO_PROPERTIES_CONFIGURACAO = "parametrosConfiguracaoAppletUnimed.properties";
	public static final String CODIGO_PRESTADOR_HERMESPARDINI = "00612000048";
	public static final String CODIGO_PRESTADOR_ECOAR = "00633003001";
	public static final String NOME_EMPRESA_HERMESPARDINI = "INSTITUTO HERMES PARDINI S/A";
	public static final String NOME_EMPRESA_ECOAR = "ECOAR - MEDICINA DIAGNOSTICA";
	public static final String ID_EMPRESA_HERMES_PARDINI = "1";
	public static final String ID_EMPRESA_ECOAR = "18";
	public static final String CHAVE_USER_UNIMED_SERVICE = "USUARIO_UNIMED_SERVICE";
	public static final String CHAVE_SENHA_UNIMED_SERVICE = "SENHA_UNIMED_SERVICE";
	public static final String CHAVE_USER_UNIMED_CERTIFICACAO = "USUARIO_UNIMED_CERTIFICACAO";
	public static final String CHAVE_SENHA_UNIMED_CERTIFICACAO = "SENHA_UNIMED_CERTIFICACAO";
	
	//Parametros de ativacao e desativacao biometria unimed
	public static final String CHAVE_BIOMETRIA_ATIVACAO = "BIOMETRIA_SERVICO_BIOMETRIA";
	public static final String ATIVO = "ATIVO";
	
	//Parametro verificacao impressora
	public static final String CHAVE_VERIFICAR_IMPRESSORA = "VERIFICAR_IMPRESSORA";

	/**
	 * Configurações applet ECOAR
	 */

	public static final String CHAVE_USER_ECOAR_SERVICE = "USUARIO_ECOAR_SERVICE";
	public static final String CHAVE_SENHA_ECOAR_SERVICE = "SENHA_ECOAR_SERVICE";

	public static final String PARAM_APPLET_LOGININCLUSAO = Constantes.CODIGO_PRESTADOR_HERMESPARDINI;
	public static final String PARAM_APPLET_CACHE_OPTION = "Yes";
	public static final String PARAM_APPLET_DIRETORIO_RETORNO_UNIX = "/tmp";
	public static final String PARAM_APPLET_DIRETORIO_RETORNO_WINDOWS = "C:/temp";
	public static final String PARAM_APPLET_EXIBIR_PROTOCOLO = "nao";
	public static final String PARAM_APPLET_URL_WEBSERVICE = "https://wshml.unimedbh.com.br/ws-VerificaPresenca";
	// "https://ws.unimedbh.com.br/ws-VerificaPresenca";
	public static final String PARAM_INICAL_LOCAL_ATENDIMENTO = "unbh";
	public static final char CODIGO_WS_PRESENCA_CONFIRMADA = '0';
	public static final char CODIGO_WS_PRESENCA_NAOCONFIRMADA = '3';
	public static final String DIRETORIO_APLICACAO = null;

	public static final String SERVICO_ENTREGA_PENDENTE = "ENTREGA_PENDENTE";
	public static final String SERVICO_ATENDIMENTO_UNIMED = "ATENDIMENTO_UNIMED";
	public static final String SERVICO_RESULTADO = "RESULTADO";
	public static final String SERVICO_PREPARACAO_EXAME = "PREPARACAO_EXAMES";
	public static final String SERVICO_ORCAMENTO = "ORCAMENTO";
	public static final String SERVICO_CHECKUP_MASCULINO = "CHECKUP_MASCULINO";
	public static final String SERVICO_PRE_ATENDIMENTO = "PRE_ATENDIMENTO";

	public static final String BOTAO_TECLADO_VOLTAR = "&lt- bksp";
	public static final String TECLADO_SEM_ACENTRO_E_NUMERO = "1234567890,qwertyuiop,asdfghjkl,zxcvbnm,shift-close-clear-back-spacebar";
	public static final String TECLADO_SOMENTE_NUMERO = "123-close,456-clear,789-back,0";
	public static final String CONVENIO_PADRAO = "UNIMED BH";
	// public static final String AMBIENTE_SERVICE = "http://100.0.0.5:8084";
	public static final String BOTAO_TECLADO_FECHAR = "OK";
	public static final String BOTAO_TECLADO_LIMPAR = "Limpar";
	public static final String OPERADORA_PADRAO = "UNIMED";
	public static final String TOKEN_PADRAO = "a";
	public static final String ORIGEM_PADRAO = "%PASSELIVRE";
	public static final String ORIGEM_DESKTOP = "%PASSELIVREDESK";
	public static final String ORIGEM_ORCAMENTO = "Autoatendimento";
	public static final String PERGUNTA_ATENDIMENTO = "F01";
	public static final String SENHA_TOKEN = "@essapervil";
	public static final String USUARIO_TOKEN = "%PASSELIVRE";
	public static final String SENHA_TOKEN_DESK = "@ksed_ervil";
	public static final String USUARIO_TOKEN_DESK = "%PASSELIVREDESK";
	public static final Long SERVICO_PADRAO = 1L;
	public static final String NAO_PARTICULAR = "N";
	public static final String OPERADORA_PARTICULAR = "PART";
	public static final String OPERADORA_CAMPANHA = "CAMPAN";
	public static final String PARTICULAR = "S";
	public static final String TIPO_DOCUMENTO = "NA";
	public static final String TIPO_AUTH_KEY = "1";
	public static final String NAO_EXIBE_COLETA = "N";
	public static final Integer STATUS_LIBERADO = 1;
	public static final String CLIENTE_PADRAO = "000000000";
	public static final String REMETENTE_PARDINI = "PASSELIVRE@hermespardini.com.br";
	public static final String REMETENTE_ECOAR = "PASSELIVRE@ecoar.com.br";
	public static final String REMETENTE_PADRAO = "PASSELIVRE@padrao.com.br";
	public static final String AUTH_KEY_TYPE_CPF = "1";
	public static final String AUTH_KEY_TYPE_CODIGO = "2";
	public static final long TEMPO_ESPERA_IMPRESSAO_PADRAO = 10000;
	public static final String LOCAL_COLETA_PADRAO = "L";
	public static final String LOCAL_COLETA_CHECKUP = "L";
	public static final String TIPO_IMPRESSAO_CHECKUP = "R";
	public static final String TIPO_IMPRESSAO_DEFAULT = "R"; // PARA PRODUÇÃO TEM QUE SER "R"
	public static final String HUMANO = "H";
	public static final String NAO_IMPRIME_FRENTE_VERSO = "0";
	public static final String IMPRIME_FRENTE_VERSO = "1";
	public static final String CODIGO_PADRAO = "0";
	public static final long TIMEOUT_ENGREGA_MATERIAL_PENDENTE = 90;
	public static final long TIMEOUT_ATUALIZAR_DADOS = 30;
	public static final long TIMEOUT_FAZER_PEDIDO = 90;
	public static final long TIMEOUT_FAZER_LOGIN = 30;
	public static final long TIMEOUT_CONSULTA_EXAMES = 30;
	public static final long TIMEOUT_LOGIN_CODIGO = 30;
	public static final Long ID_ENTREGA_PEDENTE = 2L;
	public static final Long ID_ATENDIMENTO_UNIMED = 3L;
	public static final String ORIGEM_ESTATISTICO_DESKTOP = "D";
	public static final String ORIGEM_ESTATISTICO_PADRAO = "T";
	public static final String PAGAMENTO_CARTAO = "C";
	// public static final String TOKEN_CHECKUP =
	// "cfeb6ecf76-2b03259e5c-f48103d64a-411d584d16"; //homol
	public static final String TOKEN_CHECKUP = "045ab772c2-d4389a1809-4afd1ed518-56a0f1ba21";
	public static final Object SERVICO_CHECKUP_FEMININO = "CHECKUP_FEMININO";
	public static final String TIPO_PRE_ATENDIMENTO = "P";
	public static final String CONTA_PRE_ATENDIMENTO = "HermesPardini";
	public static final Integer TIPO_PACOTE = 1;
	public static final String NAO = "N";
	public static final String SIM = "S";
	public static final String SITUACAO_A = "A";
	public static final int[] PESOCPF = { 11, 10, 9, 8, 7, 6, 5, 4, 3, 2 };

	public static final String GLOSA_GUIA_UTILIZADA = "9999";
	
	public static final String CLIENTE_LOJA = "7";
	public static final String UNIDADE_NEGOCIO_PREPARACAO = "2";
	
	public static final String URL_API_REST_BUSCAR_CEP_HOMOLOGACAO = "http://172.19.203.112:57772/csp/pscRest/consultaCEP/";
	public static final String URL_API_REST_BUSCAR_CEP_PRODUCAO = "https://hermespardini.com.br/services/pscRest/consultaCEP/";

	private Constantes() {

	}
}
