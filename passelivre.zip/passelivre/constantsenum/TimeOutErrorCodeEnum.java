package br.com.hermespardini.passelivre.constantsenum;

public enum TimeOutErrorCodeEnum {
	E001("E-001","consultaCliente"),
	E002("E-002","registrarCliente"),
	E003("E-003","consultaAgendamento");

	private final String descErrorCode;
	private final String descricaoServico;

	TimeOutErrorCodeEnum(String descErrorCode, String descricaoServico) {
		this.descErrorCode = descErrorCode;
		this.descricaoServico = descricaoServico;
	}

	public String getDescErrorCode() {
		return descErrorCode;
	}

	public String getDescricaoServico() {
		return descricaoServico;
	}	
}
