package br.com.hermespardini.passelivre.constantsenum;

public class Funcionalidade {
	public static final String ACEITADO_TERMO_EMP = "ACEITADO_TERMO_EMP";
	public static final String ATUALIZACAO_DADOS_EMP = "ATUALIZACAO_DADOS_EMP";
	public static final String CANCELAMENTO_EMP = "CANCELAMENTO_EMP";
	public static final String BOAS_VINDAS_EMP = "BOAS_VINDAS_EMP";
	public static final String CONCLUSAO_EMP = "CONCLUSAO_EMP";
	public static final String ESQUECI_SENHA_EMP = "ESQUECI_SENHA_EMP";
	public static final String LOGIN_CANCELADO_EMP = "LOGIN_CANCELADO_EMP";
	public static final String LOGIN_CODIGO_SOLICITADO_EMP = "LOGIN_CODIGO_SOLICITADO_EMP";
	public static final String LOGIN_CPF_SOLICITADO_EMP = "LOGIN_CPF_SOLICITADO_EMP";
	public static final String NEGANDO_TERMO_EMP = "NEGANDO_TERMO_EMP";
	public static final String REGISTRO_SATISFACAO_EMP = "REGISTRO_SATISFACAO_EMP";
	public static final String SOLICITACAO_EMP = "SOLICITACAO_EMP";

	public static final String NEGANDO_TERMO_NAU = "NEGANDO_TERMO_NAU";
	public static final String ACEITADO_TERMO_NAU = "ACEITADO_TERMO_NAU";
	public static final String LOGIN_CODIGO_SOLICITADO_NAU = "LOGIN_CODIGO_SOLICITADO_NAU";
	public static final String ESQUECI_SENHA_NAU = "ESQUECI_SENHA_NAU";
	public static final String LOGIN_CPF_SOLICITADO_NAU = "LOGIN_CPF_SOLICITADO_NAU";
	public static final String LOGIN_CANCELADO_NAU = "LOGIN_CANCELADO_NAU";
}
