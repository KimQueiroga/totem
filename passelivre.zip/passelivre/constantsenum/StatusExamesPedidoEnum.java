package br.com.hermespardini.passelivre.constantsenum;

public enum StatusExamesPedidoEnum {

	TODOS_EXAMES_LIBERADOS(1, "Todos exames liberados"),
	ALGUM_EXAME_NAO_LIBERADO(2, "Algum exame não liberado");
	
	private final Integer id;

	private final String descricao;

	StatusExamesPedidoEnum(Integer id, String descricao) {
		this.id = id;
		this.descricao = descricao;
	}

	public Integer getId() {
		return id;
	}

	public String getDescricao() {
		return descricao;
	}
}
