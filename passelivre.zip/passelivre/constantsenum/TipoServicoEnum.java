package br.com.hermespardini.passelivre.constantsenum;

import br.com.hermespardini.passelivre.interfaces.AcaoTela;
import br.com.hermespardini.passelivre.interfaces.TermoUso;
import br.com.hermespardini.passelivre.utils.TotemUtil;

public enum TipoServicoEnum implements AcaoTela, TermoUso {
	EMP {
		@Override
		public String redirectAposLogin() {
			return "/pages/emp/atualizarDados.xhtml?faces-redirect=true";
		}

		@Override
		public String aceitar() {
			return "/pages/emp/login.xhml?faces-redirect=true";
		}

		@Override
		public String descricaoTermoUso() {
			return "O beneficiário devidamente identificado no sistema de autoatendimento do Instituto Hermes Pardini "
					+ "S/A autoriza o cadastro das informações necessárias para a entrega de materiais pendentes, se houver.";
		}

		@Override
		public String redirectAposAtualizar() {
			return null;
		}
	},
	EMP_P {
		@Override
		public String redirectAposLogin() {
			return "/pages/emp/atualizarDados.xhtml?faces-redirect=true";
		}

		@Override
		public String aceitar() {
			return "/pages/emp/login.xhml?faces-redirect=true";
		}

		@Override
		public String descricaoTermoUso() {
			return "O beneficiário devidamente identificado no sistema de autoatendimento do Laboratorio Padrão S/A"
					+ " autoriza o cadastro das informações necessárias para a entrega de materiais pendentes, se houver.";
		}

		@Override
		public String redirectAposAtualizar() {
			return null;
		}

	},
	NAU {
		@Override
		public String redirectAposLogin() {
			return "/pages/nau/atualizarDados.xhtml?faces-redirect=true";
		}

		@Override
		public String aceitar() {
			return "/pages/nau/coletaBiometria.xhtml?faces-redirect=true";
		}

		@Override
		public String descricaoTermoUso() {
			return "O beneficiário já identificado através da inserção do cartão do Plano de Saúde e biometria digital "
					+ "no sistema de autoatendimento do INSTITUTO HERMES PARDINI S/A autoriza o cadastro das informações necessárias "
					+ "para a execução dos exames laboratoriais constantes no pedido médico já autorizado pela UNIMED-BH, estando ciente "
					+ "de que deverá preencher manualmente o TERMO DE CONSENTIMENTO e demais documentos necessários antes da realização "
					+ "do exame de diagnóstico por imagem";
		}

		@Override
		public String redirectAposAtualizar() {
			return null;
		}
	},
	RES_P {
		@Override
		public String redirectAposLogin() {
			return "/pages/res/resultado.xhtml?faces-redirect=true";
		}

		@Override
		public String aceitar() {
			return "/pages/ppe/preparacao.xhtml?faces-redirect=true";
		}

		@Override
		public String descricaoTermoUso() {
			return "Ao concordar com a impressão dos resultados de exames laboratoriais, registro que sou responsável pela conferência e"
					+ " retirada de todas as páginas impressas, devendo informar a um colaborador do Laboratorio Padrão S/A a ausência de algum(a) "
					+ "resultado/folha impresso(a). Caso seja constatado que os resultados impressos não correspondem ao usuário deste sistema, "
					+ "comprometo-me a entregar imediatamente os mesmos a um colaborador do Laboratorio Padrão S/A.";
		}

		@Override
		public String redirectAposAtualizar() {
			return null;
		}
	},
	RES {
		@Override
		public String redirectAposLogin() {
			return "/pages/res/resultado.xhtml?faces-redirect=true";
		}

		@Override
		public String aceitar() {
			return "/pages/ppe/preparacao.xhtml?faces-redirect=true";
		}

		@Override
		public String descricaoTermoUso() {
			return "Ao concordar com a impressão dos resultados de exames laboratoriais, registro que sou responsável pela conferência e"
					+ " retirada de todas as páginas impressas, devendo informar a um colaborador do Instituto Hermes Pardini S/A a ausência de algum(a) "
					+ "resultado/folha impresso(a). Caso seja constatado que os resultados impressos não correspondem ao usuário deste sistema, "
					+ "comprometo-me a entregar imediatamente os mesmos a um colaborador do Instituto Hermes Pardini S/A.";
		}

		@Override
		public String redirectAposAtualizar() {
			return null;
		}
	},
	ORM {
		@Override
		public String redirectAposLogin() {
			return "/pages/ocm/preparacao.xhtml?faces-redirect=true";
		}

		@Override
		public String aceitar() {
			return "";
		}

		@Override
		public String descricaoTermoUso() {
			return "Mensagem Orçamento.";
		}

		@Override
		public String redirectAposAtualizar() {
			return null;
		}

	},
	PAG {
		@Override
		public String redirectAposLogin() {
			return "/pages/pag/preparacao.xhtml?faces-redirect=true";
		}

		@Override
		public String aceitar() {
			return "/pages/pag/preparacao.xhtml?faces-redirect=true";
		}

		@Override
		public String descricaoTermoUso() {
			return "\u201C O beneficiário já identificado através da inserção do cartão do Plano de Saúde"
					+ " e biometria digital no sistema de autoatendimento do Instituto Hermes Pardini S/A autoriza "
					+ "o cadastro das informações necessárias para a execução dos exames laboratoriais constantes no pedido médico já"
					+ " autorizado pela UNIMED\u2013BH e/ou a respectiva entrega de materiais pendentes, se houver.";
		}

		@Override
		public String redirectAposAtualizar() {
			return null;
		}

	},
	PRE {
		@Override
		public String redirectAposLogin() {
			return "/pages/ppe/preparacao.xhtml?faces-redirect=true";
		}

		@Override
		public String aceitar() {
			return "";
		}

		@Override
		public String descricaoTermoUso() {
			return "";
		}

		@Override
		public String redirectAposAtualizar() {
			return null;
		}

	},
	CKM {
		@Override
		public String redirectAposLogin() {
			return "/pages/atualizarDados.xhtml?faces-redirect=true";
		}

		@Override
		public String aceitar() {
			return "/pages/ckm/detalheExame.xhtml?faces-redirect=true";
		}

		@Override
		public String descricaoTermoUso() {
			final StringBuilder sb = new StringBuilder();
			return sb.append(
					"Trata-se o presente instrumento de TERMO DE CONDIÇÕES PARA COMPRA DO CHECK UP - CAMPANHA NOVEMBRO AZUL - ")
					.append("realizado pelo INSTITUTO HERMES PARDINI S/A, inscrito no CNPJ/MF sob o nº 19.378.769/0001-76, sediado na Rua Aimorés, nÂº 66, bairro Funcionários, cidade de Belo Horizonte, Estado de Minas Gerais, CEP 30.140-920, doravante denominado HERMES PARDINI")
					.append(", mediante as cláusulas e condições a seguir dispostas: ")
					.append("Entende-se por CONTRATANTE aquele que acessa o terminal de auto atendimento eletrônico do HERMES PARDINI, ")
					.append("preenche o formulário de pedido no Totem, efetua a compra e pagamento do CHECK UP - CAMPANHA NOVEMBRO AZUL - ")
					.append("objeto deste TERMO. \n1.1  - O objeto do presente TERMO é a compra do CHECK UP referente a CAMPANHA NOVEMBRO AZUL")
					.append(", mediante o fornecimento de um voucher. 1.1.2 O HERMES PARDINI faculta ao CONTRATANTE a possibilidade de coletar o material biológico em domicílio")
					.append(", dentro da área de cobertura deste serviço e mediante pagamento de custos adicionais. ")
					.append("Para tanto, o CONTRATANTE deverá manter contato com a Central de Relacionamento do HERMES PARDINI por meio do telefone (31) 3228-6200 e solicitar o serviço Coleta em Domicílio.")
					.append("\n1.2   - Fica desde já registrado que a presente negociação somente será concretizada mediante o preenchimento do formulário de pedido.")
					.append("\n1.3   - A contratação ora descrita somente poderá ser usufruída pelo CONTRATANTE, sendo pessoal e intransferível. Caso o CONTRATANTE adquira o produto para utilização de um terceiro, incapaz/curatelado, o represente legal do mesmo deverá ser o responsável pelo preenchimento do formulário de pedido, conforme determina o item 1.2.a)      No momento que antecede a realização da coleta de material biológico, o representante legal do BENEFICIÁRIO incapaz/curatelado deverá apresentar documentação comprobatória que demonstre o poder de representação.")
					.append("\n1.4   - A coleta para a execução dos exames previstos no CHECK UP da CAMPANHA NOVEMBRO AZUL deverá ser realizada preferencialmente no prazo de 07 (sete) dias úteis corridos após a formalização deste instrumento na loja de atendimento escolhida pelo CONTRATANTE.")
					.append("\n1.5   - Fica desde já ressaltado que os valores praticados para a execução dos exames previstos no CHECK UP da CAMPANHA NOVEMBRO AZUL somente terão validade para o mês de novembro.")
					.append("\n1.6   - Esta campanha terá validade enquanto o HERMES PARDINI for detentor de insumos para a execução dos exames previstos no CHECK UP da CAMPANHA NOVEMBRO AZUL.")
					.append("\n1.7   - O pagamento da presente contratação somente será realizado por meio de cartão de crédito, não sendo permitido o parcelamento do valor da prestação do serviço.")
					.append("\n1.8   - Neste ato o CONTRATANTE informa que tomou conhecimento de todo o procedimento para o preparo da coleta necessário para a execução dos exames previstos no CHECK UP para CAMPANHA NOVEMBRO AZUL.")
					.append("\n1.9   - O CONTRATANTE poderá requerer o cancelamento de compra, no prazo de 07 dias contados da compra, mediante o envio de correspondência eletrônica para financeiro.lojavirtual@hermespardini.com.br.")
					.append("\n1.10  - As partes elegem o foro da Comarca de Belo Horizonte, Estado de Minas Gerais para dirimir quaisquer questões oriundas deste TERMO que não puderem ser solucionadas de comum acordo. Eventuais omissões, neste instrumento, caso vierem a acontecer, serão tratadas com o indispensável bom senso e com a mais atenta consideração e boa-fé. Belo Horizonte.")
					.toString();
		}

		@Override
		public String redirectAposAtualizar() {
			return "/pages/ckm/questionario.xhtml?faces-redirect=true";
		}

	},
	CKF {
		@Override
		public String redirectAposLogin() {
			return "/pages/atualizarDados.xhtml?faces-redirect=true";
		}

		@Override
		public String aceitar() {
			return "/pages/ckf/detalheExame.xhtml?faces-redirect=true";
		}

		@Override
		public String redirectAposAtualizar() {
			return "/pages/ckm/questionario.xhtml?faces-redirect=true";
		}

		@Override
		public String descricaoTermoUso() {
			final StringBuilder sb = new StringBuilder();
			return sb.append(
					"Trata-se o presente instrumento de TERMO DE CONDIÇÕES PARA COMPRA DO CHECK UP - CAMPANHA OUTUBRO ROSA - ")
					.append("realizado pelo INSTITUTO HERMES PARDINI S/A, inscrito no CNPJ/MF sob o nº 19.378.769/0001-76, sediado na Rua Aimorés, nº 66, bairro Funcionários, cidade de Belo Horizonte, Estado de Minas Gerais, CEP 30.140-920, doravante denominado HERMES PARDINI")
					.append(", mediante as cláusulas e condições a seguir dispostas: ")
					.append("Entende-se por CONTRATANTE aquele que acessa o terminal de auto atendimento eletrônico do HERMES PARDINI, ")
					.append("preenche o formulário de pedido no Totem, efetua a compra e pagamento do CHECK UP CAMPANHA OUTUBRO ROSA ")
					.append("objeto deste TERMO. \n1.1  - O objeto do presente TERMO é a compra do CHECK UP referente a CAMPANHA OUTUBRO ROSA")
					.append(", mediante o fornecimento de um voucher. 1.1.2 O HERMES PARDINI faculta ao CONTRATANTE a possibilidade de coletar o material biológico em domicílio")
					.append(", dentro da área de cobertura deste serviço e mediante pagamento de custos adicionais. ")
					.append("Para tanto, o CONTRATANTE deverá manter contato com a Central de Relacionamento do HERMES PARDINI por meio do telefone (31) 3228-6200 e solicitar o serviço Coleta em Domicílio.")
					.append("\n1.2   - Fica desde já registrado que a presente negociação somente será concretizada mediante o preenchimento do formulário de pedido.")
					.append("\n1.3   - A contratação ora descrita somente poderá ser usufruída pelo CONTRATANTE, sendo pessoal e intransferível. Caso o CONTRATANTE adquira o produto para utilização de um terceiro, incapaz/curatelado, o represente legal do mesmo deverá ser o responsável pelo preenchimento do formulário de pedido, conforme determina o item 1.2.a)      No momento que antecede a realização da coleta de material biológico, o representante legal do BENEFICIÁRIO incapaz/curatelado deverá apresentar documentação comprobatória que demonstre o poder de representação.")
					.append("\n1.4   - A coleta para a execução dos exames previstos no CHECK UP da CAMPANHA OUTUBRO ROSA deverá ser realizada preferencialmente no prazo de 07 (sete) dias úteis corridos após a formalização deste instrumento na loja de atendimento escolhida pelo CONTRATANTE.")
					.append("\n1.5   - Fica desde já ressaltado que os valores praticados para a execução dos exames previstos no CHECK UP da CAMPANHA OUTUBRO ROSA somente terão validade para o mês de outubro.")
					.append("\n1.6   - Esta campanha terá validade enquanto o HERMES PARDINI for detentor de insumos para a execução dos exames previstos no CHECK UP da CAMPANHA OUTUBRO ROSA.")
					.append("\n1.7   - O pagamento da presente contratação somente será realizado por meio de cartão de crédito, não sendo permitido o parcelamento do valor da prestação do serviço.")
					.append("\n1.8   - Neste ato o CONTRATANTE informa que tomou conhecimento de todo o procedimento para o preparo da coleta necessário para a execução dos exames previstos no CHECK UP para CAMPANHA OUTUBRO ROSA.")
					.append("\n1.9   - O CONTRATANTE poderá requerer o cancelamento de compra, no prazo de 07 dias contados da compra, mediante o envio de correspondência eletrônica para financeiro.lojavirtual@hermespardini.com.br.")
					.append("\n1.10  - As partes elegem o foro da Comarca de Belo Horizonte, Estado de Minas Gerais para dirimir quaisquer questões oriundas deste TERMO que não puderem ser solucionadas de comum acordo. Eventuais omissões, neste instrumento, caso vierem a acontecer, serão tratadas com o indispensável bom senso e com a mais atenta consideração e boa-fé. Belo Horizonte.\"")
					.toString();

		}
	},
	PAT {
		@Override
		public String redirectAposLogin() {
			return "/pages/atualizarDados.xhtml?faces-redirect=true";
		}

		@Override
		public String aceitar() {
			if (TotemUtil.isDesktop()) { // ValidaÃ§Ã£o necessÃ¡ria no momento, atÃ© encontrar outra forma
											// melhor

				return "/pages/pesquisaCliente.xhml?faces-redirect=true";
			} else {
				return "/pages/login.xhml?faces-redirect=true";
			}
		}

		@Override
		public String descricaoTermoUso() {
			final StringBuilder sb = new StringBuilder();
			return sb.append("TERMO DE AUTORIZAÇÃO PARA FINS DE AUTOATENDIMENTO ").append(
					"O signatário já identificado no sistema de autoatendimento do Instituto Hermes Pardini S/A, informa que após o recebimento de confirmação da realização do pré-atendimento e munido das informações (login e senha) recebidas através no endereço eletrônico informado no ato do cadastro, autoriza o lançamento das informações necessárias para a execução dos exames laboratoriais ou de diagnóstico por imagem constantes no pedido médico já deferido pela Operadora de Saúde do qual é beneficiário. Declara ainda ciente da necessidade de preencher manualmente o TERMO DE CONSENTIMENTO e demais documentos necessários antes da realização de exame de diagnóstico por imagem. ")
					.append("Neste ato declara que está ciente: ")
					.append("	Se houver necessidade de realização de exames de diagnóstico por imagem e se porventura o Plano de Saúde não possuir cobertura contratual em relação a determinado insumo, irá responsabilizar-se pelo pagamento do insumo; ")
					.append("	Da orientação recebida, através do endereço eletrônico informado no ato do cadastro, para o preparo necessário para a realização do(s) exame(s) laboratorial(is) ou de diagnóstico por imagem; ")
					.append("	Da necessidade de estar portando cartão do Plano de Saúde; documento oficial de identidade com foto e pedido médico; ")
					.append("	Do prazo de validade de 5 (cinco) dias para comparecer em uma das lojas de atendimento deste laboratório, após o recebimento do login e senha. ")
					.append("Por ser verdade firma o presente termo de autorização. ").toString();

			// return "O beneficiÃ¡rio devidamente identificado no sistema de
			// autoatendimento do Instituto
			// Hermes Pardini S/A autoriza o cadastro das informaÃ§Ãµes necessÃ¡rias para a
			// entrega de
			// materiais pendentes, se houver.";
		}

		@Override
		public String redirectAposAtualizar() {
			return "/pages/pat/agendamento.xhml?faces-redirect=true";
		}

	},
	NAU_E {
		@Override
		public String redirectAposLogin() {
			return "/pages/nau/atualizarDados.xhtml?faces-redirect=true";
		}

		@Override
		public String aceitar() {
			return "/pages/nau/coletaBiometria.xhtml?faces-redirect=true";
		}

		@Override
		public String descricaoTermoUso() {
			return "O beneficiário já identificado através da inserção do cartão do Plano de Saúde e biometria digital "
					+ "no sistema de autoatendimento da ECOAR - MEDICINA DIAGNOSTICA autoriza o cadastro das informações necessárias "
					+ "para a execução dos exames constantes no pedido médico já autorizado pela UNIMED-BH, estando ciente "
					+ "de que deverá preencher manualmente o TERMO DE CONSENTIMENTO e demais documentos necessários antes da realização "
					+ "do exame de diagnóstico por imagem";
		}

		@Override
		public String redirectAposAtualizar() {
			return null;
		}
	},
	RES_E {
		@Override
		public String redirectAposLogin() {
			return "/pages/res/resultado.xhtml?faces-redirect=true";
		}

		@Override
		public String aceitar() {
			return "/pages/ppe/preparacao.xhtml?faces-redirect=true";
		}

		@Override
		public String descricaoTermoUso() {
			return "Ao concordar com a impressão dos resultados de exames, registro que sou responsável pela conferência e"
					+ " retirada de todas as páginas impressas, devendo informar a um colaborador da ECOAR - MEDICINA DIAGNOSTICA a ausência de algum(a) "
					+ "resultado/folha impresso(a). Caso seja constatado que os resultados impressos não correspondem ao usuário deste sistema, "
					+ "comprometo-me a entregar imediatamente os mesmos a um colaborador da ECOAR - MEDICINA DIAGNOSTICA.";
		}

		@Override
		public String redirectAposAtualizar() {
			return null;
		}
	};

}
