package br.com.hermespardini.passelivre.constantsenum;

public enum OrigemIniciarInformacoesTokenSessaoEnum {

	ONLOAD(1, "onLoad"),
	BUSCAR_INFORMACOES_TOTEM(2, "buscarInformacoesTotem"),
	INICIAR_ATENDIMENTO(3, "iniciarAtendimento");
	
	private final Integer id;

	private final String descricao;

	OrigemIniciarInformacoesTokenSessaoEnum(Integer id, String descricao) {
		this.id = id;
		this.descricao = descricao;
	}

	public Integer getId() {
		return id;
	}

	public String getDescricao() {
		return descricao;
	}
}