package br.com.hermespardini.passelivre.filtro;

import java.util.ArrayList;
import java.util.List;

import br.com.hermespardini.passelivre.interfaces.RegraExcecaoParaMaterialPendente;
import br.com.hermespardini.passelivre.model.ExameMaterialPendente;
import br.com.hermespardini.passelivre.model.ExcecaoAtendimentoResult;
import br.com.hermespardini.passelivre.to.ExameFiltroTO;

public class VacinaFiltro implements RegraExcecaoParaMaterialPendente {

	@Override
	public List<ExameMaterialPendente> retornarMaterialPendenteFiltrados(
			final List<ExameMaterialPendente> parMateriaisPendentes, final ExcecaoAtendimentoResult parExcecao) {
		final List<ExameMaterialPendente> materiaisPendentesFiltros = new ArrayList<ExameMaterialPendente>();
		for (final ExameMaterialPendente locExameMaterialPendente : parMateriaisPendentes) {
			final ExameFiltroTO exameFiltroTO = new ExameFiltroTO(locExameMaterialPendente);
			if (exameNaoEhDoTipoVacina(exameFiltroTO, parExcecao)) {
				if (materialPendenteNaoFoiAdicionado(materiaisPendentesFiltros, locExameMaterialPendente)) {
					materiaisPendentesFiltros.add(locExameMaterialPendente);
				}
			}
		}
		return materiaisPendentesFiltros;
	}

	private boolean exameNaoEhDoTipoVacina(final ExameFiltroTO parExameFiltroTO,
			final ExcecaoAtendimentoResult parExcecao) {
		return !parExameFiltroTO.getMaterial().startsWith("VAC");
	}

	private boolean materialPendenteNaoFoiAdicionado(final List<ExameMaterialPendente> parMateriaisPendentes,
			final ExameMaterialPendente parExameMaterialPendente) {
		if (parMateriaisPendentes != null) {
			return !parMateriaisPendentes.contains(parExameMaterialPendente);
		}
		return true;
	}

	@Override
	public List<ExameMaterialPendente> retornarMaterialPendenteExcecao(
			final List<ExameMaterialPendente> parMateriaisPendentes, final ExcecaoAtendimentoResult parExcecao) {
		return null;
	}

}
