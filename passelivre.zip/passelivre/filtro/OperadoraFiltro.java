package br.com.hermespardini.passelivre.filtro;

public class OperadoraFiltro {

}
