package br.com.hermespardini.passelivre.filtro;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import br.com.hermespardini.passelivre.interfaces.RegraExcecaoParaProcedimento;
import br.com.hermespardini.passelivre.model.ExcecaoAtendimentoResult;
import br.com.hermespardini.passelivre.to.ProcedimentoComExamesTO;
import br.com.hermespardini.passelivre.to.ProcedimentoComExamesTOExcecao;

public class AutorizacaoFiltro implements RegraExcecaoParaProcedimento {

	@Override
	public List<ProcedimentoComExamesTO> retornarProcedimentosFiltradas(
			final List<ProcedimentoComExamesTO> parProcedimentosComExamesTO,
			final ExcecaoAtendimentoResult parExcecao) {
		try {
			final List<ProcedimentoComExamesTO> locProcedimentosFiltradas = new ArrayList<>();
			for (final ProcedimentoComExamesTO locProcedimentoComExamesTO : parProcedimentosComExamesTO) {
				if (locProcedimentoComExamesTO.getQuantidadeAutorizadas() != null) {
					if (!locProcedimentoComExamesTO.getQuantidadeAutorizadas().equals(new BigDecimal(0))) {
						locProcedimentosFiltradas.add(locProcedimentoComExamesTO);
					}
				} else {
					return parProcedimentosComExamesTO;
				}
			}
			return locProcedimentosFiltradas;
		} catch (final Exception locExc) {
			return null;
		}
	}

	@Override
	public List<ProcedimentoComExamesTOExcecao> retornarProcedimentosFiltradasExcecao(
			final List<ProcedimentoComExamesTO> parProcedimentosComExamesTO,
			final ExcecaoAtendimentoResult parExcecao) {
		try {
			final List<ProcedimentoComExamesTOExcecao> locProcedimentosFiltradasExcecao = new ArrayList<>();
			for (final ProcedimentoComExamesTO locProcedimentoComExamesTO : parProcedimentosComExamesTO) {
				if (locProcedimentoComExamesTO.getQuantidadeAutorizadas() != null) {
					if (locProcedimentoComExamesTO.getQuantidadeAutorizadas().equals(new BigDecimal(0))) {
						locProcedimentosFiltradasExcecao
								.add(new ProcedimentoComExamesTOExcecao(locProcedimentoComExamesTO));
					}
				}
			}
			return locProcedimentosFiltradasExcecao;
		} catch (final Exception locExc) {
			return null;
		}
	}
}
