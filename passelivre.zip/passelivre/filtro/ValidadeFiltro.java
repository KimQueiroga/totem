package br.com.hermespardini.passelivre.filtro;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.com.hermespardini.passelivre.interfaces.RegraExcecaoParaGuia;
import br.com.hermespardini.passelivre.model.ExcecaoAtendimentoResult;
import br.com.hermespardini.passelivre.model.GuiaAutorizadaExcecao;
import br.com.hermespardini.passelivre.utils.DataUtil;
import br.com.unimedbh.www.Ct_dadosAutorizacao;

public class ValidadeFiltro implements RegraExcecaoParaGuia {

	@Override
	public List<Ct_dadosAutorizacao> retornarGuiasFiltradas(final List<Ct_dadosAutorizacao> parGuias,
			final ExcecaoAtendimentoResult parExcecao) {
		try {
			final DataUtil dataUtil = new DataUtil();
			final List<Ct_dadosAutorizacao> locGuias = new ArrayList<Ct_dadosAutorizacao>();
			final SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			for (final Ct_dadosAutorizacao locGuiaAutorizada : parGuias) {
				final Date dataConvertida = format.parse(locGuiaAutorizada.getDadosAutorizacao().getValidadeSenha());
				final int resultadoComparacao = dataConvertida.compareTo(dataUtil.retornarDataSemHora(new Date()));
				if (resultadoComparacao > 0 || resultadoComparacao == 0) {
					locGuias.add(locGuiaAutorizada);
				}
			}
			return locGuias;
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return null;
		}
	}

	@Override
	public List<GuiaAutorizadaExcecao> retornarGuiasExcecao(final List<Ct_dadosAutorizacao> parGuias,
			final ExcecaoAtendimentoResult parExcecao) {
		try {
			final DataUtil dataUtil = new DataUtil();
			final List<GuiaAutorizadaExcecao> locGuiasExcecao = new ArrayList<GuiaAutorizadaExcecao>();
			final SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			for (final Ct_dadosAutorizacao locGuiaAutorizada : parGuias) {
				final Date dataConvertida = format.parse(locGuiaAutorizada.getDadosAutorizacao().getValidadeSenha());
				final int resultadoComparacao = dataConvertida.compareTo(dataUtil.retornarDataSemHora(new Date()));
				if (resultadoComparacao < 0) {
					locGuiasExcecao.add(GuiaAutorizadaExcecao.retornarGuiaForaDaValidade(locGuiaAutorizada));
				}
			}
			return locGuiasExcecao;
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return null;
		}

	}

}
