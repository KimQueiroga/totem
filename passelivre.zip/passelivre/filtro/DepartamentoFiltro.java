package br.com.hermespardini.passelivre.filtro;

import java.util.ArrayList;
import java.util.List;

import br.com.hermespardini.passelivre.interfaces.RegraExcecaoParaExame;
import br.com.hermespardini.passelivre.interfaces.RegraExcecaoParaMaterialPendente;
import br.com.hermespardini.passelivre.model.ExameHermesPardini;
import br.com.hermespardini.passelivre.model.ExameMaterialPendente;
import br.com.hermespardini.passelivre.model.ExcecaoAtendimentoResult;
import br.com.hermespardini.passelivre.to.DepartamentoFiltroTO;

public class DepartamentoFiltro implements RegraExcecaoParaExame, RegraExcecaoParaMaterialPendente {

	@Override
	public List<ExameHermesPardini> retornarExamesFiltrados(final List<ExameHermesPardini> parExames,
			final ExcecaoAtendimentoResult parExcecao) {
		final List<ExameHermesPardini> locExamesFiltrados = new ArrayList<ExameHermesPardini>();
		if (ehUmaExcecaoValida(parExcecao)) {
			for (final ExameHermesPardini locExame : parExames) {
				final DepartamentoFiltroTO departamentoFiltroTO = new DepartamentoFiltroTO(locExame);
				if (exameMaterialNaoEstaNaListaDeExcecoes(departamentoFiltroTO, parExcecao)) {
					if (exameNaoFoiAdicionado(locExamesFiltrados, locExame)) {
						locExamesFiltrados.add(locExame);
					}
				}
			}
		}
		return locExamesFiltrados;
	}

	private boolean ehUmaExcecaoValida(final ExcecaoAtendimentoResult parExcecao) {
		return parExcecao != null && parExcecao.getDepartamentos() != null;
	}

	private boolean exameNaoFoiAdicionado(final List<ExameHermesPardini> parExames, final ExameHermesPardini parExame) {
		if (!parExames.isEmpty()) {
			return !parExames.contains(parExame);
		}
		return true;
	}

	private boolean exameMaterialNaoEstaNaListaDeExcecoes(final DepartamentoFiltroTO parDepartamentoFiltroTO,
			final ExcecaoAtendimentoResult parExcecaoAtendimentoResult) {
		if (!parExcecaoAtendimentoResult.getDepartamentos().isEmpty()) {
			return !parExcecaoAtendimentoResult.getDepartamentos().contains(parDepartamentoFiltroTO);
		} else {
			return true;
		}
	}

	@Override
	public List<ExameHermesPardini> retornarExamesExcecao(final List<ExameHermesPardini> parExames,
			final ExcecaoAtendimentoResult parExcecao) {
		final List<ExameHermesPardini> locExamesExcecao = new ArrayList<ExameHermesPardini>();
		if (ehUmaExcecaoValida(parExcecao)) {
			for (final ExameHermesPardini locExame : parExames) {
				final DepartamentoFiltroTO departamentoFiltroTO = new DepartamentoFiltroTO(locExame);
				if (exameMaterialEstaNaListaDeExcecoes(departamentoFiltroTO, parExcecao)) {
					if (exameNaoFoiAdicionado(locExamesExcecao, locExame)) {
						locExame.setObservacao(departamentoFiltroTO.getObservacao());
						locExamesExcecao.add(locExame);
					}
				}
			}
		}
		return locExamesExcecao;
	}

	private boolean exameMaterialEstaNaListaDeExcecoes(final DepartamentoFiltroTO parDepartamentoFiltroTO,
			final ExcecaoAtendimentoResult parExcecaoAtendimentoResult) {
		if (parExcecaoAtendimentoResult.getDepartamentos() != null) {
			for (final DepartamentoFiltroTO locDepartamentoFiltroTO : parExcecaoAtendimentoResult.getDepartamentos()) {
				if (locDepartamentoFiltroTO.equals(parDepartamentoFiltroTO)) {
					parDepartamentoFiltroTO.setObservacao(locDepartamentoFiltroTO.getObservacao());
					return true;
				}
			}
			return false;
		} else {
			return false;
		}
	}

	@Override
	public List<ExameMaterialPendente> retornarMaterialPendenteFiltrados(
			final List<ExameMaterialPendente> parMateriaisPendentes, final ExcecaoAtendimentoResult parExcecao) {
		final List<ExameMaterialPendente> locMateriaisPendentesFiltrados = new ArrayList<ExameMaterialPendente>();
		if (ehUmaExcecaoValida(parExcecao)) {
			for (final ExameMaterialPendente locExame : parMateriaisPendentes) {
				final DepartamentoFiltroTO departamentoFiltroTO = new DepartamentoFiltroTO(locExame);
				if (exameMaterialNaoEstaNaListaDeExcecoes(departamentoFiltroTO, parExcecao)) {
					if (materialNaoFoiAdicionado(locMateriaisPendentesFiltrados, locExame)) {
						locMateriaisPendentesFiltrados.add(locExame);
					}
				}
			}
		}
		return locMateriaisPendentesFiltrados;
	}

	private boolean materialNaoFoiAdicionado(final List<ExameMaterialPendente> parMateriaisPendentes,
			final ExameMaterialPendente parExame) {
		if (parMateriaisPendentes != null) {
			return !parMateriaisPendentes.contains(parExame);
		}
		return true;
	}

	@Override
	public List<ExameMaterialPendente> retornarMaterialPendenteExcecao(
			final List<ExameMaterialPendente> parMateriaisPendentes, final ExcecaoAtendimentoResult parExcecao) {
		final List<ExameMaterialPendente> locMateriaisPendentesFiltrados = new ArrayList<ExameMaterialPendente>();
		for (final ExameMaterialPendente locExame : parMateriaisPendentes) {
			final DepartamentoFiltroTO departamentoFiltroTO = new DepartamentoFiltroTO(locExame);
			if (exameMaterialEstaNaListaDeExcecoes(departamentoFiltroTO, parExcecao)) {
				if (materialNaoFoiAdicionado(locMateriaisPendentesFiltrados, locExame)) {
					locExame.setObservacao(departamentoFiltroTO.getObservacao());
					locMateriaisPendentesFiltrados.add(locExame);
				}
			}
		}
		return locMateriaisPendentesFiltrados;
	}

}
