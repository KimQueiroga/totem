package br.com.hermespardini.passelivre.filtro;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import br.com.hermespardini.passelivre.interfaces.RegraExcecaoParaQuestionario;
import br.com.hermespardini.passelivre.to.PerguntaComExameTO;

public class PerguntaConsolidadaFiltro implements RegraExcecaoParaQuestionario {

	private static final String PERMITE_CONSOLIDACAO = "S";

	@Override
	public Map<String, List<PerguntaComExameTO>> retornarQuestionarioFiltrados(
			final Map<String, List<PerguntaComExameTO>> parTodasPerguntasAgrupadas) {

		final Map<String, List<PerguntaComExameTO>> locTodasPerguntasAgrupadasFiltrada = new HashMap<>();

		final List<PerguntaComExameTO> perguntasAgrupadas = new ArrayList<>();
		List<PerguntaComExameTO> perguntasAgrupadasFiltradas = new ArrayList<>();

		for (final String aba : parTodasPerguntasAgrupadas.keySet()) {
			perguntasAgrupadasFiltradas = new ArrayList<>();
			for (final PerguntaComExameTO locPerguntaComExameTO : parTodasPerguntasAgrupadas.get(aba)) {
				if (!locPerguntaComExameTO.isPermiteConsolidacao()) {
					perguntasAgrupadasFiltradas.add(locPerguntaComExameTO);
				} else {
					if (isPerguntaJaFoiAdicionada(perguntasAgrupadas, locPerguntaComExameTO)) {
						perguntasAgrupadasFiltradas.add(locPerguntaComExameTO);
					}
				}
				perguntasAgrupadas.add(locPerguntaComExameTO);
			}
			if (isExitemPerguntasParaEssaAba(perguntasAgrupadasFiltradas)) {
				locTodasPerguntasAgrupadasFiltrada.put(aba, perguntasAgrupadasFiltradas);
			}
		}
		return locTodasPerguntasAgrupadasFiltrada;
	}

	private boolean isPerguntaJaFoiAdicionada(final List<PerguntaComExameTO> perguntasAgrupadas,
			final PerguntaComExameTO locPerguntaComExameTO) {
		return !perguntasAgrupadas.contains(locPerguntaComExameTO);
	}

	private boolean isExitemPerguntasParaEssaAba(final List<PerguntaComExameTO> perguntasAgrupadasFiltradas) {
		return !perguntasAgrupadasFiltradas.isEmpty();
	}

}
