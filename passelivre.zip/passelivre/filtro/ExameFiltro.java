package br.com.hermespardini.passelivre.filtro;

import java.util.ArrayList;
import java.util.List;

import br.com.hermespardini.passelivre.interfaces.RegraExcecaoParaExame;
import br.com.hermespardini.passelivre.interfaces.RegraExcecaoParaMaterialPendente;
import br.com.hermespardini.passelivre.model.ExameHermesPardini;
import br.com.hermespardini.passelivre.model.ExameMaterialPendente;
import br.com.hermespardini.passelivre.model.ExcecaoAtendimentoResult;
import br.com.hermespardini.passelivre.to.ExameFiltroTO;

public class ExameFiltro implements RegraExcecaoParaExame, RegraExcecaoParaMaterialPendente {

	@Override
	public List<ExameHermesPardini> retornarExamesFiltrados(final List<ExameHermesPardini> parExames,
			final ExcecaoAtendimentoResult parExcecao) {
		final List<ExameHermesPardini> locExamesFiltrados = new ArrayList<>();
		for (final ExameHermesPardini locExame : parExames) {
			final ExameFiltroTO exameFiltroTO = new ExameFiltroTO(locExame);
			if (ehUmaExcecaoValida(parExcecao)) {
				if (exameMaterialNaoEstaNaListaDeExcecoes(exameFiltroTO, parExcecao)) {
					if (exameNaoFoiAdicionado(locExamesFiltrados, locExame)) {
						locExamesFiltrados.add(locExame);
					}
				}
			}
		}
		return locExamesFiltrados;
	}

	private boolean ehUmaExcecaoValida(final ExcecaoAtendimentoResult parExcecao) {
		return parExcecao != null && parExcecao.getExames() != null;
	}

	private boolean exameNaoFoiAdicionado(final List<ExameHermesPardini> parExames,
			final ExameHermesPardini parExameHermesPardini) {
		if (parExames != null || !parExames.isEmpty()) {
			return !parExames.contains(parExameHermesPardini);
		}
		return false;
	}

	private boolean exameMaterialNaoEstaNaListaDeExcecoes(final ExameFiltroTO parExameFiltroTO,
			final ExcecaoAtendimentoResult parExcecaoAtendimentoResult) {
		if (parExcecaoAtendimentoResult.getExames() != null || !parExcecaoAtendimentoResult.getExames().isEmpty()) {
			return !parExcecaoAtendimentoResult.getExames().contains(parExameFiltroTO);
		} else {
			return false;
		}
	}

	@Override
	public List<ExameHermesPardini> retornarExamesExcecao(final List<ExameHermesPardini> parExames,
			final ExcecaoAtendimentoResult parExcecao) {
		final List<ExameHermesPardini> locExamesFiltrados = new ArrayList<>();
		if (ehUmaExcecaoValida(parExcecao)) {
			for (final ExameHermesPardini locExameHermesPardini : parExames) {
				final ExameFiltroTO exameFiltroTO = new ExameFiltroTO(locExameHermesPardini);
				if (exameEstaNaListaDeExcecoes(exameFiltroTO, parExcecao, locExameHermesPardini)) {
					if (exameNaoFoiAdicionado(locExamesFiltrados, locExameHermesPardini)) {
						locExameHermesPardini.setObservacao(exameFiltroTO.getObservacao());
						locExamesFiltrados.add(locExameHermesPardini);
					}
				}
			}
		}
		return locExamesFiltrados;
	}

	private boolean exameEstaNaListaDeExcecoes(final ExameFiltroTO parExameFiltroTO,
			final ExcecaoAtendimentoResult parExcecaoAtendimentoResult,
			final ExameHermesPardini parExameHermesPardini) {
		if (parExcecaoAtendimentoResult.getExames() != null) {
			for (final ExameFiltroTO locExameFiltroTO : parExcecaoAtendimentoResult.getExames()) {
				if (locExameFiltroTO.equals(parExameFiltroTO)) {
					parExameFiltroTO.setObservacao(locExameFiltroTO.getObservacao());
					return true;
				}
			}
			return false;
		} else {
			return false;
		}
	}

	private boolean exameMaterialEstaNaListaDeExcecoes(final ExameFiltroTO parExameFiltroTO,
			final ExcecaoAtendimentoResult parExcecaoAtendimentoResult,
			final ExameMaterialPendente parExameMaterialPendente) {
		if (parExcecaoAtendimentoResult.getExames() != null) {
			for (final ExameFiltroTO locExameFiltroTO : parExcecaoAtendimentoResult.getExames()) {
				if (locExameFiltroTO.equals(parExameFiltroTO)) {
					parExameFiltroTO.setObservacao(locExameFiltroTO.getObservacao());
					return true;
				}
			}
			return false;
		} else {
			return false;
		}
	}

	@Override
	public List<ExameMaterialPendente> retornarMaterialPendenteFiltrados(
			final List<ExameMaterialPendente> parMateriaisPendentes, final ExcecaoAtendimentoResult parExcecao) {
		final List<ExameMaterialPendente> materiaisPendentesFiltros = new ArrayList<>();
		if (ehUmaExcecaoValida(parExcecao)) {
			for (final ExameMaterialPendente locExameMaterialPendente : parMateriaisPendentes) {
				final ExameFiltroTO exameFiltroTO = new ExameFiltroTO(locExameMaterialPendente);
				if (exameMaterialNaoEstaNaListaDeExcecoes(exameFiltroTO, parExcecao)) {
					if (materialPendenteNaoFoiAdicionado(materiaisPendentesFiltros, locExameMaterialPendente)) {
						materiaisPendentesFiltros.add(locExameMaterialPendente);
					}
				}
			}
		}
		return materiaisPendentesFiltros;
	}

	private boolean materialPendenteNaoFoiAdicionado(final List<ExameMaterialPendente> parMateriaisPendentes,
			final ExameMaterialPendente parExameMaterialPendente) {
		if (parMateriaisPendentes != null) {
			return !parMateriaisPendentes.contains(parExameMaterialPendente);
		}
		return true;
	}

	private boolean materialPendenteNaoEstaNaListaDeExcecoes(final ExameFiltroTO parExameFiltroTO,
			final ExcecaoAtendimentoResult parExcecao) {
		if (parExcecao.getExames() != null) {
			return !parExcecao.getExames().contains(parExameFiltroTO);
		} else {
			return true;
		}
	}

	@Override
	public List<ExameMaterialPendente> retornarMaterialPendenteExcecao(
			final List<ExameMaterialPendente> parMateriaisPendentes, final ExcecaoAtendimentoResult parExcecao) {
		final List<ExameMaterialPendente> materiaisPendentesFiltros = new ArrayList<>();
		if (ehUmaExcecaoValida(parExcecao)) {
			for (final ExameMaterialPendente locExameMaterialPendente : parMateriaisPendentes) {
				final ExameFiltroTO exameFiltroTO = new ExameFiltroTO(locExameMaterialPendente);
				if (exameMaterialEstaNaListaDeExcecoes(exameFiltroTO, parExcecao, locExameMaterialPendente)) {
					if (materialPendenteNaoFoiAdicionado(parMateriaisPendentes, locExameMaterialPendente)) {
						locExameMaterialPendente.setObservacao(exameFiltroTO.getObservacao());
						materiaisPendentesFiltros.add(locExameMaterialPendente);
					}
				}
			}
		}
		return materiaisPendentesFiltros;
	}

	private boolean materialPendenteEstaNaListaDeExcecoes(final ExameFiltroTO parExameFiltroTO,
			final ExcecaoAtendimentoResult parExcecao) {
		if (parExcecao.getExames() != null) {
			for (final ExameFiltroTO locExameFiltroTO : parExcecao.getExames()) {
				if (locExameFiltroTO.equals(parExameFiltroTO)) {
					parExameFiltroTO.setObservacao(locExameFiltroTO.getObservacao());
					return true;
				}
			}
			return false;
		} else {
			return false;
		}
	}

}
