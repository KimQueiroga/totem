package br.com.hermespardini.passelivre.filtro;

import java.util.ArrayList;
import java.util.List;

import br.com.hermespardini.passelivre.interfaces.RegraExcecaoParaGuia;
import br.com.hermespardini.passelivre.model.ExcecaoAtendimentoResult;
import br.com.hermespardini.passelivre.model.GuiaAutorizadaExcecao;
import br.com.hermespardini.passelivre.to.ProcedimentoFiltroTO;
import br.com.unimedbh.www.Ct_dadosAutorizacao;
import br.gov.ans.www.padroes.tiss.schemas.Ct_itemSolicitacao;

public class ProcedimentoFiltro implements RegraExcecaoParaGuia {

	@Override
	public List<Ct_dadosAutorizacao> retornarGuiasFiltradas(final List<Ct_dadosAutorizacao> parGuias,
			final ExcecaoAtendimentoResult parExcecao) throws RuntimeException {
		final List<Ct_dadosAutorizacao> guiasFiltradas = new ArrayList<>();
		if (ehUmaExcecaoValida(parExcecao)) {
			for (final Ct_dadosAutorizacao locCt_dadosAutorizacao : parGuias) {
				if (codigoCompletoNaoEstaNaListaDeExcecoes(locCt_dadosAutorizacao.getProcedimentos(), parExcecao)) {
					if (iniciaisDoCodigosNaoEstaoNaListaDeExcecoes(locCt_dadosAutorizacao.getProcedimentos(),
							parExcecao)) {
						if (guiaNaoFoiAdicionada(guiasFiltradas, locCt_dadosAutorizacao)) {
							guiasFiltradas.add(locCt_dadosAutorizacao);
						}
					}
				}
			}
		}
		return guiasFiltradas;
	}

	private boolean codigoCompletoNaoEstaNaListaDeExcecoes(final Ct_itemSolicitacao[] parCt_itemSolicitacaos,
			final ExcecaoAtendimentoResult parExcecao) {
		for (final Ct_itemSolicitacao locCt_itemSolicitacao : parCt_itemSolicitacaos) {
			final ProcedimentoFiltroTO codigoFiltroTO = new ProcedimentoFiltroTO(
					locCt_itemSolicitacao.getIdentificacaoProcedimentos().getCodigo(), "E");
			if (parExcecao.getProcedimentos().contains(codigoFiltroTO)) {
				return false;
			}
		}
		return true;
	}

	private boolean guiaNaoFoiAdicionada(final List<Ct_dadosAutorizacao> guiasFiltradas,
			final Ct_dadosAutorizacao locCt_dadosAutorizacao) {
		return !guiasFiltradas.contains(locCt_dadosAutorizacao);
	}

	private boolean codigoCompletoNaoEstaNaListaDeExcecoes(final ExcecaoAtendimentoResult parExcecao,
			final ProcedimentoFiltroTO codigoFiltroTO) {
		return !parExcecao.getProcedimentos().contains(codigoFiltroTO);
	}

	private boolean ehUmaExcecaoValida(final ExcecaoAtendimentoResult parExcecao) {
		return parExcecao != null && parExcecao.getProcedimentos() != null;
	}

	private boolean iniciaisDoCodigosNaoEstaoNaListaDeExcecoes(final Ct_itemSolicitacao[] parCt_itemSolicitacaos,
			final ExcecaoAtendimentoResult parExcecao) {
		for (final Ct_itemSolicitacao locCt_itemSolicitacao : parCt_itemSolicitacaos) {
			final ProcedimentoFiltroTO codigoFiltroTO = new ProcedimentoFiltroTO(
					locCt_itemSolicitacao.getIdentificacaoProcedimentos().getCodigo(), "E");
			if (!codigoFiltroTO.isIniciaisExistemNaLista(parExcecao) || isExcecaoEstaComoInclusao(parExcecao,
					locCt_itemSolicitacao.getIdentificacaoProcedimentos().getCodigo())) {
				return true;
			}
		}
		return false;
	}

	private boolean isExcecaoEstaComoInclusao(final ExcecaoAtendimentoResult parExcecao, final String parCodigo) {
		// return parExcecao.getProcedimentos().contains(new
		// ProcedimentoFiltroTO(parCodigo, "I"));
		for (final ProcedimentoFiltroTO locProcedimentoFiltroTO : parExcecao.getProcedimentos()) {
			if ((locProcedimentoFiltroTO.getCodigo().equals(parCodigo)
					|| locProcedimentoFiltroTO.getCodigo().contains("%") && parCodigo.startsWith(locProcedimentoFiltroTO
							.getCodigo().substring(0, locProcedimentoFiltroTO.getCodigo().indexOf("%"))))
					&& locProcedimentoFiltroTO.getAcao().equals("I")) {
				return true;
			}
		}
		return false;
	}

	@Override
	public List<GuiaAutorizadaExcecao> retornarGuiasExcecao(final List<Ct_dadosAutorizacao> parGuias,
			final ExcecaoAtendimentoResult parExcecao) {
		final List<GuiaAutorizadaExcecao> guiasFiltradas = new ArrayList<>();
		if (ehUmaExcecaoValida(parExcecao)) {
			for (final Ct_dadosAutorizacao locCt_dadosAutorizacao : parGuias) {
				for (final Ct_itemSolicitacao locCt_itemSolicitacao : locCt_dadosAutorizacao.getProcedimentos()) {
					final ProcedimentoFiltroTO codigoFiltroTO = new ProcedimentoFiltroTO(
							locCt_itemSolicitacao.getIdentificacaoProcedimentos().getCodigo(), "E");
					if (codigoCompletoEstaNaListaDeExcecoes(parExcecao, codigoFiltroTO, locCt_itemSolicitacao)
							|| iniciaisDoCodigosEstaoNaListaDeExcecoes(locCt_dadosAutorizacao.getProcedimentos(),
									locCt_itemSolicitacao, parExcecao)) {
						final GuiaAutorizadaExcecao guiaAutorizadaExcecao = new GuiaAutorizadaExcecao(
								locCt_dadosAutorizacao, locCt_itemSolicitacao);
						if (guiaExcecaoNaoFoiAdicionada(guiasFiltradas, guiaAutorizadaExcecao)) {
							guiasFiltradas.add(guiaAutorizadaExcecao);
						}
					}
				}
			}
		}
		return guiasFiltradas;
	}

	private boolean guiaExcecaoNaoFoiAdicionada(final List<GuiaAutorizadaExcecao> parGuiasFiltradas,
			final GuiaAutorizadaExcecao parCt_dadosAutorizacao) {
		if (parGuiasFiltradas != null) {
			return !parGuiasFiltradas.contains(parCt_dadosAutorizacao);
		}
		return false;
	}

	private boolean iniciaisDoCodigosEstaoNaListaDeExcecoes(final Ct_itemSolicitacao[] parCt_itemSolicitacaos,
			final Ct_itemSolicitacao parCt_itemSolicitacao, final ExcecaoAtendimentoResult parExcecao) {
		for (final Ct_itemSolicitacao locCt_itemSolicitacao : parCt_itemSolicitacaos) {
			final ProcedimentoFiltroTO codigoFiltroTO = new ProcedimentoFiltroTO(
					locCt_itemSolicitacao.getIdentificacaoProcedimentos().getCodigo(), "E");
			if (codigoFiltroTO.isIniciaisExistemNaLista(parExcecao) && !isExcecaoEstaComoInclusao(parExcecao,
					locCt_itemSolicitacao.getIdentificacaoProcedimentos().getCodigo())) {
				parCt_itemSolicitacao.setObservacao(codigoFiltroTO.getObservacao());
				return true;
			}
		}
		return false;
	}

	private boolean codigoCompletoEstaNaListaDeExcecoes(final ExcecaoAtendimentoResult parExcecao,
			final ProcedimentoFiltroTO parCodigoFiltroTO, final Ct_itemSolicitacao parCt_itemSolicitacao) {
		if (parExcecao.getProcedimentos() != null) {
			for (final ProcedimentoFiltroTO locProcedimentoFiltroTO : parExcecao.getProcedimentos()) {
				if (locProcedimentoFiltroTO.equals(parCodigoFiltroTO)) {
					parCt_itemSolicitacao.setObservacao(locProcedimentoFiltroTO.getObservacao());
					return true;
				}
			}
		}
		return false;
	}

}
