package br.com.hermespardini.passelivre.filtro;

import java.util.ArrayList;
import java.util.List;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.interfaces.RegraExcecaoParaGuia;
import br.com.hermespardini.passelivre.model.ExcecaoAtendimentoResult;
import br.com.hermespardini.passelivre.model.GuiaAutorizadaExcecao;
import br.com.hermespardini.passelivre.utils.TotemUtil;
import br.com.unimedbh.www.Ct_dadosAutorizacao;
import br.gov.ans.www.padroes.tiss.schemas.Ct_itemSolicitacao;
import br.gov.ans.www.padroes.tiss.schemas.Ct_motivoGlosa;

public class GlosaFiltro implements RegraExcecaoParaGuia {

	@Override
	public List<Ct_dadosAutorizacao> retornarGuiasFiltradas(final List<Ct_dadosAutorizacao> parGuias,
			final ExcecaoAtendimentoResult parExcecao) {
		final List<Ct_dadosAutorizacao> localGuias = new ArrayList<>();
		if (parGuias != null) {
			for (final Ct_dadosAutorizacao locCt_dadosAutorizacao : parGuias) {
				if (locCt_dadosAutorizacao.getMotivoNegativa() == null
						|| locCt_dadosAutorizacao.getMotivoNegativa().length == 0) {
					for (Ct_itemSolicitacao item : locCt_dadosAutorizacao.getProcedimentos()) {
						if (item.getGlosas() == null || item.getGlosas().length == 0) {
							localGuias.add(locCt_dadosAutorizacao);
							break;
						}
					}
				} else if (!TotemUtil.getAmbienteProducao()) {
					if (locCt_dadosAutorizacao.getMotivoNegativa() != null
							&& locCt_dadosAutorizacao.getMotivoNegativa().length > 0
							&& locCt_dadosAutorizacao.getMotivoNegativa()[0].getCodigoGlosa()
									.equals(Constantes.GLOSA_GUIA_UTILIZADA)) {
						localGuias.add(locCt_dadosAutorizacao);
					}
				}
			}
		}
		return localGuias;
	}

	@Override
	public List<GuiaAutorizadaExcecao> retornarGuiasExcecao(final List<Ct_dadosAutorizacao> parGuias,
			final ExcecaoAtendimentoResult parExcecao) {
		final List<GuiaAutorizadaExcecao> guiasFiltradas = new ArrayList<>();
		if (parGuias != null) {
			for (final Ct_dadosAutorizacao locCt_dadosAutorizacao : parGuias) {
				if (locCt_dadosAutorizacao.getMotivoNegativa() != null
						&& locCt_dadosAutorizacao.getMotivoNegativa().length > 0
						&& !locCt_dadosAutorizacao.getMotivoNegativa()[0].getCodigoGlosa()
								.equals(Constantes.GLOSA_GUIA_UTILIZADA)) {
					final GuiaAutorizadaExcecao guiaAutorizadaExcecao = GuiaAutorizadaExcecao
							.retornarGuiasEmGlosa(locCt_dadosAutorizacao);
					guiasFiltradas.add(guiaAutorizadaExcecao);
				} else {
					for (Ct_itemSolicitacao item : locCt_dadosAutorizacao.getProcedimentos()) {
						if (item.getGlosas() != null && item.getGlosas().length > 0) {
							final GuiaAutorizadaExcecao guiaAutorizadaExcecao = GuiaAutorizadaExcecao
									.retornarGuiasEmGlosa(locCt_dadosAutorizacao);
							guiasFiltradas.add(guiaAutorizadaExcecao);
							break;
						}
					}
				}
			}
		}
		return guiasFiltradas;
	}

	public static void main(final String[] args) {
		final Integer a[] = new Integer[] { 1, 2 };
		System.out.println(a == null);
	}
}
