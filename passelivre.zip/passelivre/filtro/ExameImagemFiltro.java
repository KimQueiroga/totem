package br.com.hermespardini.passelivre.filtro;

import java.util.List;

import br.com.hermespardini.passelivre.interfaces.RegraExcecaoParaExame;
import br.com.hermespardini.passelivre.model.ExameHermesPardini;
import br.com.hermespardini.passelivre.model.ExcecaoAtendimentoResult;

public class ExameImagemFiltro implements RegraExcecaoParaExame {

	@Override
	public List<ExameHermesPardini> retornarExamesFiltrados(final List<ExameHermesPardini> parExames,
			final ExcecaoAtendimentoResult parExcecaoAtendimentoResult) {
		return null;
	}

	@Override
	public List<ExameHermesPardini> retornarExamesExcecao(final List<ExameHermesPardini> parExames,
			final ExcecaoAtendimentoResult parExcecaoAtendimentoResult) {
		return null;
	}

}
