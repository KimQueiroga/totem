package br.com.hermespardini.passelivre.validator;

import java.text.SimpleDateFormat;

import javax.faces.application.FacesMessage;
import javax.faces.validator.ValidatorException;

public class DataHoraValidator {

	public static void validate(final String data) throws ValidatorException {
		final SimpleDateFormat simple = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		simple.setLenient(false);
		try {
			simple.parse(data);
		} catch (final Exception locExc) {
			final FacesMessage msg = new FacesMessage("Data ou Hora inválida! " + data,
					"Data ou Hora inválida! " + data);
			msg.setSeverity(FacesMessage.SEVERITY_ERROR);
			throw new ValidatorException(msg);
		}
	}

}
