package br.com.hermespardini.passelivre.validator;

import java.util.Arrays;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

import org.primefaces.context.RequestContext;

@FacesValidator("cpfValidatorPasseLivre")
public class CpfValidatorPasseLivre implements Validator {

	private final int[] pesoCpf = { 11, 10, 9, 8, 7, 6, 5, 4, 3, 2 };

// @formatter:off
private List<String> cpfInvalidos = Arrays.asList("00000000000", "11111111111", "22222222222", "33333333333",
    "44444444444", "55555555555", "66666666666", "77777777777", "88888888888", "99999999999");

// @formatter:on

	@Override
	public void validate(final FacesContext parFacesContext, final UIComponent parUiComponent,
			final Object parValueToValidate) throws ValidatorException {

		final String loCpf = String.valueOf(parValueToValidate);
		if (loCpf == null || "".equals(loCpf)) {
			return;
		} else if (!validarCpf(loCpf)) {
			final FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro", "CPF inválido!");
			RequestContext.getCurrentInstance().showMessageInDialog(message);
			throw new ValidatorException(message);
		}
	}

	private int calcularDigito(final String str, final int[] peso) {
		int soma = 0;
		for (int indice = str.length() - 1, digito; indice >= 0; indice--) {
			digito = Integer.parseInt(str.substring(indice, indice + 1));
			soma += digito * peso[peso.length - str.length() + indice];
		}
		soma = 11 - soma % 11;
		return soma > 9 ? 0 : soma;
	}

	private boolean validarCpf(final String parCpf) {
		boolean loCpfValido = true;
		// Considerar como erro CPFs com apenas números iguais.
		if (parCpf == null || cpfInvalidos.contains(parCpf) || parCpf.length() != 11) {
			loCpfValido = false;
		} else {
			final Integer digito1 = calcularDigito(parCpf.substring(0, 9), pesoCpf);
			final Integer digito2 = calcularDigito(parCpf.substring(0, 9) + digito1, pesoCpf);
			loCpfValido = parCpf.equals(parCpf.substring(0, 9) + digito1.toString() + digito2.toString());
		}

		return loCpfValido;
	}
}
