package br.com.hermespardini.passelivre.validator;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

import org.primefaces.context.RequestContext;

@FacesValidator("dataValidator")
public class DataValidator implements Validator {

	@Override
	public void validate(final FacesContext parFacesContext, final UIComponent parUiComponent,
			final Object parValueToValidate) throws ValidatorException {
		final String loData = String.valueOf(parValueToValidate);
		try {
			validarData(loData);
		} catch (final Exception locExc) {
			final FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro", "Data inválida!");
			// RequestContext.getCurrentInstance().showMessageInDialog(message);
			throw new ValidatorException(message);
		}
	}

	private void validarData(final String loData) throws Exception {
		final SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		sdf.setLenient(false);
		sdf.parse(loData);
		if (new Date().before(sdf.getCalendar().getTime())) {
			throw new Exception("Data não pode ser superior a data atual!");
		}

	}

}
