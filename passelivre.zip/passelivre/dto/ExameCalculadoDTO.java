package br.com.hermespardini.passelivre.dto;

import java.io.Serializable;

public class ExameCalculadoDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String procedimento;
	private String descricao;
	private String material;
	private String descMaterial;

}
