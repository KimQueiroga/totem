package br.com.hermespardini.passelivre.components;

import java.util.ArrayList;
import java.util.List;

import javax.faces.component.UIComponent;
import javax.faces.component.UISelectItems;
import javax.faces.model.SelectItem;

import org.primefaces.component.message.Message;
import org.primefaces.component.outputlabel.OutputLabel;
import org.primefaces.component.panelgrid.PanelGrid;
import org.primefaces.component.selectoneradio.SelectOneRadio;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.interfaces.Component;
import br.com.hermespardini.passelivre.to.PerguntaComExameTO;
import br.com.hermespardini.passelivre.utils.ComponenteUtil;

public class ComponenteRadioChoice implements Component {

	private PerguntaComExameTO pergunta;
	private PanelGrid panelGrid;
	private ComponenteUtil componenteUtil;
	private StringBuilder sb;
	private String id;

	public ComponenteRadioChoice(final PerguntaComExameTO parPergunta, final PanelGrid parPanelGrid) {
		pergunta = parPergunta;
		panelGrid = parPanelGrid;
		componenteUtil = new ComponenteUtil();
		id = retornarId();
	}

	@Override
	public UIComponent createForUnimed() {
		try {
			sb = new StringBuilder();

			final OutputLabel otpExame = new OutputLabel();
			otpExame.setValue(pergunta.getDescricaoExame());

			final OutputLabel otpPergunta = new OutputLabel();
			otpPergunta.setValue(pergunta.getDescricao());
			otpPergunta.setFor(id);

			final SelectOneRadio sor = new SelectOneRadio();
			// sor.setDisabled(pergunta.getDisable());
			final List<SelectItem> choose = new ArrayList<>();
			choose.add(new SelectItem("S", "Sim"));
			choose.add(new SelectItem("N", "Não"));
			final UISelectItems selectItems = new UISelectItems();
			selectItems.setValue(choose);
			sor.getChildren().add(selectItems);
			sor.setId(id);
			sor.setOnchange("hideKeyboard('keyboard')");
			sor.setRequiredMessage(Constantes.CAMPO_OBRIGATORIO);
			sor.setRequired(componenteUtil.isObrigatorio(pergunta.getObrigatorio()));
			sor.setValueExpression("value", componenteUtil.getValueExpression(
					sb.append("#{questionarioBean.mapQuestionarios['").append(id).append("']}").toString()));

			final Message msg = new Message();
			msg.setFor(id);

			panelGrid.getChildren().add(otpPergunta);
			panelGrid.getChildren().add(sor);
			panelGrid.getChildren().add(msg);
			return panelGrid;
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return null;
		}
	}

	private String retornarId() {
		return componenteUtil.retornarId(pergunta, "sor_");
	}

	@Override
	public UIComponent createForMaterialPendente() {
		try {
			sb = new StringBuilder();
			final OutputLabel otpExame = new OutputLabel();
			otpExame.setValue(pergunta.getDescricaoExame());

			final OutputLabel otpPergunta = new OutputLabel();
			otpPergunta.setValue(pergunta.getDescricao());
			otpPergunta.setFor(id);

			final SelectOneRadio sor = new SelectOneRadio();
			// sor.setDisabled(pergunta.getDisable());
			final List<SelectItem> choose = new ArrayList<>();
			choose.add(new SelectItem("S", "Sim"));
			choose.add(new SelectItem("N", "Não"));
			final UISelectItems selectItems = new UISelectItems();
			selectItems.setValue(choose);
			sor.getChildren().add(selectItems);
			sor.setId(id);
			sor.setOnchange("hideKeyboard('keyboard')");
			sor.setRequiredMessage(Constantes.CAMPO_OBRIGATORIO);
			sor.setRequired(componenteUtil.isObrigatorio(pergunta.getObrigatorio()));
			sor.setValueExpression("value", componenteUtil.getValueExpression(
					sb.append("#{entregaMaterialPendenteBean.mapQuestionarios['").append(id).append("']}").toString()));

			final Message msg = new Message();
			msg.setFor(id);

			panelGrid.getChildren().add(otpPergunta);
			panelGrid.getChildren().add(sor);
			panelGrid.getChildren().add(msg);
			return panelGrid;
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return null;
		}
	}

	@Override
	public UIComponent createForUnimedGuiche() {
		try {
			sb = new StringBuilder();

			final OutputLabel otpExame = new OutputLabel();
			otpExame.setId("optExame_" + id);
			otpExame.setValue(pergunta.getDescricaoExame());

			final OutputLabel otpPergunta = new OutputLabel();
			otpPergunta.setValue(pergunta.getDescricao());
			otpPergunta.setId("optPergunta_" + id);
			otpPergunta.setFor(id);

			final SelectOneRadio sor = new SelectOneRadio();
			// sor.setDisabled(pergunta.getDisable());
			final List<SelectItem> choose = new ArrayList<>();
			choose.add(new SelectItem("S", "Sim"));
			choose.add(new SelectItem("N", "Não"));
			final UISelectItems selectItems = new UISelectItems();
			selectItems.setId("sliQuestionario_" + id);
			selectItems.setValue(choose);

			sor.getChildren().add(selectItems);
			sor.setId(id);
			sor.setRequiredMessage(Constantes.CAMPO_OBRIGATORIO);
			sor.setRequired(componenteUtil.isObrigatorio(pergunta.getObrigatorio()));
			sor.setValueExpression("value",
					componenteUtil.getValueExpression(sb.append("#{novoAtendimentoUnimedGicheBean.mapQuestionarios['")
							.append(id).append("']}").toString()));

			final Message msg = new Message();
			msg.setFor(id);

			panelGrid.getChildren().add(otpPergunta);
			panelGrid.getChildren().add(sor);
			panelGrid.getChildren().add(msg);
			return panelGrid;
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return null;
		}
	}

	@Override
	public UIComponent createForQuestionario() {
		try {
			sb = new StringBuilder();

			final OutputLabel otpExame = new OutputLabel();
			otpExame.setId("optExame_" + id);
			otpExame.setValue(pergunta.getDescricaoExame());

			final OutputLabel otpPergunta = new OutputLabel();
			otpPergunta.setValue(pergunta.getDescricao());
			otpPergunta.setId("optPergunta_" + id);
			otpPergunta.setFor(id);

			final SelectOneRadio sor = new SelectOneRadio();
			// sor.setDisabled(pergunta.getDisable());
			final List<SelectItem> choose = new ArrayList<>();
			choose.add(new SelectItem("S", "Sim"));
			choose.add(new SelectItem("N", "Não"));
			final UISelectItems selectItems = new UISelectItems();
			selectItems.setId("sliQuestionario_" + id);
			selectItems.setValue(choose);

			sor.getChildren().add(selectItems);
			sor.setId(id);
			sor.setRequiredMessage(Constantes.CAMPO_OBRIGATORIO);
			sor.setRequired(componenteUtil.isObrigatorio(pergunta.getObrigatorio()));
			sor.setValueExpression("value", componenteUtil.getValueExpression(
					sb.append("#{questionarioBean.mapQuestionarios['").append(id).append("']}").toString()));

			final Message msg = new Message();
			msg.setFor(id);

			panelGrid.getChildren().add(otpPergunta);
			panelGrid.getChildren().add(sor);
			panelGrid.getChildren().add(msg);
			return panelGrid;
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return null;
		}
	}

	public UIComponent createForQuestionarioCheckup() {
		try {
			sb = new StringBuilder();

			final OutputLabel otpExame = new OutputLabel();
			otpExame.setValue(pergunta.getDescricaoExame());

			final OutputLabel otpPergunta = new OutputLabel();
			otpPergunta.setValue(pergunta.getDescricao());
			otpPergunta.setFor(id);

			final SelectOneRadio sor = new SelectOneRadio();
			// sor.setDisabled(pergunta.getDisable());
			final List<SelectItem> choose = new ArrayList<>();
			choose.add(new SelectItem("S", "Sim"));
			choose.add(new SelectItem("N", "Não"));
			final UISelectItems selectItems = new UISelectItems();
			selectItems.setValue(choose);
			sor.getChildren().add(selectItems);
			sor.setId(id);
			sor.setOnchange("hideKeyboard('keyboard')");
			sor.setRequiredMessage(Constantes.CAMPO_OBRIGATORIO);
			sor.setRequired(componenteUtil.isObrigatorio(pergunta.getObrigatorio()));
			sor.setValueExpression("value", componenteUtil.getValueExpression(
					sb.append("#{questionarioCheckupBean.mapQuestionarios['").append(id).append("']}").toString()));

			final Message msg = new Message();
			msg.setFor(id);

			panelGrid.getChildren().add(otpPergunta);
			panelGrid.getChildren().add(sor);
			panelGrid.getChildren().add(msg);
			return panelGrid;
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return null;
		}
	}
}
