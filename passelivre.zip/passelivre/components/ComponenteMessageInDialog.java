package br.com.hermespardini.passelivre.components;

import javax.faces.component.UIComponent;

import org.primefaces.component.commandlink.CommandLink;
import org.primefaces.component.dialog.Dialog;
import org.primefaces.component.graphicimage.GraphicImage;
import org.primefaces.component.outputlabel.OutputLabel;
import org.primefaces.component.panelgrid.PanelGrid;

import br.com.hermespardini.passelivre.exception.RegraNegocioException;

public class ComponenteMessageInDialog {

	public UIComponent create(final String message) throws RegraNegocioException {
		try {
			final Dialog dlgMessage = new Dialog();
			dlgMessage.setDynamic(false);
			dlgMessage.setResizable(false);
			dlgMessage.setPosition("center");
			// dlgMessage.setWidgetVar("dlgMessage");
			dlgMessage.setCloseOnEscape(true);
			dlgMessage.setWidth("576");
			dlgMessage.setStyleClass("pngMensagem");
			dlgMessage.setModal(true);

			final PanelGrid pngMessage = new PanelGrid();
			pngMessage.setColumns(1);
			pngMessage.setStyle("width: 500px !important;");

			final OutputLabel otpMessage = new OutputLabel();
			otpMessage.setValue(message);

			final CommandLink btnFechar = new CommandLink();
			btnFechar.setOnclick("PF('dlgMessage').hide();");
			btnFechar.setImmediate(true);
			btnFechar.setStyle("left: 40% !important;position: relative !important;");

			final GraphicImage gpiFechar = new GraphicImage();
			gpiFechar.setName("/images/buttons/BTN_fechar.png");

			btnFechar.getChildren().add(gpiFechar);
			pngMessage.getChildren().add(otpMessage);
			dlgMessage.getChildren().add(pngMessage);
			dlgMessage.getChildren().add(btnFechar);

			return dlgMessage;
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			throw new RegraNegocioException("Erro ao criar dialogo de mensagem!");
		}
	}
}
