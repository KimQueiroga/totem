package br.com.hermespardini.passelivre.components;

import javax.faces.component.UIComponent;

import org.primefaces.component.outputlabel.OutputLabel;
import org.primefaces.component.panelgrid.PanelGrid;

import br.com.hermespardini.passelivre.interfaces.Component;
import br.com.hermespardini.passelivre.to.PerguntaComExameTO;
import br.com.hermespardini.passelivre.utils.ComponenteUtil;

public class ComponenteNulo implements Component {

	private PerguntaComExameTO pergunta;
	private PanelGrid panelGrid;

	public ComponenteNulo(final PerguntaComExameTO parPergunta, final PanelGrid parPanelGrid) {
		pergunta = parPergunta;
		panelGrid = parPanelGrid;
	}

	@Override
	public UIComponent createForUnimed() {

		final OutputLabel otpExame = new OutputLabel();
		otpExame.setValue("");

		final OutputLabel otpPergunta = new OutputLabel();
		otpPergunta.setValue(pergunta.getDescricao());

		final OutputLabel otp = new OutputLabel();
		otp.setValue("");
		panelGrid.getChildren().add(otpPergunta);
		panelGrid.getChildren().add(otp);
		panelGrid.getChildren().add(otpExame);
		return panelGrid;
	}

	@Override
	public UIComponent createForMaterialPendente() {
		final OutputLabel otpExame = new OutputLabel();
		otpExame.setValue("");

		final OutputLabel otpPergunta = new OutputLabel();
		otpPergunta.setValue(pergunta.getDescricao());

		final OutputLabel otp = new OutputLabel();
		otp.setValue("");

		panelGrid.getChildren().add(otpPergunta);
		panelGrid.getChildren().add(otp);
		panelGrid.getChildren().add(otpExame);
		return panelGrid;
	}

	@Override
	public UIComponent createForUnimedGuiche() {
		final OutputLabel otpExame = new OutputLabel();
		otpExame.setId("optExame_" + new ComponenteUtil().retornarNumeroAleatorio());
		otpExame.setValue("");

		final OutputLabel otpPergunta = new OutputLabel();
		otpPergunta.setId("optPergunta_" + new ComponenteUtil().retornarNumeroAleatorio());
		otpPergunta.setValue(pergunta.getDescricao());

		final OutputLabel otp = new OutputLabel();
		otp.setId("opt_" + new ComponenteUtil().retornarNumeroAleatorio());
		otp.setValue("");
		panelGrid.getChildren().add(otpPergunta);
		panelGrid.getChildren().add(otp);
		panelGrid.getChildren().add(otpExame);
		return panelGrid;
	}

	@Override
	public UIComponent createForQuestionario() {
		final OutputLabel otpExame = new OutputLabel();
		otpExame.setId("optExame_" + new ComponenteUtil().retornarNumeroAleatorio());
		otpExame.setValue("");

		final OutputLabel otpPergunta = new OutputLabel();
		otpPergunta.setId("optPergunta_" + new ComponenteUtil().retornarNumeroAleatorio());
		otpPergunta.setValue(pergunta.getDescricao());

		final OutputLabel otp = new OutputLabel();
		otp.setId("opt_" + new ComponenteUtil().retornarNumeroAleatorio());
		otp.setValue("");
		panelGrid.getChildren().add(otpPergunta);
		panelGrid.getChildren().add(otp);
		panelGrid.getChildren().add(otpExame);
		return panelGrid;
	}

	public UIComponent createForQuestionarioCheckup() {
		final OutputLabel otpExame = new OutputLabel();
		otpExame.setValue("");

		final OutputLabel otpPergunta = new OutputLabel();
		otpPergunta.setValue(pergunta.getDescricao());

		final OutputLabel otp = new OutputLabel();
		otp.setValue("");
		panelGrid.getChildren().add(otpPergunta);
		panelGrid.getChildren().add(otp);
		panelGrid.getChildren().add(otpExame);
		return panelGrid;
	}

}
