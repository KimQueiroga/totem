package br.com.hermespardini.passelivre.components;

import javax.faces.component.UIComponent;

import org.primefaces.component.inputtext.InputText;
import org.primefaces.component.message.Message;
import org.primefaces.component.outputlabel.OutputLabel;
import org.primefaces.component.panelgrid.PanelGrid;
import org.primefaces.extensions.component.inputnumber.InputNumber;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.interfaces.Component;
import br.com.hermespardini.passelivre.to.PerguntaComExameTO;
import br.com.hermespardini.passelivre.utils.ComponenteUtil;

public class ComponenteNumeric implements Component {

	private PerguntaComExameTO pergunta;
	private PanelGrid panelGrid;
	private ComponenteUtil componenteUtil;
	private StringBuilder sb;
	private String id;

	public ComponenteNumeric(final PerguntaComExameTO parPergunta, final PanelGrid parPanelGrid) {
		pergunta = parPergunta;
		panelGrid = parPanelGrid;
		componenteUtil = new ComponenteUtil();
		id = retornarId();
	}

	@Override
	public UIComponent createForUnimed() {
		sb = new StringBuilder();
		final OutputLabel otpExame = new OutputLabel();
		otpExame.setValue(pergunta.getDescricaoExame());

		final OutputLabel otpPergunta = new OutputLabel();
		otpPergunta.setValue(pergunta.getDescricao());
		otpPergunta.setFor(id);

		final InputText ipt = new InputText();
		ipt.setRequiredMessage(Constantes.CAMPO_OBRIGATORIO);
		ipt.setId(id);
		ipt.setOnclick("showKeyboard('keyboard'," + id + ",'numbers_only');");
		ipt.setValueExpression("value", componenteUtil.getValueExpression(
				sb.append("#{questionarioBean.mapQuestionarios['").append(id).append("']}").toString()));
		ipt.setRequired(componenteUtil.isObrigatorio(pergunta.getObrigatorio()));

		final Message msg = new Message();
		msg.setFor(id);

		panelGrid.getChildren().add(otpPergunta);
		panelGrid.getChildren().add(ipt);
		panelGrid.getChildren().add(msg);
		return panelGrid;
	}

	private String retornarId() {
		return componenteUtil.retornarId(pergunta, "kbd_");
	}

	@Override
	public UIComponent createForMaterialPendente() {
		sb = new StringBuilder();
		final OutputLabel otpExame = new OutputLabel();
		otpExame.setValue(pergunta.getDescricaoExame());

		final OutputLabel otpPergunta = new OutputLabel();
		otpPergunta.setValue(pergunta.getDescricao());
		otpPergunta.setFor(id);

		final InputText ipt = new InputText();
		ipt.setId(id);
		ipt.setOnclick("showKeyboard('keyboard'," + id + ",'numbers_only');");
		ipt.setRequiredMessage(Constantes.CAMPO_OBRIGATORIO);
		ipt.setValueExpression("value", componenteUtil.getValueExpression(
				sb.append("#{entregaMaterialPendenteBean.mapQuestionarios['").append(id).append("']}").toString()));
		ipt.setRequired(true);

		final Message msg = new Message();
		msg.setFor(id);

		panelGrid.getChildren().add(otpPergunta);
		panelGrid.getChildren().add(ipt);
		panelGrid.getChildren().add(msg);
		return panelGrid;
	}

	@Override
	public UIComponent createForUnimedGuiche() {
		try {
			sb = new StringBuilder();
			final OutputLabel otpExame = new OutputLabel();
			otpExame.setId("optExame_" + id);
			otpExame.setValue(pergunta.getDescricaoExame());

			final OutputLabel otpPergunta = new OutputLabel();
			otpPergunta.setValue(pergunta.getDescricao());
			otpPergunta.setId("optPergunta_" + id);
			otpPergunta.setFor(id);

			final InputNumber ipn = new InputNumber();
			ipn.setRequiredMessage(Constantes.CAMPO_OBRIGATORIO);
			ipn.setId(id);
			ipn.setValueExpression("value",
					componenteUtil.getValueExpression(sb.append("#{novoAtendimentoUnimedGicheBean.mapQuestionarios['")
							.append(id).append("']}").toString()));
			ipn.setRequired(componenteUtil.isObrigatorio(pergunta.getObrigatorio()));

			final Message msg = new Message();
			msg.setFor(id);

			panelGrid.getChildren().add(otpPergunta);
			panelGrid.getChildren().add(ipn);
			panelGrid.getChildren().add(msg);
			return panelGrid;
		} catch (final Exception locExc) {
			return null;
		}

	}

	@Override
	public UIComponent createForQuestionario() {
		try {
			sb = new StringBuilder();
			final OutputLabel otpExame = new OutputLabel();
			otpExame.setId("optExame_" + id);
			otpExame.setValue(pergunta.getDescricaoExame());

			final OutputLabel otpPergunta = new OutputLabel();
			otpPergunta.setValue(pergunta.getDescricao());
			otpPergunta.setId("optPergunta_" + id);
			otpPergunta.setFor(id);

			final InputNumber ipn = new InputNumber();
			ipn.setRequiredMessage(Constantes.CAMPO_OBRIGATORIO);
			ipn.setId(id);
			ipn.setValueExpression("value", componenteUtil.getValueExpression(
					sb.append("#{questionarioBean.mapQuestionarios['").append(id).append("']}").toString()));
			ipn.setRequired(componenteUtil.isObrigatorio(pergunta.getObrigatorio()));

			final Message msg = new Message();
			msg.setFor(id);

			panelGrid.getChildren().add(otpPergunta);
			panelGrid.getChildren().add(ipn);
			panelGrid.getChildren().add(msg);
			return panelGrid;
		} catch (final Exception locExc) {
			return null;
		}
	}

	public UIComponent createForQuestionarioCheckup() {
		sb = new StringBuilder();
		final OutputLabel otpExame = new OutputLabel();
		otpExame.setValue(pergunta.getDescricaoExame());

		final OutputLabel otpPergunta = new OutputLabel();
		otpPergunta.setValue(pergunta.getDescricao());
		otpPergunta.setFor(id);

		final InputText ipt = new InputText();
		ipt.setRequiredMessage(Constantes.CAMPO_OBRIGATORIO);
		ipt.setId(id);
		ipt.setOnclick("showKeyboard('keyboard'," + id + ",'numbers_only');");
		ipt.setValueExpression("value", componenteUtil.getValueExpression(
				sb.append("#{questionarioCheckupBean.mapQuestionarios['").append(id).append("']}").toString()));
		ipt.setRequired(componenteUtil.isObrigatorio(pergunta.getObrigatorio()));

		final Message msg = new Message();
		msg.setFor(id);

		panelGrid.getChildren().add(otpPergunta);
		panelGrid.getChildren().add(ipt);
		panelGrid.getChildren().add(msg);
		return panelGrid;
	}

}
