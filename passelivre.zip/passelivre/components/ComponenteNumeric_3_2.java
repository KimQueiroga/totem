package br.com.hermespardini.passelivre.components;

import javax.faces.component.UIComponent;

import org.primefaces.component.inputmask.InputMask;
import org.primefaces.component.inputtext.InputText;
import org.primefaces.component.message.Message;
import org.primefaces.component.outputlabel.OutputLabel;
import org.primefaces.component.panelgrid.PanelGrid;
import org.primefaces.component.watermark.Watermark;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.interfaces.Component;
import br.com.hermespardini.passelivre.to.PerguntaComExameTO;
import br.com.hermespardini.passelivre.utils.ComponenteUtil;

public class ComponenteNumeric_3_2 implements Component {

	private PerguntaComExameTO pergunta;
	private PanelGrid panelGrid;
	private ComponenteUtil componenteUtil;
	private StringBuilder sb;
	private String id;

	public ComponenteNumeric_3_2(final PerguntaComExameTO parPergunta, final PanelGrid parPanelGrid) {
		pergunta = parPergunta;
		panelGrid = parPanelGrid;
		componenteUtil = new ComponenteUtil();
		id = retornarId();
	}

	@Override
	public UIComponent createForUnimed() {
		sb = new StringBuilder();
		final OutputLabel otpExame = new OutputLabel();
		otpExame.setValue(pergunta.getDescricaoExame());

		final OutputLabel otpPergunta = new OutputLabel();
		otpPergunta.setValue(pergunta.getDescricao());
		otpPergunta.setFor(id);

		final InputText ipt = new InputText();
		ipt.setMaxlength(5);
		ipt.setId(id);
		ipt.setOnclick("showKeyboard('keyboard'," + id + ",'numbers_only');");
		ipt.setRequiredMessage(Constantes.CAMPO_OBRIGATORIO);
		ipt.setValueExpression("value", componenteUtil.getValueExpression(
				sb.append("#{questionarioBean.mapQuestionarios['").append(id).append("']}").toString()));
		ipt.setOnfocus("maskNumeric32(" + id + ")");
		ipt.setRequired(componenteUtil.isObrigatorio(pergunta.getObrigatorio()));
		ipt.setLabel(pergunta.getDescricao());

		final Watermark wtm = new Watermark();
		wtm.setFor(id);
		wtm.setValue("Ex: 99999");
		ipt.getChildren().add(wtm);

		final Message msg = new Message();
		msg.setFor(id);

		panelGrid.getChildren().add(otpPergunta);
		panelGrid.getChildren().add(ipt);
		panelGrid.getChildren().add(msg);
		return panelGrid;
	}

	private String retornarId() {
		return componenteUtil.retornarId(pergunta, "kbd_");
	}

	@Override
	public UIComponent createForMaterialPendente() {
		sb = new StringBuilder();
		final OutputLabel otpExame = new OutputLabel();
		otpExame.setValue(pergunta.getDescricaoExame());

		final OutputLabel otpPergunta = new OutputLabel();
		otpPergunta.setValue(pergunta.getDescricao());
		otpPergunta.setFor(id);

		final InputText ipt = new InputText();
		ipt.setMaxlength(5);
		ipt.setId(id);
		ipt.setOnclick("showKeyboard('keyboard'," + id + ",'numbers_only');");
		ipt.setRequiredMessage(Constantes.CAMPO_OBRIGATORIO);
		ipt.setValueExpression("value", componenteUtil.getValueExpression(
				sb.append("#{entregaMaterialPendenteBean.mapQuestionarios['").append(id).append("']}").toString()));
		ipt.setOnfocus("maskNumeric32(" + id + ")");
		ipt.setRequired(componenteUtil.isObrigatorio(pergunta.getObrigatorio()));
		ipt.setLabel(pergunta.getDescricao());

		final Watermark wtm = new Watermark();
		wtm.setFor(id);
		wtm.setValue("Ex: 99999");
		ipt.getChildren().add(wtm);

		final Message msg = new Message();
		msg.setFor(id);

		panelGrid.getChildren().add(otpPergunta);
		panelGrid.getChildren().add(ipt);
		panelGrid.getChildren().add(msg);
		return panelGrid;
	}

	@Override
	public UIComponent createForUnimedGuiche() {
		sb = new StringBuilder();
		final OutputLabel otpExame = new OutputLabel();
		otpExame.setId("optExame_" + id);
		otpExame.setValue(pergunta.getDescricaoExame());

		final OutputLabel otpPergunta = new OutputLabel();
		otpPergunta.setValue(pergunta.getDescricao());
		otpPergunta.setId("optPergunta_" + id);
		otpPergunta.setFor(id);

		final InputMask ipm = new InputMask();
		ipm.setMaxlength(5);
		ipm.setId(id);
		ipm.setMask("999,99");
		ipm.setRequiredMessage(Constantes.CAMPO_OBRIGATORIO);
		ipm.setValueExpression("value", componenteUtil.getValueExpression(
				sb.append("#{novoAtendimentoUnimedGicheBean.mapQuestionarios['").append(id).append("']}").toString()));
		ipm.setRequired(componenteUtil.isObrigatorio(pergunta.getObrigatorio()));
		ipm.setLabel(pergunta.getDescricao());

		final Watermark wtm = new Watermark();
		wtm.setFor(id);
		wtm.setValue("Ex: 99999");
		ipm.getChildren().add(wtm);

		final Message msg = new Message();
		msg.setFor(id);

		panelGrid.getChildren().add(otpPergunta);
		panelGrid.getChildren().add(ipm);
		panelGrid.getChildren().add(msg);
		return panelGrid;
	}

	@Override
	public UIComponent createForQuestionario() {
		sb = new StringBuilder();
		final OutputLabel otpExame = new OutputLabel();
		otpExame.setId("optExame_" + id);
		otpExame.setValue(pergunta.getDescricaoExame());

		final OutputLabel otpPergunta = new OutputLabel();
		otpPergunta.setValue(pergunta.getDescricao());
		otpPergunta.setId("optPergunta_" + id);
		otpPergunta.setFor(id);

		final InputMask ipm = new InputMask();
		ipm.setMaxlength(5);
		ipm.setId(id);
		ipm.setMask("999,99");
		ipm.setRequiredMessage(Constantes.CAMPO_OBRIGATORIO);
		ipm.setValueExpression("value", componenteUtil.getValueExpression(
				sb.append("#{questionarioBean.mapQuestionarios['").append(id).append("']}").toString()));
		ipm.setRequired(componenteUtil.isObrigatorio(pergunta.getObrigatorio()));
		ipm.setLabel(pergunta.getDescricao());

		final Watermark wtm = new Watermark();
		wtm.setFor(id);
		wtm.setValue("Ex: 99999");
		ipm.getChildren().add(wtm);

		final Message msg = new Message();
		msg.setFor(id);

		panelGrid.getChildren().add(otpPergunta);
		panelGrid.getChildren().add(ipm);
		panelGrid.getChildren().add(msg);
		return panelGrid;
	}

	public UIComponent createForQuestionarioCheckup() {
		sb = new StringBuilder();
		final OutputLabel otpExame = new OutputLabel();
		otpExame.setValue(pergunta.getDescricaoExame());

		final OutputLabel otpPergunta = new OutputLabel();
		otpPergunta.setValue(pergunta.getDescricao());
		otpPergunta.setFor(id);

		final InputText ipt = new InputText();
		ipt.setMaxlength(5);
		ipt.setId(id);
		ipt.setOnclick("showKeyboard('keyboard'," + id + ",'numbers_only');");
		ipt.setRequiredMessage(Constantes.CAMPO_OBRIGATORIO);
		ipt.setValueExpression("value", componenteUtil.getValueExpression(
				sb.append("#{questionarioCheckupBean.mapQuestionarios['").append(id).append("']}").toString()));
		ipt.setOnfocus("maskNumeric32(" + id + ")");
		ipt.setRequired(componenteUtil.isObrigatorio(pergunta.getObrigatorio()));
		ipt.setLabel(pergunta.getDescricao());

		final Watermark wtm = new Watermark();
		wtm.setFor(id);
		wtm.setValue("Ex: 99999");
		ipt.getChildren().add(wtm);

		final Message msg = new Message();
		msg.setFor(id);

		panelGrid.getChildren().add(otpPergunta);
		panelGrid.getChildren().add(ipt);
		panelGrid.getChildren().add(msg);
		return panelGrid;
	}

}
