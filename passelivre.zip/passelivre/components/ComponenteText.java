package br.com.hermespardini.passelivre.components;

import javax.faces.component.UIComponent;

import org.primefaces.component.inputtext.InputText;
import org.primefaces.component.message.Message;
import org.primefaces.component.outputlabel.OutputLabel;
import org.primefaces.component.panelgrid.PanelGrid;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.interfaces.Component;
import br.com.hermespardini.passelivre.to.PerguntaComExameTO;
import br.com.hermespardini.passelivre.utils.ComponenteUtil;

public class ComponenteText implements Component {
	private static final int TAMANAHO_MAXIMO_DESCRICAO = 50;
	private PerguntaComExameTO pergunta;
	private PanelGrid panelGrid;
	private ComponenteUtil componenteUtil;
	private StringBuilder sb;
	private String id;

	public ComponenteText(final PerguntaComExameTO parPergunta, final PanelGrid parPanelGrid) {
		pergunta = parPergunta;
		panelGrid = parPanelGrid;
		componenteUtil = new ComponenteUtil();
		id = retornarId();
	}

	@Override
	public UIComponent createForUnimed() {
		try {
			sb = new StringBuilder();
			final OutputLabel otpExame = new OutputLabel();
			otpExame.setValue(pergunta.getDescricaoExame());

			final OutputLabel otpPergunta = new OutputLabel();
			otpPergunta.setValue(pergunta.getDescricao());
			otpPergunta.setFor(id);

			final InputText ipt = new InputText();
			ipt.setId(id);
			ipt.setMaxlength(ComponenteText.TAMANAHO_MAXIMO_DESCRICAO);
			ipt.setOnclick("showKeyboard('keyboard'," + id + ",'complet');");
			ipt.setRequiredMessage(Constantes.CAMPO_OBRIGATORIO);
			ipt.setValueExpression("value", componenteUtil.getValueExpression(
					sb.append("#{questionarioBean.mapQuestionarios['").append(id).append("']}").toString()));
			ipt.setSize(40);
			ipt.setRequired(componenteUtil.isObrigatorio(pergunta.getObrigatorio()));

			final Message msg = new Message();
			msg.setFor(id);

			panelGrid.getChildren().add(otpPergunta);
			panelGrid.getChildren().add(ipt);
			panelGrid.getChildren().add(msg);
			return panelGrid;

		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return null;
		}
	}

	private String retornarId() {
		return componenteUtil.retornarId(pergunta, "kbd_");
	}

	@Override
	public UIComponent createForMaterialPendente() {
		try {
			sb = new StringBuilder();
			final OutputLabel otpExame = new OutputLabel();
			otpExame.setValue(pergunta.getDescricaoExame());

			final OutputLabel otpPergunta = new OutputLabel();
			otpPergunta.setValue(pergunta.getDescricao());
			otpPergunta.setFor(id);

			final InputText ipt = new InputText();
			ipt.setId(id);
			ipt.setOnclick("showKeyboard('keyboard'," + id + ",'complet');");
			ipt.setRequiredMessage(Constantes.CAMPO_OBRIGATORIO);
			ipt.setMaxlength(50);
			ipt.setValueExpression("value", componenteUtil.getValueExpression(
					sb.append("#{entregaMaterialPendenteBean.mapQuestionarios['").append(id).append("']}").toString()));
			ipt.setSize(40);
			ipt.setRequired(componenteUtil.isObrigatorio(pergunta.getObrigatorio()));

			final Message msg = new Message();
			msg.setFor(id);

			panelGrid.getChildren().add(otpPergunta);
			panelGrid.getChildren().add(ipt);
			panelGrid.getChildren().add(msg);
			return panelGrid;

		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return null;
		}
	}

	@Override
	public UIComponent createForUnimedGuiche() {
		try {
			sb = new StringBuilder();
			final OutputLabel otpExame = new OutputLabel();
			otpExame.setId("optExame_" + id);
			otpExame.setValue(pergunta.getDescricaoExame());

			final OutputLabel otpPergunta = new OutputLabel();
			otpPergunta.setValue(pergunta.getDescricao());
			otpPergunta.setId("optPergunta_" + id);
			otpPergunta.setFor(id);

			final InputText ipt = new InputText();
			ipt.setId(id);
			ipt.setRequiredMessage(Constantes.CAMPO_OBRIGATORIO);
			ipt.setMaxlength(50);
			ipt.setValueExpression("value",
					componenteUtil.getValueExpression(sb.append("#{novoAtendimentoUnimedGicheBean.mapQuestionarios['")
							.append(id).append("']}").toString()));
			ipt.setSize(40);
			ipt.setRequired(componenteUtil.isObrigatorio(pergunta.getObrigatorio()));

			final Message msg = new Message();
			msg.setFor(id);

			panelGrid.getChildren().add(otpPergunta);
			panelGrid.getChildren().add(ipt);
			panelGrid.getChildren().add(msg);
			return panelGrid;

		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return null;
		}
	}

	@Override
	public UIComponent createForQuestionario() {
		try {
			sb = new StringBuilder();
			final OutputLabel otpExame = new OutputLabel();
			otpExame.setId("optExame_" + id);
			otpExame.setValue(pergunta.getDescricaoExame());

			final OutputLabel otpPergunta = new OutputLabel();
			otpPergunta.setValue(pergunta.getDescricao());
			otpPergunta.setId("optPergunta_" + id);
			otpPergunta.setFor(id);

			final InputText ipt = new InputText();
			ipt.setId(id);
			ipt.setRequiredMessage(Constantes.CAMPO_OBRIGATORIO);
			ipt.setMaxlength(50);
			ipt.setValueExpression("value", componenteUtil.getValueExpression(
					sb.append("#{questionarioBean.mapQuestionarios['").append(id).append("']}").toString()));
			ipt.setSize(40);
			ipt.setRequired(componenteUtil.isObrigatorio(pergunta.getObrigatorio()));

			final Message msg = new Message();
			msg.setFor(id);

			panelGrid.getChildren().add(otpPergunta);
			panelGrid.getChildren().add(ipt);
			panelGrid.getChildren().add(msg);
			return panelGrid;

		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return null;
		}
	}

	public UIComponent createForQuestionarioCheckup() {
		try {
			sb = new StringBuilder();
			final OutputLabel otpExame = new OutputLabel();
			otpExame.setValue(pergunta.getDescricaoExame());

			final OutputLabel otpPergunta = new OutputLabel();
			otpPergunta.setValue(pergunta.getDescricao());
			otpPergunta.setFor(id);

			final InputText ipt = new InputText();
			ipt.setId(id);
			ipt.setMaxlength(ComponenteText.TAMANAHO_MAXIMO_DESCRICAO);
			ipt.setOnclick("showKeyboard('keyboard'," + id + ",'complet');");
			ipt.setRequiredMessage(Constantes.CAMPO_OBRIGATORIO);
			ipt.setValueExpression("value", componenteUtil.getValueExpression(
					sb.append("#{questionarioCheckupBean.mapQuestionarios['").append(id).append("']}").toString()));
			ipt.setSize(40);
			ipt.setRequired(componenteUtil.isObrigatorio(pergunta.getObrigatorio()));

			final Message msg = new Message();
			msg.setFor(id);

			panelGrid.getChildren().add(otpPergunta);
			panelGrid.getChildren().add(ipt);
			panelGrid.getChildren().add(msg);
			return panelGrid;

		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return null;
		}
	}

}
