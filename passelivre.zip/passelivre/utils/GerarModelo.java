package br.com.hermespardini.passelivre.utils;

import java.io.StringWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.runtime.RuntimeConstants;
import org.apache.velocity.tools.generic.DateTool;

/**
 * @author milton.filho
 * @since 6 de abr de 2017
 */
public class GerarModelo {

	private static final String RESOURCES = "/resources/";
	private String modelo;
	private List dados;
	private Object object;
	private Object object2;

	public GerarModelo(final String nomeModelo, final Object valueObject, final List dados) {
		modelo = "template/" + nomeModelo;
		this.dados = dados;
		object = valueObject;
	}

	public GerarModelo(final String nomeModelo, final List dados) {
		modelo = "template/" + nomeModelo;
		this.dados = dados;
	}

	public GerarModelo(final String nomeModelo, final Object valueObject) {
		modelo = "template/" + nomeModelo;
		object = valueObject;
	}

	public GerarModelo(final String nomeModelo, final Object valueObject, final List dados, final Object valueObject2) {
		this(nomeModelo, valueObject, dados);
		object2 = valueObject2;
	}

	public String gerarModeloEmail(final ServletContext contexto) throws Exception {
		return generatedEmailTemplate(contexto.getRealPath(GerarModelo.RESOURCES));
	}

	public String gerarModeloEmail() throws Exception {
		final ExternalContext eContext = FacesContext.getCurrentInstance().getExternalContext();
		return generatedEmailTemplate(eContext.getRealPath(GerarModelo.RESOURCES));
	}

	private String generatedEmailTemplate(final String path) throws Exception {
		final Map<Object, Object> map = new HashMap<Object, Object>();
		final VelocityEngine ve = new VelocityEngine();
		ve.setProperty(RuntimeConstants.FILE_RESOURCE_LOADER_PATH, path);
		ve.init();
		map.put("projectPath", path);
		final Template t = ve.getTemplate(modelo, "ISO-8859-1");
		final VelocityContext context = new VelocityContext(map);
		context.put("list", dados);
		context.put("object", object);
		context.put("object2", object2);
		context.put("date", new DateTool());
		final StringWriter writer = new StringWriter();
		t.merge(context, writer);
		return writer.toString();
	}

}
