package br.com.hermespardini.passelivre.utils;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.TextNode;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.exception.BiometriaDesativadaException;
import br.com.hermespardini.passelivre.service.ParametroService;
import br.com.hermespardini.passelivre.to.ParametroAplicacaoDto;

public class ImpressoraUtil {

	private static final String URL_CHECK_STATUS_PRINTER_RICOH = "http://%s/web/guest/br/websys/webArch/getStatus.cgi";
	private static Logger log = Logger.getLogger(ImpressoraUtil.class);

	/**
	 * Metodo responsavel por retornar o status da impressora por meio de uma
	 * consulta bem simples HTTP. O metodo retorna uma string diferente de vazia
	 * caso o status da impressora seja diferente de OK Caso ocorra uma excecao nao
	 * mapeada, eh retornado o status vazio e logado o tipo de excecao como WARNING
	 * 
	 * @param ipPrinter
	 * @return
	 */
	public static String checkStatusPrinter(String ipPrinter, HttpServletRequest request) {
		String status = "";
		// ipPrinter = "192.168.11.90";

		ParametroService parametroService;
		try {
			parametroService = new ParametroService(request);
			parametroService.buscarParametro(Constantes.CHAVE_VERIFICAR_IMPRESSORA);
			ParametroAplicacaoDto verificacaoImpressoraAtividada = (ParametroAplicacaoDto) parametroService
					.getResponseObject();

			if (verificacaoImpressoraAtividada != null
					&& !Constantes.ATIVO.equals(verificacaoImpressoraAtividada.getValorAplicacao().getValor())) {
				return "";
			}
			
		} catch (Exception e1) {
			log.error("Erro ao consultar parametro (" + Constantes.CHAVE_VERIFICAR_IMPRESSORA + ").", e1);
			return "";
		}

		try {
			Document response = getStatusPrinter(ipPrinter);
			TextNode text = (TextNode) response.childNode(1).childNode(2).childNode(3).childNode(3).childNode(7)
					.childNode(1).childNode(3).childNode(3).childNode(1).childNode(1).childNode(3).childNode(1);
			// String tonerStatus =
			// response.childNode(1).childNode(2).childNode(3).childNode(3).childNode(9).childNode(1).childNode(5).childNode(3).childNode(1).childNode(1).childNode(3).childNode(2).childNode(0).attr("title");
			status = retornaStatus(text.toString());
		} catch (Exception e) {
			log.warn("Erro nao mapeado ao checar impressora [" + ipPrinter + "].", e);
			status = "";
		}

		return status;
	}

	private static String retornaStatus(String statusPrinter) {
		if ("Status OK".equals(statusPrinter)) {
			return "";
		}
		return statusPrinter;
	}

	private static Document getStatusPrinter(String ipPrinter) throws IOException {
		return Jsoup.connect(String.format(URL_CHECK_STATUS_PRINTER_RICOH, ipPrinter)).get();
	}

}
