package br.com.hermespardini.passelivre.utils;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;

import br.com.hermespardini.passelivre.model.ExameOrcamento;
import br.com.hermespardini.passelivre.to.ProcedimentoRelatorioGATO;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

/**
 * @author milton.filho
 * @since 15 de mai de 2017
 */
public class RelatorioPDF {

	private String nomeRelatorio;
	private String caminhoRelatorio;
	private String nomeArquivoSaidas;
	private Map<String, Object> parametros;
	private ServletOutputStream nomeArquivoSaida;
	private JRDataSource dataSource;
	private JRDataSource examesExecao;

	public RelatorioPDF(final String parNomeRelatorio, final Map<String, Object> parInformacoesRelatorioGA,
			final List<ProcedimentoRelatorioGATO> parRetornarProcedimentoRelatorioGA, final String parPathArquivoReport,
			final List<ProcedimentoRelatorioGATO> parProcedimentosRelatorioGATOExcecao) {
		nomeRelatorio = parNomeRelatorio;
		parametros = parInformacoesRelatorioGA;
		dataSource = new JRBeanCollectionDataSource(parRetornarProcedimentoRelatorioGA);
		caminhoRelatorio = parPathArquivoReport;
		examesExecao = new JRBeanCollectionDataSource(parProcedimentosRelatorioGATOExcecao);
	}

	public RelatorioPDF(final String parNomeRelatorio, final Map<String, Object> parInformacoesRelatorioGA,
			final String parPathArquivoReport, final List<ExameOrcamento> parExamesOrcamento) {
		nomeRelatorio = parNomeRelatorio;
		parametros = parInformacoesRelatorioGA;
		dataSource = new JRBeanCollectionDataSource(parExamesOrcamento);
		caminhoRelatorio = parPathArquivoReport;
	}

	public static RelatorioPDF criarReciboPagamento(final String parNomeArquivo,
			final Map<String, Object> parInformacoesRecibo, final String pathArquivoReport) {
		return new RelatorioPDF(parNomeArquivo, parInformacoesRecibo, pathArquivoReport);
	}

	private RelatorioPDF(final String parNomeArquivo, final Map<String, Object> parInformacoesRecibo,
			final String pathArquivoReport) {
		nomeRelatorio = parNomeArquivo;
		parametros = parInformacoesRecibo;
		caminhoRelatorio = pathArquivoReport;

	}

	public InputStream retornarRelatorio() throws Exception {
		try {
			if (dataSource == null) {
				dataSource = new JREmptyDataSource();
			}
			final JasperPrint print = JasperFillManager.fillReport(caminhoRelatorio, parametros, dataSource);
			final InputStream initialStream = new ByteArrayInputStream(JasperExportManager.exportReportToPdf(print));
			return initialStream;
		} catch (final Exception e) {
			e.printStackTrace();
			throw new Exception("Erro ao executar relatório " + nomeRelatorio, e);
		}
	}

}
