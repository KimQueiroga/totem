package br.com.hermespardini.passelivre.utils;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DataUtil {
	public String formtarDateParaStringoBR(final Date parData) {
		final SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
		return formato.format(parData);
	}

	public String formatarStringParaStringBR(final String parData) throws ParseException {
		final String dataEmUmFormato = parData;
		final SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
		final Date data = formato.parse(dataEmUmFormato);
		formato.applyPattern("dd/MM/yyyy");
		final String dataFormatada = formato.format(data);
		return dataFormatada;
	}

	public String formatarStringBRParaString(final String parData) throws ParseException {
		if (parData == null) {
			return "";
		}
		final String dataEmUmFormato = parData;
		final SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
		formato.setLenient(false);
		final Date data = formato.parse(dataEmUmFormato);
		formato.applyPattern("yyyy-MM-dd");
		final String dataFormatada = formato.format(data);
		return dataFormatada;
	}

	public String formatarStringParaStringBRComHora(final String parString) throws ParseException {
		final String dataEmUmFormato = parString;
		final SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		final Date data = formato.parse(dataEmUmFormato);
		formato.applyPattern("dd/MM/yyyy HH:mm");
		final String dataFormatada = formato.format(data);
		return dataFormatada;
	}

	public Date retornarDataSemHora(final Date data) {
		final Calendar cal = Calendar.getInstance();
		cal.setTime(data);
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		return cal.getTime();
	}

	public String retornarApenasHora(final Date data) {
		try {
			String horaAtual = "";
			final Calendar cal = Calendar.getInstance();
			cal.setTime(new Date());
			final Integer hours = cal.get(Calendar.HOUR_OF_DAY);
			final Integer minute = cal.get(Calendar.MINUTE);
			String ajusteMinuto = "";
			if (minute.toString().length() == 1) {
				ajusteMinuto = "0";
			}
			if (hours.toString().length() == 1) {
				horaAtual = "0" + hours + ":" + ajusteMinuto + minute;
			} else {
				horaAtual = hours + ":" + ajusteMinuto + minute;
			}
			return horaAtual;
		} catch (final Exception locExc) {
			return "";
		}
	}

	public String formatarStringParaStringBRComHHMMSS(final String parString) throws ParseException {
		final String dataEmUmFormato = parString;
		final SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		final Date data = formato.parse(dataEmUmFormato);
		formato.applyPattern("dd/MM/yyyy HH:mm:ss");
		final String dataFormatada = formato.format(data);
		return dataFormatada;
	}

	public String formatarDateParaStringoBRComHora(final Date parMarcacao) {
		final SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy HH:mm");
		return formato.format(parMarcacao);
	}

	public String formatarDateParaStringoComHoraSegundo(final Date parMarcacao) {
		try {
			final SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			return formato.format(parMarcacao);
		} catch (final Exception locExc) {
			return parMarcacao.toString();
		}
	}

	public String formatarDateParaString(final Date parMarcacao) {
		final SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
		return formato.format(parMarcacao);
	}

	public Date formatarTimeStampParaDate(final Timestamp marcacao) {
		final Timestamp dataTimeStamp = marcacao;
		final Date data = new Date(dataTimeStamp.getTime());
		final SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy' 'HH:mm:ss");
		format.setLenient(false);
		format.format(data);
		return data;
	}

}
