package br.com.hermespardini.passelivre.utils;

import java.util.List;

import br.com.hermespardini.passelivre.model.ClienteUnidadePasseLivre;
import br.com.hermespardini.passelivre.model.ConsultaCodigoResult;
import br.com.hermespardini.passelivre.model.CriarPedidoResult;
import br.com.hermespardini.passelivre.model.ExameHermesPardini;
import br.com.hermespardini.passelivre.model.InformacaoTotem;
import br.com.hermespardini.passelivre.model.ParametroConsultaClienteGuiche;
import br.com.hermespardini.passelivre.model.Procedimento;
import br.com.hermespardini.passelivre.to.ProcedimentoComExamesTO;
import br.com.hermespardini.passelivre.to.ProcedimentoComExamesTOExcecao;

public class MensagemUtil {

	private StringBuilder sb;

	public static String retornarMensagemErroAoConfirmarPedido(final String numeroCarteira,
			final String senhaAutorizacao, final String descricaoErro) {
		final StringBuilder sb = new StringBuilder();
		return sb.append("Confirmação para a carteira ").append(numeroCarteira).append(" e senha:")
				.append(senhaAutorizacao).append(", não foi executada com sucesso! ").append(descricaoErro).toString();
	}

	public static String retornarMensagemAoIniciarPedido(final String parSenhaGuia) {
		final StringBuilder sb = new StringBuilder();
		return sb.append("Foi feito pedido para a senha:").append(parSenhaGuia).toString();
	}

	public static String retornarMensagemErroInconsistenciaVt(final Integer parQuantidadeVTNoPedido,
			final Integer parQuantidadeExameVT, final String parSenhaGuia) {
		final StringBuilder sb = new StringBuilder();
		return sb.append("Problema de inconsistência com os VTs selecionados:").append(parQuantidadeExameVT)
				.append(" para os do pedido:").append(parQuantidadeVTNoPedido).append(" com a carteira:")
				.append(parSenhaGuia).toString();
	}

	public static String retornarMensagemAoFinalizarPedido(final Integer parPedido, final Integer parUnidade) {
		final StringBuilder sb = new StringBuilder();
		return sb.append("Pedido:").append(parPedido).append(" criado com sucesso para a unidade: ").append(parUnidade)
				.toString();
	}

	public static String retornarMensagemProcedimentoComVariosExames(final Procedimento locProcedimento,
			final ConsultaCodigoResult consultaCodigoResult) {
		final StringBuilder sb = new StringBuilder();
		return sb.append("Na guia: ").append(locProcedimento.getGuia()).append(" com o procedimento UNIMED:")
				.append(locProcedimento.getProcedimento()).append(" trouxe mais de uma relacionamento:")
				.append(MensagemUtil.retornarApenasExames(consultaCodigoResult.getExames())).toString();
	}

	private static String retornarApenasExames(final List<ExameHermesPardini> paraExames) {
		String exames = "";
		for (final ExameHermesPardini locExameHermesPardini : paraExames) {
			if (locExameHermesPardini.getExame() != null) {
				exames += locExameHermesPardini.getExame() + "/" + locExameHermesPardini.getMaterial() + ", ";
			}
		}
		return exames;
	}

	public static String retornarMensagemParaProcedimentosExcluidos(final String parProcedimento,
			final String parMotivoDeProcedimentoNaoAtendido) {
		final StringBuilder sb = new StringBuilder();
		return sb.append("Log para procedimentos não atendidos pelo totem: ").append(parProcedimento).append(" Motivo:")
				.append(parMotivoDeProcedimentoNaoAtendido).toString();
	}

	public static String retornarMensagemParaProcedimentoExcluidosPeloUsuario(final String paramNumeroCarteira,
			final ProcedimentoComExamesTO paramProcedimentoComExamesTO) {
		return "Esse procedimento foi excluido:" + paramProcedimentoComExamesTO.getProcedimento() + " para a guia: "
				+ paramProcedimentoComExamesTO.getGuia() + " carteira: " + paramNumeroCarteira;
	}

	public static String retornarMensagemCabelho(final ClienteUnidadePasseLivre parClienteUnidadePasseLivre,
			final String parNumeroCarteira) {
		if (parNumeroCarteira == null || parNumeroCarteira == "") {
			return "Bem vindo " + parClienteUnidadePasseLivre.getNomeCliente() + " - CÓDIGO DO CLIENTE: "
					+ parClienteUnidadePasseLivre.getCodigoCliente();
		} else {
			return "Bem vindo! " + parClienteUnidadePasseLivre.getNomeCliente() + " - CÓDIGO DO CLIENTE: "
					+ parClienteUnidadePasseLivre.getCodigoCliente() + " - CARTEIRA: " + parNumeroCarteira;
		}
	}

	public static String retornarMensagemCabelho(final ClienteUnidadePasseLivre parClienteUnidadePasseLivre,
			final String parNumeroCarteira, String caso) {
		if (parNumeroCarteira == null || parNumeroCarteira == "") {
			switch (caso) {
			case "bemVindo":
				return " Bem vindo  ";
			case "nomeCliente":
				return parClienteUnidadePasseLivre.getNomeCliente();
			case "codCliente":
				return " Código do Cliente: " + parClienteUnidadePasseLivre.getCodigoCliente();
			}
		} else {
			switch (caso) {
			case "bemVindo":
				return " Bem vindo  ";
			case "nomeCliente":
				return parClienteUnidadePasseLivre.getNomeCliente();
			case "codCliente":
				return " Código do Cliente: " + parClienteUnidadePasseLivre.getCodigoCliente() + " - Carteira: "
						+ parNumeroCarteira;
			}
		}
		return "";
	}

	public static String retornarMensagemCabelhoUnidade(final String unidade) {
		return "Unidade: " + unidade;
	}

	public static String retornarMensagemErroAoFazerPedido(final String parMessage,
			final CriarPedidoResult parCriarPedidoResult, final List<InformacaoTotem> parInformacoesTotem) {
		return parMessage + " Pedido :" + parCriarPedidoResult.getPedido() + " unidade:"
				+ parInformacoesTotem.get(0).getIdUnidade();
	}

	public static String retornarMensagemErroAoFazerPedido(final String parMessage,
			final CriarPedidoResult parCriarPedidoResult, final Long parUnidade) {
		return parMessage + " Pedido :" + parCriarPedidoResult.getPedido() + " unidade:" + parUnidade;
	}

	public static String retornarMensagemErroAoBuscarGuias(final String parNumeroCarteira,
			final List<InformacaoTotem> parInformacoesTotem, final String parMessage) {
		return "Erro ao buscar as guias, para a carteira: " + parNumeroCarteira + " unidade:"
				+ parInformacoesTotem.get(0).getIdUnidade() + parMessage;
	}

	public static String retornarMensagemErroAoBuscarGuias(final String parNumeroCarteira, final Long parUnidade,
			final String parMessage) {
		return "Erro ao buscar as guias, para a carteira: " + parNumeroCarteira + " " + " unidade:" + parUnidade + " "
				+ parMessage;
	}

	public static String retornarMensagemAoVerificarSeExamesForamPreenchidos(final Procedimento parProcedimento) {
		return "Exames vazios para o procedimento:" + parProcedimento.getProcedimento() + " senha:"
				+ parProcedimento.getGuia();
	}

	public static String retornarMensagemErroAoValidarCamposDescricaoMaterial(
			final ProcedimentoComExamesTO parLocProcedimento) {
		return "O campo descrição do procedimento " + parLocProcedimento.getProcedimento() + " deve ser preenchido!";
	}

	public static String retornarMensagemErroAoValidarCamposCondicaoAmostra(
			final ProcedimentoComExamesTO parLocProcedimento) {
		return "O campo condição amostra para procedimento " + parLocProcedimento.getProcedimento()
				+ " deve ser preenchido!";
	}

	public static String retornarMensagemErroAoValidarCamposCondicaoAmostraRepetida(
			final ProcedimentoComExamesTO parLocProcedimento) {
		return "O campo condição amostra para procedimento " + parLocProcedimento.getProcedimento()
				+ " náo pode ter valor idêntico!";
	}

	public static String retornarMensagemAoExcluirExames(final ExameHermesPardini parExameHermesPardini) {
		return "Log para exames não atendidos pelo totem: " + parExameHermesPardini.toString() + " Motivo:"
				+ parExameHermesPardini.getObservacao();
	}

	public static String retornarMensagemAoExibirMensagemProcedimentoNaoAtendido(
			final ProcedimentoComExamesTOExcecao parProcedimentoComExamesTOExcecao) {
		return "Log para procedimentos não atendidos pelo totem: " + parProcedimentoComExamesTOExcecao.getProcedimento()
				+ " Motivo:"
				+ MensagemUtil.retornarMotivoParaProcedimentoNaoAtendido(parProcedimentoComExamesTOExcecao);
	}

	// FIXME Verificar melhor a regra para buscar o motivo real de não atendimento
	// do procedimento.
	private static String retornarMotivoParaProcedimentoNaoAtendido(
			final ProcedimentoComExamesTOExcecao parProcedimentoComExamesTOExcecao) {
		try {
			return parProcedimentoComExamesTOExcecao.getGlosas().get(0).getDescricaoGlosa();
		} catch (final Exception locExc) {
			return "";
		}
	}

	public static String retornarMensagemAoBuscarDadosClientes(
			final ParametroConsultaClienteGuiche parParametroConsultaCliente) {
		try {
			return parParametroConsultaCliente.toString();
		} catch (final Exception locExc) {
			return "";
		}
	}

	public static String retornarMensagemAoConfirmarPedido(final String parRetornarSenhaDaGuia) {
		return "Foi feito confirmação para a senha:" + parRetornarSenhaDaGuia;
	}

	public static String retornarMensagemErroAoFazerPagamento(final String parMensagemErro) {
		final StringBuilder sb = new StringBuilder();
		return sb.append("Não foi poss�vel fazer pagamento pelo motivo: ").append(parMensagemErro).toString();
	}

	public static String retornarMensagemErroAoCancelarPedido(final String parResponseMessage) {
		final StringBuilder sb = new StringBuilder();
		return sb.append("Não foi possível cancelar oo pedido pelo motivo: ").append(parResponseMessage).toString();
	}

	public static String retornarMensagemAoCancelarPedido(final String parPedido) {
		final StringBuilder sb = new StringBuilder();
		return sb.append("Pedido ").append(parPedido).append(" foi cancelado com sucesso!").toString();
	}

	public static String retornarMensagemAoEfetivarPedido(final CriarPedidoResult parCriaPedidoResult) {
		final StringBuilder sb = new StringBuilder();
		return sb.append("Pedido ").append(parCriaPedidoResult.getPedido()).append(" foi efetivado com sucesso!")
				.toString();
	}

	public static String retornarMensagemAoConfirmarPagamentoPedido(final CriarPedidoResult parCriaPedidoResult) {
		final StringBuilder sb = new StringBuilder();
		return sb.append("Pagamento para o pedido ").append(parCriaPedidoResult.getPedido())
				.append(" foi confirmado com sucesso!").toString();
	}

	public static String retornarMensagemCabelhoPagamento(final ClienteUnidadePasseLivre parClienteUnidadePasseLivre) {
		return "Bem vindo! " + parClienteUnidadePasseLivre.getNomeCliente() + " - CÓDIGO DO CLIENTE: "
				+ parClienteUnidadePasseLivre.getCodigoCliente();
	}

	public static String retornarErroMensagemAoImprimirRecibo(final String parMessage) {
		return "Erro ao gerar o recibo do pagamento para o checkup, motivo: " + parMessage;
	}

	public static String retornaMensagemQuestionarioImpresso(final boolean concluido) {
		if (concluido) {
			return "Questionário impresso.";
		}
		return "Não foi possível imprimir o questionário.";
	}

}
