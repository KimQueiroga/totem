package br.com.hermespardini.passelivre.utils;

import java.util.List;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.primefaces.extensions.component.masterdetail.MasterDetailLevel;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.model.ClienteUnidadePasseLivre;
import br.com.hermespardini.passelivre.model.InformacaoTotem;
import br.com.hermespardini.passelivre.model.InformacaoTotemDesktop;
import br.com.hermespardini.passelivre.model.TokenResult;
import br.com.hermespardini.passelivre.model.UserAuth;
import br.com.hermespardini.passelivre.to.PerguntaComExameTO;

public class ControleBotaoUtil {

	public ControleBotaoUtil() {
	}

	public Boolean getHabilitaEntregaMaterial(final List<InformacaoTotem> informacoesTotem) {
		try {
			for (final InformacaoTotem locInformacaoTotem : informacoesTotem) {
				if (locInformacaoTotem.getDescricao().equals(Constantes.SERVICO_ENTREGA_PENDENTE)) {
					return locInformacaoTotem.totemEstaAtivo();
				}
			}
			return false;
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return false;
		}
	}

	public Boolean getHabilitaPreAtendimento(final List<InformacaoTotem> informacoesTotem) {
		try {
			for (final InformacaoTotem locInformacaoTotem : informacoesTotem) {
				if (locInformacaoTotem.getDescricao().equals(Constantes.SERVICO_PRE_ATENDIMENTO)) {
					return locInformacaoTotem.totemEstaAtivo();
				}
			}
			return false;
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return false;
		}
	}

	public Boolean getHabilitaEntregaResultado(final List<InformacaoTotem> informacoesTotem) {
		try {
			for (final InformacaoTotem locInformacaoTotem : informacoesTotem) {
				if (locInformacaoTotem.getDescricao().equals(Constantes.SERVICO_RESULTADO)) {
					return locInformacaoTotem.totemEstaAtivo();
				}
			}
			return false;
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return false;
		}
	}

	public Boolean getHabilitaOrcamento(final List<InformacaoTotem> informacoesTotem) {
		try {
			for (final InformacaoTotem locInformacaoTotem : informacoesTotem) {
				if (locInformacaoTotem.getDescricao().equals(Constantes.SERVICO_ORCAMENTO)) {
					return false;
					//return locInformacaoTotem.totemEstaAtivo();
				}
			}
			return false;
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return false;
		}
	}

	public Boolean getHabilitaAtendimentoUnimed(final List<InformacaoTotem> informacoesTotem) {
		try {
			for (final InformacaoTotem locInformacaoTotem : informacoesTotem) {
				if (locInformacaoTotem.getDescricao().equals(Constantes.SERVICO_ATENDIMENTO_UNIMED)) {
					return locInformacaoTotem.totemEstaAtivo();
				}
			}
			return false;
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return false;
		}
	}

	public Boolean getHabilitaPreparacaoExame(final List<InformacaoTotem> parInformacoesTotem) {
		try {
			for (final InformacaoTotem locInformacaoTotem : parInformacoesTotem) {
				if (locInformacaoTotem.getDescricao().equals(Constantes.SERVICO_PREPARACAO_EXAME)) {
					return locInformacaoTotem.totemEstaAtivo();
				}
			}
			return false;
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return false;
		}
	}

	public Boolean getHabilitaCheckupMasculino(final List<InformacaoTotem> parInformacoesTotem) {
		try {
			for (final InformacaoTotem locInformacaoTotem : parInformacoesTotem) {
				if (locInformacaoTotem.getDescricao().equals(Constantes.SERVICO_CHECKUP_MASCULINO)) {
					return locInformacaoTotem.totemEstaAtivo();
				}
			}
			return false;
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return false;
		}
	}

	public void redirectUnimed(final HttpServletRequest httpServletRequest,
			final ClienteUnidadePasseLivre clienteUnidadePasseLivre, final String parSessionId) {
		try {
			final HttpSession session = httpServletRequest.getSession();
			session.setAttribute("sessionId", parSessionId);
			session.setAttribute("clienteUnidadePasseLivre", clienteUnidadePasseLivre);
			FacesContext.getCurrentInstance().getExternalContext()
					.redirect("/passelivretotem/pages/nau/guiasAutorizadas.xhtml?faces-redirect=true");
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	public void redirectUnimedGuiche(final HttpServletRequest httpServletRequest,
			final ClienteUnidadePasseLivre clienteUnidadePasseLivre, final String parSessionId, final Long idUnidade,
			final Long idLocalizacao) {
		try {
			final HttpSession session = httpServletRequest.getSession();
			session.setAttribute("idUnidade", idUnidade);
			session.setAttribute("idLocalizacao", idLocalizacao);
			session.setAttribute("sessionId", parSessionId);
			session.setAttribute("clienteUnidadePasseLivre", clienteUnidadePasseLivre);
			FacesContext.getCurrentInstance().getExternalContext()
					.redirect("/passelivretotem/pagesGuiche/nau/coletaBiometria.xhtml?faces-redirect=true");
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	public void redirectMaterial(final HttpServletRequest httpServletRequest,
			final ClienteUnidadePasseLivre clienteUnidadePasseLivre, final String parSessionId,
			final TokenResult parTokenResult, final List<InformacaoTotem> parInformacoesTotem) {
		try {
			final HttpSession session = httpServletRequest.getSession();
			session.setAttribute("clienteUnidadePasseLivre", clienteUnidadePasseLivre);
			session.setAttribute("sessionId", parSessionId);
			session.setAttribute("tokenResult", parTokenResult);
			session.setAttribute("informacoesTotem", parInformacoesTotem);
			FacesContext.getCurrentInstance().getExternalContext()
					.redirect("/passelivretotem/pages/emp/listaMateriaisPendetes.xhtml?faces-redirect=true");
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	public void redirectMaterialGuiche(final HttpServletRequest httpServletRequest,
			final ClienteUnidadePasseLivre clienteUnidadePasseLivre, final String parSessionId, final Long idUnidade,
			final Long idLocalizacao) {
		try {
			final HttpSession session = httpServletRequest.getSession();
			session.setAttribute("clienteUnidadePasseLivre", clienteUnidadePasseLivre);
			session.setAttribute("sessionId", parSessionId);
			session.setAttribute("idLocalizacao", idLocalizacao);
			session.setAttribute("idUnidade", idUnidade);
			FacesContext.getCurrentInstance().getExternalContext()
					.redirect("/passelivretotem/pagesGuiche/emp/listaMateriaisPendetes.xhtml?faces-redirect=true");
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	public void redirectResultado(final HttpServletRequest httpServletRequest,
			final ClienteUnidadePasseLivre clienteUnidadePasseLivre, final String parSessionId) {
		try {
			final HttpSession session = httpServletRequest.getSession();
			session.setAttribute("clienteUnidadePasseLivre", clienteUnidadePasseLivre);
			session.setAttribute("sessionId", parSessionId);
			FacesContext.getCurrentInstance().getExternalContext()
					.redirect("/passelivretotem/pages/res/resultado.xhtml?faces-redirect=true");
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}
	
	public void redirectTelaSenhaDefinitiva(final HttpServletRequest httpServletRequest,
			final ClienteUnidadePasseLivre clienteUnidadePasseLivre, final String parSessionId) {
		try {
			final HttpSession session = httpServletRequest.getSession();
			session.setAttribute("clienteUnidadePasseLivre", clienteUnidadePasseLivre);
			session.setAttribute("sessionId", parSessionId);
			FacesContext.getCurrentInstance().getExternalContext()
					.redirect("/passelivretotem/pages/senhaDefinitiva.xhtml?faces-redirect=true");
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}
	
	public void redirectRedefinirSenha(final HttpServletRequest httpServletRequest, final UserAuth userAuth, final String parSessionId) {
		try {
			final HttpSession session = httpServletRequest.getSession();
			session.setAttribute("sessionId", parSessionId);
			session.setAttribute("userAuth", userAuth);
			FacesContext.getCurrentInstance().getExternalContext()
					.redirect("/passelivretotem/pages/redefinirSenha.xhtml?faces-redirect=true");
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}
	
	public void redirectEnviarCodVerif(final HttpServletRequest httpServletRequest, final UserAuth userAuth, final String parSessionId) {
		try {
			final HttpSession session = httpServletRequest.getSession();
			session.setAttribute("sessionId", parSessionId);
			session.setAttribute("userAuth", userAuth);
			FacesContext.getCurrentInstance().getExternalContext()
					.redirect("/passelivretotem/pages/enviaCodVerificacao.xhtml?faces-redirect=true");
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	public Boolean habilitarBotaoQuestionarioVoltar(
			final Map<String, List<PerguntaComExameTO>> parTodasPerguntasAgrupadas, final Integer parLevel) {
		if (parLevel == 1 && parLevel <= parTodasPerguntasAgrupadas.size()) {
			return false;
		} else {
			return true;
		}
	}

	public Boolean habilitarBotaoQuestionarioAvancar(
			final Map<String, List<PerguntaComExameTO>> parTodasPerguntasAgrupadas, final Integer parLevel) {
		if (parLevel < parTodasPerguntasAgrupadas.size()) {
			return true;
		} else {
			return false;
		}
	}

	public Boolean habilitarBotaoQuestionarioFinalizar(
			final Map<String, List<PerguntaComExameTO>> parTodasPerguntasAgrupadas, final Integer parLevel) {
		if (parLevel == parTodasPerguntasAgrupadas.size()) {
			return true;
		} else {
			return false;
		}
	}

	public Boolean habilitarBotaoQuestionarioCancelar(
			final Map<String, List<PerguntaComExameTO>> parTodasPerguntasAgrupadas, final Integer parLevel) {
		if (parLevel == parTodasPerguntasAgrupadas.size() && parTodasPerguntasAgrupadas.size() == 1
				|| parLevel == 1 && parTodasPerguntasAgrupadas.size() > 1) {
			return true;
		} else {
			return false;
		}
	}

	public Boolean habilitarBotaoQuestionarioVoltar(final List<MasterDetailLevel> masterDetail,
			final Integer parLevel) {
		if (parLevel == 1 && parLevel <= masterDetail.size()) {
			return false;
		} else {
			return true;
		}
	}

	public Boolean habilitarBotaoQuestionarioAvancar(final List<MasterDetailLevel> masterDetail,
			final Integer parLevel) {
		if (parLevel < masterDetail.size()) {
			return true;
		} else {
			return false;
		}
	}

	public Boolean habilitarBotaoQuestionarioFinalizar(final List<MasterDetailLevel> masterDetail,
			final Integer parLevel) {
		if (parLevel == masterDetail.size()) {
			return true;
		} else {
			return false;
		}
	}

	public Boolean habilitarBotaoQuestionarioCancelar(final List<MasterDetailLevel> masterDetail,
			final Integer parLevel) {
		if (parLevel == masterDetail.size() && masterDetail.size() == 1 || parLevel == 1 && masterDetail.size() > 1) {
			return true;
		} else {
			return false;
		}
	}

	public Boolean getHabilitaOrcamentoGuiche(final List<InformacaoTotemDesktop> parInformacoesTotemGuiche) {
		for (final InformacaoTotemDesktop locInformacaoTotemDesktop : parInformacoesTotemGuiche) {

		}
		return false;
	}

	public Boolean getHabilitaEntregaMaterialGuiche(final List<InformacaoTotemDesktop> parInformacoesTotemDesktop) {
		for (final InformacaoTotemDesktop locInformacaoTotemDesktop : parInformacoesTotemDesktop) {
			if (locInformacaoTotemDesktop.getNome().equals("ENTREGA_PENDENTE")) {
				return true;
			}
		}
		return false;
	}

	public Boolean getHabilitaAtendimentoUnimedGuiche(final List<InformacaoTotemDesktop> parInformacoesTotemDesktop) {
		for (final InformacaoTotemDesktop locInformacaoTotemDesktop : parInformacoesTotemDesktop) {
			if (locInformacaoTotemDesktop.getNome().equals("ATENDIMENTO_UNIMED")) {
				return true;
			}
		}
		return false;
	}

	public Boolean getHabilitaPreAtendimentoGuiche(final List<InformacaoTotemDesktop> parInformacoesTotemDesktop) {
		for (final InformacaoTotemDesktop locInformacaoTotemDesktop : parInformacoesTotemDesktop) {
			if (locInformacaoTotemDesktop.getNome().equals("PRE_ATENDIMENTO")) {
				return true;
			}
		}
		return false;
	}

	public Boolean getHabilitaPreparacaoExameGuiche(final List<InformacaoTotemDesktop> parInformacoesTotemGuiche) {
		for (final InformacaoTotemDesktop locInformacaoTotemDesktop : parInformacoesTotemGuiche) {
			if (locInformacaoTotemDesktop.getNome().equals("PREPARACAO_EXAMES")) {
				return true;
			}
		}
		return false;
	}

	public Boolean getHabilitaEntregaResultadoGuiche(final List<InformacaoTotemDesktop> parInformacoesTotemGuiche) {
		for (final InformacaoTotemDesktop locInformacaoTotemDesktop : parInformacoesTotemGuiche) {
			if (locInformacaoTotemDesktop.getNome().equals("RESULTADO")) {
				return true;
			}
		}
		return false;
	}

	public Boolean getHabilitaCheckupFeminino(final List<InformacaoTotem> parInformacoesTotem) {
		try {
			for (final InformacaoTotem locInformacaoTotem : parInformacoesTotem) {
				if (locInformacaoTotem.getDescricao().equals(Constantes.SERVICO_CHECKUP_FEMININO)) {
					return locInformacaoTotem.totemEstaAtivo();
				}
			}
			return false;
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return false;
		}
	}
}
