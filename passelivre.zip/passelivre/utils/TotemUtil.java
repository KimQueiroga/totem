package br.com.hermespardini.passelivre.utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;

import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.primefaces.context.RequestContext;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.constantsenum.TipoServicoEnum;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.model.ClienteUnidadePasseLivre;
import br.com.hermespardini.passelivre.model.ConsultaConfiguracaoResult;
import br.com.hermespardini.passelivre.model.DetalhePedidoCliente;
import br.com.hermespardini.passelivre.model.EmpresaTotem;
import br.com.hermespardini.passelivre.model.InformacaoTotem;
import br.com.hermespardini.passelivre.model.InformacaoTotemDesktop;
import br.com.hermespardini.passelivre.model.Localizacao;
import br.com.hermespardini.passelivre.model.MensagemAviso;
import br.com.hermespardini.passelivre.model.ParametroConsultaConfiguracao;
import br.com.hermespardini.passelivre.model.ParametroUsuarioToken;
import br.com.hermespardini.passelivre.model.TokenResult;
import br.com.hermespardini.passelivre.model.Unidade;
import br.com.hermespardini.passelivre.service.AutenticaService;

public class TotemUtil {

	public static Logger log = Logger.getLogger(Util.class);
	private static List<InformacaoTotem> informacoesTotem;
	private static List<InformacaoTotemDesktop> informacoesTotemDesktop;

	public static List<InformacaoTotem> buscarInformacoesTotem() {
		try {
			TotemUtil.informacoesTotem = new ArrayList<>();
			final HttpSession session = TotemUtil.getHttpServletRequest().getSession();
			TotemUtil.informacoesTotem = (List<InformacaoTotem>) session.getAttribute("informacoesTotem");
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
		return TotemUtil.informacoesTotem;
	}

	public static List<InformacaoTotemDesktop> buscarInformacoesTotemDesktop() {
		try {
			TotemUtil.informacoesTotemDesktop = new ArrayList<>();
			final HttpSession session = TotemUtil.getHttpServletRequest().getSession();
			TotemUtil.informacoesTotemDesktop = (List<InformacaoTotemDesktop>) session
					.getAttribute("informacoesTotemDesktop");
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
		return TotemUtil.informacoesTotemDesktop;
	}

	public static InformacaoTotem buscarInformacaoTotem() throws RegraNegocioException {
		try {
			final HttpSession session = TotemUtil.getHttpServletRequest().getSession();
			final InformacaoTotem informacaoTotem = (InformacaoTotem) session.getAttribute("informacaoTotem");
			if (informacaoTotem != null) {
				return informacaoTotem;
			}
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
		return null;
	}

	public static TokenResult buscarToken() {
		try {
			TokenResult tokenResult = new TokenResult();
			final HttpSession session = TotemUtil.getHttpServletRequest().getSession();
			return tokenResult = (TokenResult) session.getAttribute("tokenResult");
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
		return null;
	}

	public static Unidade buscarUnidade() {
		try {
			Unidade unidade = new Unidade();
			final HttpSession session = TotemUtil.getHttpServletRequest().getSession();
			return unidade = (Unidade) session.getAttribute("unidade");
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
		return null;
	}

	public static EmpresaTotem buscarEmpresa() {
		try {
			EmpresaTotem empresa = new EmpresaTotem();
			final HttpSession session = TotemUtil.getHttpServletRequest().getSession();
			return empresa = (EmpresaTotem) session.getAttribute("empresaTotem");
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
		return null;
	}

	public static String buscarIdEmpresa() {
		try {
			final HttpSession session = TotemUtil.getHttpServletRequest().getSession();
			return String.valueOf(session.getAttribute("IdEmpresa"));
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
		return null;
	}

	public static String buscarSiglaEmpresa() {
		try {
			final HttpSession session = TotemUtil.getHttpServletRequest().getSession();
			return (String) session.getAttribute("siglaEmpresa");
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
		return null;
	}

	public static Localizacao buscarLocalizacao() {
		try {
			Localizacao localizacao = new Localizacao();
			final HttpSession session = TotemUtil.getHttpServletRequest().getSession();
			return localizacao = (Localizacao) session.getAttribute("localizacao");
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
		return null;
	}

	private static HttpServletRequest getHttpServletRequest() {
		return (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
	}

	public static ClienteUnidadePasseLivre recuperarClientePasseLivre() {
		try {
			final HttpSession session = TotemUtil.getHttpServletRequest().getSession();
			final ClienteUnidadePasseLivre clienteUnidadePasseLivre = (ClienteUnidadePasseLivre) session
					.getAttribute("clienteUnidadePasseLivre");
			return clienteUnidadePasseLivre;
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
		return null;
	}

	public static TipoServicoEnum recuperarTipoServico() {
		try {
			final HttpSession session = TotemUtil.getHttpServletRequest().getSession();
			final TipoServicoEnum tipoServico = (TipoServicoEnum) session.getAttribute("tipoServico");
			return tipoServico;
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
		return null;
	}

	public static void cancelarSessao() {
		try {
			final String nomeMaquina = TotemUtil.retornarNomeDaMaquina();
			TotemUtil.getHttpServletRequest().getSession().removeAttribute("indexBean");
			TotemUtil.getHttpServletRequest().getSession().removeAttribute("preAtendimentoBean");
			TotemUtil.getHttpServletRequest().getSession().invalidate();
			TotemUtil.getHttpServletRequest().getSession(true);
			TotemUtil.getHttpServletRequest().getSession().setAttribute("nomeTotem", nomeMaquina);
			FacesContext.getCurrentInstance().getExternalContext()
					.redirect("/passelivretotem/indexTotem.xhtml?nomeTotem=" + nomeMaquina);
		} catch (final Exception exc) {
		}
	}

	public static String buscarSessionId() {
		try {
			final HttpSession session = TotemUtil.getHttpServletRequest().getSession();
			return session.getAttribute("sessionId").toString();
		} catch (final Exception locExc) {
			return "";
		}
	}

	public static String retornarNomeDaMaquina() {
		String nomeTotem = "nometotemindisponivel";
		Logger logger = Logger.getLogger(TotemUtil.class);
		
		try {
			if (TotemUtil.getHttpServletRequest().getParameter("nomeTotem") != null) {
				nomeTotem = TotemUtil.getHttpServletRequest().getParameter("nomeTotem").toLowerCase();
				TotemUtil.getHttpServletRequest().getSession().setAttribute("nomeTotem", nomeTotem.toLowerCase());
				if (nomeTotemValido(nomeTotem)) {
					setUltimoNomeTotemValido(nomeTotem);
					return nomeTotem;
				}
			}
		} catch (final Exception e) {
			logger.warn("1 - LOG DE WARNING getHttpServletRequest().getParameter TotemUtil", e);
		}
		
		try {
			if (TotemUtil.getHttpServletRequest().getAttribute("nomeTotem") != null) {
				nomeTotem = ((String) TotemUtil.getHttpServletRequest().getAttribute("nomeTotem")).toLowerCase();
				if (nomeTotemValido(nomeTotem)) {
					setUltimoNomeTotemValido(nomeTotem);
					return nomeTotem;
				}
			}
		} catch (final Exception e) {
			logger.warn("2 - LOG DE WARNING getHttpServletRequest().getAttribute().toLowerCase TotemUtil", e);
		}
		
		try {
			if (TotemUtil.getHttpServletRequest().getAttribute("nomeTotem") != null) {
				nomeTotem = (String) TotemUtil.getHttpServletRequest().getAttribute("nomeTotem");
				if (nomeTotemValido(nomeTotem)) {
					setUltimoNomeTotemValido(nomeTotem);
					return nomeTotem;
				}
			}
		} catch (final Exception e) {
			logger.warn("3 - LOG DE WARNING getHttpServletRequest().getAttribute() TotemUtil", e);
		}
		
		try {
			final HttpSession session = TotemUtil.getHttpServletRequest().getSession();
			if (session.getAttribute("nomeTotem") != null) {
				nomeTotem = session.getAttribute("nomeTotem").toString();
				if (nomeTotemValido(nomeTotem)) {
					setUltimoNomeTotemValido(nomeTotem);
					return nomeTotem;
				}
			}
		} catch (final Exception e) {
			logger.warn("4 - LOG DE WARNING getHttpServletRequest().getSession() TotemUtil", e);
		}
		
		try {
			NomeComputadorLocalUtil nomeComputadorLocalUtil = new NomeComputadorLocalUtil();
			nomeTotem = nomeComputadorLocalUtil.retornar(Util.getClientIpAddr(getHttpServletRequest()));
			if (nomeTotemValido(nomeTotem)) {
				setUltimoNomeTotemValido(nomeTotem);
				return nomeTotem;
			}
		} catch (final Exception e) {
			logger.warn("5 - LOG DE WARNING nomeComputadorLocalUtil TotemUtil", e);
		}
		
		try {
			InetAddress inetAddress = InetAddress.getByName(Util.getClientIpAddr(getHttpServletRequest()));
			nomeTotem = getHostName(inetAddress);

			if (nomeTotemValido(nomeTotem)) {
				setUltimoNomeTotemValido(nomeTotem);
				return nomeTotem;
			}
		} catch (final Exception e) {
			logger.warn("6 - LOG DE WARNING InetAddress TotemUtil", e);
		}
		
		try {
			Map<String, String> params = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap();
			nomeTotem = params.get("nomeTotem");
			if (nomeTotemValido(nomeTotem)) {
				setUltimoNomeTotemValido(nomeTotem);
				return nomeTotem;
			}
		} catch (final Exception e) {
			logger.warn("7 - LOG DE WARNING getCurrentInstance().getExternalContext() TotemUtil", e);
		}
		
		try {
			nomeTotem = getUltimoNomeTotemValido();
			if (nomeTotemValido(nomeTotem)) {
				return nomeTotem;
			}
		} catch(final Exception locExc) {
			logger.warn("8 - LOG DE WARNING getUltimoNomeTotemValido TotemUtil", locExc);
		}
		
		try {
			nomeTotem = getNomeTotemByArquivo();
			if (nomeTotemValido(nomeTotem)) {
				return nomeTotem;
			}
	    } catch (IOException e) {
			logger.warn("9 - LOG DE WARNING getNomeTotemByArquivo TotemUtil", e);
	    }
		
		logger.warn("10 - LOG DE WARNING não conseguiu buscar o nome do arquivo.");

		return nomeTotem;
	}

	private static boolean nomeTotemValido(String nomeTotem) {
		return nomeTotem != "null" && !nomeTotem.equals("null") && !nomeTotem.isEmpty() && nomeTotem.toLowerCase().contains("totem".toLowerCase())
				&& !nomeTotem.contains("indisponivel");
	}

	public static boolean isDesktop() {
		return false;
	}

	public static void retornaIndex() {
		try {
			final String nomeMaquina = TotemUtil.retornarNomeDaMaquina();
			getHttpServletRequest().getSession().invalidate();
			TotemUtil.getHttpServletRequest().getSession(true);
			TotemUtil.getHttpServletRequest().getSession().setAttribute("nomeTotem", nomeMaquina);
			FacesContext.getCurrentInstance().getExternalContext()
					.redirect("/passelivretotem/indexTotem.xhtml?nomeTotem=" + nomeMaquina);
		} catch (final IOException exc) {
			exc.printStackTrace();
		}
	}

	public static void limparSession() {
		final String nomeDaMaquina = TotemUtil.retornarNomeDaMaquina();
		TotemUtil.getHttpServletRequest().getSession().invalidate();
		TotemUtil.getHttpServletRequest().getSession(true);
		TotemUtil.getHttpServletRequest().getSession().setAttribute("nomeTotem", nomeDaMaquina);
	}

	public static void exibirDialogMensagem() {
		RequestContext.getCurrentInstance().execute("PF('dlgMessage').show()");
	}

	public static Map createBasicLogMap(Long idTotem, Long idUnidade, String ipOrigem) {
		Map additionalMap = new HashMap();

		if (idTotem != null) {
			additionalMap.put("idTotem", idTotem);
		}

		if (Constantes.APPLICATIONSVERSION != null) {
			additionalMap.put("versaoAplicacao", Constantes.APPLICATIONSVERSION);
		}

		if (idUnidade != null) {
			additionalMap.put("idUnidade", idUnidade);
		} else if (buscarUnidade() != null) {
			additionalMap.put("idUnidade", buscarUnidade().getCodigo());
		}

		if (ipOrigem != null && !ipOrigem.isEmpty()) {
			additionalMap.put("ipOrigem", ipOrigem);
		} else {
			additionalMap.put("ipOrigem", Util.getClientIpAddr(getHttpServletRequest()));
		}

		EmpresaTotem empresaTotem = buscarEmpresa();
		if (empresaTotem != null) {
			additionalMap.put("empresa", empresaTotem.getNome());
		}
		return additionalMap;
	}

	public static Map createBasicLogMap() {
		Long idTotem = null;
		Long idUnidade = null;
		informacoesTotem = buscarInformacoesTotem();
		if (informacoesTotem != null && !informacoesTotem.isEmpty()) {
			idTotem = informacoesTotem.get(0).getId();
			idUnidade = Long.valueOf(informacoesTotem.get(0).getIdUnidade());
		}
		try {
			return TotemUtil.createBasicLogMap(idTotem, idUnidade, Util.getClientIpAddr(getHttpServletRequest()));
		} catch (Exception e) {
			e.printStackTrace();
			return new HashMap();
		}
	}

	public static MensagemAviso createMensagemAviso(String mensagem) {
		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
		DateTimeFormatter timeFormat = DateTimeFormatter.ofPattern("HH:mm:ss");
		MensagemAviso mensagemAviso = new MensagemAviso();
		mensagemAviso.setIp(Util.getClientIpAddr(getHttpServletRequest()));
		mensagemAviso.setData(format.format(new Date()));
		mensagemAviso.setHora(LocalTime.now().format(timeFormat));
		mensagemAviso.setNomeTotem(retornarNomeDaMaquina());
		String sessionId = buscarSessionId();
		Unidade unidade = buscarUnidade();
		informacoesTotem = buscarInformacoesTotem();
		if (sessionId == null || sessionId.isEmpty()) {
			mensagemAviso.setSessionId("-");
		} else {
			mensagemAviso.setSessionId(buscarSessionId());
		}
		if (unidade != null) {
			mensagemAviso.setUnidade(unidade.getCodigo().toString());
		} else {
			if (informacoesTotem != null && !informacoesTotem.isEmpty()) {
				mensagemAviso.setUnidade(informacoesTotem.get(0).getIdUnidade());
			} else {
				mensagemAviso.setUnidade("-");
			}
		}
		mensagemAviso.setMensagem(mensagem);

		return mensagemAviso;
	}

	public static TokenResult gerarToken() throws Exception, RegraNegocioException {
		try {
			final ParametroUsuarioToken parametroUsuarioToken = new ParametroUsuarioToken(Constantes.ORIGEM_PADRAO);
			final AutenticaService autenticaService = new AutenticaService(getHttpServletRequest());
			autenticaService.gerarToken(parametroUsuarioToken);
			if (autenticaService.isSuccess()) {
				return (TokenResult) autenticaService.getResponseObject();
			} else {
				throw new RegraNegocioException(autenticaService.getResponseMessage());
			}
		} catch (final Exception locExc) {
			throw new RegraNegocioException(locExc.getMessage());
		}
	}

	public static boolean getAmbienteProducao() {
		ServletContext contex = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		boolean locAmbienteProducao = false;
		try {
			final String loStrAmbienteProd = contex.getInitParameter("isAmbienteProducao") == null ? System.getProperty("isAmbienteProducao") : contex.getInitParameter("isAmbienteProducao");
			locAmbienteProducao = loStrAmbienteProd == null ? false : "true".equals(loStrAmbienteProd);

		} catch (final Exception exc) {
			locAmbienteProducao = false;
		}

		return locAmbienteProducao;
	}

	private static String getHostName(InetAddress inaHost) throws UnknownHostException {
		try {
			Class clazz = Class.forName("java.net.InetAddress");
			Constructor[] constructors = clazz.getDeclaredConstructors();
			constructors[0].setAccessible(true);
			InetAddress ina = (InetAddress) constructors[0].newInstance();

			Field[] fields = ina.getClass().getDeclaredFields();
			for (Field field : fields) {
				if (field.getName().equals("nameService")) {
					field.setAccessible(true);
					Method[] methods = field.get(null).getClass().getDeclaredMethods();
					for (Method method : methods) {
						if (method.getName().equals("getHostByAddr")) {
							method.setAccessible(true);
							return (String) method.invoke(field.get(null), inaHost.getAddress());
						}
					}
				}
			}
		} catch (ClassNotFoundException cnfe) {
		} catch (IllegalAccessException iae) {
		} catch (InstantiationException ie) {
		} catch (InvocationTargetException ite) {
			throw (UnknownHostException) ite.getCause();
		}
		return null;
	}

	public static void refreshPage() {
		try {
			FacesContext.getCurrentInstance().getExternalContext().redirect(getHttpServletRequest().getRequestURI());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void setarConsultaConfiguracaoResult(final ConsultaConfiguracaoResult consultaConfiguracaoResult) {
		try {
			TotemUtil.getHttpServletRequest().getSession().setAttribute("consultaConfiguracaoResult", consultaConfiguracaoResult);
		} catch (final Exception locExc) {
			Logger logger = Logger.getLogger(TotemUtil.class);
			logger.error("LOG DE EXCESSÃO AO SETAR ConfiguracaoResult", locExc);
		}
	}
	
	public static ConsultaConfiguracaoResult recuperarConsultaConfiguracaoResult(final ParametroConsultaConfiguracao parametrosConsultaConfiguracao) throws RegraNegocioException {
		try {
			final HttpSession session = TotemUtil.getHttpServletRequest().getSession();
			final ConsultaConfiguracaoResult consultaConfiguracaoResult = (ConsultaConfiguracaoResult) session.getAttribute("consultaConfiguracaoResult");
			return consultaConfiguracaoResult;
		} catch (final Exception locExc) {
			Logger logger = Logger.getLogger(TotemUtil.class);
			logger.error("LOG DE EXCESSÃO AO RECUPERAR ConfiguracaoResult", locExc);
			throw new RegraNegocioException("6 - Erro ao buscar informações do totem: " + parametrosConsultaConfiguracao.getIp());
		}
	}	
	
	public static void setUltimoNomeTotemValido(String nomeTotem) {
		TotemUtil.getHttpServletRequest().getSession().setAttribute("ultimoNomeTotemValido", nomeTotem);
	}
	
	public static String getUltimoNomeTotemValido() throws IOException  {

			Object ultimoNomeTotemValidoObj = TotemUtil.getHttpServletRequest().getSession().getAttribute("ultimoNomeTotemValido");
			if(!Objects.isNull(ultimoNomeTotemValidoObj)) {
				String ultimoNomeTotemValido = ultimoNomeTotemValidoObj.toString();
				log.info("getUltimoNomeTotemValido - Nome do parametro: " + ultimoNomeTotemValidoObj);	
				return ultimoNomeTotemValido;
			} 
			return getNomeTotemByArquivo();

	}
	
	public static String getNomeTotemByArquivo() throws IOException {
		String caminho = Constantes.PARAM_APPLET_DIRETORIO_RETORNO_WINDOWS +"/totemConfig.properties";
		
		Properties propriedades = new Properties();

		FileInputStream stream = new FileInputStream(caminho);
	     propriedades.load(stream);
	     String nomeTotem = propriedades.getProperty("nomeTotem");
	      
	     if (nomeTotem != null && !"".equals(nomeTotem)) {
	    	 log.warn("getNomeTotemByArquivo - Nome do parametro: " + nomeTotem);	
	    	  return nomeTotem;
	      } else {
	    	  throw new IOException("Nome do parametro nomeTotem nao encontrado no arquivo");
	      }
	}
}
