package br.com.hermespardini.passelivre.utils;

import java.util.Properties;

import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.InitialDirContext;

import br.com.hermespardini.passelivre.constantsenum.Constantes;

public class NomeComputadorLocalUtil {

	public String retornar(final String ip) throws NamingException, Exception {
		try {
			String nomeMaquina = "";
			final Properties env = new Properties();
			env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.dns.DnsContextFactory");
			InitialDirContext idc;
			idc = new InitialDirContext(env);
			String ipAddr = retornarIpValido(ip);
			final String[] quads = ipAddr.split("\\.");
			final StringBuilder sb = new StringBuilder();
			for (int i = quads.length - 1; i >= 0; i--) {
				sb.append(quads[i]).append(".");
			}
			sb.append("in-addr.arpa.");
			ipAddr = sb.toString();
			final Attributes attrs = idc.getAttributes(ipAddr, new String[] { "PTR" });
			final Attribute attr = attrs.get("PTR");
			if (attr != null) {
				for (int i = 0; i < attr.size(); i++) {
					nomeMaquina = nomeMaquina + (String) attr.get(i);
				}
			}
			if (nomeMaquina.contains(".")) {
				nomeMaquina = nomeMaquina.substring(0, nomeMaquina.indexOf("."));
			}
			return nomeMaquina;
		} catch (final Exception locExc) {
			throw new Exception(locExc.getMessage());
		}
	}

	private String retornarIpValido(final String parIp) {
		if (parIp != null || !parIp.toString().isEmpty()) {
			if (parIp.toString().substring(0, 2).equals("0:")) {
				return Constantes.IP_COMPUTADOR_DEFAULT_DESKTOP;
			}
		}
		return parIp;
	}
}
