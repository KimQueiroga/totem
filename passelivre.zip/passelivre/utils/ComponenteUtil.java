package br.com.hermespardini.passelivre.utils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;

import javax.el.ELContext;
import javax.el.ExpressionFactory;
import javax.el.ValueExpression;
import javax.faces.application.Application;
import javax.faces.context.FacesContext;

import br.com.hermespardini.passelivre.to.PerguntaComExameTO;

public class ComponenteUtil {

	public ValueExpression getValueExpression(final String data) {
		final FacesContext fc = FacesContext.getCurrentInstance();
		final Application app = fc.getApplication();
		final ExpressionFactory elFactory = app.getExpressionFactory();
		final ELContext elContext = fc.getELContext();
		final ValueExpression valueExp = elFactory.createValueExpression(elContext, data, Object.class);
		return valueExp;
	}

	public String retornarId(final PerguntaComExameTO pergunta, final String tipoComponente) {
		return tipoComponente + pergunta.getCodigoQuestionario() + "_"
				+ pergunta.getExame().replaceAll("\\s+", "").replace("-", "_").replace("+", "").replace(".", "_")
				+ pergunta.getOrdem() + "_" + retornarNumeroAleatorio() + "_" + retornarNumeroAleatorio() + "_"
				+ pergunta.getCodigo();
	}

	public Integer retornarNumeroAleatorio() {
		final Random gerador = new Random();
		return gerador.nextInt(500);
	}

	public String retornarHoraAtual() {
		final SimpleDateFormat sdf = new SimpleDateFormat("ms");
		final Date time = Calendar.getInstance().getTime();
		final String hora = sdf.format(time);
		return hora;
	}

	public Boolean isObrigatorio(final String valor) {
		try {
			if (valor.equals("S")) {
				return true;
			} else {
				return false;
			}
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return false;
		}
	}

}
