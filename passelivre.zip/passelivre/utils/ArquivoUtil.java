package br.com.hermespardini.passelivre.utils;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.SocketTimeoutException;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.print.Doc;
import javax.print.DocFlavor;
import javax.print.DocPrintJob;
import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import javax.print.SimpleDoc;
import javax.print.attribute.DocAttribute;
import javax.print.attribute.DocAttributeSet;
import javax.print.attribute.HashDocAttributeSet;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.print.attribute.standard.MediaSizeName;
import javax.print.attribute.standard.Sides;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.pdfbox.io.IOUtils;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;

public class ArquivoUtil {

	private static final int DEFAULT_BUFFER_SIZE = 10240; // 10KB.

	public void downloadPDF(final String nomeDoArquivo) throws IOException {

		final FacesContext facesContext = FacesContext.getCurrentInstance();
		final ExternalContext externalContext = facesContext.getExternalContext();
		final HttpServletResponse response = (HttpServletResponse) externalContext.getResponse();

		final File file = new File(System.getProperty("java.io.tmpdir"), nomeDoArquivo);
		BufferedInputStream input = null;
		BufferedOutputStream output = null;

		try {
			input = new BufferedInputStream(new FileInputStream(file), ArquivoUtil.DEFAULT_BUFFER_SIZE);

			response.reset();
			response.setHeader("Content-Type", "application/pdf");
			response.setHeader("Content-Length", String.valueOf(file.length()));
			response.setHeader("Content-Disposition", "attachment;filename=\"" + nomeDoArquivo + "\"");
			output = new BufferedOutputStream(response.getOutputStream(), ArquivoUtil.DEFAULT_BUFFER_SIZE);

			final byte[] buffer = new byte[ArquivoUtil.DEFAULT_BUFFER_SIZE];
			int length;
			while ((length = input.read(buffer)) > 0) {
				output.write(buffer, 0, length);
			}
			output.flush();
		} finally {
			ArquivoUtil.close(output);
			ArquivoUtil.close(input);
		}

		facesContext.responseComplete();
	}

	private static void close(final Closeable resource) {
		if (resource != null) {
			try {
				resource.close();
			} catch (final IOException e) {
				e.printStackTrace();
			}
		}
	}

	public void salvarDiretorioLocal(final byte[] arquivo, final String nomeDoArquivo) throws RegraNegocioException {
		try {
			final OutputStream output = new FileOutputStream(diretorioNomeArquivo(nomeDoArquivo));
			output.write(arquivo);
			output.close();
		} catch (final Exception exc) {
			exc.printStackTrace();
			throw new RegraNegocioException("Erro ao salvar o arquivo!" + exc.getMessage());
		}
	}

	public String diretorioNomeArquivo(final String nomeDoArquivo) {
		if (nomeDoArquivo.equals("GA_40_teste2.pdf")) {
			return "/resources/"+nomeDoArquivo;
		}
		else
			return System.getProperty("java.io.tmpdir") + "/" + nomeDoArquivo;
	}

	// ip padrão de teste 172.19.114.173
	public void fazerImpressao(final String nomeDoArquivo, final String ip) throws Exception {
		try {
			// buscando o arquivo no diretorio Temp do tomcat
			System.out.println("Abrindo conexao com " + ip + "na porta 9100");
			// acessando o endereço da impressora
			final Socket sock = new Socket(ip, 9100);
			sock.setSoTimeout(5000);
			final OutputStream output = sock.getOutputStream();
			System.out.println("Buscando pelo arquivo : " + diretorioNomeArquivo(nomeDoArquivo));
			final InputStream reader = new FileInputStream(diretorioNomeArquivo(nomeDoArquivo));
			System.out.println("Convertendo arquivo PDF via pdfbox em byteArray");
			final byte[] bytes = IOUtils.toByteArray(reader);
			System.out.println("Escrevendo no socket");
//			output.write(27);
//			output.write("%-12345X@PJL\n".getBytes());
//	        output.write("@PJL SET DUPLEX=ON\n".getBytes());
	        output.write(bytes);
//	        output.write(27);
//	        output.write("%-12345X".getBytes());
			System.out.println("Fechando a conexao");
			sock.close();
			excluirArquivo(diretorioNomeArquivo(nomeDoArquivo)); // Deixando arquivo disponível para
			// download
		} catch (Exception e) {
			throw new Exception("Falha de impressão na impressora " + ip + ": Mensagem: " + e.getMessage());
		}
	}
	
	public void fazerImpressaoFrenteVerso(final String nomeDoArquivo, final String ip) throws Exception {
		try {
			// buscando o arquivo no diretorio Temp do tomcat
			System.out.println("Abrindo conexao com " + ip + "na porta 9100");
			// acessando o endereço da impressora
			final Socket sock = new Socket(ip, 9100);
			sock.setSoTimeout(5000);
			final OutputStream output = sock.getOutputStream();
			System.out.println("Buscando pelo arquivo : " + diretorioNomeArquivo(nomeDoArquivo));
			final InputStream reader = new FileInputStream(diretorioNomeArquivo(nomeDoArquivo));
			System.out.println("Convertendo arquivo PDF via pdfbox em byteArray");
			final byte[] bytes = IOUtils.toByteArray(reader);
			System.out.println("Escrevendo no socket");
			output.write(27);
			output.write("%-12345X@PJL\n".getBytes());
	        output.write("@PJL SET DUPLEX=ON\n".getBytes());
	        output.write(bytes);
	        output.write(27);
	        output.write("%-12345X".getBytes());
			System.out.println("Fechando a conexao");
			sock.close();
			excluirArquivo(diretorioNomeArquivo(nomeDoArquivo)); // Deixando arquivo disponível para
			// download
		} catch (SocketTimeoutException e) {
			throw new SocketTimeoutException("Tempo expirado de impressão na impressora " + ip + ": Mensagem: " + e.getMessage());
		}
		catch (Exception e) {
			throw new Exception("Falha de impressão na impressora " + ip + ": Mensagem: " + e.getMessage());
		}
	}
	
	public void fazerImpressaoFrenteVersoTeste(final String nomeDoArquivo, final String ip) throws Exception {
		try {
			// buscando o arquivo no diretorio Temp do tomcat
			System.out.println("Abrindo conexao com " + ip + "na porta 9100");
			// acessando o endereço da impressora
			final Socket sock = new Socket(ip, 9100);
			sock.setSoTimeout(5000);
			final OutputStream output = sock.getOutputStream();
			System.out.println("Buscando pelo arquivo : " + diretorioNomeArquivo(nomeDoArquivo));
			final InputStream reader = new FileInputStream(diretorioNomeArquivo(nomeDoArquivo));
			System.out.println("Convertendo arquivo PDF via pdfbox em byteArray");
			final byte[] bytes = IOUtils.toByteArray(reader);
			System.out.println("Escrevendo no socket");
			output.write(27);
			output.write("%-12345X@PJL\n".getBytes());
	        output.write("@PJL SET DUPLEX=ON\n".getBytes());
	        output.write(bytes);
	        output.write(27);
	        output.write("%-12345X".getBytes());
			System.out.println("Fechando a conexao");
			sock.close();
			excluirArquivo(diretorioNomeArquivo(nomeDoArquivo)); // Deixando arquivo disponível para
			// download
		} catch (SocketTimeoutException e) {
			throw new SocketTimeoutException("Tempo expirado de impressão na impressora " + ip + ": Mensagem: " + e.getMessage());
		}
		catch (Exception e) {
			throw new Exception("Falha de impressão na impressora " + ip + ": Mensagem: " + e.getMessage());
		}
	}

	public void fazerImpressaoDuplicada(final String nomeDoArquivo, final String ip) throws Exception {
		// buscando o arquivo no diretorio Temp do tomcat
		System.out.println("Abrindo conexao com " + ip + "na porta 9100");
		// acessando o endereço da impressora
		final Socket sock = new Socket(ip, 9100);
		sock.setSoTimeout(5000);
		final OutputStream output = sock.getOutputStream();
		System.out.println("Buscando pelo arquivo : " + diretorioNomeArquivo(nomeDoArquivo));
		final InputStream reader = new FileInputStream(diretorioNomeArquivo(nomeDoArquivo));
		System.out.println("Convertendo arquivo PDF via pdfbox em byteArray");
		final byte[] bytes = IOUtils.toByteArray(reader);
		System.out.println("Escrevendo no socket");
		output.write(bytes);
		output.write(bytes);
		System.out.println("Fechando a conexao");
		sock.close();
		excluirArquivo(diretorioNomeArquivo(nomeDoArquivo));
	}

	public void excluirArquivo(final String arquivo) {
		final File file = new File(arquivo);
		if (file.exists()) {
			System.out.println("Excluindo o arquivo...");
			if (file.delete()) {
				System.out.println(file.getName() + " foi excluido!");
			} else {
				System.out.println("Exclusao nao foi efetuada.");
			}
		} else {
			System.out.println("Arquivo nao encontrado.");
		}
	}

	public void salvarDiretorioLocalTemp(final byte[] arquivo, final String nomeDoArquivo)
			throws RegraNegocioException {
		try {
			System.getProperty("java.io.tmpdir");
			final OutputStream output = new FileOutputStream(
					Constantes.PARAM_APPLET_DIRETORIO_RETORNO_WINDOWS + "/" + nomeDoArquivo);
			output.write(arquivo);
			output.close();
		} catch (final Exception exc) {
			exc.printStackTrace();
			throw new RegraNegocioException("Erro ao salvar o arquivo!" + exc.getMessage());
		}
	}

	public String recuperarConteudoArquivo(String nomeArquivo) {
		FileReader arq;
		String conteudo = "";
		try {
			arq = new FileReader(Constantes.PARAM_APPLET_DIRETORIO_RETORNO_WINDOWS + "/" + nomeArquivo);
			BufferedReader lerArq = new BufferedReader(arq);
			conteudo = lerArq.readLine();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return conteudo;
	}

}
