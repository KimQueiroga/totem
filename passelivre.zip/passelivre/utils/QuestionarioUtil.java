package br.com.hermespardini.passelivre.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.model.ClienteUnidadePasseLivre;
import br.com.hermespardini.passelivre.model.ConsultaQuestionarioExameResult;
import br.com.hermespardini.passelivre.model.ExameHermesPardini;
import br.com.hermespardini.passelivre.model.ParametroImpressaoQuestionario;
import br.com.hermespardini.passelivre.model.ParametroQuestionario;
import br.com.hermespardini.passelivre.model.Questionario;
import br.com.hermespardini.passelivre.model.TokenResult;
import br.com.hermespardini.passelivre.service.PerguntasService;
import br.com.hermespardini.passelivre.service.QuestionarioService;
import br.com.hermespardini.passelivre.to.PerguntaComExameTO;
import br.com.hermespardini.passelivre.to.ProcedimentoComExamesTO;

public class QuestionarioUtil {

	public static Logger log = Logger.getLogger(Util.class);

	private List<ConsultaQuestionarioExameResult> questionariosExamesResult;
	private Map<String, List<PerguntaComExameTO>> todasPerguntasAgrupadas;

	private ConsultaQuestionarioExameResult consultaQuestionarioExameResult;
	private List<ParametroQuestionario> parametrosQuestionario;

	public void buscarQuestionario(final List<ProcedimentoComExamesTO> listaProcedimentosSelecionados,
			final ClienteUnidadePasseLivre clienteUnidadePasseLivre, final TokenResult tokenResult)
			throws RegraNegocioException {
		try {
			final QuestionarioService questionarioService = new QuestionarioService(
					QuestionarioUtil.getHttpServletRequest());
			final List<ParametroQuestionario> parametrosQuestionario = adicionarParametrosAoQuestionario(
					listaProcedimentosSelecionados, clienteUnidadePasseLivre, tokenResult);
			consultarQuestionario(questionarioService, parametrosQuestionario);
			agruparPerguntasEOrdenar();
		} catch (final Exception locExc) {
			throw new RegraNegocioException("Erro ao buscar o questionário!" + locExc.getMessage());
		}
	}

	private List<ParametroQuestionario> adicionarParametrosAoQuestionario(
			final List<ProcedimentoComExamesTO> listaProcedimentosSelecionados,
			final ClienteUnidadePasseLivre clienteUnidadePasseLivre, final TokenResult tokenResult) {
		parametrosQuestionario = new ArrayList<>();
		for (final ProcedimentoComExamesTO procedimento : listaProcedimentosSelecionados) {
			ParametroQuestionario parametroQuestionario;
			if (!procedimento.getExcluido()) {
				if (existePacoteNoExame(procedimento.getExame())) {
					for (final ExameHermesPardini exame : procedimento.getExame().getComposicaoPacote()) {
						parametroQuestionario = new ParametroQuestionario(exame, procedimento.getExame(),
								clienteUnidadePasseLivre, tokenResult);
						parametrosQuestionario.add(parametroQuestionario);
					}
				} else {
					parametroQuestionario = new ParametroQuestionario(procedimento, clienteUnidadePasseLivre,
							tokenResult);
					parametrosQuestionario.add(parametroQuestionario);
				}
			}
		}
		return parametrosQuestionario;
	}

	private void consultarQuestionario(final QuestionarioService questionarioService,
			final List<ParametroQuestionario> parametrosQuestionario) throws RegraNegocioException {
		questionariosExamesResult = new ArrayList<>();
		for (final ParametroQuestionario locParametroQuestionario : parametrosQuestionario) {
			questionarioService.setValueObject(locParametroQuestionario);
			questionarioService.consultar();
			if (questionarioService.isSuccess()) {
				consultaQuestionarioExameResult = new ConsultaQuestionarioExameResult(
						(ConsultaQuestionarioExameResult) questionarioService.getResponseObject(),
						locParametroQuestionario);
				questionariosExamesResult.add(consultaQuestionarioExameResult);
				QuestionarioUtil.getHttpServletRequest().getSession().setAttribute("questionariosExamesResult",
						questionariosExamesResult);
			} else {
				throw new RegraNegocioException(questionarioService.getResponseMessage());
			}
		}
	}

	private void agruparPerguntasEOrdenar() throws Exception {
		final PerguntasService perguntasUtil = new PerguntasService();
		todasPerguntasAgrupadas = new TreeMap<>(perguntasUtil.agruparPerguntasPorAba(questionariosExamesResult));
	}

	private boolean existePacoteNoExame(final ExameHermesPardini exame) {
		return exame.getEPacote() == Constantes.TIPO_PACOTE;
	}

	public boolean isExisteQuestionario() {
		if ((!todasPerguntasAgrupadas.isEmpty() || todasPerguntasAgrupadas.size() != 0) && !isQuestionarioImpresso()) {
			QuestionarioUtil.getHttpServletRequest().getSession().setAttribute("todasPerguntasAgrupadas",
					todasPerguntasAgrupadas);
			return true;
		} else {
			return false;
		}
	}

	public boolean isQuestionarioImpresso() {
		boolean questionarioSaoImpressos = false;
		for (final Questionario questionario : consultaQuestionarioExameResult.getQuestionarios()) {
			if (questionario.getImpresso().equals("S")) {
				questionarioSaoImpressos = true;
			}
		}
		return questionarioSaoImpressos;
	}

	public void imprimirQuestionario(final List<ProcedimentoComExamesTO> listaProcedimentosSelecionados,
			final ClienteUnidadePasseLivre clienteUnidadePasseLivre, final TokenResult tokenResult) throws Exception {

		final QuestionarioService questionarioService = new QuestionarioService(
				QuestionarioUtil.getHttpServletRequest());
		adicionarParametrosAoQuestionario(listaProcedimentosSelecionados, clienteUnidadePasseLivre, tokenResult);
		consultarQuestionario(questionarioService, parametrosQuestionario);
		if (isQuestionarioImpresso()) {
			try {
				final ParametroImpressaoQuestionario locParametroImpressaoQuestionario = new ParametroImpressaoQuestionario(
						parametrosQuestionario.get(0), listaProcedimentosSelecionados,
						TotemUtil.buscarInformacaoTotem().getImpressoraDefault());
				questionarioService.setValueObject(locParametroImpressaoQuestionario);
				questionarioService.imprimir();
			} catch (final Exception locExc) {
				throw new Exception(questionarioService.getResponseMessage());
			}
		}
	}

	private static HttpServletRequest getHttpServletRequest() {
		return (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
	}

	public ConsultaQuestionarioExameResult getConsultaQuestionarioExameResult() {
		return consultaQuestionarioExameResult;
	}

}
