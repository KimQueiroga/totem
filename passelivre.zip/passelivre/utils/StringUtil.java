package br.com.hermespardini.passelivre.utils;

import java.text.ParseException;

import javax.swing.text.MaskFormatter;

public class StringUtil {

	public String formatarCPFComMask(String parCPF) {
		try {
			MaskFormatter mask = new MaskFormatter("###.###.###-##");
			mask.setValueContainsLiteralCharacters(false);
			return mask.valueToString(parCPF);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return "";

	}

}
