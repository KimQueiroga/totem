package br.com.hermespardini.passelivre.utils;

import java.math.BigInteger;
import java.text.MessageFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Objects;
import java.util.ResourceBundle;
import java.util.concurrent.TimeUnit;

import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

import com.google.gson.Gson;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.to.ProcedimentoComExamesTO;

public class Util {
	public static Logger log = Logger.getLogger(Util.class);

	public static Boolean verificarSeConteudoEhXML(final String paramConteudo) {
		if (paramConteudo != null && !paramConteudo.isEmpty()) {
			return paramConteudo.startsWith("<");
		} else {
			return true;
		}
	}

	public static String cortarCaractere(final String parDescricaoASerCortada, final int tamanhoLimite) {
		try {
			if (parDescricaoASerCortada != null && parDescricaoASerCortada != "") {
				if (parDescricaoASerCortada.length() > tamanhoLimite) {
					return parDescricaoASerCortada.substring(0, tamanhoLimite);
				} else {
					return parDescricaoASerCortada;
				}
			}
			return "";
		} catch (final Exception locExc) {
			return "";
		}
	}

	public static String retirarCaracterEspecial(String message) {
		if (message.indexOf("&lt;BR&gt;&lt;BR&gt;") != -1) {
			message = message.replace("&lt;BR&gt;&lt;BR&gt;", "");
		}
		return message;
	}

	public String retornarEndPoint(final String valor, final HttpServletRequest request) {
		final ServletContext servletContext = request.getServletContext();
		return servletContext.getInitParameter(valor);
	}

	/**
	 * Determina se a aplica��o est� sendo executada no ambiente de produ��o.<br>
	 * Retorna True em produ��o e False em homologa��o.<br>
	 * <br>
	 * Obs.:Esta fun��o depende da configura��o do par�metro
	 * <b>isAmbienteProducao</b> no arquivo <a href=
	 * "http://tomcat.apache.org/tomcat-7.0-doc/config/context.html#Context_Parameters">context.xml</a>
	 * do tomcat.
	 *
	 * @param request
	 * @return
	 */
	public static Boolean isAmbienteProducao(final HttpServletRequest request) {
		return Boolean.valueOf(Util.getParametro(request, Constantes.IS_AMBIENTE_PRODUCAO));
	}

	/**
	 * Recupera o valor associado ao parametro presente no arquivo context.xml do
	 * tomcat.
	 *
	 * @param request
	 * @param parametro
	 * @return
	 */
	public static String getParametro(final HttpServletRequest request, final String parametro) {
		return request.getServletContext().getInitParameter(parametro);
	}

	public static String obterDiretorioArquivo(final String pathFile) {
		return Constantes.DIRETORIO_APLICACAO + pathFile;
	}

	public static Double retornarApenasNumero(final String parPrivatePrice) {
		try {
			if (!parPrivatePrice.isEmpty()) {
				return new Double(parPrivatePrice.replace("R$ ", "").replace(".", "").replace(",", "."));
			}
			return 0.0;
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return 0.0;
		}
	}

	/**
	 * O formatado da data deve seguir o padro dd/MM/yyyy data1 - menor data data2 -
	 * maior data
	 * 
	 * @param data1
	 * @param data2
	 * @return
	 */
	public static Integer retornaDiferencaAnos(String data1, String data2) {
		if ((data1 != null) && (data1 != null)) {
			return Period.between(stringToLocalDate(data1), stringToLocalDate(data2)).getYears();
		} else {
			return 0;
		}
	}

	public static Integer retornaIdade(String dataNascimento) {
		if (dataNascimento != null) {
			return Period.between(stringToLocalDate(dataNascimento), stringToLocalDate(getDataHoje())).getYears();
		} else {
			return 0;
		}
	}

	public static String getDataHoje() {
		return LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
	}

	public static String localDateToString(LocalDate data, String pattern) {
		return data.format(DateTimeFormatter.ofPattern(pattern));
	}

	public static LocalDate stringToLocalDate(String data) {
		return stringToLocalDateCustomPattern(data, "dd/MM/yyyy");
	}

	public static LocalDate stringToLocalDateCustomPattern(String data, String pattern) {
		return LocalDate.parse(data, DateTimeFormatter.ofPattern(pattern));
	}

	public static int customFrequencyProcedimento(List<ProcedimentoComExamesTO> listProcedimento,
			ProcedimentoComExamesTO procedimento) {
		int quantidade = 0;
		for (ProcedimentoComExamesTO prodL : listProcedimento) {
			if (prodL.getProcedimento().equals(procedimento.getProcedimento())) {
				quantidade++;
			}
		}
		return quantidade;
	}

	public static String getClientIpAddr(HttpServletRequest request) {
		String ip = request.getHeader("X-Forwarded-For");
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("WL-Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("HTTP_CLIENT_IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("HTTP_X_FORWARDED_FOR");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getRemoteAddr();
		}
		return ip;
	}

	public static void aguardar(int timeToSleep) {
		try {
		    TimeUnit.MILLISECONDS.sleep(timeToSleep);
		} catch (InterruptedException ie) {
		    Thread.currentThread().interrupt();
		}
	}
	
	public static String retornaJsonResult(Object result) {
		final Gson gson = new Gson();
		return gson.toJson(result);
	}

	public static Boolean isTimeOut(int code) {
		return code == BigInteger.valueOf(408).intValue();
	}
	
	public static void msgTimeOut(final String descErrorCode, final String origem, final String descricaoEndPoint, final String codigoCliente,
			String message) throws Exception {
		String retorno = montaMsgTimeOut(descErrorCode, origem, descricaoEndPoint, codigoCliente, message);
		throw new RegraNegocioException(retorno);
	}
	
	public static String msgTimeOutReturnMessage(final String descErrorCode, final String origem, final String descricaoEndPoint, final String codigoCliente,
			String message) throws Exception {
		String retorno = montaMsgTimeOut(descErrorCode, origem, descricaoEndPoint, codigoCliente, message);
		return retorno;
	}	
	
	private static String montaMsgTimeOut(final String descErrorCode, final String origem, final String descricaoServico, final String codigoCliente,
			String message) throws Exception {
		String comTimeOut = ", com timeout";
		
		if(!Objects.isNull(codigoCliente)) {
			comTimeOut += " para o cliente "+ codigoCliente;
		}
		
		log.warn("Serviço passelivretotem "+ descErrorCode + " - "+ descricaoServico + ", origem: " + origem + comTimeOut, new Exception(message));
		String retorno  = getGlobalResourceBundleString("TIME_OUT_MESSAGE", "systemAppErrorMessages");
		retorno = MessageFormat.format(retorno, descErrorCode);
		
		return retorno;
	}
	
	protected static String getGlobalResourceBundleString(final String resourceBundleKey, final String resourceBundleVar)
			throws Exception {
		final FacesContext facesContext = getContext();
		final ResourceBundle bundle = facesContext.getApplication().getResourceBundle(getContext(), resourceBundleVar);
		return bundle.getString(resourceBundleKey);
	}
	protected static final FacesContext getContext() throws Exception {
		return FacesContext.getCurrentInstance();
	}
	
	private static String retirarOsDoisPrimeirosDigitos(final String idPedido) {
		return idPedido.substring(2, idPedido.length());
	}	
	
	public static String retornarIdPedidoDetalheValido(String idPedido) {
		try {
			idPedido = retirarOsDoisPrimeirosDigitos(idPedido);
			final String unidade = idPedido.substring(0, 3);
			final String pedido = idPedido.substring(3, idPedido.length() - 2);
			return unidade + "||" + pedido;
		} catch (final Exception locExc) {
			return "";
		}
	}
	
	public static boolean isTotemAim33() {
		try {
	      return "ihpmgaim2totem2".equalsIgnoreCase(TotemUtil.retornarNomeDaMaquina());
	    } catch (Exception e) {
	    	log.error(e.getMessage(), e);
	    	return false;
	    }
	 }
}
