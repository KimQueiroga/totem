package br.com.hermespardini.passelivre.login.model;

import java.io.Serializable;

import org.wdelmaschio.base.model.ValueObject;

import br.com.hermespardini.passelivre.model.UserAuth;

public class UserGetVerificationCode extends ValueObject implements Serializable {

	private String authKey;
	private String authKeyType;
	private String verificationCodeAdvertiseChannel;
	private String birthDate;
	private String empresa;

	public UserGetVerificationCode() {

	}

	public UserGetVerificationCode(UserAuth userAuth, String localEnvioCod, String idEmpresa) {
		this.authKey = userAuth.getAuthKey();
		this.authKeyType = userAuth.getAuthKeyType();
		this.verificationCodeAdvertiseChannel = localEnvioCod;
		this.birthDate = userAuth.getBirthDate();
		this.empresa = idEmpresa;
	}

	public String getAuthKey() {
		return authKey;
	}

	public void setAuthKey(String authKey) {
		this.authKey = authKey;
	}

	public String getAuthKeyType() {
		return authKeyType;
	}

	public void setAuthKeyType(String authKeyType) {
		this.authKeyType = authKeyType;
	}

	public String getVerificationCodeAdvertiseChannel() {
		return verificationCodeAdvertiseChannel;
	}

	public void setVerificationCodeAdvertiseChannel(String verificationCodeAdvertiseChannel) {
		this.verificationCodeAdvertiseChannel = verificationCodeAdvertiseChannel;
	}

	public String getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}

	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}

}
