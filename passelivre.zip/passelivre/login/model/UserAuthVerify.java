package br.com.hermespardini.passelivre.login.model;

import java.io.Serializable;

import br.com.hermespardini.passelivre.model.UserAuth;

public class UserAuthVerify extends UserAuth implements Serializable {
	
	private String verificationCode;
	
	public UserAuthVerify() {
		
	}
	
	public UserAuthVerify(UserAuth userAuth, String cod, String novaSenha) {
		super.setAuthKey(userAuth.getAuthKey());
		super.setAuthKeyType(userAuth.getAuthKeyType());
		super.setBirthDate(userAuth.getBirthDate());
		super.setNewPass(novaSenha);
		this.verificationCode = cod;
	}

	public String getVerificationCode() {
		return verificationCode;
	}

	public void setVerificationCode(String verificationCode) {
		this.verificationCode = verificationCode;
	}
	
}
