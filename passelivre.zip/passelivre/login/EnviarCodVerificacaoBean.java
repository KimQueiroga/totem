package br.com.hermespardini.passelivre.login;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

import org.primefaces.context.RequestContext;

import br.com.hermespardini.corebusiness.model.LogAplicacaoUsuarioFactory;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.login.model.UserGetVerificationCode;
import br.com.hermespardini.passelivre.model.InformacaoTotem;
import br.com.hermespardini.passelivre.model.MensagemAviso;
import br.com.hermespardini.passelivre.model.TokenResult;
import br.com.hermespardini.passelivre.model.UserAuth;
import br.com.hermespardini.passelivre.service.IndexService;
import br.com.hermespardini.passelivre.service.SenhaService;
import br.com.hermespardini.passelivre.utils.ControleBotaoUtil;
import br.com.hermespardini.passelivre.utils.TotemUtil;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.bean.MainBean;

@ManagedBean
@SessionScoped
public class EnviarCodVerificacaoBean extends MainBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	// Infos básicas para cada tela
	private List<InformacaoTotem> informacoesTotem;
	private TokenResult tokenResult;
	private String sessionId;
	private InformacaoTotem informacaoTotem;
	private String mensagemAviso;
	private UserAuth userAuth;

	private String localEnvioCod;

	public enum ElocalEnvioCod {
		SMS("S"), EMAIL("E");

		private final String valor;

		ElocalEnvioCod(String local) {
			this.valor = local;
		}
		
		public String getValor() {
			return this.valor;
		}
	}
	
	@PostConstruct
	public void onLoad() {
		try {
			buscarInformacoesTotem();
			buscarToken();

			buscarSessionId();
			buscarInformacaoTotem();
		} catch (final Exception exc) {
			exc.printStackTrace();
			MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso(exc.getMessage());
			try {
				getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
			} catch (Exception e) {
				e.printStackTrace();
			}
			redirectTelaErro();
		}
	}

	public void onPageLoad() {
		receberUserAuth();
		this.localEnvioCod = ElocalEnvioCod.EMAIL.getValor();
	}

	public void enviarCodVerificacao() {
		try {
			final SenhaService senhaService = new SenhaService(getHttpServletRequest());
			
			UserGetVerificationCode userGetVerificationCode = new UserGetVerificationCode(userAuth, localEnvioCod, String.valueOf(informacaoTotem.getIdEmpresa()));
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, userAuth.getAuthKey());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId, createBasicLogMap());
			senhaService.enviarCodVerificacaoNovaSenha(userGetVerificationCode);
			if (senhaService.isSuccess()) {
				mensagemAviso = senhaService.getResponseMessage();
			}
			exibirDlgSucessoCodEnvio();
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			mensagemAviso = locExc.getMessage();
			gerarLogErroAoRecuperarSenha(locExc.getMessage());
			exibirDialogMensagem();
		}	
	}

	private void receberUserAuth() {
		try {
			this.userAuth = (UserAuth) getHttpServletRequest().getSession()
					.getAttribute("userAuth");
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}
	
	public void redirectRedefinirSenha() {
		try {
			new ControleBotaoUtil().redirectRedefinirSenha(getHttpServletRequest(), userAuth, sessionId);
		} catch (final Exception e) {
			e.printStackTrace();
		}
	}
	
	private void exibirDlgSucessoCodEnvio() {
		RequestContext.getCurrentInstance().execute("PF('dlgMessageSucesso').show()");
	}
	
	private void gerarLogErroAoRecuperarSenha(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, userAuth.getAuthKey());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, sessionId,
					createBasicLogMap());
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}
	
	private void exibirDialogMensagem() {
		RequestContext.getCurrentInstance().execute("PF('dlgMessage').show()");
	}
	
	public Map createBasicLogMap() {
		Long idTotem = null;
		Long idUnidade = null;
		if (informacoesTotem != null && !informacoesTotem.isEmpty()) {
			idTotem = informacoesTotem.get(0).getId();
			idUnidade = Long.valueOf(informacoesTotem.get(0).getIdUnidade());
		}
		try {
			return TotemUtil.createBasicLogMap(idTotem, idUnidade, Util.getClientIpAddr(getHttpServletRequest()));
		} catch (Exception e) {
			e.printStackTrace();
			return new HashMap();
		}
	}
	
	@SuppressWarnings("unchecked")
	private void buscarInformacoesTotem() {
		try {
			informacoesTotem = (List<InformacaoTotem>) getSession().getAttribute("informacoesTotem");
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	private void buscarToken() {
		try {
			tokenResult = (TokenResult) getSession().getAttribute("tokenResult");
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}
	
	private void buscarInformacaoTotem() throws RegraNegocioException {
		for (final InformacaoTotem localInformacaoTotem : informacoesTotem) {
			if (localInformacaoTotem.getIp().equalsIgnoreCase(retornarNomeDaMaquina())) {
				informacaoTotem = localInformacaoTotem;
			}
		}
	}
	
	private String retornarNomeDaMaquina() throws RegraNegocioException {
		try {
			final IndexService indexService = new IndexService();
			return indexService.retornarNomeMaquina(getHttpServletRequest());
		} catch (final Exception exc) {
			exc.printStackTrace();
			// gerarLogAoRetornarNomeDaMaquina(exc.getMessage());
			throw new RegraNegocioException(exc.getMessage());
		}
	}
	
	public String retornarTelaInicial() throws Exception {
		final String nomeMaquina = retornarNomeDaMaquina();
		getSession().removeAttribute("indexBean");
		TotemUtil.limparSession();
		return "/indexTotem.xhtml?faces-redirect=true&nomeTotem=" + nomeMaquina;
	}
	
	private void redirectTelaErro() {
		try {
			FacesContext.getCurrentInstance().getExternalContext().redirect(redirectAtendimentoNaoConcluidoIndex());
		} catch (final IOException exc) {
			exc.printStackTrace();
		}
	}
	
	private String redirectAtendimentoNaoConcluidoIndex() {
		return "/passelivretotem/pages/erro/atendimentoNaoConcluido.xhtml?faces-redirect=true&sessionId=" + sessionId;
	}
	
	private void buscarSessionId() throws Exception {
		sessionId = getSession().getAttribute("sessionId").toString();
	}
	
	public List<InformacaoTotem> getInformacoesTotem() {
		return informacoesTotem;
	}
	public void setInformacoesTotem(List<InformacaoTotem> informacoesTotem) {
		this.informacoesTotem = informacoesTotem;
	}
	public TokenResult getTokenResult() {
		return tokenResult;
	}
	public void setTokenResult(TokenResult tokenResult) {
		this.tokenResult = tokenResult;
	}
	public String getSessionId() {
		return sessionId;
	}
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	public InformacaoTotem getInformacaoTotem() {
		return informacaoTotem;
	}
	public void setInformacaoTotem(InformacaoTotem informacaoTotem) {
		this.informacaoTotem = informacaoTotem;
	}
	public String getMensagemAviso() {
		return mensagemAviso;
	}
	public void setMensagemAviso(String mensagemAviso) {
		this.mensagemAviso = mensagemAviso;
	}

	public UserAuth getUserAuth() {
		return userAuth;
	}

	public void setUserAuth(UserAuth userAuth) {
		this.userAuth = userAuth;
	}

	public String getLocalEnvioCod() {
		return localEnvioCod;
	}

	public void setLocalEnvioCod(String localEnvioCod) {
		this.localEnvioCod = localEnvioCod;
	}

	
}
