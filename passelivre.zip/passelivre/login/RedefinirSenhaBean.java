package br.com.hermespardini.passelivre.login;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;
import org.primefaces.context.RequestContext;

import br.com.hermespardini.corebusiness.model.LogAplicacaoUsuarioFactory;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.login.model.UserAuthVerify;
import br.com.hermespardini.passelivre.model.ClienteUnidadePasseLivre;
import br.com.hermespardini.passelivre.model.InformacaoTotem;
import br.com.hermespardini.passelivre.model.MensagemAviso;
import br.com.hermespardini.passelivre.model.TokenResult;
import br.com.hermespardini.passelivre.model.UserAuth;
import br.com.hermespardini.passelivre.service.IndexService;
import br.com.hermespardini.passelivre.service.SenhaService;
import br.com.hermespardini.passelivre.utils.TotemUtil;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.bean.MainBean;

@ManagedBean
@SessionScoped
public class RedefinirSenhaBean extends MainBean {

	private static final long serialVersionUID = 1L;

	private static final Logger Log = Logger.getLogger(RedefinirSenhaBean.class);

	// Infos básicas para cada tela
	private List<InformacaoTotem> informacoesTotem;
	private TokenResult tokenResult;
	private String sessionId;
	private InformacaoTotem informacaoTotem;

	// Dados exclusivos dessa tela
	private String codVerificacao;
	private String novaSenha;
	private String confNovaSenha;
	private String mensagemAviso;
	private UserAuth userAuth;

	@PostConstruct
	public void onLoad() {
		try {
			buscarInformacoesTotem();
			buscarToken();

			buscarSessionId();
			buscarInformacaoTotem();
		} catch (final Exception exc) {
			exc.printStackTrace();
			MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso(exc.getMessage());
			try {
				getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
			} catch (Exception e) {
				e.printStackTrace();
			}
			redirectTelaErro();
		}
	}
	
	public void onPageLoad() {
		try {
			receberUserAuth();
		} catch (final Exception exc) {
			exc.printStackTrace();
			MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso(exc.getMessage());
			try {
				getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
			} catch (Exception e) {
				e.printStackTrace();
			}
			redirectTelaErro();
		}
	}

	public void redefinirSenha() {
		String mensagemRetorno = "";
		try {
			ValidacaoSenha.validaSenhasDigitadas(novaSenha, confNovaSenha);
		
			
			final UserAuthVerify locUser = new UserAuthVerify(this.userAuth, codVerificacao, novaSenha);
		
			final SenhaService loSenhaService = new SenhaService(getHttpServletRequest());
			
			loSenhaService.redefinirSenha(locUser);

			if (loSenhaService.isSuccess()) {
				getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN,
						locUser.getAuthKey());
				registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId,
						createBasicLogMap());
			} else {
				throw new RegraNegocioException(loSenhaService.getResponseMessage());
			}
			mensagemRetorno = loSenhaService.getResponseMessage();
		} catch (RegraNegocioException e) {
			// TODO: handle exception
			exibirDlgMessage(e.getMessage());
		} catch (Exception e) {
			// TODO: handle exception
			exibirDlgMessage(e.getMessage());
		}
		if(mensagemRetorno != null && !mensagemRetorno.equals(""))
			exibirDlgSucesso(mensagemRetorno);
	}

	private void exibirDlgMessage(String textoMensagem) {
		this.mensagemAviso = textoMensagem;
		RequestContext.getCurrentInstance().execute("PF('dlgMessage').show()");
	}
	
	private void exibirDlgSucesso(String textoMensagem) {
		this.mensagemAviso = textoMensagem;
		RequestContext.getCurrentInstance().execute("PF('dlgMessageSucesso').show()");
	}

	@SuppressWarnings("unchecked")
	private void buscarInformacoesTotem() {
		try {
			informacoesTotem = (List<InformacaoTotem>) getSession().getAttribute("informacoesTotem");
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	private void buscarToken() {
		try {
			tokenResult = (TokenResult) getSession().getAttribute("tokenResult");
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	private void buscarSessionId() throws Exception {
		sessionId = getHttpServletRequest().getSession().getAttribute("sessionId").toString();
	}
	
	private void receberUserAuth() {
		try {
			this.userAuth = (UserAuth) getHttpServletRequest().getSession()
					.getAttribute("userAuth");
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	private void buscarInformacaoTotem() throws RegraNegocioException {
		for (final InformacaoTotem localInformacaoTotem : informacoesTotem) {
			if (localInformacaoTotem.getIp().equalsIgnoreCase(retornarNomeDaMaquina())) {
				informacaoTotem = localInformacaoTotem;
			}
		}
	}

	private String retornarNomeDaMaquina() throws RegraNegocioException {
		try {
			final IndexService indexService = new IndexService();
			return indexService.retornarNomeMaquina(getHttpServletRequest());
		} catch (final Exception exc) {
			exc.printStackTrace();
			// gerarLogAoRetornarNomeDaMaquina(exc.getMessage());
			throw new RegraNegocioException(exc.getMessage());
		}
	}

	private Map createBasicLogMap() {
		Long idTotem = null;
		Long idUnidade = null;
		if (informacoesTotem != null && !informacoesTotem.isEmpty()) {
			idTotem = informacoesTotem.get(0).getId();
			idUnidade = Long.valueOf(informacoesTotem.get(0).getIdUnidade());
		}
		try {
			return TotemUtil.createBasicLogMap(idTotem, idUnidade, Util.getClientIpAddr(getHttpServletRequest()));
		} catch (Exception e) {
			e.printStackTrace();
			return new HashMap();
		}
	}

	public String retornarTelaInicial() throws Exception {
		final String nomeMaquina = retornarNomeDaMaquina();
		getSession().removeAttribute("indexBean");
		TotemUtil.limparSession();
		return "/indexTotem.xhtml?faces-redirect=true&nomeTotem=" + nomeMaquina;
	}

	private void redirectTelaErro() {
		try {
			FacesContext.getCurrentInstance().getExternalContext().redirect(redirectAtendimentoNaoConcluidoIndex());
		} catch (final IOException exc) {
			exc.printStackTrace();
		}
	}

	private String redirectAtendimentoNaoConcluidoIndex() {
		return "/passelivretotem/pages/erro/atendimentoNaoConcluido.xhtml?faces-redirect=true&sessionId=" + sessionId;
	}

	public String getCodVerificacao() {
		return codVerificacao;
	}

	public void setCodVerificacao(String codVerificacao) {
		this.codVerificacao = codVerificacao;
	}

	public String getNovaSenha() {
		return novaSenha;
	}

	public void setNovaSenha(String novaSenha) {
		this.novaSenha = novaSenha;
	}

	public String getConfNovaSenha() {
		return confNovaSenha;
	}

	public void setConfNovaSenha(String confNovaSenha) {
		this.confNovaSenha = confNovaSenha;
	}

	public List<InformacaoTotem> getInformacoesTotem() {
		return informacoesTotem;
	}

	public void setInformacoesTotem(List<InformacaoTotem> informacoesTotem) {
		this.informacoesTotem = informacoesTotem;
	}

	public TokenResult getTokenResult() {
		return tokenResult;
	}

	public void setTokenResult(TokenResult tokenResult) {
		this.tokenResult = tokenResult;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public InformacaoTotem getInformacaoTotem() {
		return informacaoTotem;
	}

	public void setInformacaoTotem(InformacaoTotem informacaoTotem) {
		this.informacaoTotem = informacaoTotem;
	}

	public String getMensagemAviso() {
		return mensagemAviso;
	}

	public void setMensagemAviso(String mensagemAviso) {
		this.mensagemAviso = mensagemAviso;
	}

	public UserAuth getUserAuth() {
		return userAuth;
	}

	public void setUserAuth(UserAuth userAuth) {
		this.userAuth = userAuth;
	}

}
