package br.com.hermespardini.passelivre.login;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;
import org.primefaces.context.RequestContext;

import br.com.hermespardini.corebusiness.model.LogAplicacaoUsuarioFactory;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.model.ClienteUnidadePasseLivre;
import br.com.hermespardini.passelivre.model.InformacaoTotem;
import br.com.hermespardini.passelivre.model.MensagemAviso;
import br.com.hermespardini.passelivre.model.TokenResult;
import br.com.hermespardini.passelivre.service.IndexService;
import br.com.hermespardini.passelivre.service.SenhaService;
import br.com.hermespardini.passelivre.utils.MensagemUtil;
import br.com.hermespardini.passelivre.utils.TotemUtil;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.bean.MainBean;

@ManagedBean
@SessionScoped
public class SenhaDefinitivaBean extends MainBean {

	private static final long serialVersionUID = 1L;

	private static final Logger Log = Logger.getLogger(SenhaDefinitivaBean.class);

	//Infos básicas para cada tela
	private List<InformacaoTotem> informacoesTotem;
	private TokenResult tokenResult;
	private String sessionId;
	private InformacaoTotem informacaoTotem;
	private ClienteUnidadePasseLivre clienteUnidadePasseLivre;

	//Dados exclusivos dessa tela
	private String senhaAntiga;
	private String senha;
	private String confSenha;
	private String mensagemAviso;

	public void init() {
		// this.clienteUnidadePasseLivre = clienteUnidadePasseLivre;
		receberClientePasseLivre();
	}

	@PostConstruct
	public void onLoad() {
		try {
			clienteUnidadePasseLivre = new ClienteUnidadePasseLivre();
			buscarInformacoesTotem();
			buscarToken();
			receberClientePasseLivre();

			buscarSessionId();
			buscarInformacaoTotem();
		} catch (final Exception exc) {
			exc.printStackTrace();
			MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso(exc.getMessage());
			try {
				getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
			} catch (Exception e) {
				e.printStackTrace();
			}
			redirectTelaErro();
		}
	}

	public String criarSenha() {
		String mensagemRetorno = "";
		String cpf = "";
		try {

			ValidacaoSenha.validaSenhasDigitadas(senha, confSenha);
			cpf = clienteUnidadePasseLivre.getCpf();

			final ClienteUnidadePasseLivre locClienteUnidadePasseLivre = new ClienteUnidadePasseLivre(senha,
					clienteUnidadePasseLivre);
			final SenhaService loSenhaService = new SenhaService(getHttpServletRequest());
			loSenhaService.setValueObject(locClienteUnidadePasseLivre);
			loSenhaService.atualizarSenha();

			if (loSenhaService.isSuccess()) {
				getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN,
						clienteUnidadePasseLivre.getCpf());
				registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId,
						createBasicLogMap());
			} else {
				throw new RegraNegocioException(loSenhaService.getResponseMessage());
			}
			mensagemRetorno = loSenhaService.getResponseMessage();

		} catch (RegraNegocioException e) {
			// TODO: handle exception
			exibirMensagemValidacao(e.getMessage());
			return null;
		} catch (Exception e) {
			// TODO: handle exception
			String texto = String.format("Erro ao criar senha definitiva ao usuario %s",
					cpf);
			Log.error(texto, e);
			return null;
		}
		exibirDialogSucesso(mensagemRetorno);
		return "";
	}

	public String retornarTelaInicial() throws Exception {
		final String nomeMaquina = retornarNomeDaMaquina();
		getSession().removeAttribute("indexBean");
		TotemUtil.limparSession();
		return "/indexTotem.xhtml?faces-redirect=true&nomeTotem=" + nomeMaquina;
	}

	private void exibirDialogSucesso(String textoSucesso) {
		this.mensagemAviso = textoSucesso;
		RequestContext.getCurrentInstance().execute("PF('dlgMessageSucesso').show()");
	}

	public void exibirMensagemValidacao(String textoValidacao) {
		this.mensagemAviso = textoValidacao;
		RequestContext.getCurrentInstance().execute("PF('dlgMessage').show()");
	}

	@SuppressWarnings("unchecked")
	private void buscarInformacoesTotem() {
		try {
			informacoesTotem = (List<InformacaoTotem>) getSession().getAttribute("informacoesTotem");
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	private void buscarToken() {
		try {
			tokenResult = (TokenResult) getSession().getAttribute("tokenResult");
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	private void buscarSessionId() throws Exception {
		sessionId = getHttpServletRequest().getSession().getAttribute("sessionId").toString();
	}

	private void buscarInformacaoTotem() throws RegraNegocioException {
		for (final InformacaoTotem localInformacaoTotem : informacoesTotem) {
			if (localInformacaoTotem.getIp().equalsIgnoreCase(retornarNomeDaMaquina())) {
				informacaoTotem = localInformacaoTotem;
			}
		}
	}

	private String retornarNomeDaMaquina() throws RegraNegocioException {
		try {
			final IndexService indexService = new IndexService();
			return indexService.retornarNomeMaquina(getHttpServletRequest());
		} catch (final Exception exc) {
			exc.printStackTrace();
			// gerarLogAoRetornarNomeDaMaquina(exc.getMessage());
			throw new RegraNegocioException(exc.getMessage());
		}
	}

	private Map createBasicLogMap() {
		Long idTotem = null;
		Long idUnidade = null;
		if (informacoesTotem != null && !informacoesTotem.isEmpty()) {
			idTotem = informacoesTotem.get(0).getId();
			idUnidade = Long.valueOf(informacoesTotem.get(0).getIdUnidade());
		}
		try {
			return TotemUtil.createBasicLogMap(idTotem, idUnidade, Util.getClientIpAddr(getHttpServletRequest()));
		} catch (Exception e) {
			e.printStackTrace();
			return new HashMap();
		}
	}

	private void receberClientePasseLivre() {
		try {
			this.clienteUnidadePasseLivre = (ClienteUnidadePasseLivre) getHttpServletRequest().getSession()
					.getAttribute("clienteUnidadePasseLivre");
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	private void redirectTelaErro() {
		try {
			FacesContext.getCurrentInstance().getExternalContext().redirect(redirectAtendimentoNaoConcluidoIndex());
		} catch (final IOException exc) {
			exc.printStackTrace();
		}
	}

	private String redirectAtendimentoNaoConcluidoIndex() {
		return "/passelivretotem/pages/erro/atendimentoNaoConcluido.xhtml?faces-redirect=true&sessionId=" + sessionId;
	}

	public String mensagemCabecalho(String linha) {
		if (this.clienteUnidadePasseLivre == null)
			receberClientePasseLivre();
		try {
			return MensagemUtil.retornarMensagemCabelho(clienteUnidadePasseLivre, "", linha);
		} catch (final Exception locExc) {
			return "";
		}
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public String getConfSenha() {
		return confSenha;
	}

	public void setConfSenha(String confSenha) {
		this.confSenha = confSenha;
	}

	public String getMensagemAviso() {
		return mensagemAviso;
	}

	public void setMensagemAviso(String mensagemAviso) {
		this.mensagemAviso = mensagemAviso;
	}

	public ClienteUnidadePasseLivre getClienteUnidadePasseLivre() {
		return clienteUnidadePasseLivre;
	}

	public void setClienteUnidadePasseLivre(ClienteUnidadePasseLivre clienteUnidadePasseLivre) {
		this.clienteUnidadePasseLivre = clienteUnidadePasseLivre;
	}

	public List<InformacaoTotem> getInformacoesTotem() {
		return informacoesTotem;
	}

	public void setInformacoesTotem(List<InformacaoTotem> informacoesTotem) {
		this.informacoesTotem = informacoesTotem;
	}

	public TokenResult getTokenResult() {
		return tokenResult;
	}

	public void setTokenResult(TokenResult tokenResult) {
		this.tokenResult = tokenResult;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public InformacaoTotem getInformacaoTotem() {
		return informacaoTotem;
	}

	public void setInformacaoTotem(InformacaoTotem informacaoTotem) {
		this.informacaoTotem = informacaoTotem;
	}

	public String getSenhaAntiga() {
		return senhaAntiga;
	}

	public void setSenhaAntiga(String senhaAntiga) {
		this.senhaAntiga = senhaAntiga;
	}

}
