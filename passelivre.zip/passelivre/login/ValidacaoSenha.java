package br.com.hermespardini.passelivre.login;

import org.primefaces.context.RequestContext;

import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.model.ClienteUnidadePasseLivre;

public class ValidacaoSenha {
	
	public void validaSeSenhaTemporaria(ClienteUnidadePasseLivre clienteUnidadePasseLivre) throws RegraNegocioException {
		if (clienteUnidadePasseLivre.isSenhaTemporaria()) {
			throw new RegraNegocioException("Usuário possui senha temporária, favor criar senha definitiva");
		}
	}
	
	public static void validaSenhasDigitadas(String senha1, String senha2) throws RegraNegocioException {
		if (senha1 != null && !senha1.isEmpty() && !senha1.equals(senha2))
			throw new RegraNegocioException("As senhas digitadas estão divergentes!");
		else if (senha1 == null || senha2 == null)
			throw new RegraNegocioException("O campo de senhas deve ser preenchido!");
		else if (senha1.isEmpty() || senha2.isEmpty())
			throw new RegraNegocioException("O campo de senhas deve ser preenchido!");
		else if (senha1.length() < 8 || senha1.length() > 12)
			throw new RegraNegocioException("A nova senha deve ter entre 8 e 12 caracteres.");
		else if(!isPadraoSenhaSegura(senha1))
			throw new RegraNegocioException("A nova senha deve conter pelo menos uma letra maiúscula, uma letra minúscula e um número");
	}
	
	public static void chamaTelaSenhaDefinitiva() {
		RequestContext.getCurrentInstance().execute("PF('dlgSenhaDefinitiva').show();");	
	}
	
	public static boolean isPadraoSenhaSegura(String password) {
		//deve conter pelo menos uma letra maiúscula, uma letra minúscula e pelo menos um número
		boolean temNumero = false;
	    boolean temLetraMaiuscula = false;
	    boolean temLetraMinuscula = false;
	    for (char i : password.toCharArray()) {
	         if (i >= '0' && i <= '9') {
	             temNumero = true;
	         } else if (i >= 'A' && i <= 'Z') {
	             temLetraMaiuscula = true;
	         } else if (i >= 'a' && i <= 'z') {
	             temLetraMinuscula = true;
	         } 
	    }
	    return temNumero && temLetraMaiuscula && temLetraMinuscula;
	}
}
