package br.com.hermespardini.passelivre.interfaces;

import java.util.List;

import br.com.hermespardini.passelivre.model.ExcecaoAtendimentoResult;
import br.com.hermespardini.passelivre.model.GuiaAutorizadaExcecao;
import br.com.unimedbh.www.Ct_dadosAutorizacao;

public interface RegraExcecaoParaGuia {

	public List<Ct_dadosAutorizacao> retornarGuiasFiltradas(List<Ct_dadosAutorizacao> guias,
			ExcecaoAtendimentoResult excecao);

	public List<GuiaAutorizadaExcecao> retornarGuiasExcecao(List<Ct_dadosAutorizacao> guias,
			ExcecaoAtendimentoResult excecao);
}
