package br.com.hermespardini.passelivre.interfaces;

public interface AcaoTela {
	public String redirectAposLogin();

	public String redirectAposAtualizar();
}
