package br.com.hermespardini.passelivre.interfaces;

import java.util.List;

import br.com.hermespardini.passelivre.model.ExameHermesPardini;
import br.com.hermespardini.passelivre.model.ExcecaoAtendimentoResult;

public interface RegraExcecaoParaExame {

	public List<ExameHermesPardini> retornarExamesFiltrados(List<ExameHermesPardini> parExames,
			ExcecaoAtendimentoResult parExcecaoAtendimentoResult);

	public List<ExameHermesPardini> retornarExamesExcecao(List<ExameHermesPardini> parExames,
			ExcecaoAtendimentoResult parExcecaoAtendimentoResult);
}
