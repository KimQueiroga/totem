package br.com.hermespardini.passelivre.interfaces;

public interface Log {

	public String observacao(String informacaoComplementar);

	public String observacaoErro(String cpf, String informacaoErro);

	public String usuarioLogado(String usuarioLogado);

	public String funcionalidade();
}
