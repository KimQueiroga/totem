package br.com.hermespardini.passelivre.interfaces;

public interface FormataCampo {
	public String formatar();
}
