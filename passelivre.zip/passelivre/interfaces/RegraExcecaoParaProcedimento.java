package br.com.hermespardini.passelivre.interfaces;

import java.util.List;

import br.com.hermespardini.passelivre.model.ExcecaoAtendimentoResult;
import br.com.hermespardini.passelivre.to.ProcedimentoComExamesTO;
import br.com.hermespardini.passelivre.to.ProcedimentoComExamesTOExcecao;

public interface RegraExcecaoParaProcedimento {

	public List<ProcedimentoComExamesTO> retornarProcedimentosFiltradas(
			List<ProcedimentoComExamesTO> procedimentosComExamesTO, ExcecaoAtendimentoResult excecao);

	public List<ProcedimentoComExamesTOExcecao> retornarProcedimentosFiltradasExcecao(
			List<ProcedimentoComExamesTO> procedimentosComExamesTO, ExcecaoAtendimentoResult excecao);
}
