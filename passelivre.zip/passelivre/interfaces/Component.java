package br.com.hermespardini.passelivre.interfaces;

import javax.faces.component.UIComponent;

public interface Component {

	public UIComponent createForUnimed();

	public UIComponent createForUnimedGuiche();

	public UIComponent createForQuestionario();

	public UIComponent createForMaterialPendente();

}
