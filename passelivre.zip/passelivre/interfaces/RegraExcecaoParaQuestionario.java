package br.com.hermespardini.passelivre.interfaces;

import java.util.List;
import java.util.Map;

import br.com.hermespardini.passelivre.to.PerguntaComExameTO;

public interface RegraExcecaoParaQuestionario {

	public Map<String, List<PerguntaComExameTO>> retornarQuestionarioFiltrados(
			final Map<String, List<PerguntaComExameTO>> parTodasPerguntasAgrupadas);

}
