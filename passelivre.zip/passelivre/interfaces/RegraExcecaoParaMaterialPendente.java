package br.com.hermespardini.passelivre.interfaces;

import java.util.List;

import br.com.hermespardini.passelivre.model.ExameMaterialPendente;
import br.com.hermespardini.passelivre.model.ExcecaoAtendimentoResult;

public interface RegraExcecaoParaMaterialPendente {

	public List<ExameMaterialPendente> retornarMaterialPendenteFiltrados(List<ExameMaterialPendente> materiaisPendentes,
			ExcecaoAtendimentoResult parExcecao);

	public List<ExameMaterialPendente> retornarMaterialPendenteExcecao(List<ExameMaterialPendente> materiaisPendentes,
			ExcecaoAtendimentoResult parExcecao);
}
