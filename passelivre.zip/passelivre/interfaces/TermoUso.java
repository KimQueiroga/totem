package br.com.hermespardini.passelivre.interfaces;

public interface TermoUso {

	public String aceitar();

	public String descricaoTermoUso();

}
