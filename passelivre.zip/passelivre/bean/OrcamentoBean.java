package br.com.hermespardini.passelivre.bean;

import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.IOUtils;
import org.primefaces.context.RequestContext;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.constantsenum.FuncaoLogEstatistico;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.exception.RegraParaExameJaAdicionadoException;
import br.com.hermespardini.passelivre.model.ConfiguracaoImpressoraResult;
import br.com.hermespardini.passelivre.model.ControleEstatistico;
import br.com.hermespardini.passelivre.model.DetalhePreparacao;
import br.com.hermespardini.passelivre.model.InformacaoTotem;
import br.com.hermespardini.passelivre.model.MensagemAviso;
import br.com.hermespardini.passelivre.model.ParametroInformacaoImpressora;
import br.com.hermespardini.passelivre.model.ParametroOrcamento;
import br.com.hermespardini.passelivre.model.ParametroPreparacao;
import br.com.hermespardini.passelivre.model.Preparacao;
import br.com.hermespardini.passelivre.model.TokenResult;
import br.com.hermespardini.passelivre.service.ConfiguracaoImpressoraService;
import br.com.hermespardini.passelivre.service.ControleEstatisticoService;
import br.com.hermespardini.passelivre.service.DetalhePreparacaoService;
import br.com.hermespardini.passelivre.service.OrcamentoService;
import br.com.hermespardini.passelivre.service.PreparacaoExameService;
import br.com.hermespardini.passelivre.utils.ArquivoUtil;
import br.com.hermespardini.passelivre.utils.TotemUtil;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.bean.MainBean;

@ManagedBean
@SessionScoped
public class OrcamentoBean extends MainBean {

	private String valorTotal;
	private String mensagemAviso;
	private TokenResult tokenResult;
	private List<Preparacao> preparacoes;
	private Preparacao preparacaoSelecionada;
	private Integer quantidadeItensNoCarrinho;
	private DetalhePreparacao detalhePreparacao;
	private List<InformacaoTotem> informacoesTotem;
	private ParametroPreparacao parametroPreparacao;
	private List<DetalhePreparacao> detalhesPreparacoes;

	@PostConstruct
	public void onLoad() {
		try {
			quantidadeItensNoCarrinho = 0;
			valorTotal = "0,00";
			preparacoes = new ArrayList<>();
			detalhePreparacao = new DetalhePreparacao();
			parametroPreparacao = new ParametroPreparacao();
			informacoesTotem = new ArrayList<>();
			detalhesPreparacoes = new ArrayList<>();
			buscarInformacoesTotem();
			buscarToken();
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso(locExc.getMessage());
			try {
				getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
			} catch (Exception e) {
				e.printStackTrace();
			}
			redirectTelaErro();
		}
	}

	private void buscarToken() {
		try {
			final HttpSession session = getHttpServletRequest().getSession();
			tokenResult = (TokenResult) session.getAttribute("tokenResult");
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	private void buscarInformacoesTotem() {
		try {
			informacoesTotem = new ArrayList<>();
			final HttpSession session = getHttpServletRequest().getSession();
			informacoesTotem = (List<InformacaoTotem>) session.getAttribute("informacoesTotem");
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	public void buscarPreparacoes() {
		try {
			verificarSeCampoEstaVazio();
			final PreparacaoExameService preparacaoExameService = new PreparacaoExameService(getHttpServletRequest());
			preparacaoExameService.consultar(parametroPreparacao, tokenResult.getToken());
			preparacoes.clear();
			if (preparacaoExameService.isSuccess()) {
				preparacoes.addAll((Collection<? extends Preparacao>) preparacaoExameService.getResponseObject());
			} else {
				gerarLogAoBuscarPreparacoes(preparacaoExameService.getResponseMessage());
			}
		} catch (final RegraNegocioException locExc) {
			locExc.printStackTrace();
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
			gerarLogAoBuscarPreparacoes(locExc.getMessage());
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
			gerarLogAoBuscarPreparacoes(locExc.getMessage());
		}
	}

	private void gerarLogEstatisticoImprimirOcamento() throws Exception {
		final ControleEstatisticoService controleEstatisticoService = new ControleEstatisticoService(
				getHttpServletRequest());
		final ControleEstatistico controleEstatistico = new ControleEstatistico(Constantes.CLIENTE_PADRAO, null,
				FuncaoLogEstatistico.IMPRIMIR_ORCAMENTO.toString(), informacoesTotem.get(0).getId(), null, null,
				informacoesTotem.get(0).getIdUnidade());
		controleEstatisticoService.insert(controleEstatistico);
	}

	private void verificarSeCampoEstaVazio() throws RegraNegocioException {
		if (parametroPreparacao.getQ().isEmpty()) {
			throw new RegraNegocioException("Campo de busca é obrigatório!");
		}
	}

	private void gerarLogAoBuscarPreparacoes(final String parMessage) {
		try {
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, null, createBasicLogMap());
		} catch (final Exception locExc) {
		}
	}

	private void exibirDialogMensagem() {
		RequestContext.getCurrentInstance().execute("PF('dlgMessage').show()");
	}

	public void buscarDetalhes(final Preparacao parPreparacao) {
		try {
			final DetalhePreparacaoService detalhePreparacaoService = new DetalhePreparacaoService(
					getHttpServletRequest());
			detalhePreparacaoService.consultar(new ParametroPreparacao(parPreparacao));
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, TotemUtil.buscarSessionId(),
					createBasicLogMap());
			if (detalhePreparacaoService.isSuccess()) {
				detalhePreparacao = (DetalhePreparacao) detalhePreparacaoService.getResponseObject();
				gerarLogEstatisticoExibirDetalhes();
			} else {
				gerarLogAoBuscarDetalhePreparacao(detalhePreparacaoService.getResponseMessage());
			}
		} catch (final RegraNegocioException locExc) {
			locExc.printStackTrace();
			gerarLogAoBuscarDetalhePreparacao(locExc.getMessage());
			MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso(locExc.getMessage());
			try {
				getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
			} catch (Exception e) {
				e.printStackTrace();
			}
			redirectTelaErro();
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			gerarLogAoBuscarDetalhePreparacao(locExc.getMessage());
			redirectTelaErro();
		}
	}

	private void gerarLogEstatisticoExibirDetalhes() throws Exception {
		final ControleEstatisticoService controleEstatisticoService = new ControleEstatisticoService(
				getHttpServletRequest());
		final ControleEstatistico controleEstatistico = new ControleEstatistico(Constantes.CLIENTE_PADRAO, null,
				FuncaoLogEstatistico.VISUALIZAR_HELP_EXAME.toString(), informacoesTotem.get(0).getId(), null, null,
				informacoesTotem.get(0).getIdUnidade());
		controleEstatisticoService.insert(controleEstatistico);
	}

	private void verificarSePreparacaoFoiSelecionado() throws RegraNegocioException {
		if (preparacaoSelecionada == null) {
			throw new RegraNegocioException("Um exame deve ser selecionado!");
		}
	}

	private String redirectAtendimentoNaoConcluido() {
		return "/passelivretotem/pages/erro/atendimentoNaoConcluido.xhtml?faces-redirect=true";
	}

	private void redirectTelaErro() {
		try {
			FacesContext.getCurrentInstance().getExternalContext().redirect(redirectAtendimentoNaoConcluidoIndex());
		} catch (final IOException exc) {
			exc.printStackTrace();
		}
	}

	private String redirectAtendimentoNaoConcluidoIndex() {
		return "/passelivretotem/pages/erro/atendimentoNaoConcluido.xhtml?faces-redirect=true";
	}

	private void gerarLogAoBuscarDetalhePreparacao(final String parMessage) {
		try {
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, null, createBasicLogMap());
		} catch (final Exception locExc) {
		}
	}

	public void adicionar() {
		try {
			detalhesPreparacoes.add(detalhePreparacao);
			atualizarQuantidadeDeItens();
			calcularValorTotal();
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, TotemUtil.buscarSessionId(),
					createBasicLogMap());
			fecharDialogConfirmacao();
			mensagemAviso = "Item adicionado com sucesso!";
			exibirDialogMensagem();
			gerarLogEstatisticoAoAdicionarItemAoCarrinho();
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			gerarLogAoAdicionarIntensAoCarrinho(locExc.getMessage());
		}
	}

	public void adicionarNoDialogDetalhe() {
		try {
			detalhesPreparacoes.add(detalhePreparacao);
			atualizarQuantidadeDeItens();
			calcularValorTotal();
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, TotemUtil.buscarSessionId(),
					createBasicLogMap());
			fecharDialogConfirmacaoDetalhe();
			fecharDialogDetalhe();
			mensagemAviso = "Item adicionado com sucesso!";
			exibirDialogMensagem();
			gerarLogEstatisticoAoAdicionarItemAoCarrinho();
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			gerarLogAoAdicionarIntensAoCarrinho(locExc.getMessage());
		}
	}

	public void adicionarItemAoCarrinhoNoDialogDetalhe() {
		try {
			detalhePreparacao.verificarCamposEmBrancoAoFazerOrcamento();
			detalhePreparacao.verificarSeExameFoiAdicionado(detalhesPreparacoes);
			adicionarNoDialogDetalhe();
		} catch (final RegraNegocioException locExc) {
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
			gerarLogAoAdicionarIntensAoCarrinho(locExc.getMessage() + detalhePreparacao);
		} catch (final RegraParaExameJaAdicionadoException locExc) {
			exibirDialogConfirmacaoDetalhe();
			gerarLogAoAdicionarIntensAoCarrinho(locExc.getMessage() + detalhePreparacao);
		}
	}

	private void exibirDialogConfirmacaoDetalhe() {
		RequestContext.getCurrentInstance().execute("PF('dlgConfirmacaoDetalhe').show()");
	}

	private void fecharDialogConfirmacaoDetalhe() {
		RequestContext.getCurrentInstance().execute("PF('dlgConfirmacaoDetalhe').hide();");
	}

	private void fecharDialogConfirmacao() {
		RequestContext.getCurrentInstance().execute("PF('dlgConfirmacao').hide();");
	}

	private void exibirDialogConfirmacao() {
		RequestContext.getCurrentInstance().execute("PF('dlgConfirmacao').show()");
	}

	public void adicionarItemAoCarrinho(final Preparacao preparacao) {
		try {
			buscarDetalhes(preparacao);
			detalhePreparacao.verificarCamposEmBrancoAoFazerOrcamento();
			detalhePreparacao.verificarSeExameFoiAdicionado(detalhesPreparacoes);
			adicionar();
		} catch (final RegraNegocioException locExc) {
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
			gerarLogAoAdicionarIntensAoCarrinho(locExc.getMessage() + preparacao);
		} catch (final RegraParaExameJaAdicionadoException locExc) {
			exibirDialogConfirmacao();
			gerarLogAoAdicionarIntensAoCarrinho(locExc.getMessage() + detalhePreparacao);
		}
	}

	private void gerarLogEstatisticoAoAdicionarItemAoCarrinho() throws Exception {
		final ControleEstatisticoService controleEstatisticoService = new ControleEstatisticoService(
				getHttpServletRequest());
		final ControleEstatistico controleEstatistico = new ControleEstatistico(Constantes.CLIENTE_PADRAO, null,
				FuncaoLogEstatistico.INCLUSAO_EXAME_ORCAMENTO.toString(), informacoesTotem.get(0).getId(), null, null,
				informacoesTotem.get(0).getIdUnidade());
		controleEstatisticoService.insert(controleEstatistico);
	}

	private void gerarLogAoAdicionarIntensAoCarrinho(final String parMessage) {
		try {
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, null, createBasicLogMap());
		} catch (final Exception locExc) {
		}
	}

	public void removerItemDoCarrinho(final DetalhePreparacao paramDetalhePreparacao) {
		try {
			if (!detalhesPreparacoes.isEmpty()) {
				detalhesPreparacoes.remove(paramDetalhePreparacao);
				atualizarQuantidadeDeItens();
				calcularValorTotal();
				registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(), null, TotemUtil.buscarSessionId(),
						createBasicLogMap());
			} else {
				mensagemAviso = "Não há item a ser removido!";
				exibirDialogMensagem();
			}
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			gerarLogAoRemoverIntensAoCarrinho(locExc.getMessage());
		}
	}

	private void calcularValorTotal() {
		try {
			Double valor = 0.0;
			for (final DetalhePreparacao locDetalhePreparacao : detalhesPreparacoes) {
				valor = valor + Util.retornarApenasNumero(locDetalhePreparacao.getPrivatePrice());
			}
			final DecimalFormat formato = (DecimalFormat) NumberFormat.getInstance(new Locale("pt", "BR"));
			formato.applyLocalizedPattern("###.##0,00");
			valorTotal = formato.format(valor);
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	private void atualizarQuantidadeDeItens() {
		quantidadeItensNoCarrinho = detalhesPreparacoes.size();
	}

	private void gerarLogAoRemoverIntensAoCarrinho(final String parMessage) {
		try {
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, null, createBasicLogMap());
		} catch (final Exception locExc) {
		}
	}

	private String redirectDetalhePreparacao() {
		return "/pages/ocm/detalhePreparacao.xhtml?faces-redirect=true";
	}

	public String voltarParaPreparacao() {
		parametroPreparacao = new ParametroPreparacao();
		preparacoes.clear();
		return redirectPreparacao();
	}

	public String irParaItensAdicionados() {
		return redirectItensAdicionados();
	}

	public String cancelarPreparacao() {
		try {
			return redirectIndex();
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return "";
		}
	}

	public String redirectIndex() throws Exception {
		final String nomeMaquina = TotemUtil.retornarNomeDaMaquina();
		getSession().removeAttribute("indexBean");
		TotemUtil.limparSession();
		return "/indexTotem.xhtml?faces-redirect=true&nomeTotem=" + nomeMaquina;
	}

	private String redirectItensAdicionados() {
		return "/pages/ocm/itensAdicionados.xhtml?faces-redirect=true";
	}

	private String redirectPreparacao() {
		return "/pages/ocm/preparacao.xhtml?faces-redirect=true";
	}

	public void finalizar() {
		try {
			imprimir();
			esperarParaExibirMensagemImpressao();
			RequestContext.getCurrentInstance().execute("PF('dlgInformacaoImpressao').show()");
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			mensagemAviso = "Erro ao gerar orçamento!";
			exibirDialogMensagem();
			gerarLogAoImprimirRelatorio(locExc.getMessage());
		}
	}

	private void esperarParaExibirMensagemImpressao() throws InterruptedException {
		Thread.sleep(Constantes.TEMPO_ESPERA_IMPRESSAO_PADRAO);
	}

	private void gerarLogAoImprimirRelatorio(final String parMessage) {
		try {
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, null, createBasicLogMap());
		} catch (final Exception locExc) {
		}
	}

	private ConfiguracaoImpressoraResult retornarConfiguracoesImpressora() throws Exception {
		final ParametroInformacaoImpressora parametroInformacaoImpressora = new ParametroInformacaoImpressora(
				informacoesTotem.get(0), tokenResult);
		ConfiguracaoImpressoraResult configuracaoImpressoraResult = new ConfiguracaoImpressoraResult();
		final ConfiguracaoImpressoraService configuracaoImpressoraService = new ConfiguracaoImpressoraService(
				getHttpServletRequest());
		configuracaoImpressoraService.retornarInformacoes(parametroInformacaoImpressora);
		if (configuracaoImpressoraService.isSuccess()) {
			configuracaoImpressoraResult = (ConfiguracaoImpressoraResult) configuracaoImpressoraService
					.getResponseObject();
			return configuracaoImpressoraResult;
		} else {
			return new ConfiguracaoImpressoraResult();
		}
	}

	private void imprimir() throws RegraNegocioException {
		final ArquivoUtil arquivoUtil = new ArquivoUtil();
		try {
			final ConfiguracaoImpressoraResult configuracaoImpressoraResult = retornarConfiguracoesImpressora();
			final Date dataAtual = new Date();
			final byte[] bytes = IOUtils.toByteArray(gerarRelatorio());
			arquivoUtil.salvarDiretorioLocal(bytes, retornarDadosRelatorio(dataAtual) + ".pdf");
			arquivoUtil.fazerImpressao(retornarDadosRelatorio(dataAtual) + ".pdf",
					configuracaoImpressoraResult.getIp());
			gerarLogEstatisticoImprimirOcamento();
		} catch (final Exception exc) {
			exc.printStackTrace();
			throw new RegraNegocioException(exc.getMessage());
		}
	}

	private String retornarDadosRelatorio(final Date parDataAtual) {
		final SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		final String nomeRelatorio = df.format(parDataAtual);
		final StringBuilder sb = new StringBuilder();
		sb.append(nomeRelatorio.replaceAll("-", "").replaceAll(":", "").replaceAll(" ", ""));
		return sb.toString();
	}

	public void fecharDialogDetalhe() {
		try {
			RequestContext.getCurrentInstance().execute("PF('dlgDetalhesExame').hide();");
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	public String fecharMensagemAviso() {
		try {
			RequestContext.getCurrentInstance().execute("PF('dlgInformacaoImpressao').hide()");
			return redirectIndex();
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return null;
		}
	}

	private InputStream gerarRelatorio() throws Exception {
		try {
			final OrcamentoService orcamentoService = new OrcamentoService(getHttpServletRequest());
			final ParametroOrcamento parametroOrcamento = new ParametroOrcamento(informacoesTotem.get(0),
					detalhesPreparacoes, valorTotal, preparacaoSelecionada);
			final String pathArquivoReport = getServletContext().getRealPath("/WEB-INF/relatorio/Orcamento.jasper");
			return orcamentoService.gerarRelatorio(parametroOrcamento, getServletContext(), pathArquivoReport);
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			mensagemAviso = "Erro ao gerar relatório!";
			exibirDialogMensagem();
			return null;
		}
	}

	public Map createBasicLogMap() {
		Long idTotem = null;
		Long idUnidade = null;
		if (informacoesTotem != null && !informacoesTotem.isEmpty()) {
			idTotem = informacoesTotem.get(0).getId();
			idUnidade = Long.valueOf(informacoesTotem.get(0).getIdUnidade());
		}
		try {
			return TotemUtil.createBasicLogMap(idTotem, idUnidade, Util.getClientIpAddr(getHttpServletRequest()));
		} catch (Exception e) {
			e.printStackTrace();
			return new HashMap();
		}
	}

	public String getMensagemAviso() {
		return mensagemAviso;
	}

	public void setMensagemAviso(final String parMensagemAviso) {
		mensagemAviso = parMensagemAviso;
	}

	public List<Preparacao> getPreparacoes() {
		return preparacoes;
	}

	public void setPreparacoes(final List<Preparacao> parPreparacoes) {
		preparacoes = parPreparacoes;
	}

	public Preparacao getPreparacaoSelecionada() {
		return preparacaoSelecionada;
	}

	public void setPreparacaoSelecionada(final Preparacao parPreparacaoSelecionada) {
		preparacaoSelecionada = parPreparacaoSelecionada;
	}

	public DetalhePreparacao getDetalhePreparacao() {
		return detalhePreparacao;
	}

	public void setDetalhePreparacao(final DetalhePreparacao parDetalhePreparacao) {
		detalhePreparacao = parDetalhePreparacao;
	}

	public ParametroPreparacao getParametroPreparacao() {
		return parametroPreparacao;
	}

	public void setParametroPreparacao(final ParametroPreparacao parParametroPreparacao) {
		parametroPreparacao = parParametroPreparacao;
	}

	public Integer getQuantidadeItensNoCarrinho() {
		return quantidadeItensNoCarrinho;
	}

	public void setQuantidadeItensNoCarrinho(final Integer parQuantidadeItensNoCarrinho) {
		quantidadeItensNoCarrinho = parQuantidadeItensNoCarrinho;
	}

	public List<DetalhePreparacao> getDetalhesPreparacoes() {
		return detalhesPreparacoes;
	}

	public void setDetalhesPreparacoes(final List<DetalhePreparacao> parDetalhesPreparacoes) {
		detalhesPreparacoes = parDetalhesPreparacoes;
	}

	public String getValorTotal() {
		return valorTotal;
	}

	public void setValorTotal(final String parValorTotal) {
		valorTotal = parValorTotal;
	}

}
