package br.com.hermespardini.passelivre.bean;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.TreeMap;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.component.EditableValueHolder;
import javax.faces.component.UIComponent;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;
import javax.faces.context.PartialViewContext;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.primefaces.component.dialog.Dialog;
import org.primefaces.component.panel.Panel;
import org.primefaces.component.panelgrid.PanelGrid;
import org.primefaces.component.tabview.TabView;
import org.primefaces.context.RequestContext;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.TabChangeEvent;
import org.primefaces.event.ToggleSelectEvent;
import org.primefaces.event.UnselectEvent;
import org.primefaces.extensions.component.masterdetail.MasterDetail;
import org.primefaces.extensions.component.masterdetail.MasterDetailLevel;

import br.com.hermespardini.corebusiness.model.Cep;
import br.com.hermespardini.corebusiness.model.LogAplicacaoUsuarioFactory;
import br.com.hermespardini.corebusiness.util.SessionIdBuilder;
import br.com.hermespardini.passelivre.components.ComponenteMessageInDialog;
import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.constantsenum.FuncaoLogEstatistico;
import br.com.hermespardini.passelivre.exception.EnvioEmailException;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.exception.SenhaDefinitivaException;
import br.com.hermespardini.passelivre.factory.AplicaExcecaoMaterialPendenteFactory;
import br.com.hermespardini.passelivre.factory.AplicaExcecaoQuestionarioFactory;
import br.com.hermespardini.passelivre.factory.ComponenteFactory;
import br.com.hermespardini.passelivre.format.FormataCep;
import br.com.hermespardini.passelivre.format.FormataCpf;
import br.com.hermespardini.passelivre.format.FormataDataAnoMesDia;
import br.com.hermespardini.passelivre.format.FormataDataDiaMesAno;
import br.com.hermespardini.passelivre.format.FormataEndereco;
import br.com.hermespardini.passelivre.format.FormataTelefone;
import br.com.hermespardini.passelivre.login.ValidacaoSenha;
import br.com.hermespardini.passelivre.model.ClienteUnidadePasseLivre;
import br.com.hermespardini.passelivre.model.ConsultaCepResult;
import br.com.hermespardini.passelivre.model.ConsultaMaterialPendenteResult;
import br.com.hermespardini.passelivre.model.ConsultaQuestionarioExameResult;
import br.com.hermespardini.passelivre.model.ControleEstatistico;
import br.com.hermespardini.passelivre.model.ExameEntrega;
import br.com.hermespardini.passelivre.model.ExameMaterialPendente;
import br.com.hermespardini.passelivre.model.ExamesEntrega;
import br.com.hermespardini.passelivre.model.ExcecaoAtendimentoResult;
import br.com.hermespardini.passelivre.model.InformacaoTotem;
import br.com.hermespardini.passelivre.model.KeyMaterialPedente;
import br.com.hermespardini.passelivre.model.MensagemAviso;
import br.com.hermespardini.passelivre.model.ParametroConsultaCliente;
import br.com.hermespardini.passelivre.model.ParametroEntregaMaterial;
import br.com.hermespardini.passelivre.model.ParametroExcecaoAtendimento;
import br.com.hermespardini.passelivre.model.ParametroMaterialPendente;
import br.com.hermespardini.passelivre.model.ParametroQuestionario;
import br.com.hermespardini.passelivre.model.ParametroRegistraCliente;
import br.com.hermespardini.passelivre.model.PerguntaEntrega;
import br.com.hermespardini.passelivre.model.TokenResult;
import br.com.hermespardini.passelivre.model.UserAuth;
import br.com.hermespardini.passelivre.service.CepService;
import br.com.hermespardini.passelivre.service.ClienteService;
import br.com.hermespardini.passelivre.service.ControleEstatisticoService;
import br.com.hermespardini.passelivre.service.EntregaMaterialPendenteService;
import br.com.hermespardini.passelivre.service.EnviaEmailService;
import br.com.hermespardini.passelivre.service.ExcecaoAtendimentoService;
import br.com.hermespardini.passelivre.service.LoginService;
import br.com.hermespardini.passelivre.service.MaterialPendenteService;
import br.com.hermespardini.passelivre.service.PerguntasService;
import br.com.hermespardini.passelivre.service.QuestionarioService;
import br.com.hermespardini.passelivre.service.SenhaService;
import br.com.hermespardini.passelivre.to.HabilitacaoCamposCadastroTO;
import br.com.hermespardini.passelivre.to.PerguntaComExameTO;
import br.com.hermespardini.passelivre.utils.ControleBotaoUtil;
import br.com.hermespardini.passelivre.utils.DataUtil;
import br.com.hermespardini.passelivre.utils.MensagemUtil;
import br.com.hermespardini.passelivre.utils.TotemUtil;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.bean.MainBean;

@SessionScoped
@SuppressWarnings({ "serial" })
@ManagedBean(name = "entregaMaterialPendenteBean")
public class EntregaMaterialPendenteBean extends MainBean {
	
	private static final Logger Log = Logger.getLogger(EntregaMaterialPendenteBean.class);

	private UserAuth user;
	private boolean active0;
	private boolean active1;
	private boolean loggedIn;
	private String sessionId;
	private DataUtil dataUtil;
	private Integer activeIndex;
	private String mensagemAviso;
	private Panel pnlQuestionario;
	private Dialog messageInDialog;
	private Boolean houveAlteracao;
	private TokenResult tokenResult;
	private String paramForwardPath;
	private Boolean habilitaMarcacao;
	private PanelGrid pngQuestionario;
	private MasterDetail mtdQuestionario;
	private PerguntasService perguntasUtil;
	private FormataTelefone formataTelefone;
	private List<PerguntaEntrega> perguntas;
	private FormataEndereco formataEndereco;
	private MasterDetailLevel mdlQuestionario;
	private ControleBotaoUtil controleBotaoUtil;
	private Map<String, String> mapQuestionarios;
	private List<InformacaoTotem> informacoesTotem;
	private List<MasterDetailLevel> mdlsQuestionario;
	private List<ExameMaterialPendente> todosExamesPendentes;
	private ExcecaoAtendimentoResult excecaoAtendimentoResult;
	private ClienteUnidadePasseLivre clienteUnidadePasseLivre;
	private List<ExameMaterialPendente> ultimosExamesPendentes;
	private List<ExameMaterialPendente> examesPendentesExcecao;
	private HabilitacaoCamposCadastroTO habilitacaoCamposCadastroTO;
	private ConsultaQuestionarioExameResult consultaQuestionarioExameResult;
	private List<ConsultaQuestionarioExameResult> questionariosExamesResult;
	private List<ExameMaterialPendente> listaExameMaterialPendenteSelecionados;
	private Map<String, List<PerguntaComExameTO>> todasPerguntasAgrupadasPorAba;
	private Map<String, List<PerguntaComExameTO>> todasPerguntasAgrupadasEConsolidadas;
	private Map<KeyMaterialPedente, ParametroEntregaMaterial> materiaisAgrupadosPorPedidoUnidade;
	private String inputCodBarras;
	private String cep;
	private String bairro;
	private String numero;
	private String complemento;
	private boolean editarLogradouro;
	private boolean editarBairro;
	private String uf;
	private String cidade;
	private String logradouro;
	private Boolean isBotaoOn;

	@PostConstruct
	public final void onLoad() {
		try {
			setUser(new UserAuth());
			messageInDialog = new Dialog();
			houveAlteracao = false;
			setActiveIndex(new Integer(0));
			mtdQuestionario = new MasterDetail();
			mdlsQuestionario = new ArrayList<>();
			examesPendentesExcecao = new ArrayList<>();
			controleBotaoUtil = new ControleBotaoUtil();
			excecaoAtendimentoResult = new ExcecaoAtendimentoResult();
			clienteUnidadePasseLivre = new ClienteUnidadePasseLivre();
			listaExameMaterialPendenteSelecionados = new ArrayList<>();
			habilitacaoCamposCadastroTO = new HabilitacaoCamposCadastroTO();
			formataEndereco = new FormataEndereco();
			buscarInformacoesTotem();
			buscarToken();
			buscarSessionId();
			isBotaoOn = true;
			if (buscarInputCodBarras()) {
				String telaErro = listarMateriaisPendentesPedido(inputCodBarras);
				if(!Objects.isNull(telaErro) && !telaErro.equals("")) {
					redirectTelaErro(telaErro);	
				}
			} else {
				verificarSeClientePasseLivreExiste();
			}
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso(locExc.getMessage());
			try {
				getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
			} catch (Exception e) {
				e.printStackTrace();
			}
			redirectTelaErro();
		}
	}

	private void buscarSessionId() {
		try {
			sessionId = getSession().getAttribute("sessionId").toString();
		} catch (final Exception locExc) {
		}
	}

	private void buscarToken() {
		try {
			final HttpSession session = getHttpServletRequest().getSession();
			tokenResult = (TokenResult) session.getAttribute("tokenResult");
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	private boolean buscarInputCodBarras() {
		try {
			final HttpSession session = getHttpServletRequest().getSession();
			inputCodBarras = (String) session.getAttribute("inputCodBarras");
			return inputCodBarras != null && !inputCodBarras.isEmpty();
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
		return false;
	}

	@SuppressWarnings("unchecked")
	private void buscarInformacoesTotem() {
		try {
			informacoesTotem = new ArrayList<>();
			final HttpSession session = getHttpServletRequest().getSession();
			informacoesTotem = (List<InformacaoTotem>) session.getAttribute("informacoesTotem");
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	private void gerarQuestionario() throws RegraNegocioException, Exception {
		mtdQuestionario = new MasterDetail();
		mdlQuestionario = new MasterDetailLevel();
		mapQuestionarios = new HashMap<>();
		pngQuestionario = new PanelGrid();
		pngQuestionario.setStyleClass("pngQuestionario");
		pngQuestionario.setColumns(3);
		pngQuestionario.setStyle("height: 250px;");
		pnlQuestionario = new Panel();
		mtdQuestionario.setShowBreadcrumb(false);
		mtdQuestionario.setId("mtdQuestionario");
		buscarQuestionario();
	}

	private void gerarLogErroAoGerarQuestionario(final Exception parExc) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parExc.getMessage(),
					TotemUtil.buscarSessionId(), createBasicLogMap());
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	private void buscarQuestionario() throws RegraNegocioException, Exception {
		final List<ParametroQuestionario> parametrosQuestionario = new ArrayList<>();
		for (final ExameMaterialPendente exameMaterialPendente : listaExameMaterialPendenteSelecionados) {
			parametrosQuestionario
					.add(new ParametroQuestionario(exameMaterialPendente, clienteUnidadePasseLivre, tokenResult));
		}
		fazerBuscaQuestionario(parametrosQuestionario);
	}

	private void exibirMensagemErro(final String mensagem) {
		try {
			final ComponenteMessageInDialog messageInDialogTemp = new ComponenteMessageInDialog();
			messageInDialog = (Dialog) messageInDialogTemp.create(mensagem);
		} catch (final RegraNegocioException exc) {
			exc.printStackTrace();
		}
	}

	public void fazerAtualizacao() {
		houveAlteracao = true;
	}

	private void fazerBuscaQuestionario(final List<ParametroQuestionario> parametrosQuestionario)
			throws RegraNegocioException, Exception {
		final QuestionarioService questionarioService = new QuestionarioService(getHttpServletRequest());
		questionariosExamesResult = new ArrayList<>();
		for (final ParametroQuestionario locParametroQuestionario : parametrosQuestionario) {
			questionarioService.setValueObject(locParametroQuestionario);
			questionarioService.consultar();
			consultaQuestionarioExameResult = (ConsultaQuestionarioExameResult) questionarioService.getResponseObject();
			if (questionarioService.isSuccess()) {
				getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
				registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(), null, TotemUtil.buscarSessionId(),
						createBasicLogMap());
				questionariosExamesResult.add(consultaQuestionarioExameResult);
			} else {
				throw new RegraNegocioException(questionarioService.getResponseMessage());
			}
		}
	}

	private void agruparPerguntasPorAbaEOrdenar() throws Exception {
		perguntasUtil = new PerguntasService();
		todasPerguntasAgrupadasPorAba = new TreeMap<>(perguntasUtil.agruparPerguntasPorAba(questionariosExamesResult));
		// filtrarPerguntasConsolidadas();
	}

	private void filtrarPerguntasConsolidadas() {
		final AplicaExcecaoQuestionarioFactory aplicaExcecaoParaQuestionarioFactory = new AplicaExcecaoQuestionarioFactory();
		todasPerguntasAgrupadasEConsolidadas = new TreeMap<>(
				aplicaExcecaoParaQuestionarioFactory.retornarQuestionariosFiltrados(todasPerguntasAgrupadasPorAba));
	}

	public void alterarSenha() {
		try {
			verificarSeSenhasConferem();
			ValidacaoSenha.validaSenhasDigitadas(user.getNewPass(), user.getConfirmAuthPass());
			final ClienteUnidadePasseLivre locClienteUnidadePasseLivre = new ClienteUnidadePasseLivre(getUser(),
					clienteUnidadePasseLivre);
			final SenhaService loSenhaService = new SenhaService(getHttpServletRequest());
			loSenhaService.setValueObject(locClienteUnidadePasseLivre);
			loSenhaService.atualizarSenha();
			if (loSenhaService.isSuccess()) {
				getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
				registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(), null, TotemUtil.buscarSessionId(),
						createBasicLogMap());
			} else {
				gerarLogErroAoValidarSenha(loSenhaService.getResponseMessage());
			}
			mensagemAviso = loSenhaService.getResponseMessage();
		} catch (final Exception locExc) {
			mensagemAviso = locExc.getMessage();
			gerarLogErroAoValidarSenha(locExc.getMessage());
		} finally {
			fecharDialogResetSenha();
			exibirDialogMensagem();
			resetarCampos();
		}
	}

	private void exibirDialogMensagem() {
		RequestContext.getCurrentInstance().execute("PF('dlgMessage').show()");
	}

	private void verificarSeSenhasConferem() throws Exception {
		if (!user.getNewPass().equals(user.getConfirmAuthPass())) {
			throw new Exception("As senhas não conferem");
		}
	}

	public String aceitarTermo() {
		try {
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, TotemUtil.buscarSessionId(),
					createBasicLogMap());
			return redirectLogin();
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return null;
		}
	}

	public String atualizaDados() {
		try {
			acoesNoClienteAoAtualizar();
			formatarValoresAoAtualizar();
			return retornarAcaoAposVerificarSeDadosForamAtualizados();
		} catch (final RuntimeException locExc) {
			locExc.printStackTrace();
			gerarLogErroAoAtualizar(locExc.getMessage());
			MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso(locExc.getMessage());
			try {
				getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return redirectAtendimentoNaoConcluidoAposAtualizar();
		} catch (final RegraNegocioException locExc) {
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
			locExc.printStackTrace();
			// gerarLogErroAoAtualizar(locExc.getMessage()); //n�o gravar log de valida��o
			// de campos
			return null;
		} catch (final Exception locExc) {
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
			locExc.printStackTrace();
			gerarLogErroAoAtualizar(locExc.getMessage());
			return null;
		}
	}

	private String retornarAcaoAposVerificarSeDadosForamAtualizados() throws RuntimeException, Exception {
		return realizarAtualicacao();
	}

	private String realizarAtualicacao() throws RuntimeException, Exception {
		final ClienteService clienteService = new ClienteService(getHttpServletRequest());
		clienteService.setValueObject(clienteUnidadePasseLivre);
		ParametroRegistraCliente parRegistraCliente = new ParametroRegistraCliente(clienteUnidadePasseLivre);
		clienteService.registrarCliente(parRegistraCliente);
		getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
		registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
				Thread.currentThread().getStackTrace()[1].getMethodName(), null, TotemUtil.buscarSessionId(),
				createBasicLogMap());
		if (clienteService.isSuccess()) {
			gerarLogEstatisticoAoAtualizar();
			return listarTodosMateriaisPendentes();
		} else {
			mensagemAviso = clienteService.getResponseMessage();
			RequestContext.getCurrentInstance().execute("PF('dlgMessage').show()");
			if (mensagemAviso.contains("CPF(") && mensagemAviso.contains("inválido")) {
				clienteUnidadePasseLivre.setCpf(null);
			}
			return "";
		}
	}

	private void formatarValoresAoAtualizar() {
		formataEndereco.convertStreetAndComplement(clienteUnidadePasseLivre);
	}

	private void acoesNoClienteAoAtualizar() throws Exception {
		clienteUnidadePasseLivre.setSenhaUsuario(user.getAuthPass());
		clienteUnidadePasseLivre.setComplemento(clienteUnidadePasseLivre.retirarCaracteriosInvalidosNoComplemento());
		clienteUnidadePasseLivre.setNumero(clienteUnidadePasseLivre.retornarNumeroValido());
		clienteUnidadePasseLivre.verificarCamposEmBrancoAoAtualizar();
		clienteUnidadePasseLivre.validarEmail();
		formatarValores();
	}

	private void gerarLogEstatisticoAoAtualizar() {
		try {
			final ControleEstatisticoService controleEstatisticoService = new ControleEstatisticoService(
					getHttpServletRequest());
			final ControleEstatistico controleEstatistico = new ControleEstatistico(
					clienteUnidadePasseLivre.getCodigoCliente(), null, FuncaoLogEstatistico.ATUALIZAR_DADOS.toString(),
					informacoesTotem.get(0).getId(), null, null, retornarUnidade());
			controleEstatisticoService.insert(controleEstatistico);
		} catch (final Exception locExc) {
			gerarLogErroAoGerarLogEstatistico(locExc.getMessage());
		}
	}

	private String retornarUnidade() throws Exception {
		if (informacoesTotem.isEmpty()) {
			throw new Exception("Informações de totem vazio!");
		} else {
			return informacoesTotem.get(0).getIdUnidade();
		}
	}

	private void gerarLogErroAoAtualizar(final String parMessagem) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN,
					clienteUnidadePasseLivre.getCodigoCliente());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessagem, TotemUtil.buscarSessionId(),
					createBasicLogMap());
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	public String cancelarLogin() {
		try {
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, TotemUtil.buscarSessionId(),
					createBasicLogMap());
			return redirectIndex();
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return "";
		}
	}

	public String cancelarAtualizacao() {
		try {
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, TotemUtil.buscarSessionId(),
					createBasicLogMap());
			return redirectIndex();
		} catch (final Exception exc) {
			exc.printStackTrace();
			return "";
		}
	}

	public void cancelarSolicitacao() {
		try {
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, TotemUtil.buscarSessionId(),
					createBasicLogMap());
			final RequestContext context = RequestContext.getCurrentInstance();
			context.execute("PF('dlgConfirmacao').show();");
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	public void cancelarSessao() {
		try {
			getSession().removeAttribute("indexBean");
			TotemUtil.limparSession();
			FacesContext.getCurrentInstance().getExternalContext().redirect("/passelivretotem/");
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	public String formatarDataNascimento(final String data) {
		try {
			dataUtil = new DataUtil();
			return dataUtil.formatarStringParaStringBR(data);
		} catch (final ParseException exc) {
			return "";
		}
	}

	private void gerarLogErroAoEntrarComCPF(final Exception locExc) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), locExc.getMessage(),
					TotemUtil.buscarSessionId(), createBasicLogMap());
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	private String ipLocal() {
		try {
			return Util.getClientIpAddr(getHttpServletRequest());
		} catch (final Exception exc) {
			exc.printStackTrace();
			return "";
		}
	}

	public String entrarComCPF() {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, TotemUtil.buscarSessionId(),
					createBasicLogMap());
			RequestContext.getCurrentInstance().reset("frmPrincipal:idTabView:cpfClienteTab");
			user.setAuthKeyType(Constantes.CPFAUTHKEYTYPE);
			user.setBirthDate(formatarDataNascimentoParaRecebimento(user.getBirthDate()));
			final LoginService loginService = new LoginService(getHttpServletRequest());
			clienteUnidadePasseLivre = (ClienteUnidadePasseLivre) loginService.logar(user);
			formatarCampos();
			if (loginService.isSuccess()) {
				clienteUnidadePasseLivre.verificarSeSenhaTemporaria();
				return redirectAtualizaDados();
			} else {
				throw new Exception(loginService.getResponseMessage());
			}
		} catch (SenhaDefinitivaException e) {
			poeUsuarioNaSessao(clienteUnidadePasseLivre);
			return redirectSenhaDefinitiva();
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
			limparCampoLogin();
			// gerarLogErroAoEntrarComCPF(locExc);// n�o gerar log de erro de login
			return null;
		}
	}

	public String entregarMaterial() {
		try {
			if (isBotaoOn) {
				isBotaoOn = false;
				preencherQuestionario();
				getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
				registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(), null, TotemUtil.buscarSessionId(),
						createBasicLogMap());
				fazerEntrega();
				getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
				registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(), "Processo finalizado com sucesso!",
						TotemUtil.buscarSessionId(), createBasicLogMap());
				gerarLogEstatistico();
			}
			return redirectAtendimentoConcluido();
		} catch (final EnvioEmailException locExc) {
			locExc.printStackTrace();
			gerarLogEstatistico();
			gerarLogErroAoSolicitarExame(locExc.getMessage());
			return redirectAtendimentoConcluidoSemEmail();
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			gerarLogErroAoSolicitarExame(locExc.getMessage());
			MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso(locExc.getMessage());
			try {
				getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return redirectAtendimentoNaoConcluido();
		}
	}

	public String entrarComCodigo() {
		try {
			final LoginService loginService = new LoginService(getHttpServletRequest());
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, TotemUtil.buscarSessionId(),
					createBasicLogMap());
			user.setAuthKeyType(Constantes.CODEAUTHKEYTYPE);
			RequestContext.getCurrentInstance().reset("frmPrincipal:idTabView:codigoClienteTab");
			clienteUnidadePasseLivre = (ClienteUnidadePasseLivre) loginService.logar(user);
			formatarCampos();
			if (loginService.isSuccess()) {
				clienteUnidadePasseLivre.verificarSeSenhaTemporaria();
				return redirectAtualizaDados();
			} else {
				throw new Exception(loginService.getResponseMessage());
			}
		} catch (SenhaDefinitivaException e) {
			poeUsuarioNaSessao(clienteUnidadePasseLivre);
			return redirectSenhaDefinitiva();
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
			// gerarLogErroAoEntrarComCodigo(locExc); //n�o gerar log para erro de login
			limparCampoLogin();
			return null;
		}
	}
	
	private void poeUsuarioNaSessao(ClienteUnidadePasseLivre clienteUnidadePasseLivre) {
		if (clienteUnidadePasseLivre != null) {
			try {
				getSession().setAttribute("clienteUnidadePasseLivre", clienteUnidadePasseLivre);
			} catch (Exception e) {
				Log.error(e);
			}
		}
	}
	
	public String redirectSenhaDefinitiva() {
		return "/pages/senhaDefinitiva.xhtml?faces-redirect=true";
	}
	
	public void redirectEnviarCodVerif() {
		try {
			controleBotaoUtil.redirectEnviarCodVerif(getHttpServletRequest(), user, sessionId);
		} catch (final Exception e) {
			e.printStackTrace();
		}
	}

	public void esquecerSenha() {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, TotemUtil.buscarSessionId(),
					createBasicLogMap());
			//recuperaSenha();
			verificarTipoDeValidacao();
			redirectEnviarCodVerif();
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	public String getTextoConfirmarEmail() {
		String emailCompleto = clienteUnidadePasseLivre.getEmail();
		StringBuilder sbEmail = new StringBuilder();
		StringBuilder sbDominio = new StringBuilder();
		if (isClienteTemEmail()) {
			sbEmail.append(emailCompleto.substring(0, emailCompleto.indexOf("@")));
			sbDominio.append(emailCompleto.substring(emailCompleto.indexOf("@")));

			for (int i = 1; i < sbEmail.toString().length() - 1; i++) {
				sbEmail.setCharAt(i, '*');
			}
			for (int i = 2; i < sbDominio.indexOf("."); i++) {
				sbDominio.setCharAt(i, '*');
			}
		}
		return "Confirme o seu e-mail: " + sbEmail.toString() + sbDominio.toString();
	}

	private String recuperarEmailCliente() {
		try {
			final DataUtil dataUtil = new DataUtil();
			final ClienteService clienteService = new ClienteService(getHttpServletRequest());
			ParametroConsultaCliente parametroConsultaCliente = new ParametroConsultaCliente();
			parametroConsultaCliente.setToken(TotemUtil.buscarToken().getToken());
			parametroConsultaCliente.setAuthKey(user.getAuthKey());
			if (user.getAuthKey().length() == 11) {
				parametroConsultaCliente.setAuthKeyType("1");
				parametroConsultaCliente.setAuthKey(user.getAuthKey());
			} else {
				parametroConsultaCliente.setAuthKeyType("2");
				if (user.getAuthKey().startsWith("0")) {
					parametroConsultaCliente.setAuthKey(user.getAuthKey().substring(1));
				} else {
					parametroConsultaCliente.setAuthKey(user.getAuthKey());
				}
			}
			parametroConsultaCliente.setOrigem(Constantes.ORIGEM_PADRAO);
			parametroConsultaCliente.setBirthDate(dataUtil.formatarStringBRParaString(user.getBirthDate()));
			clienteService.consultaCliente(parametroConsultaCliente);
			clienteUnidadePasseLivre = new ClienteUnidadePasseLivre();
			if (clienteService.isSuccess() && clienteService.getResponseObject() != null) {
				clienteUnidadePasseLivre = ((List<ClienteUnidadePasseLivre>) clienteService.getResponseObject()).get(0);
				if (clienteUnidadePasseLivre.getEmail() != null && !clienteUnidadePasseLivre.getEmail().equals("")) {
					return clienteUnidadePasseLivre.getEmail();
				} else {
					return null;
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;
	}

	public boolean isClienteTemEmail() {
		return clienteUnidadePasseLivre != null && clienteUnidadePasseLivre.getEmail() != null;
	}

	private void gerarLogErroAoEntrarComCodigo(final Exception locExc) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), locExc.getMessage(),
					TotemUtil.buscarSessionId(), createBasicLogMap());
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	private void formatarCampos() throws Exception {
		formataEndereco.formataEnderecoAoLogar(clienteUnidadePasseLivre);
	}

	private void formatarValoresParaAtualizacao(final EntregaMaterialPendenteService entregaMaterialPendenteservice)
			throws Exception {
		clienteUnidadePasseLivre = (ClienteUnidadePasseLivre) entregaMaterialPendenteservice.getValueObject();
		formataEndereco.formataEnderecoAoLogar(clienteUnidadePasseLivre);
		clienteUnidadePasseLivre
				.setDataNascimento(formatarDataNascimentoParaEnvio(clienteUnidadePasseLivre.getDataNascimento()));
	}

	public void finalizarSolicitacao() {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, TotemUtil.buscarSessionId(),
					createBasicLogMap());
			final RequestContext context = RequestContext.getCurrentInstance();
			context.execute("PF('dlgConfirmacao').show();");
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			gerarLogErroAoFinalizarSolicitacao(locExc);
		}
	}

	private void gerarLogErroAoFinalizarSolicitacao(final Exception parExc) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parExc.getMessage(),
					TotemUtil.buscarSessionId(), createBasicLogMap());
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	public String naoAceitarTermo() {
		try {
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, TotemUtil.buscarSessionId(),
					createBasicLogMap());
			return redirectIndex();
		} catch (final Exception locExc) {
			return "";
		}
	}

	public void pesquisarCep() {
		try {
			final FacesContext facesContext = FacesContext.getCurrentInstance();
			final PartialViewContext partialViewContext = facesContext.getPartialViewContext();
			final Collection<String> renderIds = partialViewContext.getRenderIds();
			final UIViewRoot viewRoot = getContext().getViewRoot();
			for (final String renderId : renderIds) {
				final UIComponent component = viewRoot.findComponent(renderId);
				final EditableValueHolder input = (EditableValueHolder) component;
				if (input != null) {
					input.resetValue();
				} else {
					limparCamposEndereco();
				}
			}
			adicionarEnderecoPeloCEP();
		} catch (final NullPointerException locE) {
			limparCamposEndereco();
			gerarLogAoBuscarCEP("CEP não existe!");
		} catch (final Exception locE) {
			limparCamposEndereco();
			gerarLogAoBuscarCEP(locE.getMessage());
		}
	}

	private void gerarLogErroAoPesquisarCep(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, TotemUtil.buscarSessionId(),
					createBasicLogMap());
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	private void limparCamposEndereco() {
		clienteUnidadePasseLivre.limparCamposEndereco();
	}

	private void adicionarEnderecoPeloCEP() throws Exception {
		String cep = getClienteUnidadePasseLivre().getCep().replaceAll("[^0-9]", "");
		if (cep.length() == 8) {
			final CepService cepService = new CepService(getHttpServletRequest());
			ConsultaCepResult cepResult = cepService.consultarCep(cep, tokenResult.getToken());
			if (cepService.isSuccess()) {
				if (cepResult != null) {
					adiconarEnderecoAoCliente(cepResult);
				} else {
					limparCamposEndereco();
					exibirDialogMensagemAlert("CEP não encontrado!");
				}
			} else {
				limparCamposEndereco();
				exibirDialogMensagemAlert("CEP não encontrado!");
			}
		} else {
			limparCamposEndereco();
			exibirDialogMensagemAlert("CEP deve conter 8 caracteres numéricos!");
		}		
	}

	private void gerarLogAoBuscarCEP(final String mensagem) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, retornarCPF());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), mensagem, TotemUtil.buscarSessionId(),
					createBasicLogMap());
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}
	
	private void exibirDialogMensagemAlert(String msg) {
		setMensagemAviso(msg);
//		PrimeFaces.current().executeScript("PF('dlgMessageAviso').show()");
	}

	private String retornarCPF() {
		try {
			if (clienteUnidadePasseLivre.getCpf() != null) {
				return clienteUnidadePasseLivre.getCpf();
			} else {
				return "";
			}
		} catch (final Exception locExc) {
			return "";
		}
	}

	public void onTabChange(final TabChangeEvent event) {
		final TabView tv = (TabView) event.getComponent();
		activeIndex = tv.getActiveIndex();
		limparCampoLogin();
	}

	public void onRowSelect(final SelectEvent event) {
		ExameMaterialPendente exameMaterial = new ExameMaterialPendente();
		exameMaterial = (ExameMaterialPendente) event.getObject();
		exameMaterial.setMarcacao(exameMaterial.getMarcacaoTemp());
	}

	public void onRowUnselect(final UnselectEvent event) {
		ExameMaterialPendente exameMaterial = new ExameMaterialPendente();
		exameMaterial = (ExameMaterialPendente) event.getObject();
		exameMaterial.setMarcacao(null);
	}
	
	public void onRowSelectAll(final ToggleSelectEvent event) {
		if (event.isSelected()) {
			//marcar
			for (ExameMaterialPendente exameMaterial: getListaExameMaterialPendenteSelecionados()) {
				exameMaterial.setMarcacao(exameMaterial.getMarcacaoTemp());
			}
		}
		else {
			//desmarcar
			for (ExameMaterialPendente exameMaterial: getUltimosExamesPendentes()) {
				exameMaterial.setMarcacao(null);
			}
		}
//		List<ExameMaterialPendente> examesMaterial = (List<ExameMaterialPendente>) event.getObject();
//		for (ExameMaterialPendente exameMaterial: examesMaterial) {
//			if (exameMaterial.getMarcacao() == null)
//				exameMaterial.setMarcacao(exameMaterial.getMarcacaoTemp());
//			else
//				exameMaterial.setMarcacao(null);
//		}
	}
	
	public void onRowUnSelectAll(final UnselectEvent event) {
		List<ExameMaterialPendente> examesMaterial = (List<ExameMaterialPendente>) event.getObject();
		for (ExameMaterialPendente exameMaterial: examesMaterial) {
			exameMaterial.setMarcacao(null);
		}
	}

	public Boolean getExibirExamesPendentesExcecao() {
		return !examesPendentesExcecao.isEmpty();
	}

	public Boolean habilitarBotaoQuestionarioVoltar(final Integer level) {
		return controleBotaoUtil.habilitarBotaoQuestionarioVoltar(mdlsQuestionario, level);
	}

	public Boolean habilitarBotaoQuestionarioAvancar(final Integer level) {
		return controleBotaoUtil.habilitarBotaoQuestionarioAvancar(mdlsQuestionario, level);
	}

	public Boolean habilitarBotaoQuestionarioFinalizar(final Integer level) {
		return controleBotaoUtil.habilitarBotaoQuestionarioFinalizar(mdlsQuestionario, level);
	}

	public Boolean habilitarBotaoQuestionarioCancelar(final Integer level) {
		return controleBotaoUtil.habilitarBotaoQuestionarioCancelar(mdlsQuestionario, level);
	}

	public Boolean getHabilitaAtendimentoUnimed() {
		return controleBotaoUtil.getHabilitaAtendimentoUnimed(informacoesTotem);
	}

	public Boolean getHabilitaEntregaResultado() {
		return controleBotaoUtil.getHabilitaEntregaResultado(informacoesTotem);
	}

	public Boolean getHabilitaOrcamento() {
		return controleBotaoUtil.getHabilitaOrcamento(informacoesTotem);
	}

	public Boolean getHabilitaEntregaMaterial() {
		return controleBotaoUtil.getHabilitaEntregaMaterial(informacoesTotem);
	}

	public Boolean getHabilitaPeparacao() {
		return controleBotaoUtil.getHabilitaPreparacaoExame(informacoesTotem);
	}

	public void redirectResultado() {
		try {
			getSession().removeAttribute("resultadoPedidoBean");
			sessionId = SessionIdBuilder.build(informacoesTotem.get(0));
			if (inputCodBarras != null && inputCodBarras.length() == 14) {
				FacesContext.getCurrentInstance().getExternalContext()
				.redirect("/passelivretotem/index.xhtml?nomeTotem=" + TotemUtil.retornarNomeDaMaquina());
			} else {
				controleBotaoUtil.redirectResultado(getHttpServletRequest(), clienteUnidadePasseLivre, sessionId);
			}			
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	public void redirectMaterial() {
		try {
			getSession().removeAttribute("entregaMaterialPendenteBean");
			controleBotaoUtil.redirectMaterial(getHttpServletRequest(), clienteUnidadePasseLivre, sessionId,
					tokenResult, informacoesTotem);
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	public void redirectUnimed() {
		try {
			getSession().removeAttribute("novoAtendimentoUnimedBean");
			sessionId = SessionIdBuilder.build(informacoesTotem.get(0));
			controleBotaoUtil.redirectUnimed(getHttpServletRequest(), clienteUnidadePasseLivre, sessionId);
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	public String redirectPreparacao() {
		return "/pages/ppe/preparacao.xhtml?faces-redirect=true";
	}

	public String redirectOrcamento() {
		return "/pages/ocm/preparacao.xhtml?faces-redirect=true";
	}

	private void redirectTelaErro() {
		try {
			FacesContext.getCurrentInstance().getExternalContext().redirect(redirectAtendimentoNaoConcluidoIndex());
		} catch (final IOException exc) {
			exc.printStackTrace();
		}
	}

	private String redirectAtendimentoNaoConcluidoIndex() {
		return "/passelivretotem/pages/erro/atendimentoNaoConcluido.xhtml?faces-redirect=true";
	}

	public String redirectListaMaterialPendente() {
		return listarTodosMateriaisPendentes();
	}

	public String redirectAtendimentoConcluido() {
		return "/pages/emp/atendimentoConcluido.xhtml?faces-redirect=true";
	}

	public String redirectAtualizaDados() {
		return "/pages/emp/atualizarDados.xhtml?faces-redirect=true";
	}

	public String redirectLogin() {
		return "/pages/emp/login.xhtml?faces-redirect=true";
	}

	public String redirectIndex() throws Exception {
		final String nomeMaquina = TotemUtil.retornarNomeDaMaquina();
		getSession().removeAttribute("indexBean");
		TotemUtil.limparSession();
		setLoggedIn(Boolean.FALSE);
		return "/indexTotem.xhtml?faces-redirect=true&nomeTotem=" + nomeMaquina;
	}

	public String redirectPesquisaSatisfacao() {
		return "/pages/emp/pesquisaSatisfacao.xhtml?faces-redirect=true";
	}

	public void recuperaSenha() {
		try {
			final SenhaService senhaService = new SenhaService(getHttpServletRequest());
			verificarTipoDeValidacao();
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, TotemUtil.buscarSessionId(),
					createBasicLogMap());
			senhaService.recuperaSenha(user);
			if (senhaService.isSuccess()) {
				mensagemAviso = senhaService.getResponseMessage();
			}
			user.setEmail("");
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			mensagemAviso = locExc.getMessage();
			gerarLogErroAoRecuperarSenha(locExc);
		} finally {
			exibirDialogMensagem();
		}
	}

	private void gerarLogErroAoRecuperarSenha(final Exception locExc) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), locExc.getMessage(),
					TotemUtil.buscarSessionId(), createBasicLogMap());
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	private void verificarTipoDeValidacao() {
		if (entradaEhUsandoCodigoCliente()) {
			user.setAuthKeyType(Constantes.CODEAUTHKEYTYPE);
		} else {
			user.setAuthKeyType(Constantes.CPFAUTHKEYTYPE);
			final String dataNascimentoRetorno = formatarDataNascimentoParaRecebimento(user.getBirthDate());
			user.setBirthDate(dataNascimentoRetorno);
		}
	}

	public String irParaQuestionario() {
		try {
			gerarQuestionario();
			agruparPerguntasPorAbaEOrdenar();
			final ComponenteFactory componenteFactory = new ComponenteFactory(pnlQuestionario, mdlsQuestionario,
					mtdQuestionario, mdlQuestionario, pngQuestionario);
			return verificarSeExisteQuestionario(componenteFactory);
		} catch (final RegraNegocioException exc) {
			exc.printStackTrace();
			gerarLogErroAoGerarQuestionario(exc);
			MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso(exc.getMessage());
			try {
				getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return redirectAtendimentoNaoConcluido();
		} catch (final Exception exc) {
			exc.printStackTrace();
			gerarLogErroAoGerarQuestionario(exc);
			mensagemAviso = "Erro ao buscar o questionário!";
			exibirDialogMensagem();
			return null;
		}
	}

	private String verificarSeExisteQuestionario(final ComponenteFactory componenteFactory) throws Exception {
		if (componenteFactory.construirComponentesMaterialPendente(mapQuestionarios, todasPerguntasAgrupadasPorAba)) {
			final HttpSession session = getHttpServletRequest().getSession();
			session.setAttribute("mdlsQuestionario", mdlsQuestionario);
			session.setAttribute("sessionId", sessionId);
			session.setAttribute("questionariosExamesResult", questionariosExamesResult);
			session.setAttribute("consultaQuestionarioExameResult", consultaQuestionarioExameResult);
			session.setAttribute("sessionId", sessionId);
			session.setAttribute("tokenResult", tokenResult);
			session.setAttribute("clienteUnidadePasseLivre", clienteUnidadePasseLivre);
			session.setAttribute("questionariosExamesResult", questionariosExamesResult);
			session.setAttribute("informacoesTotem", informacoesTotem);
			session.setAttribute("todasPerguntasAgrupadas", todasPerguntasAgrupadasPorAba);
			return "/pages/emp/questionario.xhtml?faces-redirect=true";
		} else {
			return entregarMaterial();
		}
	}

	private void preencherQuestionario() throws Exception {
		try {
			if (perguntas == null || perguntas.isEmpty()) {
				perguntas = (List<PerguntaEntrega>) getSession().getAttribute("perguntas");
			}
			/*
			 * perguntas = new ArrayList<>(); if (mapQuestionarios == null ||
			 * mapQuestionarios.isEmpty()) { mapQuestionarios = (Map<String, String>)
			 * getSession().getAttribute("mapQuestionarios"); } perguntas.addAll( new
			 * QuestionarioService(getHttpServletRequest(), perguntas, mapQuestionarios,
			 * todasPerguntasAgrupadasPorAba) .preencherQuestionarioConsolidado());
			 */
		} catch (final Exception locExc) {
			throw new Exception(locExc.getMessage());
		}
	}

	private void gerarLogErroAoSolicitarExame(final String mensagem) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), mensagem, TotemUtil.buscarSessionId(),
					createBasicLogMap());
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	private void gerarLogEstatistico() {
		try {
			final ControleEstatisticoService controleEstatisticoService = new ControleEstatisticoService(
					getHttpServletRequest());
			final ControleEstatistico controleEstatistico = new ControleEstatistico(
					clienteUnidadePasseLivre.getCodigoCliente(), null,
					FuncaoLogEstatistico.ENTREGAR_MATERIAL_PENDENTE.toString(), informacoesTotem.get(0).getId(), null,
					null, retornarUnidade());
			controleEstatisticoService.insert(controleEstatistico);
		} catch (final Exception locExc) {
			gerarLogErroAoGerarLogEstatistico(locExc.getMessage());
		}
	}

	private void gerarLogEstatisticoParaAniversariante() {
		try {
			final ControleEstatisticoService controleEstatisticoService = new ControleEstatisticoService(
					getHttpServletRequest());
			final ControleEstatistico controleEstatistico = new ControleEstatistico(
					clienteUnidadePasseLivre.getCodigoCliente(), null,
					FuncaoLogEstatistico.LEMBRETE_ANIVERSARIO.toString(), informacoesTotem.get(0).getId(), null, null,
					retornarUnidade());
			controleEstatisticoService.insert(controleEstatistico);
		} catch (final Exception locExc) {
			gerarLogErroAoGerarLogEstatistico(locExc.getMessage());
		}
	}

	private void gerarLogErroAoGerarLogEstatistico(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, TotemUtil.buscarSessionId(),
					createBasicLogMap());
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	private Long retornarServicoMaterialPendente() {
		try {
			Long idServico = new Long(0);
			for (final InformacaoTotem paramInformacaoTotem : informacoesTotem) {
				if (paramInformacaoTotem.getDescricao().equals(Constantes.SERVICO_ENTREGA_PENDENTE)) {
					idServico = paramInformacaoTotem.getIdService();
				}
			}
			return idServico;
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return null;
		}
	}

	private String redirectAtendimentoNaoConcluidoAposAtualizar() {
		return "/pages/erro/atendimentoNaoConcluido.xhtml?faces-redirect=true";
	}

	private String redirectAtendimentoNaoConcluido() {
		return "/pages/erro/atendimentoNaoConcluido.xhtml?faces-redirect=true";
	}

	private String redirectAtendimentoConcluidoSemEmail() {
		return "/pages/emp/atendimentoConcluidoSemEmail.xhtml?faces-redirect=true";
	}

	private void limparCampoLogin() {
		user = new UserAuth();
		RequestContext.getCurrentInstance().reset("frmPrincipal:idTabView:codigoClienteTab");
		RequestContext.getCurrentInstance().reset("frmPrincipal:idTabView:cpfClienteTab");
	}

	private String formatarDataNascimentoParaEnvio(final String dataNascimento) {
		return new FormataDataDiaMesAno(dataNascimento).formatar();
	}

	private String formatarDataNascimentoParaRecebimento(final String dataNascimento) {
		return new FormataDataAnoMesDia(dataNascimento).formatar();
	}

	private boolean entradaEhUsandoCodigoCliente() {
		return activeIndex == 0;
	}

	public boolean getHappyBirthDate() {
		try {
			if (new ClienteService(getHttpServletRequest())
					.getHappyBirthDate(clienteUnidadePasseLivre.getDataNascimento())) {
				gerarLogEstatisticoParaAniversariante();
				return true;
			} else {
				return false;
			}
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return false;
		}
	}

	public Boolean getHabilitaMarcacao() {
		return habilitaMarcacao;
	}

	public void setHabilitaMarcacao(final Boolean parHabilitaMarcacao) {
		habilitaMarcacao = parHabilitaMarcacao;
	}

	private void verificarSeClientePasseLivreExiste() throws Exception {
		if (clienteUnidadePasseLivre.getNomeCliente() == null) {
			receberClientePasseLivre();
			listarTodosMateriaisPendentes();
		}
	}

	private String listarTodosMateriaisPendentes() {
		try {			
			informacoesTotem = new ArrayList<>();
			informacoesTotem.addAll(receberInformacaoTotem());
			final MaterialPendenteService materialPendenteService = new MaterialPendenteService(
					getHttpServletRequest());
			final EntregaMaterialPendenteService entregaMaterialPendenteService = new EntregaMaterialPendenteService(
					getHttpServletRequest());
			final ConsultaMaterialPendenteResult consultaMaterialPendenteResult;
			if (clienteUnidadePasseLivre != null) {
				final ParametroMaterialPendente cliente = new ParametroMaterialPendente(clienteUnidadePasseLivre,
						tokenResult);
				materialPendenteService.setValueObject(cliente);
				materialPendenteService.consultar();
				if (materialPendenteService.isSuccess()) {
					consultaMaterialPendenteResult = (ConsultaMaterialPendenteResult) materialPendenteService
							.getResponseObject();
					todosExamesPendentes = new ArrayList<>();
					todosExamesPendentes.addAll(entregaMaterialPendenteService.adicionarExamesMateriaisPendente(
							consultaMaterialPendenteResult, clienteUnidadePasseLivre, informacoesTotem.get(0),
							tokenResult));
				} else {
					throw new RegraNegocioException(materialPendenteService.getResponseMessage());
				}
				buscarUltimosMateriaisPendentes();
				return "/pages/emp/listaMateriaisPendetes.xhtml?faces-redirect=true";
			}
			
			return "";
		} catch (final Exception locExc) {
			gerarLogErroAoListarMateriaisPendentes(locExc.getMessage());
			MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso(locExc.getMessage());
			try {
				getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return redirectAtendimentoNaoConcluidoAposAtualizar();
		}
	}

	public String listarMateriaisPendentesPedido(final String codBarras) {
		try {
			if (codBarras.length() != 14) {
				mensagemAviso = "Posicione corretamente o código de barras no leitor.";
				exibirDialogMensagem();
				return "";
			}
			buscarInformacoesTotem();
			tokenResult = TotemUtil.buscarToken();
			examesPendentesExcecao = new ArrayList<>();
			final ParametroMaterialPendente parametroMaterialPendente = new ParametroMaterialPendente(codBarras,
					TotemUtil.buscarToken());

			final MaterialPendenteService materialPendenteService = new MaterialPendenteService(
					getHttpServletRequest());
			materialPendenteService.setValueObject(parametroMaterialPendente);
			materialPendenteService.consultar();
			if (materialPendenteService.isSuccess()) {
				final ConsultaMaterialPendenteResult consultaMaterialPendenteResult = (ConsultaMaterialPendenteResult) materialPendenteService
						.getResponseObject();
				todosExamesPendentes = new ArrayList<>();
				if (!consultaMaterialPendenteResult.getPedidos().isEmpty()) {
					ClienteService clienteService = new ClienteService(getHttpServletRequest());
					clienteUnidadePasseLivre = clienteService
							.dePacienteParaCliente(consultaMaterialPendenteResult.getPedidos().get(0).getPaciente());
					final EntregaMaterialPendenteService entregaMaterialPendenteService = new EntregaMaterialPendenteService(
							getHttpServletRequest());
					todosExamesPendentes.addAll(entregaMaterialPendenteService.adicionarExamesMateriaisPendente(
							consultaMaterialPendenteResult, null, informacoesTotem.get(0), tokenResult));
					buscarUltimosMateriaisPendentes();
					if (ultimosExamesPendentes.isEmpty()) {
						mensagemAviso = "Não existem materiais pendentes para o pedido!";
						exibirDialogMensagem();
						return "";
					}
					getHttpServletRequest().getSession().setAttribute("inputCodBarras", inputCodBarras);
				} else {
					inputCodBarras = "";
					mensagemAviso = "Não existem materiais pendentes para o pedido!";
					exibirDialogMensagem();
					return "";
				}
			} else {
				inputCodBarras = "";
				mensagemAviso = materialPendenteService.getResponseMessage();
				exibirDialogMensagem();
				return "";
				// throw new
				// RegraNegocioException(materialPendenteService.getResponseMessage());
			}
			
			FacesContext.getCurrentInstance().getExternalContext()
					.redirect("/passelivretotem/pages/emp/listaMateriaisPendetes.xhtml?faces-redirect=true&nomeTotem="
							+ TotemUtil.retornarNomeDaMaquina());
			
		} catch (final Exception locExc) {
			gerarLogErroAoListarMateriaisPendentesPorCodBarras(locExc.getMessage());
			MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso(locExc.getMessage());
			inputCodBarras = "";
			try {
				getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return redirectAtendimentoNaoConcluidoAposAtualizarPedido();
		}
		return "";
	}

	private List<InformacaoTotem> receberInformacaoTotem() throws Exception {
		try {
			final HttpSession session = getHttpServletRequest().getSession();
			return (List<InformacaoTotem>) session.getAttribute("informacoesTotem");
		} catch (final Exception locExc) {
			throw new Exception("Erro ao receber informações do totem!");
		}
	}

	private void gerarLogErroAoListarMateriaisPendentes(final String parMessagem) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN,
					clienteUnidadePasseLivre.getCodigoCliente());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessagem, TotemUtil.buscarSessionId(),
					createBasicLogMap());
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	private void gerarLogErroAoListarMateriaisPendentesPorCodBarras(final String parMessagem) {
		try {
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessagem, TotemUtil.buscarSessionId(),
					createBasicLogMap());
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	private void buscarUltimosMateriaisPendentes() throws RegraNegocioException, Exception {
		ultimosExamesPendentes = new ArrayList<>();
		excecaoAtendimentoResult = buscarExcecoes();
		if (todosExamesPendentes != null) {
			Collections.sort(todosExamesPendentes);
			for (final ExameMaterialPendente exameMaterialPendente : todosExamesPendentes) {
				if (!ultimosExamesPendentes.contains(exameMaterialPendente)) {
					ultimosExamesPendentes.add(exameMaterialPendente);
				}
			}
			Collections.sort(ultimosExamesPendentes);
			filtrarMaterialPendenteExcecao();
			filtrarMaterialPendente();
		}
	}

	private void filtrarMaterialPendenteExcecao() {
		final AplicaExcecaoMaterialPendenteFactory aplicaExcecaoMaterialPendenteFactory = new AplicaExcecaoMaterialPendenteFactory();
		examesPendentesExcecao.clear();
		examesPendentesExcecao.addAll(aplicaExcecaoMaterialPendenteFactory.retornarGuiasExcecao(ultimosExamesPendentes,
				excecaoAtendimentoResult));
	}

	private void gerarLogParaMateriaisPendenteExcluidosDoTotem() throws Exception {
		for (final ExameMaterialPendente exameMaterialPendente : examesPendentesExcecao) {
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(),
					"Log para materias não atendidos pelo totem: " + exameMaterialPendente.toString() + " Motivo:"
							+ exameMaterialPendente.getObservacao(),
					sessionId, createBasicLogMap());
		}
	}

	private ExcecaoAtendimentoResult buscarExcecoes() throws RegraNegocioException, Exception {
		final ExcecaoAtendimentoService excecaoAtendimentoService = new ExcecaoAtendimentoService(
				getHttpServletRequest());
		final ParametroExcecaoAtendimento parametroExcecaoAtendimento = new ParametroExcecaoAtendimento(
				informacoesTotem, retornarIdServico(), tokenResult);
		excecaoAtendimentoService.retornarExcecao(parametroExcecaoAtendimento);
		if (excecaoAtendimentoService.isSuccess()) {
			return (ExcecaoAtendimentoResult) excecaoAtendimentoService.getResponseObject();
		} else {
			throw new RegraNegocioException(excecaoAtendimentoService.getResponseMessage());
		}
	}

	private Long retornarIdServico() {
		if (informacoesTotem != null && !informacoesTotem.isEmpty() || !informacoesTotem.isEmpty()) {
			for (final InformacaoTotem informacaoTotem : informacoesTotem) {
				if (informacaoTotem.getDescricao().equals(Constantes.SERVICO_ENTREGA_PENDENTE)) {
					return informacaoTotem.getIdService();
				}
			}
		}
		return null;
	}

	private void filtrarMaterialPendente() {
		final AplicaExcecaoMaterialPendenteFactory aplicaExcecaoMaterialPendenteFactory = new AplicaExcecaoMaterialPendenteFactory();
		ultimosExamesPendentes = aplicaExcecaoMaterialPendenteFactory
				.retornarMaterialPendenteFiltrados(ultimosExamesPendentes, excecaoAtendimentoResult);
	}

	private void receberClientePasseLivre() {
		try {
			final HttpSession session = getHttpServletRequest().getSession();
			clienteUnidadePasseLivre = (ClienteUnidadePasseLivre) session.getAttribute("clienteUnidadePasseLivre");
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	private void formatarValores() {
		clienteUnidadePasseLivre.setCelular(formatarTelefone(clienteUnidadePasseLivre.getCelular()));
		clienteUnidadePasseLivre.setTelefone(formatarTelefone(clienteUnidadePasseLivre.getTelefone()));
		clienteUnidadePasseLivre.setCep(formatarCep(clienteUnidadePasseLivre.getCep()));
		clienteUnidadePasseLivre.setCpf(formatarCpf(retornarCPF()));
	}

	private String formatarCep(final String cep) {
		return new FormataCep(cep).formatar();
	}

	private String formatarCpf(final String cpf) {
		try {
			return new FormataCpf(cpf).formatar();
		} catch (final Exception locExc) {
			return null;
		}
	}

	private String formatarTelefone(final String telefone) {
		return new FormataTelefone(telefone).formatar();
	}

	private void adiconarEnderecoAoCliente(ConsultaCepResult consultaCepResult) {
		clienteUnidadePasseLivre.setUf(consultaCepResult.getUf());
		clienteUnidadePasseLivre.setCidade(consultaCepResult.getLocalidade());
		clienteUnidadePasseLivre.setLogradouro(montarEnderecoLogradouro(consultaCepResult));
		clienteUnidadePasseLivre.setBairro(consultaCepResult.getBairro() != null ? consultaCepResult.getBairro() : "");
		clienteUnidadePasseLivre.setNumero("");
		clienteUnidadePasseLivre.setComplemento("");
		
		if(clienteUnidadePasseLivre.getLogradouro().equals(""))
			setEditarLogradouro(true);
		else
			setEditarLogradouro(false);
		
		if(clienteUnidadePasseLivre.getBairro().equals(""))
			setEditarBairro(true);
		else
			setEditarBairro(false);
	}
	
	private String montarEnderecoLogradouro(ConsultaCepResult consultaCepResult) {
		if(consultaCepResult.getLogradouro() != null && !consultaCepResult.getLogradouro().equals("") && consultaCepResult.getTipoEndereco() != null && !consultaCepResult.getTipoEndereco().equals(""))
			return consultaCepResult.getTipoEndereco() + " " + consultaCepResult.getLogradouro();
		else if(consultaCepResult.getLogradouroAbreviado() != null && !consultaCepResult.getLogradouroAbreviado().equals(""))
			return consultaCepResult.getLogradouroAbreviado();		
		else {
			return "";
		}
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getComplemento() {
		return complemento;
	}

	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}

	public boolean isEditarLogradouro() {
		return editarLogradouro;
	}

	public void setEditarLogradouro(boolean editarLogradouro) {
		this.editarLogradouro = editarLogradouro;
	}

	public boolean isEditarBairro() {
		return editarBairro;
	}

	public void setEditarBairro(boolean editarBairro) {
		this.editarBairro = editarBairro;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getLogradouro() {
		return logradouro;
	}

	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}

	private void verificarSeHabilitaCampoUf(final String parUf) {
		getClienteUnidadePasseLivre().setUf(parUf);
		if (parUf.isEmpty() || parUf == "") {
			habilitacaoCamposCadastroTO.setHabilitaUF(true);
		}
	}

	private void verificarSeHabilitaCampoCidade(final String parLocalidade) {
		getClienteUnidadePasseLivre().setCidade(parLocalidade);
		if (parLocalidade.isEmpty() || parLocalidade == "") {
			habilitacaoCamposCadastroTO.setHabilitaCidade(true);
		}
	}

	private void verificarSeHabilitaCampoBairro(final String parBairro) {
		getClienteUnidadePasseLivre().setBairro(parBairro);
		if (parBairro.isEmpty() || parBairro == "") {
			habilitacaoCamposCadastroTO.setHabilitaBairro(true);
		}
	}

	private void verificarSeHabilitaCampoLogradouro(final String parLogradouro) {
		getClienteUnidadePasseLivre().setLogradouro(parLogradouro);
		if (parLogradouro.isEmpty() || parLogradouro == "") {
			habilitacaoCamposCadastroTO.setHabilitaLogradouro(true);
		}
	}

	private void fazerEntrega() throws Exception, EnvioEmailException {
		final MaterialPendenteService materialPendenteService = new MaterialPendenteService(getHttpServletRequest());
		for (final Map.Entry<KeyMaterialPedente, ParametroEntregaMaterial> locMapMaterialPedente : materiaisAgrupadosPorPedidoUnidade
				.entrySet()) {
			final ParametroEntregaMaterial parametroPedidoEntrega = new ParametroEntregaMaterial(
					locMapMaterialPedente.getValue(), questionariosExamesResult, informacoesTotem, perguntas,
					tokenResult);
			materialPendenteService.entregar(parametroPedidoEntrega);
		}
		if (materialPendenteService.isSuccess()) {
			enviarEmail();
			getSession().removeAttribute("inputCodBarras");
		} else {
			throw new Exception(materialPendenteService.getResponseMessage());
		}
	}

	public String verificarSeTodosMateriaisDoPedidoForamSelecionados() {
		try {
			verificarSeMaterialFoiSelecionado();
			materiaisAgrupadosPorPedidoUnidade = agruparMaterialPorPedidoUnidade();
			for (final Map.Entry<KeyMaterialPedente, ParametroEntregaMaterial> locMapMaterialPedente : materiaisAgrupadosPorPedidoUnidade
					.entrySet()) {
				Integer quantidadeDeExamesNoPedido = 0;
				final ParametroEntregaMaterial parametroPedidoEntrega = new ParametroEntregaMaterial(
						locMapMaterialPedente.getValue(), questionariosExamesResult, informacoesTotem, perguntas,
						tokenResult);
				quantidadeDeExamesNoPedido = retornarQuantidadeDeMaterialPorPedido(quantidadeDeExamesNoPedido,
						parametroPedidoEntrega);
				if (parametroPedidoEntrega.getExames().size() < quantidadeDeExamesNoPedido) {
					mensagemAviso = "Nem todos os materiais do pedido: " + parametroPedidoEntrega.getPedido()
							+ " foram selecionados, deseja continuar?";
					final RequestContext context = RequestContext.getCurrentInstance();
					context.execute("PF('dlgConfirmacaoEntrega').show();");
					return "";
				}
			}
			return irParaQuestionario();
		} catch (final RegraNegocioException locExc) {
			locExc.printStackTrace();
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
			gerarLogAoSolicitarExame(locExc.getMessage());
			return "";
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			gerarLogErroAoSolicitarExame(locExc.getMessage());
			return "";
		}
	}

	private void gerarLogAoSolicitarExame(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, TotemUtil.buscarSessionId(),
					createBasicLogMap());
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	private Integer retornarQuantidadeDeMaterialPorPedido(Integer quantidadeDeExamesNoPedido,
			final ParametroEntregaMaterial parametroPedidoEntrega) {
		for (final ExameMaterialPendente locExameMaterialPendente : ultimosExamesPendentes) {
			if (locExameMaterialPendente.getPedido().equals(parametroPedidoEntrega.getPedido())) {
				quantidadeDeExamesNoPedido += 1;
			}
		}
		return quantidadeDeExamesNoPedido;
	}

	private void enviarEmail() throws EnvioEmailException {

		try {
			final EnviaEmailService envioEmailService = new EnviaEmailService(getHttpServletRequest());
			envioEmailService.enviarEmailEntregarMaterial(clienteUnidadePasseLivre,
					listaExameMaterialPendenteSelecionados, buscarDescricaoUnidade(), getAmbienteProducao());
		} catch (final Exception locExc) {
			throw new EnvioEmailException(locExc.getMessage());
		}
	}

	private Map<KeyMaterialPedente, ParametroEntregaMaterial> agruparMaterialPorPedidoUnidade() throws Exception {
		KeyMaterialPedente keyMaterialPedente;
		final Map<KeyMaterialPedente, ParametroEntregaMaterial> mapMateriaisPendentes = new HashMap<>();
		for (final ExameMaterialPendente locExameMaterialPendente : listaExameMaterialPendenteSelecionados) {
			keyMaterialPedente = new KeyMaterialPedente(locExameMaterialPendente);
			mapMateriaisPendentes.put(keyMaterialPedente, adicionarMateriaisParaPedidoEntrega(locExameMaterialPendente,
					mapMateriaisPendentes.get(keyMaterialPedente)));
		}
		return mapMateriaisPendentes;
	}

	private ParametroEntregaMaterial adicionarMateriaisParaPedidoEntrega(
			final ExameMaterialPendente parExameMaterialPendente, ParametroEntregaMaterial pedidoEntrega)
			throws Exception {
		final List<ExameEntrega> exameEntrega = new ArrayList<>();
		ExamesEntrega examesEntrega = new ExamesEntrega();
		pedidoEntrega = verificarSePedidoEstaVazio(parExameMaterialPendente, pedidoEntrega, exameEntrega);
		exameEntrega.add(new ExameEntrega(parExameMaterialPendente));
		examesEntrega = new ExamesEntrega(exameEntrega);
		pedidoEntrega.setExames(examesEntrega);
		return pedidoEntrega;
	}

	private ParametroEntregaMaterial verificarSePedidoEstaVazio(final ExameMaterialPendente parExameMaterialPendente,
			ParametroEntregaMaterial pedidoEntrega, final List<ExameEntrega> exameEntrega) {
		if (pedidoEntrega == null) {
			pedidoEntrega = new ParametroEntregaMaterial(parExameMaterialPendente, informacoesTotem, tokenResult);
		} else {
			exameEntrega.addAll(pedidoEntrega.getExames());
		}
		return pedidoEntrega;
	}

	private String buscarDescricaoUnidade() {
		return informacoesTotem.get(0).getNomeUnd();
	}

	private void verificarSeMaterialFoiSelecionado() throws RegraNegocioException {
		if (listaExameMaterialPendenteSelecionados.isEmpty()) {
			throw new RegraNegocioException("O material pendente deve ser selecionado!");
		}
	}

	private boolean cepELogradouroNaoEstaoNulos(final Cep cep) {
		return cep != null;
	}

	public Integer getActiveIndex() {
		active0 = true;
		active1 = false;
		if (entradaEhUsandoCodigoCliente()) {
			active0 = false;
			active1 = true;
		}
		return activeIndex;
	}

	private void gerarLogErroAoValidarSenha(final String parMensagemErro) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMensagemErro,
					TotemUtil.buscarSessionId(), createBasicLogMap());
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	public Map createBasicLogMap() {
		Long idTotem = null;
		Long idUnidade = null;
		if (informacoesTotem != null && !informacoesTotem.isEmpty()) {
			idTotem = informacoesTotem.get(0).getId();
			idUnidade = Long.valueOf(informacoesTotem.get(0).getIdUnidade());
		}
		try {
			return TotemUtil.createBasicLogMap(idTotem, idUnidade, Util.getClientIpAddr(getHttpServletRequest()));
		} catch (Exception e) {
			e.printStackTrace();
			return new HashMap();
		}
	}

	private int calcularDigito(String str, int[] peso) {
		int soma = 0;
		for (int indice = str.length() - 1, digito; indice >= 0; indice--) {
			digito = Integer.parseInt(str.substring(indice, indice + 1));
			soma += digito * peso[peso.length - str.length() + indice];
		}
		soma = 11 - soma % 11;
		return soma > 9 ? 0 : soma;
	}

	public void isValidCPF() {
		String cpf = clienteUnidadePasseLivre.getCpf();
		cpf = cpf.replace(".", "").replace("-", "");
		if ((cpf == null) || (cpf.length() != 11)) {
			mensagemAviso = "CPF Inválido";
			exibirDialogMensagem();
			return;
		}

		Integer digito1 = calcularDigito(cpf.substring(0, 9), Constantes.PESOCPF);
		Integer digito2 = calcularDigito(cpf.substring(0, 9) + digito1, Constantes.PESOCPF);

		if (!cpf.equals(cpf.substring(0, 9) + digito1.toString() + digito2.toString())) {
			clienteUnidadePasseLivre.setCpf(null);
			mensagemAviso = "CPF Inválido";
			exibirDialogMensagem();
		}
	}

	public String mensagemCabecalho(String linha) {
		try {

			return MensagemUtil.retornarMensagemCabelho(clienteUnidadePasseLivre, "", linha);
		} catch (final Exception locExc) {
			return "";
		}
	}

	private void fecharDialogResetSenha() {
		RequestContext.getCurrentInstance().execute("PF('alterarSenhaDlgVar').hide()");
	}

	private void resetarCampos() {
		getUser().setNewPass("");
		getUser().setConfirmAuthPass("");
	}

	public Boolean getHabilitarImpressaoPorCodigoDeBarra() {
		return verificarSeTotemPossuiLeitorCodigoBarra();
	}

	private Boolean verificarSeTotemPossuiLeitorCodigoBarra() {
		try {
			return !informacoesTotem.get(0).getLeitorCodigoBarras().equals("N");
		} catch (final Exception locExc) {
			return true;
		}
	}

	public void entregaMaterialPorCodigoBarra() {
		String telaErro = listarMateriaisPendentesPedido(inputCodBarras);
		if(!Objects.isNull(telaErro) && !telaErro.equals("")) {
			redirectTelaErro(telaErro);	
		}
	}

	public void abrirDialgCodigoBarra() {
		inputCodBarras = "";
		final RequestContext context = RequestContext.getCurrentInstance();
		context.execute("PF('dlgCodigoBarra').show();");
	}

	public void setActiveIndex(final Integer activeIndex) {
		this.activeIndex = activeIndex;
	}

	public String getParamForwardPath() {
		return paramForwardPath;
	}

	public void setParamForwardPath(final String paramForwardPath) {
		this.paramForwardPath = paramForwardPath;
	}

	public boolean isLoggedIn() {
		return loggedIn;
	}

	public void setLoggedIn(final boolean loggedIn) {
		this.loggedIn = loggedIn;
	}

	public UserAuth getUser() {
		return user;
	}

	public void setUser(final UserAuth user) {
		this.user = user;
	}

	public boolean isActive0() {
		return active0;
	}

	public boolean isActive1() {
		return active1;
	}

	public void setActive0(final boolean active0) {
		this.active0 = active0;
	}

	public void setActive1(final boolean active1) {
		this.active1 = active1;
	}

	public void setClienteUnidadePasseLivre(final ClienteUnidadePasseLivre clienteUnidadePasseLivre) {
		this.clienteUnidadePasseLivre = clienteUnidadePasseLivre;
	}

	public FormataEndereco getFormataEndereco() {
		return formataEndereco;
	}

	public void setFormataEndereco(final FormataEndereco formataEndereco) {
		this.formataEndereco = formataEndereco;
	}

	public FormataTelefone getFormataTelefone() {
		return formataTelefone;
	}

	public void setFormataTelefone(final FormataTelefone formataTelefone) {
		this.formataTelefone = formataTelefone;
	}

	public ClienteUnidadePasseLivre getClienteUnidadePasseLivre() {
		return clienteUnidadePasseLivre;
	}

	public void setListaExameMaterialPendenteSelecionados(
			final List<ExameMaterialPendente> listaExameMaterialPendenteSelecionados) {
		this.listaExameMaterialPendenteSelecionados = listaExameMaterialPendenteSelecionados;
	}

	public List<ExameMaterialPendente> getListaExameMaterialPendenteSelecionados() {
		return listaExameMaterialPendenteSelecionados;
	}

	public List<ExameMaterialPendente> getUltimosExamesPendentes() {
		return ultimosExamesPendentes;
	}

	public void setUltimosExamesPendentes(final List<ExameMaterialPendente> parUltimosExamesPendentes) {
		ultimosExamesPendentes = parUltimosExamesPendentes;
	}

	public MasterDetail getMtdQuestionario() {
		return mtdQuestionario;
	}

	public void setMtdQuestionario(final MasterDetail parMtdQuestionario) {
		mtdQuestionario = parMtdQuestionario;
	}

	public Map<String, String> getMapQuestionarios() {
		return mapQuestionarios;
	}

	public void setMapQuestionarios(final Map<String, String> parMapQuestionarios) {
		mapQuestionarios = parMapQuestionarios;
	}

	public List<MasterDetailLevel> getMdlsQuestionario() {
		return mdlsQuestionario;
	}

	public void setMdlsQuestionario(final List<MasterDetailLevel> parMdlsQuestionario) {
		mdlsQuestionario = parMdlsQuestionario;
	}

	public Dialog getMessageInDialog() {
		return messageInDialog;
	}

	public void setMessageInDialog(final Dialog parMessageInDialog) {
		messageInDialog = parMessageInDialog;
	}

	public String getMensagemAviso() {
		return mensagemAviso;
	}

	public void setMensagemAviso(final String parMensagemAviso) {
		mensagemAviso = parMensagemAviso;
	}

	public List<ExameMaterialPendente> getExamesPendentesExcecao() {
		return examesPendentesExcecao;
	}

	public void setExamesPendentesExcecao(final List<ExameMaterialPendente> parExamesPendentesExcecao) {
		examesPendentesExcecao = parExamesPendentesExcecao;
	}

	public HabilitacaoCamposCadastroTO getHabilitacaoCamposCadastroTO() {
		return habilitacaoCamposCadastroTO;
	}

	public void setHabilitacaoCamposCadastroTO(final HabilitacaoCamposCadastroTO parHabilitacaoCamposCadastroTO) {
		habilitacaoCamposCadastroTO = parHabilitacaoCamposCadastroTO;
	}

	public Boolean getHouveAlteracao() {
		return houveAlteracao;
	}

	public void setHouveAlteracao(final Boolean parHouveAlteracao) {
		houveAlteracao = parHouveAlteracao;
	}

	public String getInputCodBarras() {
		return inputCodBarras;
	}

	public void setInputCodBarras(String inputCodBarras) {
		this.inputCodBarras = inputCodBarras;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}
	
	private String redirectAtendimentoNaoConcluidoAposAtualizarPedido() {
		return "/passelivretotem/pages/erro/atendimentoNaoConcluido.xhtml?faces-redirect=true";
	}	
	
	private void redirectTelaErro(String telaErro) {
		try {
			FacesContext.getCurrentInstance().getExternalContext().redirect(telaErro);
		} catch (final IOException exc) {
			exc.printStackTrace();
		}
	}
}
