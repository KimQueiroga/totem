package br.com.hermespardini.passelivre.bean;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Date;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import org.apache.velocity.tools.config.Data;
import org.primefaces.component.tabview.TabView;
import org.primefaces.context.RequestContext;
import org.primefaces.event.TabChangeEvent;

import br.com.hermespardini.corebusiness.model.LogAplicacaoUsuarioFactory;
import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.constantsenum.TipoServicoEnum;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.format.FormataDataAnoMesDia;
import br.com.hermespardini.passelivre.model.ClienteUnidadePasseLivre;
import br.com.hermespardini.passelivre.model.DetalhePreparacao;
import br.com.hermespardini.passelivre.model.InformacaoTotem;
import br.com.hermespardini.passelivre.model.Paciente;
import br.com.hermespardini.passelivre.model.ParametroConsultaCliente;
import br.com.hermespardini.passelivre.model.ParametroConsultaClienteGuiche;
import br.com.hermespardini.passelivre.model.ParametroPreAtendimento;
import br.com.hermespardini.passelivre.model.PreAtendimento;
import br.com.hermespardini.passelivre.model.UserAuth;
import br.com.hermespardini.passelivre.service.ClienteService;
import br.com.hermespardini.passelivre.service.LoginService;
import br.com.hermespardini.passelivre.service.PreAtendimentoService;
import br.com.hermespardini.passelivre.service.SenhaService;
import br.com.hermespardini.passelivre.utils.DataUtil;
import br.com.hermespardini.passelivre.utils.MensagemUtil;
import br.com.hermespardini.passelivre.utils.TotemUtil;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.bean.MainBean;

@ViewScoped
@ManagedBean
@SuppressWarnings("serial")
public class LoginckfBean extends MainBean {

	private UserAuth user;

	private boolean active0;
	private boolean active1;
	private boolean loggedIn;
	private String sessionId;
	private Integer activeIndex;
	private String mensagemAviso;
	private TipoServicoEnum tipoServico;
	private DetalhePreparacao detalhePreparacao;
	private List<InformacaoTotem> informacoesTotem;
	private ClienteUnidadePasseLivre clienteUnidadePasseLivre;
	private String inputCodBarras;
	private boolean semSenha;
	private List<ClienteUnidadePasseLivre> clientesUnidadePasseLivre;
	private ParametroConsultaClienteGuiche parametroConsultaCliente;

	@PostConstruct
	public void onLoad() {
		try {
			activeIndex = 0;
			user = new UserAuth();
			clienteUnidadePasseLivre = new ClienteUnidadePasseLivre();
			parametroConsultaCliente = new ParametroConsultaClienteGuiche();
			clientesUnidadePasseLivre = new ArrayList<>();
			buscarInformacoesTotem();
			buscarTipoServico();
			buscarDetalhePreparo();
			sessionId = buscarSessionId();
			inputCodBarras = "";
			this.semSenha = false;
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	private void buscarDetalhePreparo() {
		try {
			final HttpSession session = getHttpServletRequest().getSession();
			detalhePreparacao = (DetalhePreparacao) getHttpServletRequest().getSession()
					.getAttribute("detalhePreparacao");
		} catch (final Exception locExc) {
		}
	}

	private String buscarSessionId() {
		try {
			final HttpSession session = getHttpServletRequest().getSession();
			return session.getAttribute("sessionId").toString();
		} catch (final Exception locExc) {
			return "";
		}
	}

	private void buscarTipoServico() throws Exception {
		final HttpSession session = getHttpServletRequest().getSession();
		tipoServico = (TipoServicoEnum) session.getAttribute("tipoServico");
	}

	@SuppressWarnings("unchecked")
	private void buscarInformacoesTotem() {
		try {
			informacoesTotem = new ArrayList<>();
			final HttpSession session = getHttpServletRequest().getSession();
			informacoesTotem = (List<InformacaoTotem>) session.getAttribute("informacoesTotem");
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	public String buscarDadosCliente() {
		try {
			clientesUnidadePasseLivre.clear();

			final ClienteService clienteService = new ClienteService(getHttpServletRequest());

			if (botaoCPFEstaAtivado()) {

				parametroConsultaCliente.setCpf(user.getAuthKey());
				parametroConsultaCliente.setAuthKeyType("1");
				SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
				Date data = formato.parse(user.getBirthDate());
				parametroConsultaCliente.setBirthDate(data);

			} else {
				parametroConsultaCliente.setCodigo(user.getAuthKey());
			}

			parametroConsultaCliente = new ParametroConsultaClienteGuiche(TotemUtil.buscarToken(),
					parametroConsultaCliente);
			clienteService.consultaClienteGuiche(parametroConsultaCliente);
			clienteUnidadePasseLivre = new ClienteUnidadePasseLivre();
			if (clienteService.isSuccess() && clienteService.getResponseObject() != null) {
				clientesUnidadePasseLivre = (List<ClienteUnidadePasseLivre>) clienteService.getResponseObject();
				registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(),
						MensagemUtil.retornarMensagemAoBuscarDadosClientes(parametroConsultaCliente),
						TotemUtil.buscarSessionId(), createBasicLogMap());

				// se tiver mais de um Usuario tem q mudar
				clienteUnidadePasseLivre = clientesUnidadePasseLivre.get(0);

				adicionarAtributoEmSessaoAposLogin();
				return tipoServico.redirectAposLogin();

			} else {
				mensagemAviso = clienteService.getResponseMessage();
				exibirDialogMensagem();
				gerarLogErroAoBuscarDadosCliente(mensagemAviso);
			}
		} catch (

		final RegraNegocioException locExc) {
			locExc.printStackTrace();
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
			gerarLogErroAoBuscarDadosCliente(locExc.getMessage());
		} catch (final Exception locExcexc) {
			locExcexc.printStackTrace();
			mensagemAviso = locExcexc.getMessage();
			exibirDialogMensagem();
			gerarLogErroAoBuscarDadosCliente(locExcexc.getMessage());
		}
		return null;
	}

	private void gerarLogErroAoBuscarDadosCliente(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, retornarCodigoPesquisado());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, TotemUtil.buscarSessionId(),
					createBasicLogMap());
		} catch (final Exception exc) {
		}
	}

	private String retornarCodigoPesquisado() {
		try {
			if (parametroConsultaCliente.getCodigo() != null) {
				return parametroConsultaCliente.getCodigo();
			} else {
				return parametroConsultaCliente.getAuthKey();
			}
		} catch (final Exception locExc) {
			return "";
		}
	}

	public String entrar() {

		String page = "";

		if (semSenha && botaoCodigoEstaAtivado()) {
			page = buscarDadosCliente();
		} else if (!semSenha && botaoCodigoEstaAtivado()) {
			page = entrarComCodigo();
		} else if (!semSenha && botaoCPFEstaAtivado()) {
			page = entrarComCPF();
		} else {
			page = buscarDadosCliente();
		}
		return page;
	}

	public String entrarComCPF() {
		try {
			final LoginService loginService = new LoginService(getHttpServletRequest());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId, createBasicLogMap());
			RequestContext.getCurrentInstance().reset("frmPrincipal:idTabView:cpfClienteTab");
			user.setAuthKeyType(Constantes.CPFAUTHKEYTYPE);
			user.setBirthDate(formatarDataNascimentoParaRecebimento(user.getBirthDate()));
			clienteUnidadePasseLivre = (ClienteUnidadePasseLivre) loginService.logar(user);
			clienteUnidadePasseLivre.setCurrentPass(user.getAuthPass());
			adicionarAtributoEmSessaoAposLogin();
			return tipoServico.redirectAposLogin();
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			gerarLogErroAoEntrarComCPF(locExc);
			limparCampoLogin();
			mensagemAviso = locExc.getMessage();
			RequestContext.getCurrentInstance().execute("PF('dlgMessage').show()");
			/*
			 * final FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,
			 * "Erro", locExc.getMessage());
			 * RequestContext.getCurrentInstance().showMessageInDialog(message);
			 */

			return null;
		}
	}

	private void adicionarAtributoEmSessaoAposLogin() throws Exception {
		getHttpServletRequest().getSession().setAttribute("user", user);
		getHttpServletRequest().getSession().setAttribute("sessionId", sessionId);
		getHttpServletRequest().getSession().setAttribute("detalhePreparacao", detalhePreparacao);
		getHttpServletRequest().getSession().setAttribute("informacoesTotemDesktop", informacoesTotem);
		getHttpServletRequest().getSession().setAttribute("clienteUnidadePasseLivre", clienteUnidadePasseLivre);
		getHttpServletRequest().getSession().setAttribute("inputCodBarras", inputCodBarras);
		getHttpServletRequest().getSession().setAttribute("semSenha", semSenha);
	}

	public void onTabChange(final TabChangeEvent event) {
		final TabView tv = (TabView) event.getComponent();
		activeIndex = tv.getActiveIndex();
		limparCampoLogin();
	}

	private void gerarLogErroAoEntrarComCPF(final Exception locExc) {
		try {
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), locExc.getMessage(), sessionId,
					createBasicLogMap());
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	public void esquecerSenha() {
		try {
			String email = recuperarEmailCliente();
			if (email == null || email.equals("")) {
				mensagemAviso = "Cliente não possui e-mail cadastrado. Favor se dirigir a um guich� para atualizar o seu cadastro.";
				FacesContext.getCurrentInstance().validationFailed();
				RequestContext.getCurrentInstance().update("insertEmailDialogId");
				exibirDialogMensagem();
			} else {
				RequestContext.getCurrentInstance().update("insertEmailDialogId");
				getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
				registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId,
						createBasicLogMap());
			}
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	private void exibirDialogMensagem() {
		RequestContext.getCurrentInstance().execute("PF('dlgMessage').show()");
	}

	public String cancelarLogin() {
		try {
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId, createBasicLogMap());
			return redirectIndex();
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return "";
		}
	}

	public String redirectIndex() throws Exception {
		final String nomeMaquina = TotemUtil.retornarNomeDaMaquina();
		getSession().removeAttribute("indexBean");
		TotemUtil.limparSession();
		setLoggedIn(Boolean.FALSE);
		return "/indexTotem.xhtml?faces-redirect=true&nomeTotem=" + nomeMaquina;
	}

	private void limparCampoLogin() {
		user = new UserAuth();
		RequestContext.getCurrentInstance().reset("frmPrincipal:idTabView:codigoClienteTab");
		RequestContext.getCurrentInstance().reset("frmPrincipal:idTabView:cpfClienteTab");
	}

	private String formatarDataNascimentoParaRecebimento(final String dataNascimento) {
		return new FormataDataAnoMesDia(dataNascimento).formatar();
	}

	public String entrarComCodigo() {
		try {
			final LoginService loginService = new LoginService(getHttpServletRequest());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId, createBasicLogMap());
			user.setAuthKeyType(Constantes.CODEAUTHKEYTYPE);
			RequestContext.getCurrentInstance().reset("frmPrincipal:idTabView:codigoClienteTab");
			clienteUnidadePasseLivre = (ClienteUnidadePasseLivre) loginService.logar(user);
			clienteUnidadePasseLivre.setCurrentPass(user.getAuthPass());
			adicionarAtributoEmSessaoAposLogin();
			return tipoServico.redirectAposLogin();
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			mensagemAviso = locExc.getMessage();
			/*
			 * final FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,
			 * "Erro", locExc.getMessage());
			 * RequestContext.getCurrentInstance().showMessageInDialog(message);
			 */
			RequestContext.getCurrentInstance().execute("PF('dlgMessage').show()");
			gerarLogErroAoEntrarComCodigo(locExc);
			return null;
		}
	}

	public Boolean botaoCPFEstaAtivado() {
		getRequestContext().update("frmPrincipal:btnBotao");
		return activeIndex == 1;
	}

	private void verificarTipoLogin() {
		if (botaoCodigoEstaAtivado()) {
			user.setAuthKeyType(Constantes.CODEAUTHKEYTYPE);
		} else {
			user.setAuthKeyType(Constantes.CPFAUTHKEYTYPE);
			final String dataNascimentoRetorno = formatarDataNascimentoParaRecebimento(user.getBirthDate());
			user.setBirthDate(dataNascimentoRetorno);
		}
	}

	public Boolean botaoCodigoEstaAtivado() {
		getRequestContext().update("frmPrincipal:btnBotao");
		return activeIndex == 0;
	}

	private void gerarLogErroAoEntrarComCodigo(final Exception locExc) {
		try {
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), locExc.getMessage(), sessionId,
					createBasicLogMap());
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	public void recuperaSenha() {
		try {
			if (!user.getEmail().equals(clienteUnidadePasseLivre.getEmail())) {
				mensagemAviso = "E-mail informado não confere com o cadastrado para o cliente.";
				exibirDialogMensagem();
			} else {
				final SenhaService senhaService = new SenhaService(getHttpServletRequest());
				verificarTipoDeValidacao();
				registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId,
						createBasicLogMap());
				senhaService.recuperaSenha(user);
				if (senhaService.isSuccess()) {
					mensagemAviso = senhaService.getResponseMessage();
					/*
					 * final FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,
					 * "Info", senhaService.getResponseMessage());
					 * RequestContext.getCurrentInstance().showMessageInDialog(message);
					 */
					RequestContext.getCurrentInstance().execute("PF('dlgRecuperaEmail').hide()");
					RequestContext.getCurrentInstance().execute("PF('dlgMessage').show()");

				} else {
					/*
					 * final FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,
					 * "Erro", senhaService.getResponseMessage());
					 * RequestContext.getCurrentInstance().showMessageInDialog(message);
					 */
					mensagemAviso = senhaService.getResponseMessage();
					RequestContext.getCurrentInstance().execute("PF('dlgMessage').show()");
				}
				user.setEmail("");
			}
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			gerarLogErroAoRecuperarSenha(locExc);
		}
	}

	private void gerarLogErroAoRecuperarSenha(final Exception parExc) {
		try {
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parExc.getMessage(), sessionId,
					createBasicLogMap());
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	private void verificarTipoDeValidacao() {
		if (user.getAuthKey().length() != 11) {
			user.setAuthKeyType(Constantes.CODEAUTHKEYTYPE);
		} else {
			user.setAuthKeyType(Constantes.CPFAUTHKEYTYPE);
			final String dataNascimentoRetorno = formatarDataNascimentoParaRecebimento(user.getBirthDate());
			user.setBirthDate(dataNascimentoRetorno);
		}
	}

	private boolean entradaEhUsandoCodigoCliente() {
		return activeIndex == 1;
	}

	public void executarFuncaoExtra() {

	}

	public Boolean getHabilitarBotaoExtra() {
		return tipoServico.equals(TipoServicoEnum.CKM);
	}

	public String retornarBotaoPeloTipo() {
		return "";
	}

	public Integer getActiveIndex() {
		active0 = true;
		active1 = false;
		if (entradaEhUsandoCodigoCliente()) {
			active0 = false;
			active1 = true;
		}
		return activeIndex;
	}

	private String ipLocal() {
		try {
			return Util.getClientIpAddr(getHttpServletRequest());
		} catch (final Exception exc) {
			exc.printStackTrace();
			return "";
		}
	}

	public boolean habilitarCodigoDeBarra() {
		if (tipoServico.equals(TipoServicoEnum.PAT) || tipoServico.equals(TipoServicoEnum.EMP)) {
			return true;
		}
		return false;
	}

	public void abrirDialgCodigoBarra() {
		inputCodBarras = "";
		final RequestContext context = RequestContext.getCurrentInstance();
		context.execute("PF('dlgCodigoBarra').show();");
	}

	public String verificarCodBarras() {
		final RequestContext context = RequestContext.getCurrentInstance();
		try {
			if (inputCodBarras != null) {
				context.execute("PF('dlgCodigoBarra').hide();");
				registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(),
						"Código de barras lido: " + inputCodBarras, sessionId, createBasicLogMap());
				if (tipoServico.equals(TipoServicoEnum.PAT)) {
					return loginPreAtendimentoCodBarras();
				} else if (tipoServico.equals(TipoServicoEnum.EMP)) {
					return loginMaterialPendenteCodBarras();
				}
			}
		} catch (final Exception exc) {
			exc.printStackTrace();
			context.execute("PF('dlgCodigoBarra').hide();");
			mensagemAviso = exc.getMessage();
			TotemUtil.exibirDialogMensagem();
			return "";
		}
		return "";
	}

	public String loginPreAtendimentoCodBarras() {
		try {
			/*
			 * final ParametroPreAtendimento parametroPreAtendimento = new
			 * ParametroPreAtendimento(inputCodBarras, TotemUtil.buscarToken());
			 */
			// teste
			final ParametroPreAtendimento parametroPreAtendimento = new ParametroPreAtendimento("3",
					TotemUtil.buscarToken());
			// fim do teste
			final PreAtendimentoService preAtendimentoService = new PreAtendimentoService(getHttpServletRequest());
			final ClienteService clienteService = new ClienteService(getHttpServletRequest());
			preAtendimentoService.consultarPreAtendimento(parametroPreAtendimento);
			if (preAtendimentoService.isSuccess()) {
				final List<PreAtendimento> result = (List<PreAtendimento>) preAtendimentoService.getResponseObject();
				if (result != null && !result.isEmpty()) {
					final PreAtendimento preAtendimento = result.get(0);
					final Paciente paciente = preAtendimento.getPaciente();
					// clienteUnidadePasseLivre = clienteService.dePacienteParaCliente(paciente);
					// Essa parte é para testes
					final LoginService loginService = new LoginService(getHttpServletRequest());
					user.setAuthKeyType(Constantes.CODEAUTHKEYTYPE);
					user.setAuthKey("803425594");
					user.setAuthPass("931340");
					user.setPassword("931340");
					clienteUnidadePasseLivre = (ClienteUnidadePasseLivre) loginService.logar(user);
					// fim do teste
					getHttpServletRequest().getSession().setAttribute("preAtendimentoSelecionado", preAtendimento);
					adicionarAtributoEmSessaoAposLogin();
					FacesContext.getCurrentInstance().getExternalContext()
							.redirect("/passelivretotem" + tipoServico.redirectAposLogin());
					return "";
				} else {
					mensagemAviso = "Não foi encontrado pré atendimento";
					TotemUtil.exibirDialogMensagem();
				}
			} else {
				mensagemAviso = "Falha na consulta do código de barras.";
				TotemUtil.exibirDialogMensagem();
			}
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
		return "";
	}

	public String loginMaterialPendenteCodBarras() {
		try {
			adicionarAtributoEmSessaoAposLogin();
			FacesContext.getCurrentInstance().getExternalContext()
					.redirect("/passelivretotem/pages/emp/listaMateriaisPendetes.xhtml?faces-redirect=true&nomeTotem="
							+ TotemUtil.retornarNomeDaMaquina());
			return "";
		} catch (final Exception locExc) {
			mensagemAviso = "Falha na consulta do código de barras.";
			TotemUtil.exibirDialogMensagem();
			locExc.printStackTrace();
		}
		return "";
	}

	public String getTextoConfirmarEmail() {
		String emailCompleto = clienteUnidadePasseLivre.getEmail();
		StringBuilder sbEmail = new StringBuilder();
		StringBuilder sbDominio = new StringBuilder();
		if (isClienteTemEmail()) {
			sbEmail.append(emailCompleto.substring(0, emailCompleto.indexOf("@")));
			sbDominio.append(emailCompleto.substring(emailCompleto.indexOf("@")));

			for (int i = 1; i < sbEmail.toString().length() - 1; i++) {
				sbEmail.setCharAt(i, '*');
			}
			for (int i = 2; i < sbDominio.indexOf("."); i++) {
				sbDominio.setCharAt(i, '*');
			}
		}
		return "Confirme o seu e-mail: " + sbEmail.toString() + sbDominio.toString();
	}

	private String recuperarEmailCliente() {
		try {
			final DataUtil dataUtil = new DataUtil();
			final ClienteService clienteService = new ClienteService(getHttpServletRequest());
			ParametroConsultaCliente parametroConsultaCliente = new ParametroConsultaCliente();
			parametroConsultaCliente.setToken(TotemUtil.buscarToken().getToken());
			parametroConsultaCliente.setAuthKey(user.getAuthKey());
			if (user.getAuthKey().length() == 11) {
				parametroConsultaCliente.setAuthKeyType("1");
				parametroConsultaCliente.setAuthKey(user.getAuthKey());
			} else {
				parametroConsultaCliente.setAuthKeyType("2");
				if (user.getAuthKey().startsWith("0")) {
					parametroConsultaCliente.setAuthKey(user.getAuthKey().substring(1));
				} else {
					parametroConsultaCliente.setAuthKey(user.getAuthKey());
				}
			}
			parametroConsultaCliente.setOrigem(Constantes.ORIGEM_PADRAO);
			parametroConsultaCliente.setBirthDate(dataUtil.formatarStringBRParaString(user.getBirthDate()));
			clienteService.consultaCliente(parametroConsultaCliente);
			clienteUnidadePasseLivre = new ClienteUnidadePasseLivre();
			if (clienteService.isSuccess() && clienteService.getResponseObject() != null) {
				clienteUnidadePasseLivre = ((List<ClienteUnidadePasseLivre>) clienteService.getResponseObject()).get(0);
				if (clienteUnidadePasseLivre.getEmail() != null && !clienteUnidadePasseLivre.getEmail().equals("")) {
					return clienteUnidadePasseLivre.getEmail();
				} else {
					return null;
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;
	}

	public boolean isClienteTemEmail() {
		return clienteUnidadePasseLivre != null && clienteUnidadePasseLivre.getEmail() != null;
	}

	public Map createBasicLogMap() {
		Long idTotem = null;
		Long idUnidade = null;
		if (informacoesTotem != null && !informacoesTotem.isEmpty()) {
			idTotem = informacoesTotem.get(0).getId();
			idUnidade = Long.valueOf(informacoesTotem.get(0).getIdUnidade());
		}
		try {
			return TotemUtil.createBasicLogMap(idTotem, idUnidade, Util.getClientIpAddr(getHttpServletRequest()));
		} catch (Exception e) {
			e.printStackTrace();
			return new HashMap();
		}
	}

	public String redirectAtualizaDados() {
		return "/pages/emp/atualizarDados.xhtml?faces-redirect=true";
	}

	public UserAuth getUser() {
		return user;
	}

	public void setUser(final UserAuth parUser) {
		user = parUser;
	}

	public void setActiveIndex(final Integer parActiveIndex) {
		activeIndex = parActiveIndex;
	}

	public boolean isActive0() {
		return active0;
	}

	public boolean isActive1() {
		return active1;
	}

	public void setActive0(final boolean active0) {
		this.active0 = active0;
	}

	public void setActive1(final boolean active1) {
		this.active1 = active1;
	}

	public boolean isLoggedIn() {
		return loggedIn;
	}

	public void setLoggedIn(final boolean parLoggedIn) {
		loggedIn = parLoggedIn;
	}

	public String getMensagemAviso() {
		return mensagemAviso;
	}

	public void setMensagemAviso(final String parMensagemAviso) {
		mensagemAviso = parMensagemAviso;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(final String parSessionId) {
		sessionId = parSessionId;
	}

	public TipoServicoEnum getTipoServico() {
		return tipoServico;
	}

	public void setTipoServico(final TipoServicoEnum parTipoServico) {
		tipoServico = parTipoServico;
	}

	public DetalhePreparacao getDetalhePreparacao() {
		return detalhePreparacao;
	}

	public void setDetalhePreparacao(final DetalhePreparacao parDetalhePreparacao) {
		detalhePreparacao = parDetalhePreparacao;
	}

	public List<InformacaoTotem> getInformacoesTotem() {
		return informacoesTotem;
	}

	public void setInformacoesTotem(final List<InformacaoTotem> parInformacoesTotem) {
		informacoesTotem = parInformacoesTotem;
	}

	public ClienteUnidadePasseLivre getClienteUnidadePasseLivre() {
		return clienteUnidadePasseLivre;
	}

	public void setClienteUnidadePasseLivre(final ClienteUnidadePasseLivre parClienteUnidadePasseLivre) {
		clienteUnidadePasseLivre = parClienteUnidadePasseLivre;
	}

	public String getInputCodBarras() {
		return inputCodBarras;
	}

	public void setInputCodBarras(final String parInputCodBarras) {
		inputCodBarras = parInputCodBarras;
	}

	public boolean isSemSenha() {
		return semSenha;
	}

	public void setSemSenha(boolean semSenha) {
		this.semSenha = semSenha;
	}

	public List<ClienteUnidadePasseLivre> getClientesUnidadePasseLivre() {
		return clientesUnidadePasseLivre;
	}

	public void setClientesUnidadePasseLivre(List<ClienteUnidadePasseLivre> clientesUnidadePasseLivre) {
		this.clientesUnidadePasseLivre = clientesUnidadePasseLivre;
	}

	public ParametroConsultaClienteGuiche getParametroConsultaCliente() {
		return parametroConsultaCliente;
	}

	public void setParametroConsultaCliente(ParametroConsultaClienteGuiche parametroConsultaCliente) {
		this.parametroConsultaCliente = parametroConsultaCliente;
	}

}
