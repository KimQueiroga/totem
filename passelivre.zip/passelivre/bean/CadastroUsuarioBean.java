package br.com.hermespardini.passelivre.bean;

import java.io.IOException;
import java.text.ParseException;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.component.EditableValueHolder;
import javax.faces.component.UIComponent;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;
import javax.faces.context.PartialViewContext;
import javax.faces.view.ViewScoped;
import javax.servlet.http.HttpSession;

import org.primefaces.context.RequestContext;

import br.com.hermespardini.corebusiness.model.Cep;
import br.com.hermespardini.corebusiness.model.LogAplicacaoUsuarioFactory;
import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.format.FormataCep;
import br.com.hermespardini.passelivre.format.FormataCpf;
import br.com.hermespardini.passelivre.format.FormataDataAnoMesDia;
import br.com.hermespardini.passelivre.format.FormataDataDiaMesAno;
import br.com.hermespardini.passelivre.format.FormataEndereco;
import br.com.hermespardini.passelivre.format.FormataTelefone;
import br.com.hermespardini.passelivre.interfaces.FormataCampo;
import br.com.hermespardini.passelivre.model.ClienteUnidadePasseLivre;
import br.com.hermespardini.passelivre.model.ConsultaCepResult;
import br.com.hermespardini.passelivre.model.InformacaoTotem;
import br.com.hermespardini.passelivre.model.ParametroRegistraCliente;
import br.com.hermespardini.passelivre.model.RegistraResult;
import br.com.hermespardini.passelivre.model.TokenResult;
import br.com.hermespardini.passelivre.service.ClienteService;
import br.com.hermespardini.passelivre.utils.DataUtil;
import br.com.hermespardini.passelivre.utils.TotemUtil;
import br.com.hermespardini.web.bean.MainBean;
import br.com.hermespardini.passelivre.service.CepService;

@ViewScoped
@ManagedBean
public class CadastroUsuarioBean extends MainBean {

	private String mensagemAviso;
	private CepService cepService;
	private FormataCampo formataCampo;
	private FormataEndereco formataEndereco;
	private static final long serialVersionUID = 1L;
	private ClienteUnidadePasseLivre clienteUnidadePasseLivre;
	
	private String cep;
	private String bairro;
	private String numero;
	private String complemento;
	private boolean editarLogradouro;
	private boolean editarBairro;
	private String uf;
	private String cidade;
	private String logradouro;
	private TokenResult tokenResult;
	private List<InformacaoTotem> informacoesTotem;

	@PostConstruct
	public void onLoad() {
		try {
			formataEndereco = new FormataEndereco();
			cepService = new CepService(getHttpServletRequest());
			clienteUnidadePasseLivre = new ClienteUnidadePasseLivre();
			verificarSeClientePasseLivreExiste();
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	private void receberClientePasseLivre() {
		try {
			final HttpSession session = getHttpServletRequest().getSession();
			if ((ClienteUnidadePasseLivre) session.getAttribute("clienteUnidadePasseLivre") != null) {
				clienteUnidadePasseLivre = (ClienteUnidadePasseLivre) session.getAttribute("clienteUnidadePasseLivre");
			}
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	private void verificarSeClientePasseLivreExiste() {
		if (clienteUnidadePasseLivre.getCpf() == null) {
			receberClientePasseLivre();
		}
	}

	public void cadastrar() {
		String mensagem = "";
		try {
			final ClienteService clienteService = new ClienteService(getHttpServletRequest());
			validarEFormatarValores();
			formataEndereco.convertStreetAndComplement(clienteUnidadePasseLivre);
			ParametroRegistraCliente parRegistraCliente = new ParametroRegistraCliente(clienteUnidadePasseLivre);
			clienteService.registrarCliente(parRegistraCliente);
			// clienteService.setValueObject(clienteUnidadePasseLivre);
			// clienteService.cadastrar();
			if (clienteService.isSuccess()) {
				RegistraResult result = (RegistraResult) clienteService.getResponseObject();
				clienteUnidadePasseLivre.setCodigoCliente(result.getIdCliente());
				clienteService.setValueObject(clienteUnidadePasseLivre);
				// clienteService.atualizar();
				acoesAposCadastro();
			} else {
				mensagem = clienteService.getResponseMessage();
				formatarValoresAposErroCadastro();
				mensagemAviso = clienteService.getResponseMessage();
				RequestContext.getCurrentInstance().execute("PF('dlgMessage').show()");
			}
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			mensagemAviso = locExc.getMessage();
			RequestContext.getCurrentInstance().execute("PF('dlgMessage').show()");
		}
	}

	public void cadastrarNoGuiche() {
		String mensagem = "";
		try {
			final ClienteService clienteService = new ClienteService(getHttpServletRequest());
			validarEFormatarValoresGuiche();
			clienteService.setValueObject(clienteUnidadePasseLivre);
			ParametroRegistraCliente parRegistraCliente = new ParametroRegistraCliente(clienteUnidadePasseLivre);
			clienteService.registrarCliente(parRegistraCliente);
			if (clienteService.isSuccess()) {
				RegistraResult result = (RegistraResult) clienteService.getResponseObject();
				clienteUnidadePasseLivre.setCodigoCliente(result.getIdCliente());
				clienteService.setValueObject(clienteUnidadePasseLivre);
				// clienteService.atualizar();
				acoesAposCadastroNoGuiche();
			} else {
				mensagem = clienteService.getResponseMessage();
				formatarValoresAposErroCadastro();
				mensagemAviso = clienteService.getResponseMessage();
				RequestContext.getCurrentInstance().execute("PF('dlgMessage').show()");
			}
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			mensagemAviso = locExc.getMessage();
			RequestContext.getCurrentInstance().execute("PF('dlgMessage').show()");
		}
	}

	private void formatarValoresAposErroCadastro() throws Exception {
		try {
			clienteUnidadePasseLivre
					.setDataNascimento(formatarDataNascimento(clienteUnidadePasseLivre.getDataNascimento()));
			clienteUnidadePasseLivre.setCelular(formatarTelefone(clienteUnidadePasseLivre.getCelular()));
			clienteUnidadePasseLivre.setTipo(Constantes.TIPO_CLIENTE);
			clienteUnidadePasseLivre.setTelefone(formatarTelefone(clienteUnidadePasseLivre.getTelefone()));
			clienteUnidadePasseLivre.setCep(formatarCep(clienteUnidadePasseLivre.getCep()));
			clienteUnidadePasseLivre.setCpf(formatarCpf(clienteUnidadePasseLivre.getCpf()));
		} catch (final Exception e) {
			throw new Exception("Erro ao formatar os dados!");
		}
	}

	private void acoesAposCadastro() throws Exception, IOException {
		final HttpSession session = getHttpServletRequest().getSession();
		clienteUnidadePasseLivre.getDataNascimento();
		session.setAttribute("clienteUnidadePasseLivre", clienteUnidadePasseLivre);
		formatarValoresAposCadastro();
		FacesContext.getCurrentInstance().getExternalContext().redirect("atualizarDados.xhtml");
	}

	private void acoesAposCadastroNoGuiche() throws Exception, IOException {
		clienteUnidadePasseLivre.getDataNascimento();
		formatarValoresAposCadastro();
		FacesContext.getCurrentInstance().getExternalContext().redirect("atualizarDados.xhtml");
	}

	private void validarEFormatarValoresGuiche() throws RegraNegocioException, Exception {
		clienteUnidadePasseLivre.verificarCamposEmBranco();
		clienteUnidadePasseLivre.validarEmail();
		formatarValoresGuiche();
	}

	private void validarEFormatarValores() throws RegraNegocioException, Exception {
		clienteUnidadePasseLivre.verificarCamposEmBranco();
		clienteUnidadePasseLivre.validarEmail();
		clienteUnidadePasseLivre.validarSenhas();
		formatarValores();
	}

	public String cancelar() {
		try {
			return redirectIndex();
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return "";
		}
	}

	public String redirectIndex() throws Exception {
		final String nomeMaquina = TotemUtil.retornarNomeDaMaquina();
		getSession().removeAttribute("indexBean");
		TotemUtil.limparSession();
		return "/indexTotem.xhtml?faces-redirect=true&nomeTotem=" + nomeMaquina;
	}

	public void pesquisarCep() {
		try {
			final FacesContext facesContext = FacesContext.getCurrentInstance();
			final PartialViewContext partialViewContext = facesContext.getPartialViewContext();
			final Collection<String> renderIds = partialViewContext.getRenderIds();
			final UIViewRoot viewRoot = getContext().getViewRoot();
			for (final String renderId : renderIds) {
				final UIComponent component = viewRoot.findComponent(renderId);
				final EditableValueHolder input = (EditableValueHolder) component;
				if (input != null) {
					input.resetValue();
				} else {
					limparCamposEndereco();
				}
			}
			adicionarEnderecoPeloCEP();
		} catch (final NullPointerException locE) {
			limparCamposEndereco();
			gerarLogAoBuscarCEP("CEP não existe!");
		} catch (final Exception locE) {
			limparCamposEndereco();
			gerarLogAoBuscarCEP(locE.getMessage());
		}
	}
	
	private void adicionarEnderecoPeloCEP() throws Exception {
		String cep = getClienteUnidadePasseLivre().getCep().replaceAll("[^0-9]", "");
		tokenResult = TotemUtil.buscarToken();
		if (cep.length() == 8) {
			final CepService cepService = new CepService(getHttpServletRequest());
			ConsultaCepResult cepResult = cepService.consultarCep(cep, tokenResult.getToken());
			if (cepService.isSuccess()) {
				if (cepResult != null) {
					adiconarEnderecoAoCliente(cepResult);
				} else {
					limparCamposEndereco();
					exibirDialogMensagemAlert("CEP não encontrado!");
				}
			} else {
				limparCamposEndereco();
				exibirDialogMensagemAlert("CEP não encontrado!");
			}
		} else {
			limparCamposEndereco();
			exibirDialogMensagemAlert("CEP deve conter 8 caracteres numéricos!");
		}		
	}
	
	private void gerarLogAoBuscarCEP(final String mensagem) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, retornarCPF());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), mensagem, TotemUtil.buscarSessionId(),
					createBasicLogMap());
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}
	
	private String retornarCPF() {
		try {
			if (clienteUnidadePasseLivre.getCpf() != null) {
				return clienteUnidadePasseLivre.getCpf();
			} else {
				return "";
			}
		} catch (final Exception locExc) {
			return "";
		}
	}
	
	public Map createBasicLogMap() {
		Long idTotem = null;
		Long idUnidade = null;
		if (informacoesTotem != null && !informacoesTotem.isEmpty()) {
			idTotem = informacoesTotem.get(0).getId();
			idUnidade = Long.valueOf(informacoesTotem.get(0).getIdUnidade());
		}
		try {
			return TotemUtil.createBasicLogMap(idTotem, idUnidade, getHttpServletRequest().getRemoteAddr());
		} catch (Exception e) {
			e.printStackTrace();
			return new HashMap();
		}
	}
	
	private void exibirDialogMensagemAlert(String msg) {
		setMensagemAviso(msg);
//		PrimeFaces.current().executeScript("PF('dlgMessageAviso').show()");
	}

	private void limparCamposEndereco() {
		clienteUnidadePasseLivre.limparCamposEndereco();
	}

	private String redirectAtualizarUsuario() {
		return "/pages/nau/atualizarDados.xhtml?faces-redirect=true";
	}

	private String formatarCep(final String cep) {
		formataCampo = new FormataCep(cep);
		return formataCampo.formatar();
	}

//	private void verificarSeCepFoiBuscado() throws Exception {
//		if (cepService.isSuccess()) {
//			final Cep cep = (Cep) cepService.getResponseObject();
//			if (cepELogradouroNaoEstaoNulos(cep)) {
//				adiconarEnderecoAoCliente(cep);
//			} else {
//				mensagemAviso = "Falhar ao buscar o CEP!";
//				RequestContext.getCurrentInstance().execute("PF('dlgMessage').show()");
//			}
//		}
//	}

	private boolean cepELogradouroNaoEstaoNulos(final Cep cep) {
		return cep != null;
	}

	private void adiconarEnderecoAoCliente(ConsultaCepResult consultaCepResult) {
		clienteUnidadePasseLivre.setUf(consultaCepResult.getUf());
		clienteUnidadePasseLivre.setCidade(consultaCepResult.getLocalidade());
		clienteUnidadePasseLivre.setLogradouro(montarEnderecoLogradouro(consultaCepResult));
		clienteUnidadePasseLivre.setBairro(consultaCepResult.getBairro() != null ? consultaCepResult.getBairro() : "");
		clienteUnidadePasseLivre.setNumero("");
		clienteUnidadePasseLivre.setComplemento("");
		
		if(clienteUnidadePasseLivre.getLogradouro().equals(""))
			setEditarLogradouro(true);
		else
			setEditarLogradouro(false);
		
		if(clienteUnidadePasseLivre.getBairro().equals(""))
			setEditarBairro(true);
		else
			setEditarBairro(false);
	}
	
	private String montarEnderecoLogradouro(ConsultaCepResult consultaCepResult) {
		if(consultaCepResult.getLogradouro() != null && !consultaCepResult.getLogradouro().equals("") && consultaCepResult.getTipoEndereco() != null && !consultaCepResult.getTipoEndereco().equals(""))
			return consultaCepResult.getTipoEndereco() + " " + consultaCepResult.getLogradouro();
		else if(consultaCepResult.getLogradouroAbreviado() != null && !consultaCepResult.getLogradouroAbreviado().equals(""))
			return consultaCepResult.getLogradouroAbreviado();		
		else {
			return "";
		}
	}

//	private void buscarCep(final String cep) throws Exception {
//		try {
//			cepService = new CepService(getHttpServletRequest());
//			cepService.getCep(cep);
//		} catch (final Exception locExc) {
//			throw new Exception("Erro ao buscar o CEP!" + locExc.getMessage());
//		}
//	}

	private void formatarValoresGuiche() throws Exception {
		try {
			clienteUnidadePasseLivre.setDataNascimento(
					formatarDataNascimentoParaRecebimento(clienteUnidadePasseLivre.getDataNascimento()));
			clienteUnidadePasseLivre.setCelular(formatarTelefone(clienteUnidadePasseLivre.getCelular()));
			clienteUnidadePasseLivre.setTipo(Constantes.TIPO_CLIENTE);
			clienteUnidadePasseLivre.setTelefone(formatarTelefone(clienteUnidadePasseLivre.getTelefone()));
			clienteUnidadePasseLivre.setCep(formatarCep(clienteUnidadePasseLivre.getCep()));
			clienteUnidadePasseLivre.setCpf(formatarCpf(clienteUnidadePasseLivre.getCpf()));
		} catch (final Exception e) {
			throw new Exception("Erro ao formatar os dados!");
		}
	}

	private void formatarValores() throws Exception {
		try {
			clienteUnidadePasseLivre.setDataNascimento(
					formatarDataNascimentoParaRecebimento(clienteUnidadePasseLivre.getDataNascimento()));
			clienteUnidadePasseLivre.setCelular(formatarTelefone(clienteUnidadePasseLivre.getCelular()));
			clienteUnidadePasseLivre.setTipo(Constantes.TIPO_CLIENTE);
			clienteUnidadePasseLivre.setTelefone(formatarTelefone(clienteUnidadePasseLivre.getTelefone()));
			clienteUnidadePasseLivre.setCep(formatarCep(clienteUnidadePasseLivre.getCep()));
			clienteUnidadePasseLivre.setCpf(formatarCpf(clienteUnidadePasseLivre.getCpf()));
		} catch (final Exception e) {
			throw new Exception("Erro ao formatar os dados!");
		}
	}

	public String formatarDataNascimento(final String data) {
		try {
			final DataUtil dataUtil = new DataUtil();
			return dataUtil.formatarStringParaStringBR(data);
		} catch (final ParseException exc) {
			exc.printStackTrace();
			return "";
		}
	}

	private void formatarValoresAposCadastro() throws Exception {
		try {
			clienteUnidadePasseLivre.setCelular(formatarTelefone(clienteUnidadePasseLivre.getCelular()));
			clienteUnidadePasseLivre.setTipo(Constantes.TIPO_CLIENTE);
			clienteUnidadePasseLivre.setTelefone(formatarTelefone(clienteUnidadePasseLivre.getTelefone()));
			clienteUnidadePasseLivre.setCep(formatarCep(clienteUnidadePasseLivre.getCep()));
			clienteUnidadePasseLivre.setCpf(formatarCpf(clienteUnidadePasseLivre.getCpf()));
		} catch (final Exception e) {
			throw new Exception("Erro ao formatar os dados!");
		}
	}

	private String formatarDataNascimentoParaRecebimento(final String dataNascimento) {
		formataCampo = new FormataDataAnoMesDia(dataNascimento);
		return formataCampo.formatar();
	}

	private String formatarDataNascimentoParaEnvio(final String dataNascimento) {
		formataCampo = new FormataDataDiaMesAno(dataNascimento);
		return formataCampo.formatar();
	}

	private String formatarCpf(final String cpf) {
		formataCampo = new FormataCpf(cpf);
		return formataCampo.formatar();
	}

	private String formatarTelefone(final String telefone) {
		formataCampo = new FormataTelefone(telefone);
		return formataCampo.formatar();
	}

//	public void pesquisarCep(final String cep) {
//		try {
//			cepService.getCep(cep);
//		} catch (final Exception locExc) {
//			locExc.printStackTrace();
//		}
//	}

	public ClienteUnidadePasseLivre getClienteUnidadePasseLivre() {
		return clienteUnidadePasseLivre;
	}

	public void setClienteUnidadePasseLivre(final ClienteUnidadePasseLivre clienteUnidadePasseLivre) {
		this.clienteUnidadePasseLivre = clienteUnidadePasseLivre;
	}

	public String getMensagemAviso() {
		return mensagemAviso;
	}

	public void setMensagemAviso(final String parMensagemAviso) {
		mensagemAviso = parMensagemAviso;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getComplemento() {
		return complemento;
	}

	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}

	public boolean isEditarLogradouro() {
		return editarLogradouro;
	}

	public void setEditarLogradouro(boolean editarLogradouro) {
		this.editarLogradouro = editarLogradouro;
	}

	public boolean isEditarBairro() {
		return editarBairro;
	}

	public void setEditarBairro(boolean editarBairro) {
		this.editarBairro = editarBairro;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getLogradouro() {
		return logradouro;
	}

	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}

}
