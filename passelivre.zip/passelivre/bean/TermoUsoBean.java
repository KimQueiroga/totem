
package br.com.hermespardini.passelivre.bean;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.servlet.http.HttpSession;

import br.com.hermespardini.passelivre.constantsenum.TipoServicoEnum;
import br.com.hermespardini.passelivre.model.InformacaoTotem;
import br.com.hermespardini.passelivre.model.TokenResult;
import br.com.hermespardini.passelivre.utils.TotemUtil;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.bean.MainBean;

@ManagedBean
public class TermoUsoBean extends MainBean {

	private String sessionId;
	private TokenResult tokenResult;
	private TipoServicoEnum tipoServico;
	private List<InformacaoTotem> informacoesTotem;
	private String descricaoTermoUso;

	@PostConstruct
	public void onLoad() {
		buscarInformacoesTotem();
		buscarToken();
		buscarSessionId();
		buscarTipoServico();
	}

	private void buscarTipoServico() {
		try {
			final HttpSession session = getHttpServletRequest().getSession();
			tipoServico = (TipoServicoEnum) session.getAttribute("tipoServico");
			descricaoTermoUso = new String(tipoServico.descricaoTermoUso().getBytes());
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	private void buscarSessionId() {
		try {
			final HttpSession session = getHttpServletRequest().getSession();
			sessionId = session.getAttribute("sessionId").toString();
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	private void buscarToken() {
		try {
			tokenResult = new TokenResult();
			final HttpSession session = getHttpServletRequest().getSession();
			tokenResult = (TokenResult) session.getAttribute("tokenResult");
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	private void buscarInformacoesTotem() {
		try {
			informacoesTotem = new ArrayList<>();
			final HttpSession session = getHttpServletRequest().getSession();
			informacoesTotem = (List<InformacaoTotem>) session.getAttribute("informacoesTotem");
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	public String aceitarTermo() {
		try {
			// adicionarAtributoEmSessaoAposAceitar();
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId, createBasicLogMap());
			return tipoServico.aceitar();
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return "";
		}
	}

	private void adicionarAtributoEmSessaoAposAceitar() throws Exception {
		getHttpServletRequest().getSession().setAttribute("sessionId", sessionId);
		getHttpServletRequest().getSession().setAttribute("tipoServico", tipoServico);
		getHttpServletRequest().getSession().setAttribute("tokenResult", tokenResult);
		getHttpServletRequest().getSession().setAttribute("informacoesTotem", informacoesTotem);
		System.out.println(getHttpServletRequest().getCharacterEncoding());
	}

	public String getMensagemTermoUso() throws Exception {
		final HttpSession session = getHttpServletRequest().getSession();
	    tipoServico = (TipoServicoEnum) session.getAttribute("tipoServico");
	    return tipoServico.descricaoTermoUso();//new String(tipoServico.descricaoTermoUso().getBytes(), StandardCharsets.UTF_8);
	}

	public String naoAceitarTermo() {
		final String nomeMaquina = TotemUtil.retornarNomeDaMaquina();
		return "/indexTotem.xhtml?faces-redirect=true&nomeTotem=" + nomeMaquina;
	}

	public Map createBasicLogMap() {
		Long idTotem = null;
		Long idUnidade = null;
		if (informacoesTotem != null && !informacoesTotem.isEmpty()) {
			idTotem = informacoesTotem.get(0).getId();
			idUnidade = Long.valueOf(informacoesTotem.get(0).getIdUnidade());
		}
		try {
			return TotemUtil.createBasicLogMap(idTotem, idUnidade, Util.getClientIpAddr(getHttpServletRequest()));
		} catch (Exception e) {
			e.printStackTrace();
			return new HashMap();
		}
	}

	public TipoServicoEnum getTipoServico() {
		return tipoServico;
	}

	public String getDescricaoTermoUso() {
		return descricaoTermoUso;
	}

	public void setDescricaoTermoUso(String descricaoTermoUso) {
		this.descricaoTermoUso = descricaoTermoUso;
	}

}
