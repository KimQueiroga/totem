package br.com.hermespardini.passelivre.bean;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.primefaces.context.RequestContext;

import br.com.hermespardini.corebusiness.model.LogAplicacaoUsuarioFactory;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.format.FormataEndereco;
import br.com.hermespardini.passelivre.model.ClienteUnidadePasseLivre;
import br.com.hermespardini.passelivre.model.InformacaoTotem;
import br.com.hermespardini.passelivre.model.ParametroConsultaClienteGuiche;
import br.com.hermespardini.passelivre.service.ClienteService;
import br.com.hermespardini.passelivre.utils.DataUtil;
import br.com.hermespardini.passelivre.utils.MensagemUtil;
import br.com.hermespardini.passelivre.utils.TotemUtil;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.bean.MainBean;

@ManagedBean
@ViewScoped
public class PesquisaUsuarioBean extends MainBean {

	private ParametroConsultaClienteGuiche parametroConsultaCliente;
	private List<ClienteUnidadePasseLivre> clientesUnidadePasseLivre;
	private ClienteUnidadePasseLivre clienteUnidadeSelecionado;
	private ClienteUnidadePasseLivre clienteUnidadePasseLivre;
	private String mensagemAviso;
	private FormataEndereco formataEndereco;
	private DataUtil dataUtil;

	@PostConstruct
	public void onload() {
		clientesUnidadePasseLivre = new ArrayList<>();
		parametroConsultaCliente = new ParametroConsultaClienteGuiche();
		formataEndereco = new FormataEndereco();
		clienteUnidadePasseLivre = new ClienteUnidadePasseLivre();
		clienteUnidadeSelecionado = new ClienteUnidadePasseLivre();
		dataUtil = new DataUtil();
	}

	public void buscarDadosCliente() {
		try {
			clientesUnidadePasseLivre.clear();
			final ClienteService clienteService = new ClienteService(getHttpServletRequest());
			parametroConsultaCliente = new ParametroConsultaClienteGuiche(TotemUtil.buscarToken(),
					parametroConsultaCliente);
			clienteService.consultaClienteGuiche(parametroConsultaCliente);
			clienteUnidadePasseLivre = new ClienteUnidadePasseLivre();
			if (clienteService.isSuccess() && clienteService.getResponseObject() != null) {
				clientesUnidadePasseLivre = (List<ClienteUnidadePasseLivre>) clienteService.getResponseObject();
				registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(),
						MensagemUtil.retornarMensagemAoBuscarDadosClientes(parametroConsultaCliente),
						TotemUtil.buscarSessionId(), createBasicLogMap());
			} else {
				mensagemAviso = clienteService.getResponseMessage();
				exibirDialogMensagem();
				gerarLogErroAoBuscarDadosCliente(mensagemAviso);
			}
		} catch (

		final RegraNegocioException locExc) {
			locExc.printStackTrace();
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
			gerarLogErroAoBuscarDadosCliente(locExc.getMessage());
		} catch (final Exception locExcexc) {
			locExcexc.printStackTrace();
			mensagemAviso = locExcexc.getMessage();
			exibirDialogMensagem();
			gerarLogErroAoBuscarDadosCliente(locExcexc.getMessage());
		}
	}

	public void cancelar() {
		TotemUtil.retornaIndex();
	}

	private void gerarLogErroAoBuscarDadosCliente(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, retornarCodigoPesquisado());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, TotemUtil.buscarSessionId(),
					createBasicLogMap());
		} catch (final Exception exc) {
		}
	}

	private String retornarCodigoPesquisado() {
		try {
			if (parametroConsultaCliente.getCodigo() != null) {
				return parametroConsultaCliente.getCodigo();
			} else {
				return parametroConsultaCliente.getAuthKey();
			}
		} catch (final Exception locExc) {
			return "";
		}
	}

	public String retornarCPFValido(final String parCpf) {
		try {
			return parCpf.substring(0, 3) + "." + parCpf.substring(3, 6) + "." + parCpf.substring(6, 9) + "-"
					+ parCpf.substring(9);
		} catch (final Exception locExc) {
			return "";
		}
	}

	public void irParaTelaAtualizacaoDados() {
		try {
			mensagemAviso = "";
			if (clienteNaoFoiSelecionado()) {
				adicionarValoresAoCadastro();
				FacesContext.getCurrentInstance().getExternalContext().redirect(redirectCadastroUsuario());
			} else {
				verificarSerUsuarioFoiSelecionado();
				clienteUnidadePasseLivre = clienteUnidadeSelecionado;

				formatarEndereco();
				FacesContext.getCurrentInstance().getExternalContext().redirect(redirectAtualizacaoUsuario());
			}
		} catch (final RegraNegocioException locExc) {
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
		}
	}

	private void verificarSerUsuarioFoiSelecionado() throws RegraNegocioException {
		if (clienteNaoFoiSelecionado()) {
			throw new RegraNegocioException("Cliente deve ser selecionado!");
		}
	}

	private boolean clienteNaoFoiSelecionado() {
		try {
			return clienteUnidadeSelecionado.getCodigoCliente() == null;
		} catch (final Exception locExc) {
			return true;
		}
	}

	public boolean exibirAvancar() {
		try {
			return clienteUnidadeSelecionado.getCodigoCliente() != null;
		} catch (final Exception locExc) {
			return true;
		}
	}

	public void unselectRow() {
		clienteUnidadeSelecionado = new ClienteUnidadePasseLivre();
	}

	private String redirectAtualizacaoUsuario() {
		try {
			getHttpServletRequest().getSession().setAttribute("clienteUnidadePasseLivre", clienteUnidadePasseLivre);
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
		return "/passelivretotem/pages/atualizarDados.xhtml?faces-redirect=true";
	}

	private String redirectCadastroUsuario() {
		return "/passelivretotem/pagesGuiche/nau/cadastroUsuario.xhtml?faces-redirect=true";
	}

	private void exibirDialogMensagem() {
		RequestContext.getCurrentInstance().execute("PF('dlgMessage').show()");
	}

	private void formatarEndereco() throws Exception {
		formataEndereco.formataEnderecoAoLogar(clienteUnidadePasseLivre);
	}

	private void adicionarValoresAoCadastro() {
		try {
			clienteUnidadePasseLivre = new ClienteUnidadePasseLivre();
			clienteUnidadePasseLivre.setCpf(parametroConsultaCliente.getCpf());
			clienteUnidadePasseLivre.setDataNascimento(retornarDataNascimentoFormatada());
		} catch (final Exception locExc) {
		}
	}

	private String retornarDataNascimentoFormatada() {
		try {
			final SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			return sdf.format(parametroConsultaCliente.getBirthDate());
		} catch (final Exception locExc) {
			return "";
		}
	}

	public String formatarDataNascimento(final String data) {
		try {
			return dataUtil.formatarStringParaStringBR(data);
		} catch (final ParseException exc) {
			return "";
		}
	}

	public Map createBasicLogMap() {
		Long idTotem = null;
		Long idUnidade = null;
		List<InformacaoTotem> informacoesTotem = TotemUtil.buscarInformacoesTotem();
		if (informacoesTotem != null && !informacoesTotem.isEmpty()) {
			idTotem = informacoesTotem.get(0).getId();
			idUnidade = Long.valueOf(informacoesTotem.get(0).getIdUnidade());
		}
		try {
			return TotemUtil.createBasicLogMap(idTotem, idUnidade, Util.getClientIpAddr(getHttpServletRequest()));
		} catch (Exception e) {
			e.printStackTrace();
			return new HashMap();
		}
	}

	public ParametroConsultaClienteGuiche getParametroConsultaCliente() {
		return parametroConsultaCliente;
	}

	public void setParametroConsultaCliente(final ParametroConsultaClienteGuiche parParametroConsultaCliente) {
		parametroConsultaCliente = parParametroConsultaCliente;
	}

	public List<ClienteUnidadePasseLivre> getClientesUnidadePasseLivre() {
		return clientesUnidadePasseLivre;
	}

	public void setClientesUnidadePasseLivre(final List<ClienteUnidadePasseLivre> parClientesUnidadePasseLivre) {
		clientesUnidadePasseLivre = parClientesUnidadePasseLivre;
	}

	public ClienteUnidadePasseLivre getClienteUnidadeSelecionado() {
		return clienteUnidadeSelecionado;
	}

	public void setClienteUnidadeSelecionado(final ClienteUnidadePasseLivre parClienteUnidadeSelecionado) {
		clienteUnidadeSelecionado = parClienteUnidadeSelecionado;
	}

	public ClienteUnidadePasseLivre getClienteUnidadePasseLivre() {
		return clienteUnidadePasseLivre;
	}

	public void setClienteUnidadePasseLivre(final ClienteUnidadePasseLivre parClienteUnidadePasseLivre) {
		clienteUnidadePasseLivre = parClienteUnidadePasseLivre;
	}

	public String getMensagemAviso() {
		return mensagemAviso;
	}

	public void setMensagemAviso(final String parMensagemAviso) {
		mensagemAviso = parMensagemAviso;
	}

	public FormataEndereco getFormataEndereco() {
		return formataEndereco;
	}

	public void setFormataEndereco(final FormataEndereco parFormataEndereco) {
		formataEndereco = parFormataEndereco;
	}
}
