package br.com.hermespardini.passelivre.bean;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import br.com.hermespardini.passelivre.dao.ExamesCalculadosDAO;
import br.com.hermespardini.passelivre.model.ExamePreCalculado;
import br.com.hermespardini.passelivre.model.ExameSimplificado;
import br.gov.ans.www.padroes.tiss.schemas.Ct_itemSolicitacao;
import br.gov.ans.www.padroes.tiss.schemas.Ct_tabela;

public class ExamesCalculadosBean {
	
	/**
	 * método para verificar se há exames calculados - retornar o procedimentoComExamesTO com a parte do ExamesCalculados preenchido
	 * 												 - receber
	 */
	
	/**
	 * método para 'calcular' exames - retorna o procedimentoComExamesTO com os exames 'calculados'
	 * 								 - 
	 */
	
	/**
	 * 1 método para cada tipo de calculo de exames
	 * 1 - 1 para vários (desmembrar)
	 * 2 - 1 para vários (adicionar)
	 * 2 - vários para um (unir)
	 * 
	 */
	
	public boolean existeExamesCalculos1(List<String> codigosGuia) {
		Collections.sort(codigosGuia);
		Set<String> listaCodigosPais = ExamesCalculadosDAO.getCombinacaoCompletaCodigos().keySet();
		
		for (String codigoExameCalc : listaCodigosPais) {
			List<String> listCodigosExameCalc = Arrays.asList(codigoExameCalc.split(","));
			Collections.sort(listCodigosExameCalc);
			
			if (codigosGuia.contains(codigoExameCalc)) {
				return true;//pai contido na combinacao
			}
			else if (codigosGuia.containsAll(listCodigosExameCalc)) {
				return true;//pai contido na guia
			}
		}
		return false;
	}
	
	public boolean existeExamesCalculos(List<ExamePreCalculado> examesPreCalculados) {
		Collections.sort(examesPreCalculados);
		Set<List<ExamePreCalculado>> listaExamesPreCalcPais = ExamesCalculadosDAO.getCombinacaoCompletaExCalcs().keySet();
		
		for (List<ExamePreCalculado> exameCalcPais : listaExamesPreCalcPais) {
			Collections.sort(exameCalcPais);
			
//			if (examesPreCalculados.contains(listaExameCalcPais)) {
//				return true;//pai contido na combinacao
//			}
//			else if (examesPreCalculados.containsAll(exameCalcPais)) {
//				return true;//pai contido na guia
//			}
			if (ExamesCalculadosDAO.contemTodosFilhosCod(examesPreCalculados, exameCalcPais)) {
				return true;//filhos contido na guia
			}
		}
		return false;
	}
//	
//	public Ct_itemSolicitacao castExameSimplificado(ExameSimplificado simplificado) {
//		return new Ct_itemSolicitacao();
//	}
//	
	
	public Map<ExameSimplificado, List<ExameSimplificado>> getPossiveisCalculosNew(List<Ct_itemSolicitacao> procedimentosGuia, List<ExamePreCalculado> procedimentosPreCalculados) {
		Map<ExameSimplificado, List<ExameSimplificado>> paisFilhos = new HashMap<ExameSimplificado, List<ExameSimplificado>>();
				
		Map<List<ExamePreCalculado>, ExamePreCalculado> paiFilhoCombNew = ExamesCalculadosDAO.getCombinacaoCompletaExCalcs();
		
		
		for (List<ExamePreCalculado> examesChavesPreCalc: paiFilhoCombNew.keySet()) {
			List<ExameSimplificado> filhos = new ArrayList<ExameSimplificado>();
			for (ExamePreCalculado examePreCalculado: procedimentosPreCalculados) {
//				Integer qtdFilhosExamesCalc = examesChavesPreCalc.size();
//				if (examesPaisPreCalc.size() == 1) {
//					//verifica relação de demembramento (1 pai, 1 ou mais filhos)
//					
//				}
//				else {
//					
//				}
//				if (procedimentosPreCalculados.containsAll(examesChavesPreCalc)
//						&& !jaPossuiExamePreCalc(paisFilhos, paiFilhoCombNew.get(examesChavesPreCalc)) 
//						&& examesChavesPreCalc.contains(examePreCalculado)) {
//					List<ExameSimplificado> filhosAdicionados = new ArrayList<ExameSimplificado>();
//					
//					for (ExamePreCalculado exameChavePreCalc: examesChavesPreCalc) {						
//						if (examesChavesPreCalc.size() != qtdFilhosPreenchido) {
//							qtdFilhosPreenchido++;
//							filhosAdicionados.add(ExamesCalculadosDAO.getExameSimplificadoByExamPreCalc(exameChavePreCalc));
//						}
//					}
//					paisFilhos.put(
//							ExamesCalculadosDAO.getExameSimplificadoPaiUniaoByCod(paiFilhoCombNew.get(examesChavesPreCalc).getCodigo()),
//							filhosAdicionados
//							);
//					qtdFilhosPreenchido = 0;
//				}
				if (ExamesCalculadosDAO.contemTodosFilhosCod(procedimentosPreCalculados, examesChavesPreCalc) // procedimentosPreCalculados(examesChavesPreCalc)
						&& examesChavesPreCalc.stream().anyMatch(examCalc -> examCalc.getCodigo().equals(examePreCalculado.getCodigo()))
						&& !existeOutroFilhoMaisCompativel(procedimentosPreCalculados, paiFilhoCombNew.get(examesChavesPreCalc), examePreCalculado)
						) {
					
					ExameSimplificado pai = ExamesCalculadosDAO.getExameSimplificadoPaiUniaoByCod(paiFilhoCombNew.get(examesChavesPreCalc).getCodigo());
				
					if (filhos.size() < 2) {
						filhos.add(ExamesCalculadosDAO.getExameSimplificadoByExamPreCalc(examePreCalculado));
					}
					if (filhos.size() == 2) {
						paisFilhos.put(pai,filhos);
						break;
					}
				}
				else if (!ExamesCalculadosDAO.contemTodosFilhosCod(procedimentosPreCalculados, examesChavesPreCalc)) {
					break;
					
				}
			}
		}
		
		return paisFilhos;
	}
	
	
	private boolean existeOutroFilhoMaisCompativel(List<ExamePreCalculado> procedimentosPreCalculados,
			ExamePreCalculado exameChavePreCalc, ExamePreCalculado examePreCalculado) {
		for (ExamePreCalculado examesDaGuia: procedimentosPreCalculados) {
			if (!examesDaGuia.getDescricaoCompleta().equals(examePreCalculado.getDescricaoCompleta())) {
				if (exameChavePreCalc.getCodigo().equals(examesDaGuia.getCodigo())
						&& examesDaGuia.getDescricaoCompleta().contains(exameChavePreCalc.getMaterial())) {
					return true;
				}
			}
		}
		return false;
	}

//	public Map<ExameSimplificado, List<ExameSimplificado>> getPossiveisCalculos(List<Ct_itemSolicitacao> procedimentosGuia, List<ExamePreCalculado> procedimentosPreCalculados) {
//		Map<ExameSimplificado, List<ExameSimplificado>> paisFilhos = new HashMap<ExameSimplificado, List<ExameSimplificado>>();
//		
//		Map<String,String> paiFilhoComb = ExamesCalculadosDAO.getCombinacaoCompletaCodigos();
//		
//		//Map<List<ExamePreCalculado>, ExamePreCalculado> paiFilhoCombNew = ExamesCalculadosDAO.getCombinacaoCompletaExCalcs();
//		
//		for (Ct_itemSolicitacao item: procedimentosGuia) {
//			for (String codigosPai: paiFilhoComb.keySet()) {
//				if (!codigosPai.contains(",")) {
//					//verifica relação de desmambramento
//					if (codigosPai.contains(item.getIdentificacaoProcedimentos().getCodigo())) {
//						paisFilhos.put(
//								ExamesCalculadosDAO.getExameSimplificadoPaiDesmByCod(item),
//								ExamesCalculadosDAO.getListExameSimplificadoByCods(Arrays.asList(paiFilhoComb.get(item.getIdentificacaoProcedimentos().getCodigo()).split(",")))
//								);
//					}
//				}
//				else {
//					//verifica relação de uniao/subst
//					List<String> listaCodigosPai = Arrays.asList(codigosPai.split(","));
//					Collections.sort(listaCodigosPai);
//					
//					List<String> listaExamesGuia = procedimentosGuia.stream().map(itemSol -> itemSol.getIdentificacaoProcedimentos().getCodigo()).collect(Collectors.toList());
//					Collections.sort(listaExamesGuia);
//					
//					if (listaExamesGuia.containsAll(listaCodigosPai) 
//							&& !alreadyHasValue(paisFilhos, codigosPai) && codigosPai.contains(item.getIdentificacaoProcedimentos().getCodigo())
//							) {
//						paisFilhos.put(
//								ExamesCalculadosDAO.getExameSimplificadoPaiUniaoByCod(String.valueOf(paiFilhoComb.get(codigosPai))),
//								ExamesCalculadosDAO.getListExameSimplificadoByItens(
//										procedimentosGuia.stream().
//											filter(itensGuia -> Arrays.asList(codigosPai.split(",")).stream()
//													.anyMatch(codsPai -> itensGuia.getIdentificacaoProcedimentos().getCodigo().equals(codsPai)))
//											.collect(Collectors.toList())
//										)
//								);
//					}
//				}
//			}
//		}
//		return paisFilhos;
//	}
//	ExamesCalculadosDAO.getListExameSimplificadoByExamPreCalc(
//	procedimentosPreCalculados.stream()
//	.filter(proced -> examesChavesPreCalc.stream()
//			.anyMatch(exameChave -> proced.equals(exameChave))
//			).collect(Collectors.toList())
//	)	
	
	
	public Ct_itemSolicitacao[] retornaProcedimentosGuiaDesmembra(Ct_itemSolicitacao[] solicitacoesGuia, List<ExameSimplificado> examesFilhos, ExameSimplificado examePaiASerRemovido) {
		List<Ct_itemSolicitacao> novaLista = new ArrayList<Ct_itemSolicitacao>();
		
		for (Ct_itemSolicitacao item: solicitacoesGuia) {
			if (item.getIdentificacaoProcedimentos().getCodigo().equals(examePaiASerRemovido.getCodigo()) && item.getIdentificacaoProcedimentos().getDescricao().equals(examePaiASerRemovido.getDescricao())) {
				for (ExameSimplificado simplificado: examesFilhos) {
					novaLista.add(new Ct_itemSolicitacao(
							new Ct_tabela(simplificado.getCodigo(), "", simplificado.getDescricao()),
							item.getQuantidadeSolicitada(),
							item.getQuantidadeAutorizada(),
							item.getStatusSolicitacaoProcedimento(),
							item.getGlosas(),
							"Adicionado por opção do cliente ou atendente."							
							));
				}
			}
			else {
				novaLista.add(item);
			}
		}
		
		return novaLista.toArray(solicitacoesGuia);
	}
	
	public Ct_itemSolicitacao[] retornaProcedimentosGuiaSubst(Ct_itemSolicitacao[] solicitacoesGuia, List<ExameSimplificado> examesASeremRemovidos, ExameSimplificado examePai) {
		List<Ct_itemSolicitacao> novaLista = new ArrayList<Ct_itemSolicitacao>();
		
		
		for (Ct_itemSolicitacao item: solicitacoesGuia) {
			for (ExameSimplificado simplificado: examesASeremRemovidos) {
				if (item.getIdentificacaoProcedimentos().getCodigo().equals(simplificado.getCodigo()) 
						&& item.getIdentificacaoProcedimentos().getDescricao().toUpperCase().equals(simplificado.getDescricao()) 
						&& !novaLista.stream().anyMatch(itemNovo -> (itemNovo.getIdentificacaoProcedimentos().getCodigo().equals(examePai.getCodigo()) 
								&& itemNovo.getIdentificacaoProcedimentos().getDescricao().toUpperCase().equals(examePai.getDescricao().toUpperCase()))
								)
						) {
					novaLista.add(new Ct_itemSolicitacao(
							new Ct_tabela(examePai.getCodigo(), "", examePai.getDescricao()),
							item.getQuantidadeSolicitada(),
							item.getQuantidadeAutorizada(),
							item.getStatusSolicitacaoProcedimento(),
							item.getGlosas(),
							"Adicionado por opção do cliente ou atendente."							
							));
				}
				else if(!examesASeremRemovidos.stream().anyMatch(itemVelho -> itemVelho.getCodigo().equals(item.getIdentificacaoProcedimentos().getCodigo())) 
						&& !novaLista.stream().anyMatch(itemNovo -> itemNovo.getIdentificacaoProcedimentos().getCodigo().equals(item.getIdentificacaoProcedimentos().getCodigo()))) {
					novaLista.add(item);
				}
			}
		}
		Ct_itemSolicitacao[] itemSolicitacao = new Ct_itemSolicitacao[novaLista.size()];
		
		return novaLista.toArray(itemSolicitacao);
	}
	
//	private boolean alreadyHasValue(Map<ExameSimplificado, List<ExameSimplificado>> mapaExame, String valor) {
//		String valores = "";
//		for(List<ExameSimplificado> listaValores: mapaExame.values() ) {
//			for(ExameSimplificado simplificado: listaValores) {
//				valores+=simplificado.getCodigo()+",";
//			}
//		}
//		return valores.contains(valor);
//	}
	
	
	private boolean jaPossuiExamePreCalc(Map<ExameSimplificado, List<ExameSimplificado>> mapaExame, ExamePreCalculado paiPreCalc) {
		for(ExameSimplificado simplificado: mapaExame.keySet()) {
//			if (simplificado.getExamePreCalculado().getCodigo().equals(paiPreCalc.getCodigo())) {
//				return true;
//			}
		}
		return false;
	}
	
	
	public static String retornaMaterialByDescricao(String descricaoExame) {		
		return ExamesCalculadosDAO.getMaterialByDescExame(descricaoExame);
	}
}
