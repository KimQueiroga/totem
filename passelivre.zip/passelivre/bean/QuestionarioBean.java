
package br.com.hermespardini.passelivre.bean;

import java.io.InputStream;
import java.rmi.RemoteException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.IOUtils;
import org.primefaces.component.panel.Panel;
import org.primefaces.component.panelgrid.PanelGrid;
import org.primefaces.context.RequestContext;
import org.primefaces.extensions.component.masterdetail.MasterDetail;
import org.primefaces.extensions.component.masterdetail.MasterDetailLevel;

import br.com.hermespardini.corebusiness.model.LogAplicacaoUsuarioFactory;
import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.constantsenum.FuncaoLogEstatistico;
import br.com.hermespardini.passelivre.constantsenum.TipoServicoEnum;
import br.com.hermespardini.passelivre.exception.EnvioEmailException;
import br.com.hermespardini.passelivre.exception.ImpressaoException;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.factory.ComponenteFactory;
import br.com.hermespardini.passelivre.model.ClienteUnidadePasseLivre;
import br.com.hermespardini.passelivre.model.ConfiguracaoImpressoraResult;
import br.com.hermespardini.passelivre.model.ConsultaDadosAd;
import br.com.hermespardini.passelivre.model.ConsultaQuestionarioExameResult;
import br.com.hermespardini.passelivre.model.ControleEstatistico;
import br.com.hermespardini.passelivre.model.CriarPedidoResult;
import br.com.hermespardini.passelivre.model.ExamesResultadosPedido;
import br.com.hermespardini.passelivre.model.InformacaoTotem;
import br.com.hermespardini.passelivre.model.InformacaoTotemDesktop;
import br.com.hermespardini.passelivre.model.Localidade;
import br.com.hermespardini.passelivre.model.Localizacao;
import br.com.hermespardini.passelivre.model.MensagemAviso;
import br.com.hermespardini.passelivre.model.ParametroInformacaoImpressora;
import br.com.hermespardini.passelivre.model.ParametroPedido;
import br.com.hermespardini.passelivre.model.PerguntaEntrega;
import br.com.hermespardini.passelivre.model.TokenResult;
import br.com.hermespardini.passelivre.model.Unidade;
import br.com.hermespardini.passelivre.service.AtendimentoService;
import br.com.hermespardini.passelivre.service.ConfiguracaoImpressoraService;
import br.com.hermespardini.passelivre.service.ControleEstatisticoService;
import br.com.hermespardini.passelivre.service.EnviaEmailService;
import br.com.hermespardini.passelivre.service.NovoAtendimentoService;
import br.com.hermespardini.passelivre.service.QuestionarioService;
import br.com.hermespardini.passelivre.to.PerguntaComExameTO;
import br.com.hermespardini.passelivre.to.ProcedimentoComExamesTO;
import br.com.hermespardini.passelivre.utils.ArquivoUtil;
import br.com.hermespardini.passelivre.utils.ControleBotaoUtil;
import br.com.hermespardini.passelivre.utils.MensagemUtil;
import br.com.hermespardini.passelivre.utils.TotemUtil;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.bean.MainBean;
import br.com.unimedbh.www.Ct_dadosAutorizacao;
import br.com.unimedbh.www.DestinatarioInvalido;
import br.com.unimedbh.www.HashInvalido;
import br.com.unimedbh.www.RemetenteInvalido;
import br.com.unimedbh.www.VersaoInvalida;
import br.com.unimedbh.www.schemas.Ct_respostaComunicacao;
import br.com.unimedbh.www.ws.tipos.Ws_respostaCobertura;
import br.com.unimedbh.www.ws.tipos.Ws_respostaComunicacao;

@ViewScoped
@ManagedBean
public class QuestionarioBean extends MainBean {

	private Unidade unidade;
	private String sessionId;
	private Integer numeroPedido;
	private String mensagemAviso;
	private Panel pnlQuestionario;
	private String numeroCarteira;
	private String providencia;
	private Localizacao localizacao;
	private TokenResult tokenResult;
	private Integer quantidadeExameVT;
	private PanelGrid pngQuestionario;
	private MasterDetail mtdQuestionario;
	private ConsultaDadosAd consultaDadosAd;
	private List<PerguntaEntrega> perguntas;
	private ParametroPedido parametroPedido;
	private MasterDetailLevel mdlQuestionario;
	private ControleBotaoUtil controleBotaoUtil;
	private Map<String, String> mapQuestionarios;
	private List<MasterDetailLevel> mdlsQuestionario;
	private static final String CODIGO_IMAGEM = "03";
	private Ws_respostaCobertura ws_respostaCobertura;
	private static final String CODIGO_PATOLOGIA = "09";
	private Ct_dadosAutorizacao guiasAutorizadaSelecionada;
	private ClienteUnidadePasseLivre clienteUnidadePasseLivre;
	private List<InformacaoTotemDesktop> informacoesTotemDesktop;
	private List<ProcedimentoComExamesTO> procedimentosExcluidos;
	private Map<String, List<PerguntaComExameTO>> todasPerguntasAgrupadas;
	private List<ConsultaQuestionarioExameResult> questionariosExamesResult;
	private ConsultaQuestionarioExameResult consultaQuestionarioExameResult;
	private List<ProcedimentoComExamesTO> procedimentosComExamesParaGerarPedido;
	private Map<String, String> mapPerguntaResposta;
	private InformacaoTotem informacaoTotem;
	private List<InformacaoTotem> informacoesTotem;
	private TotemUtil totemUtil;

	public String nomeExame;
	
	private boolean isBotaoOn;

	@PostConstruct
	public void onLoad() {
		try {
			unidade = retornarUnidade();
			sessionId = returnarSessionId();
			numeroPedido = retornarNumeroPedido();
			mapQuestionarios = new HashMap<>();
			numeroCarteira = retornarCarteira();
			providencia = retornarProvidencia();
			tokenResult = retornarTokenResult();
			consultaDadosAd = retornarDadosAd();
			localizacao = retornarLocalizacao();
			mdlsQuestionario = new ArrayList<>();
			controleBotaoUtil = new ControleBotaoUtil();
			quantidadeExameVT = retornarQuantidadeExameVT();
			ws_respostaCobertura = retornarRespostaCobertura();
			clienteUnidadePasseLivre = retornarClienteUnidade();
			informacoesTotemDesktop = retornarInformacoesTotemDesktop();
			procedimentosExcluidos = retornarProcedimentosExluido();
			todasPerguntasAgrupadas = retornarPerguntasAgrupadas();
			questionariosExamesResult = retornarQuestionarioExamesResult();
			guiasAutorizadaSelecionada = retornarGuiasAutorizadaSelecionadas();
			procedimentosComExamesParaGerarPedido = retornarProcedimentosComExames();
			informacaoTotem = retornarInformacaoTotem();
			informacoesTotem = retornarInformacoesTotem();
			mapPerguntaResposta = new HashMap<>();
			totemUtil = new TotemUtil();
			gerarQuestionario();

		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	private String retornarProvidencia() {
		try {
			final HttpSession session = getHttpServletRequest().getSession();
			return session.getAttribute("providencia").toString();
		} catch (final Exception locExc) {
			return null;
		}
	}

	private List<ProcedimentoComExamesTO> retornarProcedimentosExluido() {
		try {
			final HttpSession session = getHttpServletRequest().getSession();
			return (List<ProcedimentoComExamesTO>) session.getAttribute("procedimentosExcluidos");
		} catch (final Exception locExc) {
			return null;
		}
	}

	private Integer retornarNumeroPedido() {
		try {
			final HttpSession session = getHttpServletRequest().getSession();
			return (Integer) session.getAttribute("numeroPedido");
		} catch (final Exception locExc) {
			return 0;
		}
	}

	private Integer retornarQuantidadeExameVT() throws Exception {
		final HttpSession session = getHttpServletRequest().getSession();
		return (Integer) session.getAttribute("quantidadeExameVT");
	}

	private String returnarSessionId() throws Exception {
		/*
		 * final HttpSession session = getHttpServletRequest().getSession(); return
		 * session.getAttribute("sessionId").toString();
		 */
		return TotemUtil.buscarSessionId();
	}

	private String retornarCarteira() throws Exception {
		final HttpSession session = getHttpServletRequest().getSession();
		return (String) session.getAttribute("numeroCarteira");
	}

	private ConsultaDadosAd retornarDadosAd() throws Exception {
		final HttpSession session = getHttpServletRequest().getSession();
		return (ConsultaDadosAd) session.getAttribute("consultaDadosAd");
	}

	private List<InformacaoTotemDesktop> retornarInformacoesTotemDesktop() throws Exception {
		final HttpSession session = getHttpServletRequest().getSession();
		return (List<InformacaoTotemDesktop>) session.getAttribute("informacoesTotemDesktop");
	}

	private Localizacao retornarLocalizacao() throws Exception {
		final HttpSession session = getHttpServletRequest().getSession();
		return (Localizacao) session.getAttribute("localizacao");
	}

	private Localidade retornarLocalidade() throws Exception {
		final HttpSession session = getHttpServletRequest().getSession();
		return (Localidade) session.getAttribute("localidade");
	}

	private Unidade retornarUnidade() throws Exception {
		final HttpSession session = getHttpServletRequest().getSession();
		return (Unidade) session.getAttribute("unidade");
	}

	private TokenResult retornarTokenResult() throws Exception {
		final HttpSession session = getHttpServletRequest().getSession();
		return (TokenResult) session.getAttribute("tokenResult");
	}

	private Ws_respostaCobertura retornarRespostaCobertura() throws Exception {
		final HttpSession session = getHttpServletRequest().getSession();
		return (Ws_respostaCobertura) session.getAttribute("ws_respostaCobertura");
	}

	private ClienteUnidadePasseLivre retornarClienteUnidade() throws Exception {
		final HttpSession session = getHttpServletRequest().getSession();
		return (ClienteUnidadePasseLivre) session.getAttribute("clienteUnidadePasseLivre");
	}

	private List<ProcedimentoComExamesTO> retornarProcedimentosComExames() throws Exception {
		final HttpSession session = getHttpServletRequest().getSession();
		return (List<ProcedimentoComExamesTO>) session.getAttribute("procedimentosComExamesParaGerarPedido");
	}

	private Ct_dadosAutorizacao retornarGuiasAutorizadaSelecionadas() throws Exception {
		final HttpSession session = getHttpServletRequest().getSession();
		return (Ct_dadosAutorizacao) session.getAttribute("guiasAutorizadaSelecionada");
	}

	private List<ConsultaQuestionarioExameResult> retornarQuestionarioExamesResult() throws Exception {
		final HttpSession session = getHttpServletRequest().getSession();
		return (List<ConsultaQuestionarioExameResult>) session.getAttribute("questionariosExamesResult");
	}

	private InformacaoTotem retornarInformacaoTotem() throws Exception {
		final HttpSession session = getHttpServletRequest().getSession();
		return (InformacaoTotem) session.getAttribute("informacaoTotem");
	}

	private List<InformacaoTotem> retornarInformacoesTotem() throws Exception {
		final HttpSession session = getHttpServletRequest().getSession();
		return (List<InformacaoTotem>) session.getAttribute("informacoesTotem");
	}

	public String retornaExamesDoQuestionario(final String level) throws Exception {
		final HttpSession session = getHttpServletRequest().getSession();
		final Map<String, Integer> mapExameLevel = (Map<String, Integer>) session.getAttribute("mapExameLevel");

		String examesLevel = " Questionário para os exames: ";
		boolean primeiro = true;
		for (final Map.Entry<String, Integer> temp : mapExameLevel.entrySet()) {
			if (temp.getValue().equals(Integer.valueOf(level))) {
				if (primeiro) {
					examesLevel = examesLevel.concat(temp.getKey());
					primeiro = false;
				} else {
					examesLevel = examesLevel.concat(" / " + temp.getKey());
				}
			}
		}
		return examesLevel;
	}

	public void finalizarPedido() {
		try {
			numeroCarteira = "";
			FacesContext.getCurrentInstance().getExternalContext()
					.redirect("/passelivretotem/pagesGuiche/indexGuiche.xhtml?faces-redirect=true");
		} catch (final Exception locExc) {
		}
	}

	
	public String fazerPedido() throws Exception {
		final QuestionarioService questionarioService = new QuestionarioService(getHttpServletRequest(), perguntas,
				mapQuestionarios, todasPerguntasAgrupadas);
		
		//TODO: Refatorar a estrategia do isBotaoOn, foi adicionado o 
		// boolean para tratar a duplicidade da chamada do metodo pelo "front" (questionario.xhtml).
		
		isBotaoOn = (boolean) getSession().getAttribute("questionarioIsBotaoOn");
		
		if(isBotaoOn) {
			
			if (validarRespostasQuestionario(questionarioService)) {
				getSession().setAttribute("perguntas", perguntas);
				getSession().setAttribute("mapQuestionarios", mapQuestionarios);
				final TipoServicoEnum tipoServico = TotemUtil.recuperarTipoServico();
				getSession().setAttribute("questionarioIsBotaoOn", false);
				if (tipoServico.equals(TipoServicoEnum.PAT)) {
					final PreAtendimentoBean preAtenimentoBean = findPreAtendimentoBean();
					return preAtenimentoBean.fazerPedido();
				} else {
					final NovoAtendimentoUnimedBean novoAtendimentoUnimedBean = findNovoAtendimentoUnimedeBean();
					return novoAtendimentoUnimedBean.fazerPedido();
				}
			}
		}

		MensagemAviso mensagemAviso = TotemUtil
				.createMensagemAviso("Erro ao validar resposta do questionário ao fazer pedido.");
		try {
			getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return redirectAtendimentoNaoConcluido();

		// CÃ³digo duplicado comentado para testes
		/*
		 * CriarPedidoResult locCriarPedidoResult = new CriarPedidoResult(); try {
		 * getSession().setAttribute("mapQuestionarios", mapQuestionarios);
		 * mensagemAviso = ""; preencherQuestionario();
		 * gerarLogProcedimentosExcluidos(); if (informacoesTotemDesktop != null) {
		 * parametroPedido = new ParametroPedido(guiasAutorizadaSelecionada,
		 * procedimentosComExamesParaGerarPedido, questionariosExamesResult, perguntas,
		 * clienteUnidadePasseLivre, ws_respostaCobertura, tokenResult,
		 * retornarSiglaUsuario(), unidade, localizacao.getCodigo(), sessionId,
		 * providencia); } else { parametroPedido = new
		 * ParametroPedido(guiasAutorizadaSelecionada,
		 * procedimentosComExamesParaGerarPedido, questionariosExamesResult,
		 * informacaoTotem, perguntas, clienteUnidadePasseLivre, ws_respostaCobertura,
		 * tokenResult); } verificarSeExamesEmVTEstaoCoerentes();
		 * getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN,
		 * retornarCodigo()); new MensagemUtil();
		 * registrarLogAcessoFuncionalidade(Thread.currentThread().getStackTrace()[1].
		 * getClassName(), Thread.currentThread().getStackTrace()[1].getMethodName(),
		 * MensagemUtil.retornarMensagemAoIniciarPedido(retornarSenhaDaGuia()),
		 * sessionId); final PedidoService pedidoService = new
		 * PedidoService(getHttpServletRequest()); confirmarPedido();
		 * pedidoService.fazerPedido(parametroPedido); if (pedidoService.isSuccess()) {
		 * locCriarPedidoResult = (CriarPedidoResult) pedidoService.getResponseObject();
		 * final HttpSession session = getHttpServletRequest().getSession();
		 * session.setAttribute("numeroPedido", locCriarPedidoResult.getPedido());
		 * pedidoService.getResponseMessage();
		 * acoesAposPedidoRealizadoComSucesso(locCriarPedidoResult);
		 * registrarLogAcessoFuncionalidade(Thread.currentThread().getStackTrace()[1].
		 * getClassName(), Thread.currentThread().getStackTrace()[1].getMethodName(),
		 * MensagemUtil.retornarMensagemAoFinalizarPedido(
		 * locCriarPedidoResult.getPedido(), locCriarPedidoResult.getUnidade()),
		 * sessionId); gerarLogEstatistico(); providencia = ""; } else {
		 * gerarLogErroAoFazerPedido(pedidoService.getResponseMessage()); mensagemAviso
		 * = pedidoService.getResponseMessage(); exibirDialogMensagem(); return null; }
		 * return redirectAtendimentoConcluido(); } catch (final ImpressaoException exc)
		 * { exc.printStackTrace(); if (informacoesTotemDesktop != null) {
		 * gerarLogErroAoFazerPedido(
		 * MensagemUtil.retornarMensagemErroAoFazerPedido(exc.getMessage(),
		 * locCriarPedidoResult, unidade.getCodigo())); } else {
		 * gerarLogErroAoFazerPedido(
		 * MensagemUtil.retornarMensagemErroAoFazerPedido(exc.getMessage(),
		 * locCriarPedidoResult, informacoesTotem)); } gerarLogEstatistico(); return
		 * redirectAtendimentoConcluidoSemImpressaoGA(); } catch (final
		 * EnvioEmailException exc) { exc.printStackTrace(); new MensagemUtil();
		 * gerarLogErroEmailAoFazerPedido(exc.getMessage() +
		 * MensagemUtil.retornarMensagemAoFinalizarPedido(
		 * locCriarPedidoResult.getPedido(), locCriarPedidoResult.getUnidade()));
		 * gerarLogEstatistico(); return redirectAtendimentoConcluidoSemEmail(); } catch
		 * (final Exception exc) { exc.printStackTrace();
		 * gerarLogErroAoFazerPedido(exc.getMessage()); mensagemAviso =
		 * exc.getMessage(); exibirDialogMensagem(); return null; } finally {
		 * numeroCarteira = ""; }
		 */
	}

	public String entregarMaterial() throws Exception {
		final QuestionarioService questionarioService = new QuestionarioService(getHttpServletRequest(), perguntas,
				mapQuestionarios, todasPerguntasAgrupadas);
		if (validarRespostasQuestionario(questionarioService)) {
			getSession().setAttribute("perguntas", perguntas);
			getSession().setAttribute("mapQuestionarios", mapQuestionarios);
			final EntregaMaterialPendenteBean entregaMaterialPendenteBean = findEntregaMaterialPendenteBean();
			return entregaMaterialPendenteBean.entregarMaterial();
		}
		MensagemAviso mensagemAviso = TotemUtil
				.createMensagemAviso("Erro ao validar resposta do questionário ao entregar o material pendente.");
		try {
			getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return redirectAtendimentoNaoConcluido();
	}

	public EntregaMaterialPendenteBean findEntregaMaterialPendenteBean() {
		final FacesContext context = FacesContext.getCurrentInstance();
		return context.getApplication().evaluateExpressionGet(context, "#{entregaMaterialPendenteBean}",
				EntregaMaterialPendenteBean.class);
	}

	public NovoAtendimentoUnimedBean findNovoAtendimentoUnimedeBean() {
		final FacesContext context = FacesContext.getCurrentInstance();
		return context.getApplication().evaluateExpressionGet(context, "#{novoAtendimentoUnimedBean}",
				NovoAtendimentoUnimedBean.class);
	}

	public PreAtendimentoBean findPreAtendimentoBean() {
		final FacesContext context = FacesContext.getCurrentInstance();
		return context.getApplication().evaluateExpressionGet(context, "#{preAtendimentoBean}",
				PreAtendimentoBean.class);
	}

	private String redirectAtendimentoConcluidoSemImpressaoGA() {
		return "/pagesGuiche/nau/atendimentoConcluidoSemImpressaoGA.xhtml?faces-redirect=true";
	}

	private void gerarLogProcedimentosExcluidos() {
		try {
			if (procedimentosExcluidos != null && !procedimentosExcluidos.isEmpty()) {
				for (final ProcedimentoComExamesTO locProcedimentoComExamesTO : procedimentosExcluidos) {
					getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, retornarCodigo());
					registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
							Thread.currentThread().getStackTrace()[1].getMethodName(),
							MensagemUtil.retornarMensagemParaProcedimentoExcluidosPeloUsuario(numeroCarteira,
									locProcedimentoComExamesTO),
							sessionId, createBasicLogMap());
				}
			}
		} catch (final Exception locExc) {
		}
	}

	private void gerarLogEstatistico() {
		try {
			final ControleEstatisticoService controleEstatisticoService = new ControleEstatisticoService(
					getHttpServletRequest());
			final ControleEstatistico controleEstatistico = new ControleEstatistico(
					clienteUnidadePasseLivre.getCodigoCliente(), null,
					controleEstatisticoService
							.retornarDescricaoParaAtendimentoUnimed(procedimentosComExamesParaGerarPedido),
					retornarSiglaUsuario(), null, null, unidade.getCodigo().toString());
			controleEstatisticoService.insert(controleEstatistico);
		} catch (final Exception locExc) {
		}
	}

	private String retornarDescricaoDeServico() {
		if (isExisteExameDeImagem()) {
			return FuncaoLogEstatistico.REALIZAR_ATENDIMENTO.toString();
		} else {
			return FuncaoLogEstatistico.REALIZAR_ATENDIMENTO_IMAGEM.toString();
		}
	}

	private void verificarSeExamesEmVTEstaoCoerentes() throws RegraNegocioException {
		final Integer quantidadeVTNoPedido = retornarQuantidadeEmVt();
		final Integer diferencaEntreVts = quantidadeExameVT - quantidadeVTNoPedido;
		try {
			if (quantidadeExameVT != quantidadeVTNoPedido) {
				throw new RegraNegocioException(MensagemUtil.retornarMensagemErroInconsistenciaVt(quantidadeVTNoPedido,
						quantidadeExameVT, mensagemAviso));
			}
		} catch (final Exception locExc) {
			new MensagemUtil();
			throw new RegraNegocioException(MensagemUtil.retornarMensagemErroInconsistenciaVt(quantidadeVTNoPedido,
					quantidadeExameVT, mensagemAviso));
		}
	}

	private Integer retornarQuantidadeEmVt() {
		Integer localQuanddadeExaneVt = 0;
		for (final ProcedimentoComExamesTO locProcedimentoComExame : procedimentosComExamesParaGerarPedido) {
			if (locProcedimentoComExame.getVt() && !locProcedimentoComExame.getExcluido()) {
				localQuanddadeExaneVt += 1;
			}
		}
		return localQuanddadeExaneVt;
	}

	private void acoesAposPedidoRealizadoComSucesso(final CriarPedidoResult locCriarPedidoResult)
			throws Exception, EnvioEmailException {
		if (getAmbienteProducao()) {
			imprimirGA(locCriarPedidoResult); // ALTERAR ELLEN MAIA
			enviarEmailPedidoFinalizado(locCriarPedidoResult);
		}
	}

	private void confirmarPedido() throws Exception, HashInvalido, RemetenteInvalido, VersaoInvalida,
			DestinatarioInvalido, RemoteException, ParseException {
		if (getAmbienteProducao()) {
			final AtendimentoService atendimentoService = new AtendimentoService(getHttpServletRequest());
			final Ws_respostaComunicacao ws_respostaComunicacao = atendimentoService.confirmarAtendimento(
					guiasAutorizadaSelecionada, retornarLocalAtendimento(), retornarCodigoLabCdt());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(),
					MensagemUtil.retornarMensagemAoConfirmarPedido(retornarSenhaDaGuia()), sessionId,
					createBasicLogMap());
			if (ws_respostaComunicacao != null) {
				for (final Ct_respostaComunicacao localCt_respostaComunicacao : ws_respostaComunicacao
						.getRespostaComunicacao()) {
					if (!localCt_respostaComunicacao.getRespostaComunicacao().equals("1")) {
						throw new Exception(MensagemUtil.retornarMensagemErroAoConfirmarPedido(
								localCt_respostaComunicacao.getDadosBeneficiario().getNumeroCarteira(),
								retornarSenhaAutorizada(),
								localCt_respostaComunicacao.getGlosas(0).getDescricaoGlosa()));
					}
				}
			}
		}
	}

	private boolean isExisteExameDeImagem() {
		for (final ProcedimentoComExamesTO locProcedimentoComExamesTO : procedimentosComExamesParaGerarPedido) {
			if (locProcedimentoComExamesTO.getExame().getMaterial().equals("VIVO")) {
				return true;
			}
		}
		return false;
	}

	private String retornarCodigoLabCdt() {
		if (isExisteExameDeImagem()) {
			return QuestionarioBean.CODIGO_IMAGEM;
		} else {
			return QuestionarioBean.CODIGO_PATOLOGIA;
		}
	}

	private String retornarSenhaAutorizada() {
		try {
			return guiasAutorizadaSelecionada.getDadosAutorizacao().getSenhaAutorizacao();
		} catch (final Exception locExc) {
			return "";
		}
	}

	private String retornarLocalAtendimento() throws Exception {
		if (unidade != null) {
			return Constantes.PARAM_INICAL_LOCAL_ATENDIMENTO + unidade.getUnimedBH().getUnbh();
		} else {
			return "";
		}
	}

	private String retornarCodigo() {
		try {
			if (clienteUnidadePasseLivre.getCodigoCliente() != null) {
				return clienteUnidadePasseLivre.getCodigoCliente();
			} else {
				return "";
			}
		} catch (final Exception locExc) {
			return "";
		}
	}

	private String retornarSiglaUsuario() {
		if (consultaDadosAd != null && consultaDadosAd.getUsuarioAd() != null) {
			return consultaDadosAd.getUsuarioAd().getSigla();
		} else {
			return "";
		}
	}

	private void gerarLogErroAoFazerPedido(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, retornarCodigo());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, sessionId,
					createBasicLogMap());
		} catch (final Exception exc) {
		}
	}

	private void gerarLogErroEmailAoFazerPedido(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, retornarCodigo());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, sessionId,
					createBasicLogMap());
		} catch (final Exception exc) {
		}
	}

	public String getMensagemCabecalho() {
		try {
			return MensagemUtil.retornarMensagemCabelho(clienteUnidadePasseLivre, numeroCarteira);
		} catch (final Exception locExc) {
			return "";
		}
	}

	/**
	 * Verifica se estÃ¡ em ambiente de produÃ§Ã£o ou se o email pertence ao
	 * Pardini antes de enviar.
	 *
	 * @param parCriarPedidoResult
	 * @throws EnvioEmailException
	 */
	private void enviarEmailPedidoFinalizado(final CriarPedidoResult parCriarPedidoResult) throws EnvioEmailException {
		final ExamesResultadosPedido locExamesResultadosPedido = new ExamesResultadosPedido();
		try {
			final EnviaEmailService envioEmailService = new EnviaEmailService(getHttpServletRequest());
			adicionarUnidade(parCriarPedidoResult);
			locExamesResultadosPedido.addAll(parCriarPedidoResult.getExames());

			if (informacoesTotem.get(0).getIdEmpresa().equals(Long.parseLong(Constantes.ID_EMPRESA_ECOAR))) {
				envioEmailService.enviarEmailFinalizarPedido(clienteUnidadePasseLivre, locExamesResultadosPedido,
						getAmbienteProducao(), true);
			} else {
				envioEmailService.enviarEmailFinalizarPedido(clienteUnidadePasseLivre, locExamesResultadosPedido,
						getAmbienteProducao(), false);

			}

		} catch (final Exception exc) {
			throw new EnvioEmailException(exc.getMessage());
		}
	}

	private void adicionarUnidade(final CriarPedidoResult parCriarPedidoResult) {
		for (final InformacaoTotemDesktop locInformacaoTotem : informacoesTotemDesktop) {
			if (unidade.getCodigo().toString().equals(parCriarPedidoResult.getUnidade().toString())) {
				clienteUnidadePasseLivre.setUnidade(parCriarPedidoResult.getPedido() + "-" + unidade.getCodigo());
			}
		}
	}

	private void imprimirGA(final CriarPedidoResult parCriarPedidoResult) throws ImpressaoException {
		final ArquivoUtil arquivoUtil = new ArquivoUtil();
		try {
			final ConfiguracaoImpressoraResult configuracaoImpressoraResult = retornarConfiguracoesImpressora();
			final NovoAtendimentoService novoAtendimentoService = new NovoAtendimentoService(getHttpServletRequest());
			final byte[] bytes = IOUtils
					.toByteArray(gerarRelatorioGA(parCriarPedidoResult, guiasAutorizadaSelecionada));
			arquivoUtil.salvarDiretorioLocal(bytes, retornarDadosGA(parCriarPedidoResult) + ".pdf");
			arquivoUtil.fazerImpressaoFrenteVerso(retornarDadosGA(parCriarPedidoResult) + ".pdf",
					configuracaoImpressoraResult.getIp());
		} catch (final Exception exc) {
			throw new ImpressaoException("Erro ao fazer impressão de GA: " + exc.getMessage());
		}
	}

	private String retornarDadosGA(final CriarPedidoResult parCriarPedidoResult) {
		final StringBuilder sb = new StringBuilder();
		sb.append("GA_").append(unidade.getCodigo()).append("_").append(parCriarPedidoResult.getPedido());
		return sb.toString();
	}

	private InputStream gerarRelatorioGA(final CriarPedidoResult parCriarPedidoResult,
			final Ct_dadosAutorizacao parLocalCt_dadosAutorizacao) throws Exception {
		try {
			mensagemAviso = "";
			final NovoAtendimentoService novoAtendimentoService = new NovoAtendimentoService(getHttpServletRequest());
			String codPrestadorUnimed = (String) getSession().getAttribute("codigoPrestadorUnimed");
			final String pathArquivoReport = getServletContext()
					.getRealPath("/WEB-INF/relatorio/GuiaAtendimento.jasper");
			return novoAtendimentoService.gerarRelatorioGA(parCriarPedidoResult, ws_respostaCobertura,
					parLocalCt_dadosAutorizacao, getServletContext(), pathArquivoReport, procedimentosExcluidos,
					questionariosExamesResult, procedimentosComExamesParaGerarPedido, codPrestadorUnimed,
					informacaoTotem.getNomeEmpresa(), informacaoTotem.getCnesUnidade());
		} catch (final Exception locExc) {
			mensagemAviso = "Erro ao gerar relatório!";
			exibirDialogMensagem();
			return null;
		}
	}

	private void exibirDialogMensagem() {
		RequestContext.getCurrentInstance().execute("PF('dlgMessage').show()");
	}

	private ConfiguracaoImpressoraResult retornarConfiguracoesImpressora() throws Exception {
		final ParametroInformacaoImpressora parametroInformacaoImpressora = new ParametroInformacaoImpressora(
				tokenResult, localizacao.retornarImpressoraValida().getCodigo());
		ConfiguracaoImpressoraResult configuracaoImpressoraResult = new ConfiguracaoImpressoraResult();
		final ConfiguracaoImpressoraService configuracaoImpressoraService = new ConfiguracaoImpressoraService(
				getHttpServletRequest());
		configuracaoImpressoraService.retornarInformacoes(parametroInformacaoImpressora);
		if (configuracaoImpressoraService.isSuccess()) {
			configuracaoImpressoraResult = (ConfiguracaoImpressoraResult) configuracaoImpressoraService
					.getResponseObject();
			return configuracaoImpressoraResult;
		} else {
			throw new Exception(configuracaoImpressoraService.getResponseMessage());
		}
	}

	private String retornarSenhaDaGuia() {
		try {
			if (guiasAutorizadaSelecionada.getDadosAutorizacao().getSenhaAutorizacao() != null) {
				return guiasAutorizadaSelecionada.getDadosAutorizacao().getSenhaAutorizacao();
			}
			return "";
		} catch (final Exception locExc) {
			return "";
		}
	}

	private void preencherQuestionario() throws Exception {
		try {
			perguntas = new ArrayList<>();
			// perguntas.addAll(new QuestionarioService(getHttpServletRequest(), perguntas,
			// mapQuestionarios).preencherQuestionario());
			perguntas.addAll(new QuestionarioService(getHttpServletRequest(), perguntas, mapQuestionarios,
					todasPerguntasAgrupadas).preencherQuestionarioConsolidado());
		} catch (final Exception locExc) {
			throw new Exception(locExc.getMessage());
		}
	}

	public String redirectAtendimentoConcluido() {
		if (isDesktop()) {
			return "/pagesGuiche/nau/finalizacaoPedidoQuestionario.xhtml?faces-redirect=true";
		} else {
			if (isExisteExameDeImagem()) {
				return "/pages/nau/finalizacaoPedidoComRaioX.xhtml?faces-redirect=true";
			} else {
				return "/pages/nau/finalizacaoPedido.xhtml?faces-redirect=true";
			}
		}
	}

	private String redirectAtendimentoConcluidoSemEmail() {
		return "/pagesGuiche/nau/atendimentoConcluidoSemEmail.xhtml?faces-redirect=true";
	}

	private void gerarQuestionario() throws RegraNegocioException {
		try {
			mtdQuestionario = new MasterDetail();
			mdlQuestionario = new MasterDetailLevel();
			mdlQuestionario.setId("mdlQuestionario");
			mapQuestionarios = new HashMap<>();
			pngQuestionario = new PanelGrid();
			pngQuestionario.setId("pngQuestionario");
			pngQuestionario.setStyleClass("pngQuestionario");
			pngQuestionario.setColumns(3);
			pngQuestionario.setStyle("height: 250px;");
			pnlQuestionario = new Panel();
			mtdQuestionario.setShowBreadcrumb(false);
			mtdQuestionario.setId("mtdQuestionario");
			buscarQuestionario();
			final ComponenteFactory componenteFactory = new ComponenteFactory(pnlQuestionario, mdlsQuestionario,
					mtdQuestionario, mdlQuestionario, pngQuestionario);
			componenteFactory.construirComponentesQuestionario(mapQuestionarios, todasPerguntasAgrupadas, isDesktop());
		} catch (final Exception locExc) {
			throw new RegraNegocioException(locExc.getMessage());
		}
	}

	private void buscarQuestionario() throws RegraNegocioException {
		try {
			final HttpSession session = getHttpServletRequest().getSession();
			consultaQuestionarioExameResult = (ConsultaQuestionarioExameResult) session
					.getAttribute("consultaQuestionarioExameResult");
		} catch (final Exception locExc) {
			throw new RegraNegocioException("Erro ao buscar o questionário!" + locExc.getMessage());
		}
	}

	private List<MasterDetailLevel> retornarMlsQuestionario() throws Exception {
		final HttpSession session = getHttpServletRequest().getSession();
		return (List<MasterDetailLevel>) session.getAttribute("mdlsQuestionario");
	}

	private Map<String, List<PerguntaComExameTO>> retornarPerguntasAgrupadas() throws Exception {
		final HttpSession session = getHttpServletRequest().getSession();
		return (Map<String, List<PerguntaComExameTO>>) session.getAttribute("todasPerguntasAgrupadas");
	}

	public void cancelarSessao() {
		try {
			final String nomeMaquina = TotemUtil.retornarNomeDaMaquina();
			TotemUtil.limparSession();
			FacesContext.getCurrentInstance().getExternalContext()
					.redirect("/passelivretotem/indexTotem.xhtml?faces-redirect=true&nomeTotem=" + nomeMaquina);
		} catch (final Exception exc) {
		}
	}

	public void cancelar() {
		try {

			final String nomeMaquina = TotemUtil.retornarNomeDaMaquina();
			TotemUtil.limparSession();
			FacesContext.getCurrentInstance().getExternalContext()
					.redirect("/passelivretotem/indexTotem.xhtml?faces-redirect=true&nomeTotem=" + nomeMaquina);
		} catch (final Exception locExc) {
		}
	}

	public boolean validarRespostasQuestionario(final QuestionarioService questionarioService) throws Exception {
		perguntas = new ArrayList<>();
		perguntas.addAll(questionarioService.preencherQuestionarioConsolidado());
		for (final ConsultaQuestionarioExameResult questionario : questionariosExamesResult) {
			if (!questionario.getQuestionarios().isEmpty()) {
				if (!questionarioService.validarRespostaInviolavel(questionario.getQuestionarios())) {
					final String parMessage = "A resposta informada não permite a realização deste atendimento.";
					registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
							Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, sessionId,
							createBasicLogMap());
					MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso("QUESTIONÁRIO");
					getSession().setAttribute("mensagemAviso", mensagemAviso);
					return false;
				}
			}
		}
		return true;
	}

	public Map createBasicLogMap() {
		Long idTotem = null;
		Long idUnidade = null;
		if (informacoesTotem != null && !informacoesTotem.isEmpty()) {
			idTotem = informacoesTotem.get(0).getId();
			idUnidade = Long.valueOf(informacoesTotem.get(0).getIdUnidade());
		}
		try {
			return TotemUtil.createBasicLogMap(idTotem, idUnidade, Util.getClientIpAddr(getHttpServletRequest()));
		} catch (Exception e) {
			e.printStackTrace();
			return new HashMap();
		}
	}

	private String redirectAtendimentoNaoConcluido() {
		return "/pages/erro/atendimentoNaoConcluido.xhtml?faces-redirect=true";
	}

	private boolean isDesktop() {
		return !TotemUtil.retornarNomeDaMaquina().contains("totem");
	}

	public Boolean habilitarBotaoQuestionarioVoltar(final Integer level) {
		return controleBotaoUtil.habilitarBotaoQuestionarioVoltar(mdlsQuestionario, level);
	}

	public Boolean habilitarBotaoQuestionarioCancelar(final Integer level) {
		return controleBotaoUtil.habilitarBotaoQuestionarioCancelar(mdlsQuestionario, level);
	}

	public Boolean habilitarBotaoQuestionarioAvancar(final Integer level) {
		return controleBotaoUtil.habilitarBotaoQuestionarioAvancar(mdlsQuestionario, level);
	}

	public Boolean habilitarBotaoQuestionarioFinalizar(final Integer level) {
		return controleBotaoUtil.habilitarBotaoQuestionarioFinalizar(mdlsQuestionario, level);
	}

	public List<MasterDetailLevel> getMdlsQuestionario() {
		return mdlsQuestionario;
	}

	public void setMdlsQuestionario(final List<MasterDetailLevel> parMdlsQuestionario) {
		mdlsQuestionario = parMdlsQuestionario;
	}

	public Map<String, List<PerguntaComExameTO>> getTodasPerguntasAgrupadas() {
		return todasPerguntasAgrupadas;
	}

	public void setTodasPerguntasAgrupadas(final Map<String, List<PerguntaComExameTO>> parTodasPerguntasAgrupadas) {
		todasPerguntasAgrupadas = parTodasPerguntasAgrupadas;
	}

	public Panel getPnlQuestionario() {
		return pnlQuestionario;
	}

	public void setPnlQuestionario(final Panel parPnlQuestionario) {
		pnlQuestionario = parPnlQuestionario;
	}

	public PanelGrid getPngQuestionario() {
		return pngQuestionario;
	}

	public void setPngQuestionario(final PanelGrid parPngQuestionario) {
		pngQuestionario = parPngQuestionario;
	}

	public MasterDetail getMtdQuestionario() {
		return mtdQuestionario;
	}

	public void setMtdQuestionario(final MasterDetail parMtdQuestionario) {
		mtdQuestionario = parMtdQuestionario;
	}

	public MasterDetailLevel getMdlQuestionario() {
		return mdlQuestionario;
	}

	public void setMdlQuestionario(final MasterDetailLevel parMdlQuestionario) {
		mdlQuestionario = parMdlQuestionario;
	}

	public Map<String, String> getMapQuestionarios() {
		return mapQuestionarios;
	}

	public void setMapQuestionarios(final Map<String, String> parMapQuestionarios) {
		mapQuestionarios = parMapQuestionarios;
	}

	public String getMensagemAviso() {
		return mensagemAviso;
	}

	public void setMensagemAviso(final String parMensagemAviso) {
		mensagemAviso = parMensagemAviso;
	}

	public Integer getNumeroPedido() {
		return numeroPedido;
	}

	public void setNumeroPedido(final Integer parNumeroPedido) {
		numeroPedido = parNumeroPedido;
	}

	public ClienteUnidadePasseLivre getClienteUnidadePasseLivre() {
		return clienteUnidadePasseLivre;
	}

	public void setClienteUnidadePasseLivre(final ClienteUnidadePasseLivre parClienteUnidadePasseLivre) {
		clienteUnidadePasseLivre = parClienteUnidadePasseLivre;
	}

	public String getProvidencia() {
		return providencia;
	}

	public void setProvidencia(final String parProvidencia) {
		providencia = parProvidencia;
	}

}
