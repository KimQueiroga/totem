package br.com.hermespardini.passelivre.bean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.primefaces.context.RequestContext;

import br.com.hermespardini.corebusiness.model.LogAplicacaoUsuarioFactory;
import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.constantsenum.FuncaoLogEstatistico;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.model.ConsultaDetalheResult;
import br.com.hermespardini.passelivre.model.ConsultaHelpResult;
import br.com.hermespardini.passelivre.model.ControleEstatistico;
import br.com.hermespardini.passelivre.model.DetalhePreparacao;
import br.com.hermespardini.passelivre.model.ExamesEncontrados;
import br.com.hermespardini.passelivre.model.InformacaoTotem;
import br.com.hermespardini.passelivre.model.MensagemAviso;
import br.com.hermespardini.passelivre.model.ParametroPreparacao;
import br.com.hermespardini.passelivre.model.TokenResult;
import br.com.hermespardini.passelivre.service.ControleEstatisticoService;
import br.com.hermespardini.passelivre.service.DetalhePreparacaoService;
import br.com.hermespardini.passelivre.service.IndexService;
import br.com.hermespardini.passelivre.service.PreparacaoExameService;
import br.com.hermespardini.passelivre.utils.TotemUtil;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.bean.MainBean;

@ManagedBean
@SessionScoped
public class PreparacaoExameBean extends MainBean {
	
	private static Logger log = Logger.getLogger(PreparacaoExameBean.class);

	private String mensagemAviso;
	private TokenResult tokenResult;
	private List<ExamesEncontrados> preparacoes;
	private ExamesEncontrados preparacaoSelecionada;
	private ConsultaDetalheResult detalhePreparacao;
	private List<InformacaoTotem> informacoesTotem;
	private ParametroPreparacao parametroPreparacao;
	private DetalhePreparacao detalheExame;
	private InformacaoTotem informacaoTotem;
	private String sessionId;
	

	@PostConstruct
	public void onLoad() {
		try {
			sessionId = buscarSessionId();
			informacaoTotem = new InformacaoTotem();
			informacoesTotem = new ArrayList<>();
			parametroPreparacao = new ParametroPreparacao();
			preparacoes = new ArrayList<ExamesEncontrados>();
			detalhePreparacao = new ConsultaDetalheResult();
			buscarInformacoesTotem();
			buscarToken();
			buscarInformacaoTotem();
		} catch (RegraNegocioException e) {
			log.error("LOG DE EXCESSÃO ONLOAD PreparacaoExameBean", e);
			mensagemAviso = e.getMessage();
			redirectTelaErro();
		}
	}

	private void buscarToken() {
		try {
			final HttpSession session = getHttpServletRequest().getSession();
			tokenResult = (TokenResult) session.getAttribute("tokenResult");
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	private void buscarInformacoesTotem() {
		try {
			informacoesTotem = new ArrayList<>();
			final HttpSession session = getHttpServletRequest().getSession();
			informacoesTotem = (List<InformacaoTotem>) session.getAttribute("informacoesTotem");
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	public void buscarPreparacoes() {
		try {
			verificarSeCampoEstaVazio();
			final PreparacaoExameService preparacaoExameService = new PreparacaoExameService(getHttpServletRequest());
			preparacaoExameService.consultar(parametroPreparacao, tokenResult.getToken());
			preparacoes.clear();
			if (preparacaoExameService.isSuccess()) {
				ConsultaHelpResult preparacao = (ConsultaHelpResult) preparacaoExameService.getResponseObject();

				List<ExamesEncontrados> preparacaoSort = preparacao.getExamesEncontrados();
				List<ExamesEncontrados> preparacaoContains = new ArrayList<>();
				preparacoes.addAll(preparacaoSort.stream()
						.filter(p -> p.getNome().startsWith(parametroPreparacao.getQ().toUpperCase(), 0))
						.collect(Collectors.toList()));
				preparacaoContains.addAll(preparacaoSort.stream()
						.filter(p -> p.getNome().toUpperCase().contains(parametroPreparacao.getQ().toUpperCase()))
						.collect(Collectors.toList()));
				preparacaoContains.removeAll(preparacoes);
				preparacoes.addAll(preparacaoContains);
				preparacoes.addAll(preparacaoSort.stream()
						.filter(p -> !p.getNome().toUpperCase().contains(parametroPreparacao.getQ().toUpperCase()))
						.collect(Collectors.toList()));

			} else {
				gerarLogErroAoBuscarPreparacoes(preparacaoExameService.getResponseMessage());
			}
		} catch (final RegraNegocioException locExc) {
			locExc.printStackTrace();
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
			gerarLogAoBuscarPreparacoes(locExc.getMessage());
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
			gerarLogErroAoBuscarPreparacoes(locExc.getMessage());
		}
	}

	private void gerarLogErroAoBuscarPreparacoes(final String parMessage) {
		try {
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, TotemUtil.buscarSessionId(),
					createBasicLogMap());
		} catch (final Exception locExc) {
		}
	}

	public String cancelarPreparacao() {
		try {
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, TotemUtil.buscarSessionId(),
					createBasicLogMap());
			return redirectIndex();
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return "";
		}
	}

	private String redirectIndex() throws Exception {
		final String nomeMaquina = TotemUtil.retornarNomeDaMaquina();
		getSession().removeAttribute("indexBean");
		TotemUtil.limparSession();
		return "/indexTotem.xhtml?faces-redirect=true&nomeTotem=" + nomeMaquina;
	}

	private void exibirDialogMensagem() {
		RequestContext.getCurrentInstance().execute("PF('dlgMessage').show()");
	}

	private void verificarSeCampoEstaVazio() throws RegraNegocioException {
		if (parametroPreparacao.getQ().isEmpty()) {
			throw new RegraNegocioException("Campo de busca é obrigatório!");
		}
	}

	private void gerarLogAoBuscarPreparacoes(final String parMessage) {
		try {
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, TotemUtil.buscarSessionId(),
					createBasicLogMap());
		} catch (final Exception locExc) {
		}
	}

	public String exibirDetalhes() {
		try {
			final DetalhePreparacaoService detalhePreparacaoService = new DetalhePreparacaoService(
					getHttpServletRequest());
			verificarSePreparacaoFoiSelecionado();
			detalhePreparacaoService.consultar(preparacaoSelecionada.getID(), tokenResult.getToken(), informacaoTotem);
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, TotemUtil.buscarSessionId(),
					createBasicLogMap());
			if (detalhePreparacaoService.isSuccess()) {
				detalhePreparacao = (ConsultaDetalheResult) detalhePreparacaoService.getResponseObject();
				detalheExame = new DetalhePreparacao(detalhePreparacao);
				detalheExame.verificarCamposEmBrancoAoVerHelp();
				return redirectDetalhePreparacao();
			} else {
				gerarLogAoBuscarDetalhePreparacao(detalhePreparacaoService.getResponseMessage());
				MensagemAviso mensagemAviso = TotemUtil
						.createMensagemAviso(detalhePreparacaoService.getResponseMessage());
				try {
					getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
				} catch (Exception e) {
					e.printStackTrace();
				}
				return redirectAtendimentoNaoConcluido();
			}
		} catch (final RuntimeException locRun) {
			locRun.printStackTrace();
			gerarLogAoBuscarDetalhePreparacao(locRun.getMessage() + preparacaoSelecionada);
			mensagemAviso = locRun.getMessage();
			exibirDialogMensagem();
			return null;
		} catch (final RegraNegocioException locExc) {
			// gerarLogAoBuscarDetalhePreparacao(locExc.getMessage() +
			// preparacaoSelecionada); // n�o
			// gravar log de regra de neg�cio
			return redirectDetalhePreparacao();
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			gerarLogAoBuscarDetalhePreparacao(locExc.getMessage());
			return redirectAtendimentoNaoConcluido();
		}
	}

	private void verificarSePreparacaoFoiSelecionado() throws RegraNegocioException {
		if (preparacaoSelecionada == null) {
			throw new RegraNegocioException("Um exame deve ser selecionado!");
		}
	}

	private String redirectAtendimentoNaoConcluido() {
		return "/pages/erro/atendimentoNaoConcluido.xhtml?faces-redirect=true";
	}

	private void gerarLogAoBuscarDetalhePreparacao(final String parMessage) {
		try {
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, TotemUtil.buscarSessionId(),
					createBasicLogMap());
		} catch (final Exception locExc) {
		}
	}

	public String finalizar() {
		try {
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, TotemUtil.buscarSessionId(),
					createBasicLogMap());
			gerarLogEstatistico();
			return redirectIndex();
		} catch (final Exception exc) {
			exc.printStackTrace();
			return "";
		}
	}

	private void gerarLogEstatistico() {
		try {
			final ControleEstatisticoService controleEstatisticoService = new ControleEstatisticoService(
					getHttpServletRequest());
			final ControleEstatistico controleEstatistico = new ControleEstatistico(Constantes.CODIGO_PADRAO, null,
					FuncaoLogEstatistico.EXIBICAO_EXAMES_PREPARO.toString(), retornarId(), null, null,
					retornarUnidade());
			controleEstatisticoService.insert(controleEstatistico);
		} catch (final Exception locExc) {
			gerarLogErroAoGerarLogEstatistico(locExc.getMessage());
		}
	}

	private String retornarUnidade() {
		if (informacoesTotem == null || informacoesTotem.isEmpty()) {
			return null;
		} else {
			return informacoesTotem.get(0).getIdUnidade();
		}
	}

	private Long retornarId() {
		if (informacoesTotem == null || informacoesTotem.isEmpty()) {
			return null;
		} else {
			return informacoesTotem.get(0).getId();
		}
	}

	private void gerarLogErroAoGerarLogEstatistico(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, Constantes.USUARIO_PADRAO);
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, TotemUtil.buscarSessionId(),
					createBasicLogMap());
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	public Map createBasicLogMap() {
		Long idTotem = null;
		Long idUnidade = null;
		if (informacoesTotem != null && !informacoesTotem.isEmpty()) {
			idTotem = informacoesTotem.get(0).getId();
			idUnidade = Long.valueOf(informacoesTotem.get(0).getIdUnidade());
		}
		try {
			return TotemUtil.createBasicLogMap(idTotem, idUnidade, Util.getClientIpAddr(getHttpServletRequest()));
		} catch (Exception e) {
			e.printStackTrace();
			return new HashMap();
		}
	}

	public String voltarParaPreparacao() {
		parametroPreparacao = new ParametroPreparacao();
		preparacoes.clear();
		return redirectPreparacao();
	}

	private String redirectDetalhePreparacao() {
		return "/pages/ppe/detalhePreparacao.xhtml?faces-redirect=true";
	}

	public String redirectPreparacao() {
		return "/pages/ppe/preparacao.xhtml?faces-redirect=true";
	}

	public ParametroPreparacao getParametroPreparacao() {
		return parametroPreparacao;
	}

	public void setParametroPreparacao(final ParametroPreparacao parParametroPreparacao) {
		parametroPreparacao = parParametroPreparacao;
	}

	public ConsultaDetalheResult getDetalhePreparacao() {
		return detalhePreparacao;
	}

	public void setDetalhePreparacao(ConsultaDetalheResult detalhePreparacao) {
		this.detalhePreparacao = detalhePreparacao;
	}

	public List<ExamesEncontrados> getPreparacoes() {
		return preparacoes;
	}

	public void setPreparacoes(final List<ExamesEncontrados> parPreparacoes) {
		preparacoes = parPreparacoes;
	}

	public String getMensagemAviso() {
		return mensagemAviso;
	}

	public void setMensagemAviso(final String parMensagemAviso) {
		mensagemAviso = parMensagemAviso;
	}

	public ExamesEncontrados getPreparacaoSelecionada() {
		return preparacaoSelecionada;
	}

	public void setPreparacaoSelecionada(ExamesEncontrados preparacaoSelecionada) {
		this.preparacaoSelecionada = preparacaoSelecionada;
	}

	public DetalhePreparacao getDetalheExame() {
		return detalheExame;
	}

	public void setDetalheExame(DetalhePreparacao detalheExame) {
		this.detalheExame = detalheExame;
	}

	private void buscarInformacaoTotem() throws RegraNegocioException {
		for (final InformacaoTotem localInformacaoTotem : informacoesTotem) {
			if (localInformacaoTotem.getIp().equalsIgnoreCase(retornarNomeDaMaquina())
					&& localInformacaoTotem.getDescricao().equals(Constantes.SERVICO_PREPARACAO_EXAME)) {
				informacaoTotem = localInformacaoTotem;
			}
		}
	}

	private String retornarNomeDaMaquina() throws RegraNegocioException {
		try {
			final IndexService indexService = new IndexService();
			return indexService.retornarNomeMaquina(getHttpServletRequest());
		} catch (final Exception exc) {
			exc.printStackTrace();
			gerarLogAoRetornarNomeDaMaquina(exc.getMessage());
			throw new RegraNegocioException(exc.getMessage());
		}
	}
	
	private void gerarLogAoRetornarNomeDaMaquina(final String parMessage) {
		try {
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, TotemUtil.buscarSessionId(),
					createBasicLogMap());
		} catch (final Exception locExc) {
		}
	}
	
	private String buscarSessionId() {
		try {
			final HttpSession session = getHttpServletRequest().getSession();
			return session.getAttribute("sessionId").toString();
		} catch (final Exception locExc) {
			return "";
		}
	}

	private void redirectTelaErro() {
		try {
			MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso(this.mensagemAviso);
			try {
				getSession().setAttribute("mensagemAviso", mensagemAviso);
			} catch (Exception e) {
				log.error("LOG DE EXCESSÃO AO SETAR mensagemAviso PreparacaoExameBean", e);
			}
			
			FacesContext.getCurrentInstance().getExternalContext().redirect(redirectAtendimentoNaoConcluidoIndex());
		} catch (Exception e) {
		}
	}

	private String redirectAtendimentoNaoConcluidoIndex() throws Exception {
		final String nomeTotem = retornarNomeDaMaquina();
		registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
				Thread.currentThread().getStackTrace()[1].getMethodName(), mensagemAviso, TotemUtil.buscarSessionId(),
				createBasicLogMap());
		return "/passelivretotem/pages/erro/atendimentoNaoConcluido.xhtml?faces-redirect=true&sessionId=" + sessionId
				+ "&nomeTotem=" + nomeTotem;
	}
}
