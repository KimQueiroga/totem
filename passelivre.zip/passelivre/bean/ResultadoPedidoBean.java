package br.com.hermespardini.passelivre.bean;

import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.component.EditableValueHolder;
import javax.faces.component.UIComponent;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;
import javax.faces.context.PartialViewContext;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.log4j.Logger;
import org.primefaces.component.tabview.TabView;
import org.primefaces.context.RequestContext;
import org.primefaces.event.TabChangeEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;

import br.com.hermespardini.corebusiness.model.Cep;
import br.com.hermespardini.corebusiness.model.LogAplicacaoUsuarioFactory;
import br.com.hermespardini.corebusiness.util.SessionIdBuilder;
import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.constantsenum.FuncaoLogEstatistico;
import br.com.hermespardini.passelivre.constantsenum.SituacaoExamePedidoClienteEnum;
import br.com.hermespardini.passelivre.constantsenum.SituacaoPedidoClienteEnum;
import br.com.hermespardini.passelivre.constantsenum.StatusExamesPedidoEnum;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.exception.SenhaDefinitivaException;
import br.com.hermespardini.passelivre.format.FormataCep;
import br.com.hermespardini.passelivre.format.FormataCpf;
import br.com.hermespardini.passelivre.format.FormataDataAnoMesDia;
import br.com.hermespardini.passelivre.format.FormataDataDiaMesAno;
import br.com.hermespardini.passelivre.format.FormataEndereco;
import br.com.hermespardini.passelivre.format.FormataTelefone;
import br.com.hermespardini.passelivre.interfaces.FormataCampo;
import br.com.hermespardini.passelivre.model.ClienteUnidadePasseLivre;
import br.com.hermespardini.passelivre.model.ConsultaCepResult;
import br.com.hermespardini.passelivre.model.ControleEstatistico;
import br.com.hermespardini.passelivre.model.DetalhePedidoCliente;
import br.com.hermespardini.passelivre.model.InformacaoTotem;
import br.com.hermespardini.passelivre.model.MensagemAviso;
import br.com.hermespardini.passelivre.model.ParametroConsultaCliente;
import br.com.hermespardini.passelivre.model.ParametroImpressao;
import br.com.hermespardini.passelivre.model.ParametroRegistraCliente;
import br.com.hermespardini.passelivre.model.PedidoCliente;
import br.com.hermespardini.passelivre.model.PedidoDetalheResult;
import br.com.hermespardini.passelivre.model.ResultadoResult;
import br.com.hermespardini.passelivre.model.TokenResult;
import br.com.hermespardini.passelivre.model.UserAuth;
import br.com.hermespardini.passelivre.service.CepService;
import br.com.hermespardini.passelivre.service.ClienteService;
import br.com.hermespardini.passelivre.service.ControleEstatisticoService;
import br.com.hermespardini.passelivre.service.FazImpressaoService;
import br.com.hermespardini.passelivre.service.IndexService;
import br.com.hermespardini.passelivre.service.LoginService;
import br.com.hermespardini.passelivre.service.PedidoService;
import br.com.hermespardini.passelivre.service.SenhaService;
import br.com.hermespardini.passelivre.utils.ArquivoUtil;
import br.com.hermespardini.passelivre.utils.ControleBotaoUtil;
import br.com.hermespardini.passelivre.utils.DataUtil;
import br.com.hermespardini.passelivre.utils.MensagemUtil;
import br.com.hermespardini.passelivre.utils.TotemUtil;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.bean.MainBean;

@ManagedBean
@SessionScoped
public class ResultadoPedidoBean extends MainBean {
	
	private static final Logger Log = Logger.getLogger(ResultadoPedidoBean.class);

	private UserAuth user;
	private String sessionId;
	private Integer activeIndex;
	private String numeroPedido;
	private String mensagemAviso;
	private TokenResult tokenResult;
	private FormataCampo formataCampo;
	private List<PedidoCliente> pedidos;
	private ResultadoResult resultadoResult;
	private FormataEndereco formataEndereco;
	private PedidoCliente pedidoSelecionado;
	private InformacaoTotem informacaoTotem;
	private ControleBotaoUtil controleBotaoUtil;
	private List<InformacaoTotem> informacoesTotem;
	private List<PedidoCliente> pedidosSelecionados;
	private List<DetalhePedidoCliente> detalhesPedido;
	private DetalhePedidoCliente detalhePedidoExibicao;
	private ClienteUnidadePasseLivre clienteUnidadePasseLivre;
	private StreamedContent pedidoEmPDF;
	
	private String cep;
	private String bairro;
	private String numero;
	private String complemento;
	private boolean editarLogradouro;
	private boolean editarBairro;
	private String uf;
	private String cidade;
	private String logradouro;

	private String nomeTotem;
	private String nomeTotemNovo;
	private List<DetalhePedidoCliente> detalhesPedidoCodBarras;
	private PedidoDetalheResult pedidoDetalheResult;

	@PostConstruct
	public final void onLoad() {
		try {
			activeIndex = 0;
			numeroPedido = "";
			user = new UserAuth();
			resultadoResult = new ResultadoResult();
			informacaoTotem = new InformacaoTotem();
			controleBotaoUtil = new ControleBotaoUtil();
			formataEndereco = new FormataEndereco();
			clienteUnidadePasseLivre = new ClienteUnidadePasseLivre();
			buscarInformacoesTotem();
			buscarToken();
			verificarSeClientePasseLivreExiste();
			buscarSessionId();
			buscarInformacaoTotem();
			nomeTotem = TotemUtil.retornarNomeDaMaquina();
		} catch (final Exception exc) {
			exc.printStackTrace();
			MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso(exc.getMessage());
			try {
				getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
			} catch (Exception e) {
				e.printStackTrace();
			}
			redirectTelaErro();
		}
	}

	private void buscarDadosCliente() {
		try {
			clienteUnidadePasseLivre = (ClienteUnidadePasseLivre) getSession().getAttribute("clienteUnidadePasseLivre");
		} catch (final Exception locExc) {
		}
	}

	private void buscarInformacaoTotem() throws RegraNegocioException {
		for (final InformacaoTotem localInformacaoTotem : informacoesTotem) {
			if (localInformacaoTotem.getIp().equalsIgnoreCase(retornarNomeDaMaquina())) {
				informacaoTotem = localInformacaoTotem;
			}
		}
	}

	private String retornarNomeDaMaquina() throws RegraNegocioException {
		try {
			final IndexService indexService = new IndexService();
			return indexService.retornarNomeMaquina(getHttpServletRequest());
		} catch (final Exception exc) {
			exc.printStackTrace();
			gerarLogAoRetornarNomeDaMaquina(exc.getMessage());
			throw new RegraNegocioException(exc.getMessage());
		}
	}

	private void gerarLogAoRetornarNomeDaMaquina(final String parMessage) {
		try {
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, null, createBasicLogMap());
		} catch (final Exception locExc) {
		}
	}

	private void buscarSessionId() throws Exception {
		sessionId = getSession().getAttribute("sessionId").toString();
	}
	
	public void redirectEnviarCodVerif() {
		try {
			controleBotaoUtil.redirectEnviarCodVerif(getHttpServletRequest(), user, sessionId);
		} catch (final Exception e) {
			e.printStackTrace();
		}
	}

	private void redirectTelaErro() {
		try {
			FacesContext.getCurrentInstance().getExternalContext().redirect(redirectAtendimentoNaoConcluidoIndex());
		} catch (final IOException exc) {
			exc.printStackTrace();
		}
	}

	private String redirectAtendimentoNaoConcluidoIndex() {
		return "/passelivretotem/pages/erro/atendimentoNaoConcluido.xhtml?faces-redirect=true&sessionId=" + sessionId;
	}

	private void buscarToken() {
		try {
			tokenResult = (TokenResult) getSession().getAttribute("tokenResult");
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	private void buscarInformacoesTotem() {
		try {
			informacoesTotem = (List<InformacaoTotem>) getSession().getAttribute("informacoesTotem");
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	public void atualizarDados() {
		String mensagem = "";
		try {
			final ClienteService clienteService = new ClienteService(getHttpServletRequest());
			clienteUnidadePasseLivre.setSenhaUsuario(user.getAuthPass());
			clienteUnidadePasseLivre
					.setComplemento(clienteUnidadePasseLivre.retirarCaracteriosInvalidosNoComplemento());
			clienteUnidadePasseLivre.setNumero(clienteUnidadePasseLivre.retornarNumeroValido());
			clienteUnidadePasseLivre.verificarCamposEmBrancoAoAtualizar();
			clienteUnidadePasseLivre.validarEmail();
			formatarValores();
			formataEndereco.convertStreetAndComplement(clienteUnidadePasseLivre);
			clienteService.setValueObject(clienteUnidadePasseLivre);
			ParametroRegistraCliente parRegistraCliente = new ParametroRegistraCliente(clienteUnidadePasseLivre);
			clienteService.registrarCliente(parRegistraCliente);
			mensagem = clienteService.getResponseMessage();
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, clienteUnidadePasseLivre.getCpf());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId, createBasicLogMap());
			if (clienteService.isSuccess()) {
				redirectResultado();
				gerarLogEstatisticoAoAtualizar();
			} else {
				mensagemAviso = clienteService.getResponseMessage();
				RequestContext.getCurrentInstance().execute("PF('dlgMessage').show()");
				if (mensagemAviso.contains("CPF(") && mensagemAviso.contains("inválido")) {
					clienteUnidadePasseLivre.setCpf(null);
				}
			}
		} catch (final RuntimeException locExc) {
			gerarLogErroAoAtualizar(locExc.getMessage() + mensagem);
			MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso(locExc.getMessage());
			try {
				getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
			} catch (Exception e) {
				e.printStackTrace();
			}
			redirectTelaErro();
		} catch (final Exception locExc) {
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
			locExc.printStackTrace();
			gerarLogErroAoAtualizar(locExc.getMessage() + mensagem);
		}
	}

	private void gerarLogEstatisticoAoAtualizar() {
		try {
			final ControleEstatisticoService controleEstatisticoService = new ControleEstatisticoService(
					getHttpServletRequest());
			abrirResultadoCompleto();
			final ControleEstatistico controleEstatistico = new ControleEstatistico(
					clienteUnidadePasseLivre.getCodigoCliente(), null, FuncaoLogEstatistico.ATUALIZAR_DADOS.toString(),
					informacoesTotem.get(0).getId(), null, null, informacoesTotem.get(0).getIdUnidade());
			controleEstatisticoService.insert(controleEstatistico);
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	public String cancelarAtualizacao() {
		try {
			return redirectIndex();
		} catch (final Exception exc) {
			exc.printStackTrace();
			return "";
		}
	}

	private void formatarValores() {
		clienteUnidadePasseLivre.setCelular(formatarTelefone(clienteUnidadePasseLivre.getCelular()));
		clienteUnidadePasseLivre.setTelefone(formatarTelefone(clienteUnidadePasseLivre.getTelefone()));
		clienteUnidadePasseLivre.setCep(formatarCep(clienteUnidadePasseLivre.getCep()));
		clienteUnidadePasseLivre.setCpf(formatarCpf(clienteUnidadePasseLivre.getCpf()));
	}

	private String formatarTelefone(final String telefone) {
		return new FormataTelefone(telefone).formatar();
	}

	private String formatarCep(final String cep) {
		formataCampo = new FormataCep(cep);
		return formataCampo.formatar();
	}

	private String formatarCpf(final String cpf) {
		try {
			return new FormataCpf(cpf).formatar();
		} catch (final Exception locExc) {
			return null;
		}
	}

	public String formatarDataNascimento(final String data) {
		try {
			final DataUtil dataUtil = new DataUtil();
			return dataUtil.formatarStringParaStringBR(data);
		} catch (final ParseException exc) {
			exc.printStackTrace();
			return "";
		}
	}

	public boolean getHappyBirthDate() {
		try {
			buscarDadosCliente();
			if (new ClienteService(getHttpServletRequest())
					.getHappyBirthDate(clienteUnidadePasseLivre.getDataNascimento())) {
				gerarLogEstatisticoParaAniversariante();
				return true;
			} else {
				return false;
			}
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return false;
		}
	}

	private void gerarLogEstatisticoParaAniversariante() {
		try {
			final ControleEstatisticoService controleEstatisticoService = new ControleEstatisticoService(
					getHttpServletRequest());
			final ControleEstatistico controleEstatistico = new ControleEstatistico(
					clienteUnidadePasseLivre.getCodigoCliente(), null,
					FuncaoLogEstatistico.LEMBRETE_ANIVERSARIO.toString(), informacoesTotem.get(0).getId(), null, null,
					informacoesTotem.get(0).getIdUnidade());
			controleEstatisticoService.insert(controleEstatistico);
		} catch (final Exception locExc) {
			gerarLogErroAoGerarLogEstatistico(locExc.getMessage());
		}
	}

	private void gerarLogErroAoGerarLogEstatistico(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, clienteUnidadePasseLivre.getCpf());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, sessionId,
					createBasicLogMap());
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	public String aceitarTermo() {
		try {
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId, createBasicLogMap());
			// return redirectPreparacao();
			return redirectLogin();
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return "";
		}
	}

	public String naoAceitarTermo() {
		try {
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId, createBasicLogMap());
			return redirectIndex();
		} catch (final Exception locExc) {
			return "";
		}
	}

	public void pesquisarCep() {
		try {
			final FacesContext facesContext = FacesContext.getCurrentInstance();
			final PartialViewContext partialViewContext = facesContext.getPartialViewContext();
			final Collection<String> renderIds = partialViewContext.getRenderIds();
			final UIViewRoot viewRoot = getContext().getViewRoot();
			for (final String renderId : renderIds) {
				final UIComponent component = viewRoot.findComponent(renderId);
				final EditableValueHolder input = (EditableValueHolder) component;
				if (input != null) {
					input.resetValue();
				} else {
					limparCamposEndereco();
				}
			}
			adicionarEnderecoPeloCEP();
		} catch (final NullPointerException locE) {
			limparCamposEndereco();
			gerarLogAoBuscarCEP("CEP não existe!");
		} catch (final Exception locE) {
			limparCamposEndereco();
			gerarLogAoBuscarCEP(locE.getMessage());
		}
	}

	private void limparCamposEndereco() {
		getClienteUnidadePasseLivre().setUf("");
		getClienteUnidadePasseLivre().setBairro("");
		getClienteUnidadePasseLivre().setCidade("");
		getClienteUnidadePasseLivre().setUf("");
		getClienteUnidadePasseLivre().setNumero("");
		getClienteUnidadePasseLivre().setComplemento("");
	}

	private void adicionarEnderecoPeloCEP() throws Exception {
		String cep = getCep().replaceAll("[^0-9]", "");
		if (cep.length() == 8) {
			final CepService cepService = new CepService(getHttpServletRequest());
			ConsultaCepResult cepResult = cepService.consultarCep(cep, tokenResult.getToken());
			if (cepService.isSuccess()) {
				if (cepResult != null) {
					adiconarEnderecoAoCliente(cepResult);
				} else {
					limparCamposEndereco();
					exibirDialogMensagemAlert("CEP não encontrado!");
				}
			} else {
				limparCamposEndereco();
				exibirDialogMensagemAlert("CEP não encontrado!");
			}
		} else {
			limparCamposEndereco();
			exibirDialogMensagemAlert("CEP deve conter 8 caracteres numéricos!");
		}		
	}
	
	private void exibirDialogMensagemAlert(String msg) {
		setMensagemAviso(msg);
//		PrimeFaces.current().executeScript("PF('dlgMessageAviso').show()");
	}

	private void gerarLogAoBuscarCEP(final String mensagem) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, clienteUnidadePasseLivre.getCpf());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), mensagem, sessionId,
					createBasicLogMap());
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	private void adiconarEnderecoAoCliente(ConsultaCepResult consultaCepResult) {
		clienteUnidadePasseLivre.setUf(consultaCepResult.getUf());
		clienteUnidadePasseLivre.setCidade(consultaCepResult.getLocalidade());
		clienteUnidadePasseLivre.setLogradouro(montarEnderecoLogradouro(consultaCepResult));
		clienteUnidadePasseLivre.setBairro(consultaCepResult.getBairro() != null ? consultaCepResult.getBairro() : "");
		clienteUnidadePasseLivre.setNumero("");
		clienteUnidadePasseLivre.setComplemento("");
		
		if(clienteUnidadePasseLivre.getLogradouro().equals(""))
			setEditarLogradouro(true);
		else
			setEditarLogradouro(false);
		
		if(clienteUnidadePasseLivre.getBairro().equals(""))
			setEditarBairro(true);
		else
			setEditarBairro(false);
	}
	
	private String montarEnderecoLogradouro(ConsultaCepResult consultaCepResult) {
		if(consultaCepResult.getLogradouro() != null && !consultaCepResult.getLogradouro().equals("") && consultaCepResult.getTipoEndereco() != null && !consultaCepResult.getTipoEndereco().equals(""))
			return consultaCepResult.getTipoEndereco() + " " + consultaCepResult.getLogradouro();
		else if(consultaCepResult.getLogradouroAbreviado() != null && !consultaCepResult.getLogradouroAbreviado().equals(""))
			return consultaCepResult.getLogradouroAbreviado();		
		else {
			return "";
		}
	}

	private boolean cepELogradouroNaoEstaoNulos(final Cep cep) {
		return cep != null;
	}

	public void alterarSenha() {
		try {
			verificarSeSenhasConferem();
			final ClienteUnidadePasseLivre locClienteUnidadePasseLivre = new ClienteUnidadePasseLivre(getUser(),
					getClienteUnidadePasseLivre());
			final SenhaService loSenhaService = new SenhaService(getHttpServletRequest());
			loSenhaService.setValueObject(locClienteUnidadePasseLivre);
			loSenhaService.atualizarSenha();
			if (loSenhaService.isSuccess()) {
				getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
				registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId,
						createBasicLogMap());
			} else {
				gerarLogErroAoValidarSenha(loSenhaService.getResponseMessage());
			}
			mensagemAviso = loSenhaService.getResponseMessage();
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			mensagemAviso = locExc.getMessage();
			gerarLogErroAoValidarSenha(locExc.getMessage());
		} finally {
			fecharDialogResetSenha();
			exibirDialogMensagem();
			resetarCampos();
		}
	}

	private void exibirDialogMensagem() {
		RequestContext.getCurrentInstance().execute("PF('dlgMessage').show()");
	}

	private void verificarSeSenhasConferem() throws Exception {
		if (!user.getNewPass().equals(user.getConfirmAuthPass())) {
			throw new Exception("As senhas não conferem");
		}
	}

	private void resetarCampos() {
		getUser().setNewPass("");
		getUser().setConfirmAuthPass("");
	}

	private void gerarLogErroAoValidarSenha(final String parMensagemErro) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMensagemErro, sessionId,
					createBasicLogMap());
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	private void fecharDialogResetSenha() {
		RequestContext.getCurrentInstance().execute("PF('dlgAlterarSenha').hide()");
	}

	private void gerarLogErroAoAtualizar(final String parMensagem) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMensagem, sessionId,
					createBasicLogMap());
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	public String retornarSituacao(final String situacao) {
		return SituacaoPedidoClienteEnum.valueOfSituacao(situacao).getDescricao();
	}
	
	public String retornarSituacaoPedidoDetalhe(DetalhePedidoCliente detalhe) {
		
		if(detalhe.getSamplePendency() == 1) {			
			return SituacaoExamePedidoClienteEnum.valueOfSituacao(detalhe.getSamplePendency().toString()).getDescricao();
		} else {
			
			return SituacaoPedidoClienteEnum.valueOfSituacao(detalhe.getTestStatus().toString()).getDescricao();
		}
		
	}

	public Boolean botaoCPFEstaAtivado() {
		getRequestContext().update("frmPrincipal:btnBotao");
		return activeIndex == 1;
	}

	public void finalizar() {
		final RequestContext context = RequestContext.getCurrentInstance();
		context.execute("PF('dlgConfirmacao').show();");
	}

	private void buscarPedidos() throws Exception {
		pedidos = new ArrayList<>();
		if (clienteUnidadePasseLivre != null) {
			final PedidoService pedidoService = new PedidoService(getHttpServletRequest());
			pedidoService.setValueObject(clienteUnidadePasseLivre);
			pedidoService.montarUrlConsulta(informacaoTotem.getIdEmpresa());
			pedidoService.consultar();
			final List<PedidoCliente> pedidosClientes = (List<PedidoCliente>) pedidoService.getResponseObject();
			pedidos.addAll(retornarResultadosLiberados(pedidosClientes));
		}
	}

	private void verificarSeClientePasseLivreExiste() throws Exception {
		if (clienteUnidadePasseLivre.getNomeCliente() == null) {
			receberClientePasseLivre();
			buscarPedidos();
		}
	}

	private void receberClientePasseLivre() {
		try {
			clienteUnidadePasseLivre = (ClienteUnidadePasseLivre) getSession().getAttribute("clienteUnidadePasseLivre");
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	private void buscarDetalhesPedido() throws Exception {
		detalhesPedido = new ArrayList<>();
		final PedidoService pedidoService = new PedidoService(getHttpServletRequest());
		pedidoService.setValueObject(clienteUnidadePasseLivre);
		pedidoService.consultarResultado(pedidoSelecionado.getId());
		detalhesPedido.addAll((List<DetalhePedidoCliente>) pedidoService.getResponseObject());
	}

	private void poeUsuarioNaSessao(ClienteUnidadePasseLivre clienteUnidadePasseLivre) {
		if (clienteUnidadePasseLivre != null) {
			try {
				getSession().setAttribute("clienteUnidadePasseLivre", clienteUnidadePasseLivre);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				
				Log.error(e);
			}
		}
	}

	public void abrirResultadoIndividual(final DetalhePedidoCliente detalhePedidoCliente) {
		try {
			detalhePedidoExibicao = new DetalhePedidoCliente();
			detalhePedidoExibicao = detalhePedidoCliente;
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, clienteUnidadePasseLivre.getCpf());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId, createBasicLogMap());
			final RequestContext context = RequestContext.getCurrentInstance();
			context.execute("PF('dlgPDFResultadoIndividual').show();");
			gerarLogEstatisticoAbrirResultadoIndividual();
		} catch (final Exception exc) {
			exc.printStackTrace();
			gerarLogErroAoAbrirResultadoIndividual(exc.getMessage());
		}
	}

	private void gerarLogEstatisticoAbrirResultadoIndividual() {
		try {
			final ControleEstatisticoService controleEstatisticoService = new ControleEstatisticoService(
					getHttpServletRequest());
			abrirResultadoCompleto();
			final ControleEstatistico controleEstatistico = new ControleEstatistico(
					clienteUnidadePasseLivre.getCodigoCliente(), null,
					FuncaoLogEstatistico.VISUALIZAR_LAUDO_PARCIAL.toString(), informacoesTotem.get(0).getId(), null,
					null, informacoesTotem.get(0).getIdUnidade());
			controleEstatisticoService.insert(controleEstatistico);
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	private void gerarLogErroAoAbrirResultadoIndividual(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, clienteUnidadePasseLivre.getCpf());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, sessionId,
					createBasicLogMap());
		} catch (final Exception locExc) {
			locExc.getMessage();
		}
	}

	public void imprimirResultadoIndividual(final DetalhePedidoCliente paramDetalhePedidoCliente) {
		try {
			final ParametroImpressao parametroImpressao = new ParametroImpressao(paramDetalhePedidoCliente,
					informacoesTotem.get(0), tokenResult, clienteUnidadePasseLivre);
			final FazImpressaoService fazImpressaoService = new FazImpressaoService(getHttpServletRequest());
			final ArquivoUtil arquivoUtil = new ArquivoUtil();
			final RequestContext context = RequestContext.getCurrentInstance();
			context.execute("PF('dlgPDFResultadoIndividual').hide();");
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, clienteUnidadePasseLivre.getCpf());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId, createBasicLogMap());
			fazImpressaoService.imprimirResultado(parametroImpressao);
			resultadoResult = new ResultadoResult();
			if (fazImpressaoService.isSuccess()) {
				resultadoResult = (ResultadoResult) fazImpressaoService.getResponseObject();
				gerarLogEstatisticoImprimirResultadoIndividual();
				context.execute("PF('dlgInformacaoImpressao').show();");
			} else {
				gerarLogAoFazerImpressaoResultadoIndividual(fazImpressaoService.getResponseMessage());
				MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso(fazImpressaoService.getResponseMessage());
				try {
					getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
				} catch (Exception e) {
					e.printStackTrace();
				}
				redirectTelaErro();
			}
			fecharArquivos();
		} catch (final Exception exc) {
			exc.printStackTrace();
			gerarLogAoFazerImpressaoResultadoIndividual(exc.getMessage());
			redirectTelaErro();
		}
	}

	public void imprimirRestultadoIndividual() {
		try {
			final ParametroImpressao parametroImpressao = new ParametroImpressao(detalhePedidoExibicao,
					informacoesTotem.get(0), tokenResult, clienteUnidadePasseLivre);
			final FazImpressaoService fazImpressaoService = new FazImpressaoService(getHttpServletRequest());
			final RequestContext context = RequestContext.getCurrentInstance();
			context.execute("PF('dlgPDFResultadoIndividual').hide();");
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, clienteUnidadePasseLivre.getCpf());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId, createBasicLogMap());
			fazImpressaoService.imprimirResultado(parametroImpressao);
			resultadoResult = new ResultadoResult();
			if (fazImpressaoService.isSuccess()) {
				resultadoResult = (ResultadoResult) fazImpressaoService.getResponseObject();
				gerarLogEstatisticoImprimirResultadoIndividual();
				context.execute("PF('dlgInformacaoImpressao').show();");
			} else {
				gerarLogAoFazerImpressaoResultadoIndividual(fazImpressaoService.getResponseMessage());
				MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso(fazImpressaoService.getResponseMessage());
				try {
					getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
				} catch (Exception e) {
					e.printStackTrace();
				}
				redirectTelaErro();
			}
			fecharArquivos();
		} catch (final Exception exc) {
			exc.printStackTrace();
			gerarLogAoFazerImpressaoResultadoIndividual(exc.getMessage());
			redirectTelaErro();
		}
	}

	private void esperarParaExibirMensagemImpressao() throws InterruptedException {
		Thread.sleep(Constantes.TEMPO_ESPERA_IMPRESSAO_PADRAO);
	}

	private void gerarLogEstatisticoImprimirResultadoIndividual() {
		try {
			final ControleEstatisticoService controleEstatisticoService = new ControleEstatisticoService(
					getHttpServletRequest());
			abrirResultadoCompleto();
			final ControleEstatistico controleEstatistico = new ControleEstatistico(
					clienteUnidadePasseLivre.getCodigoCliente(), null,
					FuncaoLogEstatistico.IMPRIMIR_LAUDO_PARCIAL.toString(), informacoesTotem.get(0).getId(), null, null,
					informacoesTotem.get(0).getIdUnidade());
			controleEstatisticoService.insert(controleEstatistico);
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	public void imprimirRestultadoCompleto() {
		try {
			final ParametroImpressao parametroImpressao = new ParametroImpressao(pedidoSelecionado,
					informacoesTotem.get(0), tokenResult, clienteUnidadePasseLivre);
			final FazImpressaoService fazImpressaoService = new FazImpressaoService(getHttpServletRequest());
			final RequestContext context = RequestContext.getCurrentInstance();
			context.execute("PF('dlgPDFResultado').hide();");
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, clienteUnidadePasseLivre.getCpf());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId, createBasicLogMap());
			fazImpressaoService.imprimirResultado(parametroImpressao);
			resultadoResult = new ResultadoResult();
			if (fazImpressaoService.isSuccess()) {
				resultadoResult = (ResultadoResult) fazImpressaoService.getResponseObject();
				gerarLogEstatisticoImprimirResultadoCompleto();
				context.execute("PF('dlgInformacaoImpressao').show();");
			} else {
				gerarLogAoFazerImpressaoResultadoCompleto(fazImpressaoService.getResponseMessage());
				MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso(fazImpressaoService.getResponseMessage());
				try {
					getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
				} catch (Exception e) {
					e.printStackTrace();
				}
				redirectTelaErro();
			}
		} catch (final Exception exc) {
			exc.printStackTrace();
			gerarLogAoFazerImpressaoResultadoCompleto(exc.getMessage());
			redirectTelaErro();
		}
	}

	public void abrirDialgImpressaoPorCodigoBarra() {
		numeroPedido = "";
		final RequestContext context = RequestContext.getCurrentInstance();
		context.execute("PF('dlgCodigoBarra').show();");
	}

	public void imprimirRestultadoPorCodigoBarra() {
		final RequestContext context = RequestContext.getCurrentInstance();
		try {
			if (numeroPedido != null && numeroPedido.length() == 14 && numeroPedido.startsWith("01")
					&& numeroPedido.endsWith("00")) {
				buscarPedidoDetalheResult();
                if(StatusExamesPedidoEnum.TODOS_EXAMES_LIBERADOS.getId().equals(pedidoDetalheResult.getStatusExamesPedido()) ) {
					final ParametroImpressao parametroImpressao = new ParametroImpressao(numeroPedido,
							informacoesTotem.get(0), tokenResult);
					final FazImpressaoService fazImpressaoService = new FazImpressaoService(getHttpServletRequest());
					context.execute("PF('dlgCodigoBarra').hide();");
					registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
							Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId,
							createBasicLogMap());
					fazImpressaoService.imprimirResultado(parametroImpressao);
					resultadoResult = new ResultadoResult();
					if (fazImpressaoService.isSuccess()) {
						resultadoResult = (ResultadoResult) fazImpressaoService.getResponseObject();
						getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN,
								resultadoResult.getCodigoCliente());
						gerarLogEstatisticoImprimirResultadoCompletoPorCodigoBarra(resultadoResult);
						
						context.execute("PF('dlgInformacaoImpressao').show();");
					} else {
						context.execute("PF('dlgCodigoBarra').hide();");
						getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN,
								resultadoResult.getCodigoCliente());
						if (fazImpressaoService.getResponseMessage().contains("sem laudo liberado")) {
							registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
									Thread.currentThread().getStackTrace()[1].getMethodName(),
									fazImpressaoService.getResponseMessage(), sessionId, createBasicLogMap());
						} else {
							gerarLogErroAoFazerImpressaoResultadoCompletoPorCodigoBarra(
									fazImpressaoService.getResponseMessage());
						}
						mensagemAviso = fazImpressaoService.getResponseMessage();
						exibirDialogMensagem();
					}
				} else {
					context.execute("PF('dlgInformacaoImpressaoParcial').show();");
				}
				
			} else {
				numeroPedido = "";
			}
		} catch (final Exception exc) {
			exc.printStackTrace();
			context.execute("PF('dlgCodigoBarra').hide();");
			gerarLogErroAoFazerImpressaoResultadoCompletoPorCodigoBarra(exc.getMessage());
			mensagemAviso = exc.getMessage();
			exibirDialogMensagem();
		}
	}

	private void gerarLogErroAoFazerImpressaoResultadoCompletoPorCodigoBarra(final String parResponseMessage) {
		try {
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parResponseMessage, sessionId,
					createBasicLogMap());
		} catch (final Exception locExc) {
			locExc.getMessage();
		}
	}

	private void gerarLogEstatisticoImprimirResultadoCompleto() {
		try {
			final ControleEstatisticoService controleEstatisticoService = new ControleEstatisticoService(
					getHttpServletRequest());
			abrirResultadoCompleto();
			final ControleEstatistico controleEstatistico = new ControleEstatistico(
					clienteUnidadePasseLivre.getCodigoCliente(), null,
					FuncaoLogEstatistico.IMPRIMIR_LAUDO_COMPLETO.toString(), informacoesTotem.get(0).getId(), null,
					null, informacoesTotem.get(0).getIdUnidade());
			controleEstatisticoService.insert(controleEstatistico);
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	private void gerarLogEstatisticoImprimirResultadoCompletoPorCodigoBarra(final ResultadoResult parResultadoResult) {
		try {
			final ControleEstatisticoService controleEstatisticoService = new ControleEstatisticoService(
					getHttpServletRequest());
			abrirResultadoCompleto();
			final ControleEstatistico controleEstatistico = new ControleEstatistico(
					parResultadoResult.getCodigoCliente(), null,
					FuncaoLogEstatistico.IMPRIMIR_LAUDO_CODIGO_BARRA.toString(), informacoesTotem.get(0).getId(), null,
					null, informacoesTotem.get(0).getIdUnidade());
			controleEstatisticoService.insert(controleEstatistico);
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	private void gerarLogImprimirResultadoCompleto() {
		try {
			final ControleEstatisticoService controleEstatisticoService = new ControleEstatisticoService(
					getHttpServletRequest());
			abrirResultadoCompleto();
			final ControleEstatistico controleEstatistico = new ControleEstatistico(
					clienteUnidadePasseLivre.getCodigoCliente(), null,
					FuncaoLogEstatistico.IMPRIMIR_LAUDO_COMPLETO.toString(), informacoesTotem.get(0).getId(), null,
					null, informacoesTotem.get(0).getIdUnidade());
			controleEstatisticoService.insert(controleEstatistico);
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	private void gerarLogAoFazerImpressaoResultadoIndividual(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, clienteUnidadePasseLivre.getCpf());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, sessionId,
					createBasicLogMap());
		} catch (final Exception locExc) {
			locExc.getMessage();
		}
	}

	private void gerarLogAoFazerImpressaoResultadoCompleto(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, clienteUnidadePasseLivre.getCpf());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, sessionId,
					createBasicLogMap());
		} catch (final Exception locExc) {
			locExc.getMessage();
		}
	}

	private String retornarNomeRelatorio() {
		return informacoesTotem.get(0).getIdUnidade() + pedidoSelecionado.getNumeroPedido();
	}

	public void abrirImagemIndividual(final DetalhePedidoCliente detalhePedidoCliente) {
		try {
			detalhePedidoExibicao = new DetalhePedidoCliente();
			detalhePedidoExibicao = detalhePedidoCliente;
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, clienteUnidadePasseLivre.getCpf());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId, createBasicLogMap());
			final RequestContext context = RequestContext.getCurrentInstance();
			context.execute("PF('dlgImagemIndividual').show();");
			gerarLogEstatisticoImagemIndividual();
		} catch (final Exception exc) {
			exc.printStackTrace();
			gerarLogAoAbrirImagemIndividual(exc.getMessage());
		}
	}

	private void gerarLogEstatisticoImagemIndividual() {
		try {
			final ControleEstatisticoService controleEstatisticoService = new ControleEstatisticoService(
					getHttpServletRequest());
			abrirResultadoCompleto();
			final ControleEstatistico controleEstatistico = new ControleEstatistico(
					clienteUnidadePasseLivre.getCodigoCliente(), null,
					FuncaoLogEstatistico.VISUALIZAR_IMAGEM.toString(), informacoesTotem.get(0).getId(), null, null,
					informacoesTotem.get(0).getIdUnidade());
			controleEstatisticoService.insert(controleEstatistico);
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	private void gerarLogAoAbrirImagemIndividual(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, clienteUnidadePasseLivre.getCpf());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, sessionId,
					createBasicLogMap());
		} catch (final Exception locExc) {
			locExc.getMessage();
		}
	}

	public String cancelarLogin() {
		try {
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId, createBasicLogMap());
			return redirectIndex();
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return "";
		}
	}

	public void cancelarResultado() {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, clienteUnidadePasseLivre.getCpf());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId, createBasicLogMap());
			final RequestContext context = RequestContext.getCurrentInstance();
			context.execute("PF('dlgConfirmacao').show();");
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	public void cancelarSessao() {
		try {
			fecharArquivos();
			final String nomeMaquina = TotemUtil.retornarNomeDaMaquina();
			TotemUtil.limparSession();
			FacesContext.getCurrentInstance().getExternalContext()
					.redirect("/passelivretotem/indexTotem.xhtml?faces-redirect=true&nomeTotem=" + nomeMaquina);
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	public String redirectPreparacao() {
		return "/pages/ppe/preparacao.xhtml?faces-redirect=true";
	}

	public String redirectOrcamento() {
		return "/pages/ocm/preparacao.xhtml?faces-redirect=true";
	}

	public void esquecerSenha() {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId,
					createBasicLogMap());
			verificarTipoLogin();
			redirectEnviarCodVerif();
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	public Boolean getHabilitaAtendimentoUnimed() {
		return controleBotaoUtil.getHabilitaAtendimentoUnimed(informacoesTotem);
	}

	public Boolean getHabilitaOrcamento() {
		return controleBotaoUtil.getHabilitaOrcamento(informacoesTotem);
	}

	public Boolean getHabilitaEntregaResultado() {
		return controleBotaoUtil.getHabilitaEntregaResultado(informacoesTotem);
	}

	public Boolean getHabilitaEntregaMaterial() {
		return controleBotaoUtil.getHabilitaEntregaMaterial(informacoesTotem);
	}

	public Boolean getHabilitaPeparacao() {
		return controleBotaoUtil.getHabilitaPreparacaoExame(informacoesTotem);
	}

	private boolean servicoEstaAtivado(final InformacaoTotem locInformacaoTotem) {
		return locInformacaoTotem.getAtivo().equals("S");
	}

	public String voltarParaResultado() {
		return "/pages/res/resultado.xhtml?faces-redirect=true";
	}

	public String exibirDetalhes() {
		try {
			verificarSePedidoFoiSelecionado();
			buscarDetalhesPedido();
			return redirectDetalhesResultado();
		} catch (final IOException exc) {
			exc.printStackTrace();
			return redirectAtendimentoNaoConcluido();
		} catch (final RegraNegocioException exc) {
			mensagemAviso = exc.getMessage();
			exibirDialogMensagem();
			return "";
		} catch (final Exception exc) {
			exc.printStackTrace();
			return redirectAtendimentoNaoConcluido();
		}
	}

	private String redirectDetalhesResultado() {
		return "/pages/res/detalhesResultado.xhtml?faces-redirect=true";
	}

	private String redirectAtendimentoNaoConcluido() {
		return "/passelivretotem/pages/erro/atendimentoNaoConcluido.xhtml?faces-redirect=true&sessionId=" + sessionId;
	}

	private void verificarSePedidoFoiSelecionado() throws RegraNegocioException {
		if (pedidoSelecionado == null) {
			throw new RegraNegocioException("Pedido deve ser selecionado!");
		}
	}

	public Boolean exibirPDFDetalhe(final DetalhePedidoCliente detalhePedidoCliente) {
		if (detalhePedidoCliente != null) {
			return detalhePedidoCliente.getTestStatus() == 1;
		} else {
			return false;
		}
	}

	public Boolean exibirImagemDetalhe(final DetalhePedidoCliente detalhePedidoCliente) {
		try {
			if (detalhePedidoCliente != null && detalhePedidoCliente.getResultPacsUrl() != null) {
				return detalhePedidoCliente.getTestStatus() == 1
						&& !detalhePedidoCliente.getResultPacsUrl().equals("-1");
			} else {
				return false;
			}
		} catch (final Exception locExc) {
			return false;
		}
	}

	public Boolean getExibirPDF() {
		if (pedidoSelecionado != null) {
			return pedidoSelecionado.exibirPdf(detalhesPedido);
		} else {
			return false;
		}
	}

	public void onTabChange(final TabChangeEvent event) {
		final TabView tv = (TabView) event.getComponent();
		activeIndex = tv.getActiveIndex();
		limparCampoLogin();
	}

	public String dataFormatada(final String data) {
		final DataUtil dataUtil = new DataUtil();
		try {
			if (StringUtils.containsAny("/^[A-Za-z ]+$/", data)) {
				return dataUtil.formatarStringParaStringBR(data);
			} else {
				return "";
			}
		} catch (final ParseException exc) {
			return "";
		}
	}

	public String dataFormatadaComHora(final String dataTime) {
		final DataUtil dataUtil = new DataUtil();
		try {
			return dataUtil.formatarStringParaStringBRComHora(dataTime);
		} catch (final ParseException exc) {
			return "";
		}
	}

	private InputStream buscarDetalhePedidoEmPDF(final DetalhePedidoCliente paramDetalhePedidoSelecionado) {
		try {
			final HttpClient client = HttpClientBuilder.create().build();
			final HttpGet request = new HttpGet(paramDetalhePedidoSelecionado.getTestPdfUrl());
			final HttpResponse response = client.execute(request);
			final InputStream initialStream = response.getEntity().getContent();
			return initialStream;
		} catch (final IOException exc) {
			exc.printStackTrace();
			return null;
		}
	}

	private InputStream buscarPedidoEmPDF() {
		try {
			final HttpClient client = HttpClientBuilder.create().build();
			final HttpGet request = new HttpGet(pedidoSelecionado.getResultPdfUrl());
			final HttpResponse response = client.execute(request);
			final InputStream inputStream = response.getEntity().getContent();
			return inputStream;
		} catch (final IOException exc) {
			exc.printStackTrace();
			return null;
		}
	}

	public StreamedContent getPedidoCompleto() {
		pedidoEmPDF = null;
		pedidoEmPDF = new DefaultStreamedContent(buscarPedidoEmPDF(), "application/pdf;navpanes=0", "pedido");
		return pedidoEmPDF;
	}

	public StreamedContent getPedidoIndividual() {
		try {
			pedidoEmPDF = null;
			pedidoEmPDF = new DefaultStreamedContent(buscarDetalhePedidoEmPDF(detalhePedidoExibicao),
					"application/pdf;?#toolbar=0&navpanes=0", "pedido");
			return pedidoEmPDF;
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return null;
		}
	}

	public void fecharArquivos() {
		try {
			if (pedidoEmPDF != null) {
				pedidoEmPDF.getStream().close();
			}
		} catch (IOException locExc) {
			locExc.printStackTrace();
		}
	}

	private String retornarDadosGA() {
		final StringBuilder sb = new StringBuilder();
		sb.append(informacoesTotem.get(0).getIdUnidade()).append("_").append(pedidoSelecionado.getId());
		return sb.toString();
	}

	public String redirectLogin() {
		return "/pages/res/login.xhtml?faces-redirect=true";
	}

	public void redirectResultado() {
		try {
			// getSession().removeAttribute("resultadoPedidoBean");
			controleBotaoUtil.redirectResultado(getHttpServletRequest(), clienteUnidadePasseLivre, sessionId);
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}
	
	public void redirectSenhaDefinitiva() {
		try {
			controleBotaoUtil.redirectTelaSenhaDefinitiva(getHttpServletRequest(), clienteUnidadePasseLivre, sessionId);
		} catch (final Exception e) {
			e.printStackTrace();
		}
	}

	public void redirectMaterial() {
		try {
			sessionId = SessionIdBuilder.build(informacoesTotem.get(0)).toString();
			getSession().removeAttribute("entregaMaterialPendenteBean");
			controleBotaoUtil.redirectMaterial(getHttpServletRequest(), clienteUnidadePasseLivre, sessionId,
					tokenResult, informacoesTotem);
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	private String redirectAtualizarUsuario() {
		return "/pages/res/atualizarDados.xhtml?faces-redirect=true";
	}

	public void redirectUnimed() {
		try {
			sessionId = SessionIdBuilder.build(informacoesTotem.get(0)).toString();
			getSession().removeAttribute("novoAtendimentoUnimedBean");
			controleBotaoUtil.redirectUnimed(getHttpServletRequest(), clienteUnidadePasseLivre, sessionId);
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	public String getImagemIndividual() {
		return "";
	}

	private String retornarNomeArquivo() {
		return System.getProperty("java.io.tmpdir") + "/" + "unidade_totem_" + pedidoSelecionado.getNumeroPedido()
				+ ".pdf";
	}

	public String getRetornarPDF() {
		return retornarNomeArquivo();
	}

	public String redirectIndex() throws Exception {
		final String nomeMaquina = TotemUtil.retornarNomeDaMaquina();
		getSession().removeAttribute("indexBean");
		TotemUtil.limparSession();
		return "/indexTotem.xhtml?faces-redirect=true&nomeTotem=" + nomeMaquina;
	}

	@SuppressWarnings("unchecked")
	private List<PedidoCliente> retornarResultadosLiberados(final List<PedidoCliente> parPedidosClientes) {
		final List<PedidoCliente> resultadosLiberados = new ArrayList<>();
		for (final PedidoCliente locPedidoCliente : parPedidosClientes) {
			resultadosLiberados.add(locPedidoCliente);
		}
		return resultadosLiberados;
	}

	public void recuperaSenha() {
		try {
			final SenhaService senhaService = new SenhaService(getHttpServletRequest());
			verificarTipoLogin();
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId, createBasicLogMap());
			senhaService.recuperaSenha(user);
			if (senhaService.isSuccess()) {
				mensagemAviso = senhaService.getResponseMessage();
			}
			user.setEmail("");
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			mensagemAviso = locExc.getMessage();
			gerarLogErroAoRecuperarSenha(locExc.getMessage());
		} finally {
			exibirDialogMensagem();
		}
	}

	private void gerarLogErroAoRecuperarSenha(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, sessionId,
					createBasicLogMap());
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	private String ipLocal() {
		try {
			return Util.getClientIpAddr(getHttpServletRequest());
		} catch (final Exception exc) {
			exc.printStackTrace();
			return "";
		}
	}

	public void entrarComCodigo() {
		try {
			final LoginService loginService = new LoginService(getHttpServletRequest());
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId, createBasicLogMap());
			RequestContext.getCurrentInstance().reset("frmPrincipal:idTabView:codigoClienteTab");
			user.setAuthKeyType(Constantes.CODEAUTHKEYTYPE);
			clienteUnidadePasseLivre = (ClienteUnidadePasseLivre) loginService.logar(user);
			formatarCampos();
			if (loginService.isSuccess()) {
				clienteUnidadePasseLivre.verificarSeSenhaTemporaria();
				buscarPedidos();
				redirectResultado();
			} else {
				throw new Exception(loginService.getResponseMessage());
			}
		} catch (SenhaDefinitivaException e) {
			poeUsuarioNaSessao(clienteUnidadePasseLivre);
			redirectSenhaDefinitiva();
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
			// gerarLogErroLoginComCodigo(locExc); //n�o gerar log de credenciais inv�lidas
			limparCampoLogin();
		}
	}

	private void gerarLogErroLoginComCodigo(final Exception locExc) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), locExc.getMessage(), sessionId,
					createBasicLogMap());
		} catch (final Exception locExc2) {
			locExc2.printStackTrace();
		}
	}

	public void entrarComCPF() {
		try {
			final LoginService loginService = new LoginService(getHttpServletRequest());
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId, createBasicLogMap());
			RequestContext.getCurrentInstance().reset("frmPrincipal:idTabView:cpfClienteTab");
			user.setAuthKeyType(Constantes.CPFAUTHKEYTYPE);
			user.setBirthDate(formatarDataNascimentoParaRecebimento(user.getBirthDate()));
			clienteUnidadePasseLivre = (ClienteUnidadePasseLivre) loginService.logar(user);
			formatarCampos();
			if (loginService.isSuccess()) {
				clienteUnidadePasseLivre.verificarSeSenhaTemporaria();
				buscarPedidos();
				redirectResultado();
			} else {
				throw new Exception(loginService.getResponseMessage());
			}
		} catch (SenhaDefinitivaException e) {
			poeUsuarioNaSessao(clienteUnidadePasseLivre);
			redirectSenhaDefinitiva();
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
			if (!(locExc instanceof RegraNegocioException)) {
				gerarLogErroAoLogarComCpf(locExc);
			}
			limparCampoLogin();
		}
	}

	private void gerarLogErroAoLogarComCpf(final Exception locExc) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), locExc.getMessage(), sessionId,
					createBasicLogMap());
		} catch (final Exception locExc2) {
			locExc2.printStackTrace();
		}
	}

	public void gerarLogEstatistico() {
		try {
			final ControleEstatisticoService controleEstatisticoService = new ControleEstatisticoService(
					getHttpServletRequest());
			abrirResultadoCompleto();
			final ControleEstatistico controleEstatistico = new ControleEstatistico(
					clienteUnidadePasseLivre.getCodigoCliente(), null,
					FuncaoLogEstatistico.VISUALIZAR_LAUDO_COMPLETO.toString(), informacoesTotem.get(0).getId(), null,
					null, informacoesTotem.get(0).getIdUnidade());
			controleEstatisticoService.insert(controleEstatistico);
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	private void abrirResultadoCompleto() {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId, createBasicLogMap());
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	private Long retornarServicoResultado() {
		try {
			Long idServico = new Long(0);
			for (final InformacaoTotem paramInformacaoTotem : informacoesTotem) {
				if (paramInformacaoTotem.getDescricao().equals(Constantes.SERVICO_RESULTADO)) {
					idServico = paramInformacaoTotem.getIdService();
				}
			}
			return idServico;
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return null;
		}
	}

	public String mensagemCabecalho(String linha) {
		try {

			return MensagemUtil.retornarMensagemCabelho(clienteUnidadePasseLivre, "", linha);
		} catch (final Exception locExc) {
			return "";
		}
	}

	private void formatarCampos() throws Exception {
		formataEndereco.formataEnderecoAoLogar(clienteUnidadePasseLivre);
	}

	private String formatarDataNascimentoParaEnvio(final String dataNascimento) {
		formataCampo = new FormataDataDiaMesAno(dataNascimento);
		return formataCampo.formatar();
	}

	private String redirectResultadoPedidos() throws Exception {
		buscarPedidos();
		return "/pages/res/resultado.xhtml?faces-redirect=true";
	}

	private void limparCampoLogin() {
		user = new UserAuth();
		RequestContext.getCurrentInstance().reset("frmPrincipal:idTabView:codigoClienteTab");
		RequestContext.getCurrentInstance().reset("frmPrincipal:idTabView:cpfClienteTab");
	}

	private void verificarTipoLogin() {
		if (botaoCodigoEstaAtivado()) {
			user.setAuthKeyType(Constantes.CODEAUTHKEYTYPE);
		} else {
			user.setAuthKeyType(Constantes.CPFAUTHKEYTYPE);
			final String dataNascimentoRetorno = formatarDataNascimentoParaRecebimento(user.getBirthDate());
			user.setBirthDate(dataNascimentoRetorno);
		}
	}

	public Boolean getHabilitarImpressaoPorCodigoDeBarra() {
		return verificarSeTotemPossuiLeitorCodigoBarra();
	}

	private Boolean verificarSeTotemPossuiLeitorCodigoBarra() {
		try {
			return !informacaoTotem.getLeitorCodigoBarras().equals("N");
		} catch (final Exception locExc) {
			return true;
		}
	}

	private int calcularDigito(String str, int[] peso) {
		int soma = 0;
		for (int indice = str.length() - 1, digito; indice >= 0; indice--) {
			digito = Integer.parseInt(str.substring(indice, indice + 1));
			soma += digito * peso[peso.length - str.length() + indice];
		}
		soma = 11 - soma % 11;
		return soma > 9 ? 0 : soma;
	}

	public void isValidCPF() {
		String cpf = clienteUnidadePasseLivre.getCpf();
		cpf = cpf.replace(".", "").replace("-", "");
		if ((cpf == null) || (cpf.length() != 11)) {
			mensagemAviso = "CPF Inválido";
			exibirDialogMensagem();
			return;
		}

		Integer digito1 = calcularDigito(cpf.substring(0, 9), Constantes.PESOCPF);
		Integer digito2 = calcularDigito(cpf.substring(0, 9) + digito1, Constantes.PESOCPF);

		if (!cpf.equals(cpf.substring(0, 9) + digito1.toString() + digito2.toString())) {
			clienteUnidadePasseLivre.setCpf(null);
			mensagemAviso = "CPF Inválido";
			exibirDialogMensagem();
		}
	}

	public String getTextoConfirmarEmail() {
		String emailCompleto = clienteUnidadePasseLivre.getEmail();
		StringBuilder sbEmail = new StringBuilder();
		StringBuilder sbDominio = new StringBuilder();
		if (isClienteTemEmail()) {
			sbEmail.append(emailCompleto.substring(0, emailCompleto.indexOf("@")));
			sbDominio.append(emailCompleto.substring(emailCompleto.indexOf("@")));

			for (int i = 1; i < sbEmail.toString().length() - 1; i++) {
				sbEmail.setCharAt(i, '*');
			}
			for (int i = 2; i < sbDominio.indexOf("."); i++) {
				sbDominio.setCharAt(i, '*');
			}
		}
		return "Confirme o seu e-mail: " + sbEmail.toString() + sbDominio.toString();
	}

	private String recuperarEmailCliente() {
		try {
			final DataUtil dataUtil = new DataUtil();
			final ClienteService clienteService = new ClienteService(getHttpServletRequest());
			ParametroConsultaCliente parametroConsultaCliente = new ParametroConsultaCliente();
			parametroConsultaCliente.setToken(tokenResult.getToken());
			if (user.getAuthKey().length() == 11) {
				parametroConsultaCliente.setAuthKeyType("1");
				parametroConsultaCliente.setAuthKey(user.getAuthKey());
			} else {
				parametroConsultaCliente.setAuthKeyType("2");
				if (user.getAuthKey().startsWith("0")) {
					parametroConsultaCliente.setAuthKey(user.getAuthKey().substring(1));
				} else {
					parametroConsultaCliente.setAuthKey(user.getAuthKey());
				}
			}
			parametroConsultaCliente.setOrigem(Constantes.ORIGEM_PADRAO);
			parametroConsultaCliente.setBirthDate(dataUtil.formatarStringBRParaString(user.getBirthDate()));
			clienteService.consultaCliente(parametroConsultaCliente);
			clienteUnidadePasseLivre = new ClienteUnidadePasseLivre();
			if (clienteService.isSuccess() && clienteService.getResponseObject() != null) {
				clienteUnidadePasseLivre = ((List<ClienteUnidadePasseLivre>) clienteService.getResponseObject()).get(0);
				if (clienteUnidadePasseLivre.getEmail() != null && !clienteUnidadePasseLivre.getEmail().equals("")) {
					return clienteUnidadePasseLivre.getEmail();
				} else {
					return null;
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;
	}

	public boolean isClienteTemEmail() {
		return clienteUnidadePasseLivre != null && clienteUnidadePasseLivre.getEmail() != null
				&& !clienteUnidadePasseLivre.getEmail().equals("");
	}

	public void cancelarRecuperarSenha() {
		clienteUnidadePasseLivre = new ClienteUnidadePasseLivre();
	}

	public Map createBasicLogMap() {
		Long idTotem = null;
		Long idUnidade = null;
		if (informacoesTotem != null && !informacoesTotem.isEmpty()) {
			idTotem = informacoesTotem.get(0).getId();
			idUnidade = Long.valueOf(informacoesTotem.get(0).getIdUnidade());
		}
		try {
			return TotemUtil.createBasicLogMap(idTotem, idUnidade, Util.getClientIpAddr(getHttpServletRequest()));
		} catch (Exception e) {
			e.printStackTrace();
			return new HashMap();
		}
	}

	private String formatarDataNascimentoParaRecebimento(final String dataNascimento) {
		formataCampo = new FormataDataAnoMesDia(dataNascimento);
		return formataCampo.formatar();
	}

	public Boolean botaoCodigoEstaAtivado() {
		getRequestContext().update("frmPrincipal:btnBotao");
		return activeIndex == 0;
	}

	public List<PedidoCliente> getPedidosSelecionados() {
		return pedidosSelecionados;
	}

	public void setPedidosSelecionados(final List<PedidoCliente> parPedidosSelecionados) {
		pedidosSelecionados = parPedidosSelecionados;
	}

	public List<PedidoCliente> getPedidos() {
		return pedidos;
	}

	public UserAuth getUser() {
		return user;
	}

	public void setUser(final UserAuth parUser) {
		user = parUser;
	}

	public ClienteUnidadePasseLivre getClienteUnidadePasseLivre() {
		return clienteUnidadePasseLivre;
	}

	public void setClienteUnidadePasseLivre(final ClienteUnidadePasseLivre parClienteUnidadePasseLivre) {
		clienteUnidadePasseLivre = parClienteUnidadePasseLivre;
	}

	public Integer getActiveIndex() {
		return activeIndex;
	}

	public void setActiveIndex(final Integer parActiveIndex) {
		activeIndex = parActiveIndex;
	}

	public PedidoCliente getPedidoSelecionado() {
		return pedidoSelecionado;
	}

	public void setPedidoSelecionado(final PedidoCliente parPedidoSelecionado) {
		pedidoSelecionado = parPedidoSelecionado;
	}

	public List<DetalhePedidoCliente> getDetalhesPedido() {
		return detalhesPedido;
	}

	public DetalhePedidoCliente getDetalhePedidoExibicao() {
		return detalhePedidoExibicao;
	}

	public void setDetalhePedidoExibicao(final DetalhePedidoCliente parDetalhePedidoExibicao) {
		detalhePedidoExibicao = parDetalhePedidoExibicao;
	}

	public String getMensagemAviso() {
		return mensagemAviso;
	}

	public void setMensagemAviso(final String parMensagemAviso) {
		mensagemAviso = parMensagemAviso;
	}

	public ResultadoResult getResultadoResult() {
		return resultadoResult;
	}

	public void setResultadoResult(final ResultadoResult parResultadoResult) {
		resultadoResult = parResultadoResult;
	}

	public String getNumeroPedido() {
		return numeroPedido;
	}

	public void setNumeroPedido(final String parNumeroPedido) {

		numeroPedido = parNumeroPedido;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getComplemento() {
		return complemento;
	}

	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}

	public boolean isEditarLogradouro() {
		return editarLogradouro;
	}

	public void setEditarLogradouro(boolean editarLogradouro) {
		this.editarLogradouro = editarLogradouro;
	}

	public boolean isEditarBairro() {
		return editarBairro;
	}

	public void setEditarBairro(boolean editarBairro) {
		this.editarBairro = editarBairro;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getLogradouro() {
		return logradouro;
	}

	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}

	public String getNomeTotem() {
		return nomeTotem;
	}

	public String getNomeTotemNovo() {
		return nomeTotemNovo;
	}

	public void setNomeTotemNovo(String nomeTotemNovo) {
		this.nomeTotemNovo = nomeTotemNovo;
	}	
	
	public String exibirDetalhesPorCodigoBarra() {
		clienteUnidadePasseLivre = new ClienteUnidadePasseLivre();
		clienteUnidadePasseLivre.setCodigoCliente(pedidoDetalheResult.getCliente().getCodigoCliente());
		clienteUnidadePasseLivre.setNomeCliente(pedidoDetalheResult.getCliente().getNomeCliente());
		
		pedidoSelecionado = pedidoDetalheResult.getPedido();
		detalhesPedido = new ArrayList<>();
		detalhesPedido.addAll(pedidoDetalheResult.getDetalhes());	
		filtrarDetalhesPedidoCodBarrasNaoLiberados();
		
		return redirectDetalhesResultadoCodBarras();
	}

	private String redirectDetalhesResultadoCodBarras() {
		return "/pages/res/detalhesResultadoCodBarras.xhtml?faces-redirect=true";
	}
	
	public String voltarParaLogin() {
		return "/pages/res/login.xhtml?faces-redirect=true";
	}

	public List<DetalhePedidoCliente> getDetalhesPedidoCodBarras() {
		return detalhesPedidoCodBarras;
	}
	
	@SuppressWarnings("unchecked")
	private void buscarPedidoDetalheResult() throws Exception {
		pedidoDetalheResult = new PedidoDetalheResult();
		final PedidoService pedidoService = new PedidoService(getHttpServletRequest());
		String IdPedidoDetalhe = Util.retornarIdPedidoDetalheValido(numeroPedido);
		pedidoService.consultarPedidoDetalheResult(IdPedidoDetalhe, tokenResult.getToken());
		if(pedidoService.isSuccess()) {
			pedidoDetalheResult = (PedidoDetalheResult) pedidoService.getResponseObject();
		} else {
			throw new Exception(pedidoService.getResponseMessage());
		}
	}	
	
	private void filtrarDetalhesPedidoCodBarrasNaoLiberados() {
		detalhesPedidoCodBarras = 	detalhesPedido.stream()
				.filter(det -> (!det.getTestStatus().equals(Constantes.STATUS_LIBERADO)))
				.collect(Collectors.toList());
	}
	
	public void imprimirRestultadoCompletoDetalhes() {
		final RequestContext context = RequestContext.getCurrentInstance();
		try {
			final ParametroImpressao parametroImpressao = new ParametroImpressao(pedidoSelecionado,
					informacoesTotem.get(0), tokenResult, clienteUnidadePasseLivre);
			final FazImpressaoService fazImpressaoService = new FazImpressaoService(getHttpServletRequest());
			context.execute("PF('dlgPDFResultado').hide();");
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, clienteUnidadePasseLivre.getCpf());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId, createBasicLogMap());
			fazImpressaoService.imprimirResultado(parametroImpressao);
			resultadoResult = new ResultadoResult();
			if (fazImpressaoService.isSuccess()) {
				resultadoResult = (ResultadoResult) fazImpressaoService.getResponseObject();
				gerarLogEstatisticoImprimirResultadoCompleto();
				context.execute("PF('dlgInformacaoImpressao').show();");
			} else {
				gerarLogAoFazerImpressaoResultadoCompleto(fazImpressaoService.getResponseMessage());
				try {
					mensagemAviso = (fazImpressaoService.getResponseMessage());
					getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
				} catch (Exception e) {
					e.printStackTrace();
				}
				exibirDialogMensagem();
			}
		} catch (final Exception exc) {
			exc.printStackTrace();
			gerarLogAoFazerImpressaoResultadoCompleto(exc.getMessage());
			exibirDialogMensagem();
		}
	}
	
}
