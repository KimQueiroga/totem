package br.com.hermespardini.passelivre.bean;

import java.io.IOException;
import java.sql.Time;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.model.ConsultaConfiguracaoResult;
import br.com.hermespardini.passelivre.model.InformacaoTotem;
import br.com.hermespardini.passelivre.model.MensagemAviso;
import br.com.hermespardini.passelivre.model.ParametroConsultaConfiguracao;
import br.com.hermespardini.passelivre.model.ParametroUsuarioToken;
import br.com.hermespardini.passelivre.model.Servico;
import br.com.hermespardini.passelivre.model.TokenResult;
import br.com.hermespardini.passelivre.model.Totem;
import br.com.hermespardini.passelivre.service.AutenticaService;
import br.com.hermespardini.passelivre.service.IndexService;
import br.com.hermespardini.passelivre.service.InformacaoTotemService;
import br.com.hermespardini.passelivre.utils.TotemUtil;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.bean.MainBean;
//import br.com.hermespardini.webservices.registralog.model.Log;

@SuppressWarnings("serial")
@ManagedBean(name = "idleMonitorBean")
public class IdleMonitorBean extends MainBean {

	private LocalTime horaFim;
	private String tempoTimout;
	private String timeoutGuiche;
	private LocalTime horaInicio;
	private TokenResult tokenResult;
	private static final Integer MINIMO = 3;
	private static final Integer MAXIMO = 30;
	private static final String INTERVALO_MINIMO = "59000";
	private static final String INTERVALO_MAXIMO = "1800000";
	private Boolean erroOnload;
	private String timeoutQuestionario;

	@PostConstruct
	public void onLoad() {
		erroOnload = false;
		try {
			timeoutGuiche = "3600000";
			timeoutQuestionario = "300000";
			tokenResult = new TokenResult();
			retornarHoraInicioEHoraFim();
			tempoTimout = verificarHoraAtual();
		} catch (final Exception locExc) {
			erroOnload = true;
			try {
				String erro = locExc.getMessage();
				FacesContext.getCurrentInstance().getExternalContext().redirect(createAndGetPageErrorRedirect(erro));
			} catch (IOException e) {
				Logger logger = Logger.getLogger(TelaErroBean.class);
				logger.error("LOG DE Exceção onLoad IdleMonitorBean", e);
			}
		}
	}

	private String verificarHoraAtual() {
		if (ehHorarioDeFuncionamento()) {
			return IdleMonitorBean.INTERVALO_MINIMO;
		} else {
			return IdleMonitorBean.INTERVALO_MAXIMO;
		}
	}

	private boolean ehHorarioDeFuncionamento() {
		final LocalTime horaAgora = LocalTime.now();
		if (horaInicio != null && horaFim != null) {
			if (horaAgora.isAfter(horaInicio.minus(30, ChronoUnit.MINUTES)) && horaAgora.isBefore(horaFim)) {
				return true;
			}
		}
		return horaAtualEhMaiorQueHoraInicio(horaAgora, horaInicio) && horaAtualEhMenorQueHoraFim(horaAgora, horaFim);
	}

	private boolean horaAtualEhMenorQueHoraFim(final LocalTime dataAgora, final LocalTime dataFim) {
		try {
			if (dataAgora.isBefore(dataFim)) {
				return diferencaDaHoraAtualParaProximaEhMaiorQueOMaximo(dataAgora, dataFim);
			} else {
				return false;
			}
		} catch (final Exception locExc) {
			return false;
		}

	}

	private boolean diferencaDaHoraAtualParaProximaEhMaiorQueOMaximo(final LocalTime parDataAgora,
			final LocalTime parDataFim) {
		final Time agora = new Time(new Date().getTime());
		LocalTime localtime = agora.toLocalTime();
		localtime = localtime.plusMinutes(IdleMonitorBean.MAXIMO);
		return localtime.isBefore(parDataFim);
	}

	private boolean horaAtualEhMaiorQueHoraInicio(final LocalTime dataAgora, final LocalTime dataInicio) {
		try {
			if (dataAgora.isAfter(dataInicio)) {
				return diferencaDaHoraAtualParaProximaEhMaiorQueMinimo(dataInicio);
			} else {
				return false;
			}
		} catch (final Exception locExc) {
			return false;
		}
	}

	private boolean diferencaDaHoraAtualParaProximaEhMaiorQueMinimo(final LocalTime parDataInicio) {
		final Time agora = new Time(new Date().getTime());
		LocalTime localtime = agora.toLocalTime();
		localtime = localtime.plusMinutes(IdleMonitorBean.MINIMO);
		return localtime.isAfter(parDataInicio);
	}

	public void processTimeOut(String tela) throws Exception {
		if(!erroOnload) {
			try {
				registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(),
						"Processando idlemonitor: " + tela + " Totem: " + TotemUtil.retornarNomeDaMaquina(),
						TotemUtil.buscarSessionId(), createBasicLogMap());
				final String nomeMaquina = TotemUtil.retornarNomeDaMaquina();
				TotemUtil.limparSession();
				FacesContext.getCurrentInstance().getExternalContext()
						.redirect("/passelivretotem/indexTotem.xhtml?nomeTotem=" + nomeMaquina);
			} catch (Exception e) {
				Logger logger = Logger.getLogger(IdleMonitorBean.class);
				logger.warn("*******************************************************************");
				logger.warn("*         LOG DE EXCESSÃO AO PROCESSAR TIMEOUT MONITOR BEAN          ");
				logger.warn("*                                                                  ");
				e.printStackTrace();
			}
		}
	}
	
	@Deprecated
	public void processTimeOutIdle(String tela) throws Exception {
		try {
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(),
					"Processando idlemonitor: " + tela + " Totem: " + TotemUtil.retornarNomeDaMaquina(),
					TotemUtil.buscarSessionId(), createBasicLogMap());
			final String nomeMaquina = TotemUtil.retornarNomeDaMaquina();
			TotemUtil.limparSession();
			FacesContext.getCurrentInstance().getExternalContext()
					.redirect("/passelivretotem/index.xhtml?nomeTotem=" + nomeMaquina);
		} catch (Exception e) {
			Logger logger = Logger.getLogger(IdleMonitorBean.class);
			logger.warn("*******************************************************************");
			logger.warn("*         LOG DE EXCESSÃO AO PROCESSAR TIMEOUT IDLE MONITOR BEAN          ");
			logger.warn("*                                                                  ");
			e.printStackTrace();
		}
	}

	public void processTimeOutGuiche() throws Exception {
		FacesContext.getCurrentInstance().getExternalContext()
				.redirect("/passelivretotem/pagesGuiche/indexGuiche.xhtml");
	}

	public void returnIndex() throws Exception {
		final String nomeMaquina = TotemUtil.retornarNomeDaMaquina();
		FacesContext.getCurrentInstance().getExternalContext()
				.redirect("/passelivretotem/index.xhtml?nomeTotem=" + nomeMaquina);
	}

	public void returnIndexGuiche() throws Exception {
		FacesContext.getCurrentInstance().getExternalContext().redirect("/passelivretotem/login.xhtml");
	}

	public String getRetornarAmbiente() {
		StringBuilder sb;
		try {
			sb = new StringBuilder().append("-IP: ").append(retornarIp()).append(" Equipamento: ")
					.append(TotemUtil.retornarNomeDaMaquina());
			// FIXME adicionar sessionId aqui
			// .append(" Impressora:")
			// .append(informacoesTotemDesktop.get(0).getImpressoraDefault());
			if (getAmbienteProducao()) {
				return sb.toString();
			} else {
				return " - " + Constantes.AMBIENTE_HOMOLOGACAO + sb.toString();
			}
		} catch (final Exception exc) {
			gerarLogErroRetornarAmbiente(exc.getMessage());
			exc.printStackTrace();
			return "";
		}
	}

	private void gerarLogErroRetornarAmbiente(final String parMessage) {
		try {
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, null, createBasicLogMap());
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	private String retornarIp() throws Exception {
		final HttpServletRequest request = getHttpServletRequest();
		return Util.getClientIpAddr(request);
	}

	private void retornarHoraInicioEHoraFim() throws RegraNegocioException {
		try {
			tokenResult = retornarToken();
			final ParametroConsultaConfiguracao parametroConsultaConfiguracao = new ParametroConsultaConfiguracao(
					retornarNomeDaMaquina(), tokenResult);
			final InformacaoTotemService informacaoTotemService = new InformacaoTotemService(getHttpServletRequest());
			informacaoTotemService.consultar(parametroConsultaConfiguracao);
			final ConsultaConfiguracaoResult consultaConfiguracaoResult = (ConsultaConfiguracaoResult) informacaoTotemService
					.getResponseObject();
			if (!Objects.isNull(consultaConfiguracaoResult)) {
				for (final Totem totem : consultaConfiguracaoResult.getTotens()) {
					for (final Servico servico : totem.getServicos()) {
						adicionarMaiorHorario(servico);
						adicionarMenorHorario(servico);
					}
				}
			} else {
				throw new RegraNegocioException(
						"1 - Erro ao buscar informações do totem:" + parametroConsultaConfiguracao.getIp());
			}
		} catch (final Exception locExc) {
			throw new RegraNegocioException(locExc.getMessage());
		}
	}

	private void adicionarMenorHorario(final Servico parServico) {
		try {
			if (horaInicio == null) {
				horaInicio = LocalTime.parse(parServico.getHoraInicioFuncionamento());
			}
			final LocalTime dataHoraInicio = LocalTime.parse(parServico.getHoraInicioFuncionamento());
			if (horaInicio.isBefore(dataHoraInicio)) {
				horaInicio = dataHoraInicio;
			}
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	private void adicionarMaiorHorario(final Servico parServico) {
		try {
			if (horaFim == null) {
				horaFim = LocalTime.parse(parServico.getHoraFimFuncionamento());
			}
			final LocalTime dataHoraFim = LocalTime.parse(parServico.getHoraFimFuncionamento());
			if (horaFim.isBefore(dataHoraFim)) {
				horaFim = dataHoraFim;
			}
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	private String retornarDataHoraValida(final String parDataHora) {
		return parDataHora.trim().replace(" ", "T");
	}

	private String retornarNomeDaMaquina() throws RegraNegocioException {
		try {
			final IndexService indexService = new IndexService();
			return indexService.retornarNomeMaquina(getHttpServletRequest());
		} catch (final Exception exc) {
			exc.printStackTrace();
			gerarLogAoRetornarNomeDaMaquina(exc.getMessage());
			throw new RegraNegocioException(exc.getMessage());
		}
	}

	private void gerarLogAoRetornarNomeDaMaquina(final String parMessage) {
		try {
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, null, createBasicLogMap());
		} catch (final Exception locExc) {
		}
	}

	private TokenResult retornarToken() throws Exception, RegraNegocioException {
		try {
			final ParametroUsuarioToken parametroUsuarioToken = new ParametroUsuarioToken(Constantes.ORIGEM_PADRAO);
			final AutenticaService autenticaService = new AutenticaService(getHttpServletRequest());
			autenticaService.gerarToken(parametroUsuarioToken);
			if (autenticaService.isSuccess()) {
				return (TokenResult) autenticaService.getResponseObject();
			} else {
				throw new RegraNegocioException(autenticaService.getResponseMessage());
			}
		} catch (final Exception locExc) {
			throw new RegraNegocioException(locExc.getMessage());
		}
	}

	public Map createBasicLogMap() {
		Long idTotem = null;
		Long idUnidade = null;
		List<InformacaoTotem> informacoesTotem = TotemUtil.buscarInformacoesTotem();
		if (informacoesTotem != null && !informacoesTotem.isEmpty()) {
			idTotem = informacoesTotem.get(0).getId();
			idUnidade = Long.valueOf(informacoesTotem.get(0).getIdUnidade());
		}
		try {
			return TotemUtil.createBasicLogMap(idTotem, idUnidade, Util.getClientIpAddr(getHttpServletRequest()));
		} catch (Exception e) {
			e.printStackTrace();
			return new HashMap();
		}
	}

	public String getTempoTimout() {
		return tempoTimout;
	}

	public void setTempoTimout(final String parTempoTimout) {
		tempoTimout = parTempoTimout;
	}

	public String getTimeoutGuiche() {
		return timeoutGuiche;
	}

	public void setTimeoutGuiche(final String parTimeoutGuiche) {
		timeoutGuiche = parTimeoutGuiche;
	}
	
	public String getTimeoutQuestionario() {
		return timeoutQuestionario;
	}

	public void setTimeoutQuestionario(String timeoutQuestionario) {
		this.timeoutQuestionario = timeoutQuestionario;
	}

	private String createAndGetPageErrorRedirect(final String exceptionMessage) {
		MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso(exceptionMessage);
		try {
			getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
		} catch (Exception e) {
			Logger logger = Logger.getLogger(IndexBean.class);
			logger.error("LOG DE EXCESSÃO AO SETAR mensagemAviso", e);
		}
		
		String pageErrorRedirect = "/pages/erro/sistemaIndisponivelSemRodape.xhtml?faces-redirect=true&sessionId="
				+ TotemUtil.buscarSessionId() + "&nomeTotem=" + TotemUtil.retornarNomeDaMaquina();
		
		HttpServletRequest req = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		String url = req.getRequestURL().toString();
		url = url.substring(0, url.length() - req.getRequestURI().length()) + req.getContextPath();
		pageErrorRedirect = url + pageErrorRedirect;
		
		return  pageErrorRedirect;
	}
}
