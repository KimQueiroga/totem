package br.com.hermespardini.passelivre.bean;

import java.text.ParseException;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.component.EditableValueHolder;
import javax.faces.component.UIComponent;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;
import javax.faces.context.PartialViewContext;
import javax.faces.view.ViewScoped;

import org.apache.log4j.Logger;
import org.primefaces.context.RequestContext;

import br.com.hermespardini.corebusiness.model.Cep;
import br.com.hermespardini.corebusiness.model.LogAplicacaoUsuarioFactory;
import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.constantsenum.FuncaoLogEstatistico;
import br.com.hermespardini.passelivre.constantsenum.TipoServicoEnum;
import br.com.hermespardini.passelivre.exception.GuiasAutorizadasException;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.format.FormataCep;
import br.com.hermespardini.passelivre.format.FormataCpf;
import br.com.hermespardini.passelivre.format.FormataEndereco;
import br.com.hermespardini.passelivre.format.FormataTelefone;
import br.com.hermespardini.passelivre.model.ClienteUnidadePasseLivre;
import br.com.hermespardini.passelivre.model.ConsultaCepResult;
import br.com.hermespardini.passelivre.model.ControleEstatistico;
import br.com.hermespardini.passelivre.model.DetalhePreparacao;
import br.com.hermespardini.passelivre.model.InformacaoTotem;
import br.com.hermespardini.passelivre.model.MensagemAviso;
import br.com.hermespardini.passelivre.model.ParametroLogin;
import br.com.hermespardini.passelivre.model.ParametroRegistraCliente;
import br.com.hermespardini.passelivre.model.TokenResult;
import br.com.hermespardini.passelivre.model.UserAuth;
import br.com.hermespardini.passelivre.service.CepService;
import br.com.hermespardini.passelivre.service.ClienteService;
import br.com.hermespardini.passelivre.service.ControleEstatisticoService;
import br.com.hermespardini.passelivre.service.SenhaService;
import br.com.hermespardini.passelivre.to.HabilitacaoCamposCadastroTO;
import br.com.hermespardini.passelivre.utils.DataUtil;
import br.com.hermespardini.passelivre.utils.TotemUtil;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.bean.MainBean;

@ManagedBean
@ViewScoped
public class AtualizaUsuarioBean extends MainBean {

	private UserAuth user;
	private String sessionId;
	private String mensagemAviso;
	private TipoServicoEnum tipoServico;
	private ParametroLogin parametroLogin;
	private DetalhePreparacao detalhePreparacao;
	private List<InformacaoTotem> informacoesTotem;
	private ClienteUnidadePasseLivre clienteUnidadePasseLivre;
	private HabilitacaoCamposCadastroTO habilitacaoCamposCadastroTO;
	private boolean semSenha;
	private String cep;
	private TokenResult tokenResult;
	private String bairro;
	private String numero;
	private String complemento;
	private boolean editarLogradouro;
	private boolean editarBairro;
	private String uf;
	private String cidade;
	private String logradouro;
	

	@PostConstruct
	public void onload() {
		buserUser();
		buscarSessionId();
		buscarTipoServico();
		buscarInformacoesTotem();
		buscarDadosCliente();
		formatarCampos();
		buscarDetalhePreparacao();
		habilitacaoCamposCadastroTO = new HabilitacaoCamposCadastroTO();
		semSenha = recuperarFlagSenha();
	}

	private void buscarDetalhePreparacao() {
		try {
			detalhePreparacao = (DetalhePreparacao) getHttpServletRequest().getSession()
					.getAttribute("detalhePreparacao");
		} catch (final Exception locExc) {
		}
	}

	private void formatarCampos() {
		try {
			new FormataEndereco().formataEnderecoAoLogar(clienteUnidadePasseLivre);
		} catch (final Exception locExc) {
		}
	}

	private void buserUser() {
		try {
			user = (UserAuth) getHttpServletRequest().getSession().getAttribute("user");
			if (user == null) {
				user = new UserAuth();
			}
		} catch (final Exception locExc) {
		}
	}

	public boolean recuperarFlagSenha() {
		try {
			return (boolean) getHttpServletRequest().getSession().getAttribute("semSenha");
		} catch (Exception e) {
			Logger logger = Logger.getLogger(TelaErroBean.class);
			logger.warn("LOG DE WARNING recuperarFlagSenha AtualizaUsuarioBean", e);
		}
		return false;
	}

	private void buscarSessionId() {
		try {
			sessionId = getHttpServletRequest().getSession().getAttribute("sessionId").toString();
		} catch (final Exception locExc) {
		}
	}

	private void buscarTipoServico() {
		try {
			tipoServico = (TipoServicoEnum) getHttpServletRequest().getSession().getAttribute("tipoServico");
		} catch (final Exception locExc) {
		}
	}

	private void buscarInformacoesTotem() {
		try {
			informacoesTotem = (List<InformacaoTotem>) getHttpServletRequest().getSession()
					.getAttribute("informacoesTotem");
		} catch (final Exception locExc) {
		}
	}

	private void buscarDadosCliente() {
		try {
			clienteUnidadePasseLivre = (ClienteUnidadePasseLivre) getHttpServletRequest().getSession()
					.getAttribute("clienteUnidadePasseLivre");
		} catch (final Exception locExc) {
		}
	}

	public void cancelarAtualizacao() {
		/*
		 * try { getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN,
		 * retornarCodigo());
		 * registrarLogAcessoFuncionalidade(Thread.currentThread().getStackTrace()[1].
		 * getClassName(), Thread.currentThread().getStackTrace()[1].getMethodName(),
		 * sessionId); return redirectIndex(); } catch (final Exception exc) { return
		 * ""; }
		 */
		TotemUtil.retornaIndex();
	}

	public String redirectIndex() throws Exception {
		final String nomeMaquina = TotemUtil.retornarNomeDaMaquina();
		getSession().removeAttribute("indexBean");
		TotemUtil.limparSession();
		return "/indexTotem.xhtml?faces-redirect=true&nomeTotem=" + nomeMaquina;
	}

	public String atualizarDados() {
		try {
			if (!semSenha) {
				acoesNoClienteAoAtualizar();
				formatarValores();
				return realizarAtualicacao();
			}

			return tipoServico.redirectAposAtualizar();

		} catch (final RuntimeException locExc) {
			gerarLogErroAoAtualizar(locExc.getMessage());
			MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso(locExc.getMessage());
			try {
				getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return redirectAtendimentoNaoConcluido();
		} catch (final RegraNegocioException locExc) {
			gerarLogErroAoAtualizar(locExc.getMessage());
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
			return null;
		} catch (final Exception locExc) {
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
			locExc.printStackTrace();
			gerarLogErroAoAtualizar(locExc.getMessage());
			return null;
		}
	}

	public void alterarSenha() {
		try {
			verificarSeSenhasConferem();
			final ClienteUnidadePasseLivre locClienteUnidadePasseLivre = new ClienteUnidadePasseLivre(getUser(),
					clienteUnidadePasseLivre);
			final SenhaService loSenhaService = new SenhaService(getHttpServletRequest());
			loSenhaService.setValueObject(locClienteUnidadePasseLivre);
			loSenhaService.atualizarSenha();
			if (loSenhaService.isSuccess()) {
				getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
				registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId,
						createBasicLogMap());
			} else {
				gerarLogErroAoValidarSenha(loSenhaService.getResponseMessage());
			}
			mensagemAviso = loSenhaService.getResponseMessage();
		} catch (final Exception locExc) {
			mensagemAviso = locExc.getMessage();
			gerarLogErroAoValidarSenha(locExc.getMessage());
		} finally {
			fecharDialogResetSenha();
			exibirDialogMensagem();
			resetarCampos();
		}
	}

	private void resetarCampos() {
		getUser().setNewPass("");
		getUser().setConfirmAuthPass("");
	}

	private void fecharDialogResetSenha() {
		RequestContext.getCurrentInstance().execute("PF('alterarSenhaDlgVar').hide()");
	}

	private void verificarSeSenhasConferem() throws Exception {
		if (!user.getNewPass().equals(user.getConfirmAuthPass())) {
			throw new Exception("As senhas não conferem");
		}
	}

	private void gerarLogErroAoValidarSenha(final String parMensagemErro) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMensagemErro, sessionId,
					createBasicLogMap());
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	private void acoesNoClienteAoAtualizar() throws Exception {
		clienteUnidadePasseLivre.setComplemento(clienteUnidadePasseLivre.retirarCaracteriosInvalidosNoComplemento());
		clienteUnidadePasseLivre.setNumero(clienteUnidadePasseLivre.retornarNumeroValido());
		clienteUnidadePasseLivre.verificarCamposEmBrancoAoAtualizar();
		clienteUnidadePasseLivre.validarEmail();
	}

	private void formatarValores() {
		clienteUnidadePasseLivre.setCelular(formatarTelefone(clienteUnidadePasseLivre.getCelular()));
		clienteUnidadePasseLivre.setTelefone(formatarTelefone(clienteUnidadePasseLivre.getTelefone()));
		clienteUnidadePasseLivre.setCep(formatarCep(clienteUnidadePasseLivre.getCep()));
		clienteUnidadePasseLivre.setCpf(formatarCpf(clienteUnidadePasseLivre.getCpf()));
	}

	private void adicionarAtributoEmSessaoAposAtualizar() throws Exception {
		getHttpServletRequest().getSession().setAttribute("sessionId", sessionId);
		getHttpServletRequest().getSession().setAttribute("informacoesTotem", informacoesTotem);
		getHttpServletRequest().getSession().setAttribute("detalhePreparacao", detalhePreparacao);
		getHttpServletRequest().getSession().setAttribute("clienteUnidadePasseLivre", clienteUnidadePasseLivre);
	}

	private String formatarCpf(final String cpf) {
		try {
			return new FormataCpf(cpf).formatar();
		} catch (final Exception locExc) {
			return null;
		}
	}

	private String formatarTelefone(final String telefone) {
		return new FormataTelefone(telefone).formatar();
	}

	private String realizarAtualicacao()
			throws RuntimeException, RegraNegocioException, GuiasAutorizadasException, Exception {
		final ClienteService clienteService = new ClienteService(getHttpServletRequest());
		if (!semSenha) {
			acoesNoClienteAoAtualizar();
			formatarValores();
		}
		new FormataEndereco().convertStreetAndComplement(clienteUnidadePasseLivre);
		clienteService.setValueObject(clienteUnidadePasseLivre);
		ParametroRegistraCliente parRegistraCliente = new ParametroRegistraCliente(clienteUnidadePasseLivre);
		clienteService.registrarCliente(parRegistraCliente);
		getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, retornarCodigo());
		registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
				Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId, createBasicLogMap());
		if (clienteService.isSuccess()) {
			adicionarAtributoEmSessaoAposAtualizar();
			gerarLogEstatisticoAoAtualizar();
			return tipoServico.redirectAposAtualizar();
		} else {
			mensagemAviso = clienteService.getResponseMessage();
			RequestContext.getCurrentInstance().execute("PF('dlgMessage').show()");
			if (mensagemAviso.contains("CPF(") && mensagemAviso.contains("inválido")) {
				clienteUnidadePasseLivre.setCpf(null);
			}
			return "";
		}
	}

	private void gerarLogEstatisticoAoAtualizar() {
		try {
			final ControleEstatisticoService controleEstatisticoService = new ControleEstatisticoService(
					getHttpServletRequest());
			final ControleEstatistico controleEstatistico = new ControleEstatistico(
					clienteUnidadePasseLivre.getCodigoCliente(), null, FuncaoLogEstatistico.ATUALIZAR_DADOS.toString(),
					informacoesTotem.get(0).getId(), null, null, retornarUnidade());
			controleEstatisticoService.insert(controleEstatistico);
		} catch (final Exception locExc) {
			gerarLogErroAoGerarLogEstatistico(locExc.getMessage());
		}
	}

	private void gerarLogErroAoAtualizar(final String parMensagemErro) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, retornarCodigo());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMensagemErro, sessionId,
					createBasicLogMap());
		} catch (final Exception exc) {
		}
	}

	private void gerarLogErroAoBuscarGuias(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, retornarCodigo());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, sessionId,
					createBasicLogMap());
		} catch (final Exception exc) {
		}
	}

	private void exibirDialogMensagem() {
		RequestContext.getCurrentInstance().execute("PF('dlgMessage').show()");
	}

	private String redirectGuiasAutorizadas() {
		return "/pages/nau/guiasAutorizadas.xhtml?faces-redirect=true";
	}

	private String redirectAtendimentoNaoConcluido() {
		return "/pages/erro/atendimentoNaoConcluido.xhtml?faces-redirect=true&sessionId=" + sessionId;
	}

	private String redirectAtendimentoNaoConcluidoIndex() {
		return "/passelivretotem/pages/erro/atendimentoNaoConcluido.xhtml?faces-redirect=true&sessionId=" + sessionId;
	}

	public void pesquisarCep() {
		try {
			final FacesContext facesContext = FacesContext.getCurrentInstance();
			final PartialViewContext partialViewContext = facesContext.getPartialViewContext();
			final Collection<String> renderIds = partialViewContext.getRenderIds();
			final UIViewRoot viewRoot = getContext().getViewRoot();
			for (final String renderId : renderIds) {
				final UIComponent component = viewRoot.findComponent(renderId);
				final EditableValueHolder input = (EditableValueHolder) component;
				if (input != null) {
					input.resetValue();
				} else {
					limparCamposEndereco();
				}
			}
			adicionarEnderecoPeloCEP();
		} catch (final NullPointerException locE) {
			limparCamposEndereco();
			gerarLogAoBuscarCEP("CEP não existe!");
		} catch (final Exception locE) {
			limparCamposEndereco();
			gerarLogAoBuscarCEP(locE.getMessage());
		}
	}

	private void limparCamposEndereco() {
		clienteUnidadePasseLivre.limparCamposEndereco();
	}

	private void adicionarEnderecoPeloCEP() throws Exception {
		String cep = getClienteUnidadePasseLivre().getCep().replaceAll("[^0-9]", "");
		tokenResult = TotemUtil.buscarToken();
		if (cep.length() == 8) {
			final CepService cepService = new CepService(getHttpServletRequest());
			ConsultaCepResult cepResult = cepService.consultarCep(cep, tokenResult.getToken());
			if (cepService.isSuccess()) {
				if (cepResult != null) {
					adiconarEnderecoAoCliente(cepResult);
				} else {
					limparCamposEndereco();
					exibirDialogMensagemAlert("CEP não encontrado!");
				}
			} else {
				limparCamposEndereco();
				exibirDialogMensagemAlert("CEP não encontrado!");
			}
		} else {
			limparCamposEndereco();
			exibirDialogMensagemAlert("CEP deve conter 8 caracteres numéricos!");
		}		
	}
	
	private void exibirDialogMensagemAlert(String msg) {
		setMensagemAviso(msg);
//		PrimeFaces.current().executeScript("PF('dlgMessageAviso').show()");
	}

	private void adiconarEnderecoAoCliente(ConsultaCepResult consultaCepResult) {
		clienteUnidadePasseLivre.setUf(consultaCepResult.getUf());
		clienteUnidadePasseLivre.setCidade(consultaCepResult.getLocalidade());
		clienteUnidadePasseLivre.setLogradouro(montarEnderecoLogradouro(consultaCepResult));
		clienteUnidadePasseLivre.setBairro(consultaCepResult.getBairro() != null ? consultaCepResult.getBairro() : "");
		clienteUnidadePasseLivre.setNumero("");
		clienteUnidadePasseLivre.setComplemento("");
		
		if(clienteUnidadePasseLivre.getLogradouro().equals(""))
			setEditarLogradouro(true);
		else
			setEditarLogradouro(false);
		
		if(clienteUnidadePasseLivre.getBairro().equals(""))
			setEditarBairro(true);
		else
			setEditarBairro(false);
	}
	
	private String montarEnderecoLogradouro(ConsultaCepResult consultaCepResult) {
		if(consultaCepResult.getLogradouro() != null && !consultaCepResult.getLogradouro().equals("") && consultaCepResult.getTipoEndereco() != null && !consultaCepResult.getTipoEndereco().equals(""))
			return consultaCepResult.getTipoEndereco() + " " + consultaCepResult.getLogradouro();
		else if(consultaCepResult.getLogradouroAbreviado() != null && !consultaCepResult.getLogradouroAbreviado().equals(""))
			return consultaCepResult.getLogradouroAbreviado();		
		else {
			return "";
		}
	}

	private void verificarSeHabilitaCampoUf(final String parUf) {
		getClienteUnidadePasseLivre().setUf(parUf);
		if (parUf.isEmpty() || parUf == "") {
			habilitacaoCamposCadastroTO.setHabilitaUF(true);
		}
	}

	private void verificarSeHabilitaCampoCidade(final String parLocalidade) {
		getClienteUnidadePasseLivre().setCidade(parLocalidade);
		if (parLocalidade.isEmpty() || parLocalidade == "") {
			habilitacaoCamposCadastroTO.setHabilitaCidade(true);
		}
	}

	private void verificarSeHabilitaCampoBairro(final String parBairro) {
		getClienteUnidadePasseLivre().setBairro(parBairro);
		if (parBairro.isEmpty() || parBairro == "") {
			habilitacaoCamposCadastroTO.setHabilitaBairro(true);
		}
	}

	private void verificarSeHabilitaCampoLogradouro(final String parLogradouro) {
		getClienteUnidadePasseLivre().setLogradouro(parLogradouro);
		if (parLogradouro.isEmpty() || parLogradouro == "") {
			habilitacaoCamposCadastroTO.setHabilitaLogradouro(true);
		}
	}

	public boolean getHappyBirthDate() {
		try {
			if (new ClienteService(getHttpServletRequest())
					.getHappyBirthDate(clienteUnidadePasseLivre.getDataNascimento())) {
				gerarLogEstatisticoParaAniversariante();
				return true;
			} else {
				return false;
			}
		} catch (final Exception locExc) {
			return false;
		}
	}

	private void gerarLogEstatisticoParaAniversariante() {
		try {
			final ControleEstatisticoService controleEstatisticoService = new ControleEstatisticoService(
					getHttpServletRequest());
			final ControleEstatistico controleEstatistico = new ControleEstatistico(
					clienteUnidadePasseLivre.getCodigoCliente(), null,
					FuncaoLogEstatistico.LEMBRETE_ANIVERSARIO.toString(), informacoesTotem.get(0).getId(), null, null,
					retornarUnidade());
			controleEstatisticoService.insert(controleEstatistico);
		} catch (final Exception locExc) {
			gerarLogErroAoGerarLogEstatistico(locExc.getMessage());
		}
	}

	private String retornarUnidade() {
		if (informacoesTotem == null || informacoesTotem.isEmpty()) {
			return null;
		} else {
			return informacoesTotem.get(0).getIdUnidade();
		}
	}

	private void gerarLogErroAoGerarLogEstatistico(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, parametroLogin.getAuthKey());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, sessionId,
					createBasicLogMap());
		} catch (final Exception exc) {
		}
	}

	private void gerarLogAoBuscarCEP(final String mensagem) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, retornarCodigo());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), mensagem, sessionId,
					createBasicLogMap());
		} catch (final Exception exc) {
		}
	}

	private String formatarCep(final String cep) {
		return new FormataCep(cep).formatar();
	}

	private String retornarCodigo() {
		try {
			if (clienteUnidadePasseLivre.getCodigoCliente() != null) {
				return clienteUnidadePasseLivre.getCodigoCliente();
			} else {
				return "";
			}
		} catch (final Exception locExc) {
			return "";
		}
	}

	public String formatarDataNascimento(final String data) {
		try {
			if (data != null || !data.isEmpty() || naoContemNumero(data)) {
				return new DataUtil().formatarStringParaStringBR(data);
			}
			return "";
		} catch (final ParseException exc) {
			return "";
		}
	}

	public Map createBasicLogMap() {
		Long idTotem = null;
		Long idUnidade = null;
		if (informacoesTotem != null && !informacoesTotem.isEmpty()) {
			idTotem = informacoesTotem.get(0).getId();
			idUnidade = Long.valueOf(informacoesTotem.get(0).getIdUnidade());
		}
		try {
			return TotemUtil.createBasicLogMap(idTotem, idUnidade, Util.getClientIpAddr(getHttpServletRequest()));
		} catch (Exception e) {
			e.printStackTrace();
			return new HashMap();
		}
	}

	private int calcularDigito(String str, int[] peso) {
		int soma = 0;
		for (int indice = str.length() - 1, digito; indice >= 0; indice--) {
			digito = Integer.parseInt(str.substring(indice, indice + 1));
			soma += digito * peso[peso.length - str.length() + indice];
		}
		soma = 11 - soma % 11;
		return soma > 9 ? 0 : soma;
	}

	public void isValidCPF() {
		String cpf = clienteUnidadePasseLivre.getCpf();
		cpf = cpf.replace(".", "").replace("-", "");
		if ((cpf == null) || (cpf.length() != 11)) {
			mensagemAviso = "CPF Inválido";
			exibirDialogMensagem();
			return;
		}

		Integer digito1 = calcularDigito(cpf.substring(0, 9), Constantes.PESOCPF);
		Integer digito2 = calcularDigito(cpf.substring(0, 9) + digito1, Constantes.PESOCPF);

		if (!cpf.equals(cpf.substring(0, 9) + digito1.toString() + digito2.toString())) {
			clienteUnidadePasseLivre.setCpf(null);
			mensagemAviso = "CPF Inválido";
			exibirDialogMensagem();
		}
	}

	private boolean naoContemNumero(final String parData) {
		return !org.apache.commons.lang.StringUtils.isNumeric(parData);
	}

	private boolean cepELogradouroNaoEstaoNulos(final Cep cep) {
		return cep != null;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(final String parSessionId) {
		sessionId = parSessionId;
	}

	public String getMensagemAviso() {
		return mensagemAviso;
	}

	public void setMensagemAviso(final String parMensagemAviso) {
		mensagemAviso = parMensagemAviso;
	}

	public List<InformacaoTotem> getInformacoesTotem() {
		return informacoesTotem;
	}

	public void setInformacoesTotem(final List<InformacaoTotem> parInformacoesTotem) {
		informacoesTotem = parInformacoesTotem;
	}

	public ClienteUnidadePasseLivre getClienteUnidadePasseLivre() {
		return clienteUnidadePasseLivre;
	}

	public void setClienteUnidadePasseLivre(final ClienteUnidadePasseLivre parClienteUnidadePasseLivre) {
		clienteUnidadePasseLivre = parClienteUnidadePasseLivre;
	}

	public HabilitacaoCamposCadastroTO getHabilitacaoCamposCadastroTO() {
		return habilitacaoCamposCadastroTO;
	}

	public void setHabilitacaoCamposCadastroTO(final HabilitacaoCamposCadastroTO parHabilitacaoCamposCadastroTO) {
		habilitacaoCamposCadastroTO = parHabilitacaoCamposCadastroTO;
	}

	public UserAuth getUser() {
		return user;
	}

	public void setUser(final UserAuth parUser) {
		user = parUser;
	}

	public boolean isSemSenha() {
		return semSenha;
	}

	public void setSemSenha(boolean semSenha) {
		this.semSenha = semSenha;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getComplemento() {
		return complemento;
	}

	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}

	public boolean isEditarLogradouro() {
		return editarLogradouro;
	}

	public void setEditarLogradouro(boolean editarLogradouro) {
		this.editarLogradouro = editarLogradouro;
	}

	public boolean isEditarBairro() {
		return editarBairro;
	}

	public void setEditarBairro(boolean editarBairro) {
		this.editarBairro = editarBairro;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getLogradouro() {
		return logradouro;
	}

	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}
	
	
}
