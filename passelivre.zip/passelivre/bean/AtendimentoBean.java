package br.com.hermespardini.passelivre.bean;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import br.com.hermespardini.passelivre.constantsenum.TipoServicoEnum;
import br.com.hermespardini.passelivre.model.ClienteUnidadePasseLivre;
import br.com.hermespardini.passelivre.model.TokenResult;
import br.com.hermespardini.passelivre.utils.MensagemUtil;
import br.com.hermespardini.passelivre.utils.TotemUtil;
import br.com.hermespardini.web.bean.MainBean;

@ManagedBean
@ViewScoped
public class AtendimentoBean extends MainBean {

	private ClienteUnidadePasseLivre clienteUnidadePasseLivre;
	private String numeroPedido;
	private TipoServicoEnum tipoServico;
	private TokenResult tokenResult;
	private String sessionId;

	@PostConstruct
	public void onLoad() {
		tipoServico = TotemUtil.recuperarTipoServico();
		tokenResult = TotemUtil.buscarToken();
		clienteUnidadePasseLivre = TotemUtil.recuperarClientePasseLivre();
		sessionId = TotemUtil.buscarSessionId();
		numeroPedido = recuperaNumeroPedido();
	}

	public String getMensagemCabecalho() {
		try {
			return MensagemUtil.retornarMensagemCabelho(clienteUnidadePasseLivre, "");
		} catch (final Exception locExc) {
			return "";
		}
	}

	public String mensagemCabecalho(String linha) {
		try {

			return MensagemUtil.retornarMensagemCabelho(clienteUnidadePasseLivre, "", linha);
		} catch (final Exception locExc) {
			return "";
		}
	}

	private String recuperaNumeroPedido() {
		try {
			final Integer pedido = (Integer) getHttpServletRequest().getSession().getAttribute("numeroPedido");
			if (pedido != null) {
				return pedido.toString();
			}
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
		return "";
	}

	public void finalizarPedido() {
		try {
			final String nomeTotem = TotemUtil.retornarNomeDaMaquina();
			TotemUtil.limparSession();
			FacesContext.getCurrentInstance().getExternalContext()
					.redirect("/passelivretotem/indexTotem.xhtml?faces-redirect=true&nomeTotem=" + nomeTotem);
		} catch (final Exception locExc) {
		}
	}

	public ClienteUnidadePasseLivre getClienteUnidadePasseLivre() {
		return clienteUnidadePasseLivre;
	}

	public void setClienteUnidadePasseLivre(final ClienteUnidadePasseLivre parClienteUnidadePasseLivre) {
		clienteUnidadePasseLivre = parClienteUnidadePasseLivre;
	}

	public String getNumeroPedido() {
		return numeroPedido;
	}

	public void setNumeroPedido(final String parNumeroPedido) {
		numeroPedido = parNumeroPedido;
	}

	public TipoServicoEnum getTipoServico() {
		return tipoServico;
	}

	public void setTipoServico(final TipoServicoEnum parTipoServico) {
		tipoServico = parTipoServico;
	}

	public TokenResult getTokenResult() {
		return tokenResult;
	}

	public void setTokenResult(final TokenResult parTokenResult) {
		tokenResult = parTokenResult;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(final String parSessionId) {
		sessionId = parSessionId;
	}

}
