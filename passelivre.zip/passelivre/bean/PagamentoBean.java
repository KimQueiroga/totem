package br.com.hermespardini.passelivre.bean;

import java.time.LocalTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.view.ViewScoped;

import org.apache.commons.io.IOUtils;
import org.primefaces.context.RequestContext;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import br.com.hermespardini.corebusiness.model.LogAplicacaoUsuarioFactory;
import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.constantsenum.FuncaoLogEstatistico;
import br.com.hermespardini.passelivre.constantsenum.TipoServicoEnum;
import br.com.hermespardini.passelivre.exception.ImpressaoException;
import br.com.hermespardini.passelivre.exception.PagamentoException;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.model.CancelarPedidoResult;
import br.com.hermespardini.passelivre.model.ClienteUnidadePasseLivre;
import br.com.hermespardini.passelivre.model.ConfiguracaoImpressoraResult;
import br.com.hermespardini.passelivre.model.ConsultaQuestionarioExameResult;
import br.com.hermespardini.passelivre.model.ControleEstatistico;
import br.com.hermespardini.passelivre.model.CriarPedidoResult;
import br.com.hermespardini.passelivre.model.Customer;
import br.com.hermespardini.passelivre.model.DadosCartao;
import br.com.hermespardini.passelivre.model.DetalhePreparacao;
import br.com.hermespardini.passelivre.model.EPacoteResult;
import br.com.hermespardini.passelivre.model.InformacaoTotem;
import br.com.hermespardini.passelivre.model.MensagemAviso;
import br.com.hermespardini.passelivre.model.PagamentoResult;
import br.com.hermespardini.passelivre.model.ParametroCancelaPedido;
import br.com.hermespardini.passelivre.model.ParametroEntregaMaterial;
import br.com.hermespardini.passelivre.model.ParametroInformacaoImpressora;
import br.com.hermespardini.passelivre.model.ParametroPagamento;
import br.com.hermespardini.passelivre.model.ParametroPagarPedido;
import br.com.hermespardini.passelivre.model.ParametroPedido;
import br.com.hermespardini.passelivre.model.ParametroRecibo;
import br.com.hermespardini.passelivre.model.Payment;
import br.com.hermespardini.passelivre.model.PerguntaEntrega;
import br.com.hermespardini.passelivre.model.Product;
import br.com.hermespardini.passelivre.model.TokenResult;
import br.com.hermespardini.passelivre.model.UserAuth;
import br.com.hermespardini.passelivre.service.ConfiguracaoImpressoraService;
import br.com.hermespardini.passelivre.service.ControleEstatisticoService;
import br.com.hermespardini.passelivre.service.IndexService;
import br.com.hermespardini.passelivre.service.MaterialPendenteService;
import br.com.hermespardini.passelivre.service.PagamentoService;
import br.com.hermespardini.passelivre.service.PedidoService;
import br.com.hermespardini.passelivre.utils.ArquivoUtil;
import br.com.hermespardini.passelivre.utils.MensagemUtil;
import br.com.hermespardini.passelivre.utils.TotemUtil;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.bean.MainBean;

@SessionScoped
@ManagedBean
public class PagamentoBean extends MainBean {

	private UserAuth user;
	private String sessionId;
	private String mensagemAviso;
	private TokenResult tokenResult;
	private DadosCartao dadosCartao;
	private EPacoteResult ePacoteResult;
	private List<PerguntaEntrega> perguntas;
	private ParametroPedido parametroPedido;
	private InformacaoTotem informacaoTotem;
	private PagamentoResult pagamentoResult;
	private CriarPedidoResult criaPedidoResult;
	private DetalhePreparacao detalhePreparacao;
	private ParametroPagamento parametroPagamento;
	private List<InformacaoTotem> informacoesTotem;
	private ClienteUnidadePasseLivre clienteUnidadePasseLivre;
	private List<ConsultaQuestionarioExameResult> questionariosExamesResult;

	@PostConstruct
	public void onLoad() {
		buscarSessionId();
		buscarUser();
		buscarInformacoesTotem();
		buscarDadosCliente();
		buscarDetalhePreparacao();
		buscarInformacaoTotem();
		buscarTokenResult();
		buscarPergunta();
		buscarQuestionario();
		pagamentoResult = new PagamentoResult();
		ePacoteResult = new EPacoteResult();
		criaPedidoResult = new CriarPedidoResult();
		dadosCartao = new DadosCartao();
	}

	private void buscarQuestionario() {
		try {
			questionariosExamesResult = (List<ConsultaQuestionarioExameResult>) getHttpServletRequest().getSession()
					.getAttribute("questionariosExamesResult");
		} catch (final Exception locExc) {
		}
	}

	private void buscarPergunta() {
		try {
			perguntas = (List<PerguntaEntrega>) getHttpServletRequest().getSession().getAttribute("perguntas");
		} catch (final Exception locExc) {
		}
	}

	private void buscarUser() {
		try {
			user = (UserAuth) getHttpServletRequest().getSession().getAttribute("user");
		} catch (final Exception locExc) {
		}
	}

	private void buscarTokenResult() {
		try {
			tokenResult = (TokenResult) getHttpServletRequest().getSession().getAttribute("tokenResult");
		} catch (final Exception locExc) {
		}
	}

	private void buscarInformacaoTotem() {
		try {
			for (final InformacaoTotem localInformacaoTotem : informacoesTotem) {
				if (localInformacaoTotem.getIp().equalsIgnoreCase(retornarNomeDaMaquina())) {
					informacaoTotem = localInformacaoTotem;
				}
			}
		} catch (final Exception locExc) {
		}
	}

	private String retornarNomeDaMaquina() throws RegraNegocioException {
		try {
			final IndexService indexService = new IndexService();
			return indexService.retornarNomeMaquina(getHttpServletRequest());
		} catch (final Exception exc) {
			exc.printStackTrace();
			gerarLogAoRetornarNomeDaMaquina(exc.getMessage());
			throw new RegraNegocioException(exc.getMessage());
		}
	}

	private void gerarLogAoRetornarNomeDaMaquina(final String parMessage) {
		try {
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, null, createBasicLogMap());
		} catch (final Exception locExc) {
		}
	}

	private void buscarDetalhePreparacao() {
		try {
			detalhePreparacao = (DetalhePreparacao) getHttpServletRequest().getSession()
					.getAttribute("detalhePreparacao");
		} catch (final Exception locExc) {
		}
	}

	private void buscarSessionId() {
		try {
			sessionId = getHttpServletRequest().getSession().getAttribute("sessionId").toString();
		} catch (final Exception locExc) {
		}
	}

	private void buscarInformacoesTotem() {
		try {
			informacoesTotem = (List<InformacaoTotem>) getHttpServletRequest().getSession()
					.getAttribute("informacoesTotem");
		} catch (final Exception locExc) {
		}
	}

	private void buscarDadosCliente() {
		try {
			clienteUnidadePasseLivre = (ClienteUnidadePasseLivre) getHttpServletRequest().getSession()
					.getAttribute("clienteUnidadePasseLivre");
		} catch (final Exception locExc) {
		}
	}

	public String pagar() {
		try {
			dadosCartao.verificarSeCamposForamPreenchidos();
			buscarExamesFilhos();
			fazerPedido();
			fazerPagamentoNaCielo();
			confirmarPagamentoNoLegado();
			efetivarPedido();
			gerarLogEstatistico();
			fazerImpressaoRecibo();
			return redirectAtendimentoConcluidoComSucesso();
		} catch (final RegraNegocioException locExc) {
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
			return "";
		} catch (final PagamentoException locExc) {
			cancelarPedido(locExc.getMessage());
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
			return "";
		} catch (final ImpressaoException locExc) {
			return redirectAtendimentoConcluidoSemRecibo();
		} catch (final Exception locExc) {
			MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso(locExc.getMessage());
			try {
				getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return redirectAtendimentoNaoConcluido();
		}
	}

	private String redirectAtendimentoConcluidoSemRecibo() {
		return "/passelivretotem/pages/ckm/atendimentoConcluidoSemRecibo.xhtml?faces-redirect=true";
	}

	private void fazerImpressaoRecibo() throws ImpressaoException {
		try {
			final ConfiguracaoImpressoraResult configuracaoImpressoraResult = retornarConfiguracoesImpressora();
			final ArquivoUtil arquivoUtil = new ArquivoUtil();
			final PagamentoService pagamentoService = new PagamentoService(getHttpServletRequest());
			final ParametroRecibo parametroRecibo = ParametroRecibo.criarParametros(clienteUnidadePasseLivre,
					criaPedidoResult, detalhePreparacao,
					getServletContext().getRealPath("/WEB-INF/relatorio/recibo.jasper"));
			parametroRecibo.setUnidade(informacoesTotem.get(0).getNomeUnd());
			final byte[] bytes = IOUtils.toByteArray(pagamentoService.gerarRecibo(parametroRecibo));
			arquivoUtil.salvarDiretorioLocal(bytes, retornarDadosRecibo(criaPedidoResult) + ".pdf");
			arquivoUtil.fazerImpressao(retornarDadosRecibo(criaPedidoResult) + ".pdf",
					configuracaoImpressoraResult.getIp());
		} catch (final Exception locExc) {
			throw new ImpressaoException(MensagemUtil.retornarErroMensagemAoImprimirRecibo(locExc.getMessage()));
		}
	}

	private ConfiguracaoImpressoraResult retornarConfiguracoesImpressora() throws Exception {
		final ParametroInformacaoImpressora parametroInformacaoImpressora = new ParametroInformacaoImpressora(
				informacoesTotem.get(0), tokenResult);
		ConfiguracaoImpressoraResult configuracaoImpressoraResult = new ConfiguracaoImpressoraResult();
		final ConfiguracaoImpressoraService configuracaoImpressoraService = new ConfiguracaoImpressoraService(
				getHttpServletRequest());
		configuracaoImpressoraService.retornarInformacoes(parametroInformacaoImpressora);
		if (configuracaoImpressoraService.isSuccess()) {
			configuracaoImpressoraResult = (ConfiguracaoImpressoraResult) configuracaoImpressoraService
					.getResponseObject();
			return configuracaoImpressoraResult;
		} else {
			throw new Exception(configuracaoImpressoraService.getResponseMessage());
		}
	}

	private String retornarDadosRecibo(final CriarPedidoResult parCriarPedidoResult) {
		final StringBuilder sb = new StringBuilder();
		sb.append("Recibo").append(retornarUnidade()).append("_").append(parCriarPedidoResult.getPedido());
		return sb.toString();
	}

	private void buscarExamesFilhos() throws RegraNegocioException {
		try {
			ePacoteResult = (EPacoteResult) getHttpServletRequest().getSession().getAttribute("ePacoteResult");
		} catch (final Exception locExc) {
		}
	}

	private void gerarLogErroAoBuscarExamesFilhos(final String parMessage) {
		try {
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, null, createBasicLogMap());
		} catch (final Exception locExc) {
		}
	}

	private void exibirDialogMensagem() {
		RequestContext.getCurrentInstance().execute("PF('dlgMessage').show()");
	}

	private String redirectAtendimentoNaoConcluido() {
		return "/pages/erro/atendimentoNaoConcluido.xhtml?faces-redirect=true&sessionId=" + sessionId;
	}

	private String redirectAtendimentoConcluidoComSucesso() {
		return "/pages/ckm/atendimentoConcluido.xhtml?faces-redirect=true";
	}

	private void confirmarPagamentoNoLegado() throws RegraNegocioException {
		try {
			final PedidoService service = new PedidoService(getHttpServletRequest());
			final ParametroPagarPedido locParametroPagarPedido = ParametroPagarPedido.criarParametroPagarPedido(
					clienteUnidadePasseLivre, dadosCartao, criaPedidoResult, tokenResult, detalhePreparacao,
					pagamentoResult);
			service.confirmar(locParametroPagarPedido);
			if (service.isSuccess()) {
				registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(),
						MensagemUtil.retornarMensagemAoConfirmarPagamentoPedido(criaPedidoResult), sessionId,
						createBasicLogMap());
			} else {
				throw new RegraNegocioException(service.getResponseMessage());
			}
		} catch (final Exception locExc) {
			gerarLogErroAoConfirmarPedido(locExc.getMessage());
			throw new RegraNegocioException(locExc.getMessage());
		}
	}

	private void efetivarPedido() throws RegraNegocioException {
		try {
			final MaterialPendenteService service = new MaterialPendenteService(getHttpServletRequest());
			final ParametroEntregaMaterial parametroPedidoEntrega = ParametroEntregaMaterial
					.criarParametroEntregaParaPagamento(criaPedidoResult, tokenResult, informacaoTotem,
							detalhePreparacao, ePacoteResult, questionariosExamesResult, perguntas);
			service.entregar(parametroPedidoEntrega);
			if (service.isSuccess()) {
				registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(),
						MensagemUtil.retornarMensagemAoEfetivarPedido(criaPedidoResult), sessionId,
						createBasicLogMap());
			} else {
				throw new RegraNegocioException(service.getResponseMessage());
			}
		} catch (final Exception locExc) {
			gerarLogErroAoEfetivarPedido(locExc.getMessage());
			throw new RegraNegocioException(locExc.getMessage());
		}
	}

	private void gerarLogErroAoEfetivarPedido(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, sessionId,
					createBasicLogMap());
		} catch (final Exception exc) {
		}
	}

	private void gerarLogErroAoConfirmarPedido(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, sessionId,
					createBasicLogMap());
		} catch (final Exception exc) {
		}
	}

	private void fazerPedido() throws RegraNegocioException {
		try {
			final PedidoService service = new PedidoService(getHttpServletRequest());
			parametroPedido = ParametroPedido.criarPedidoParaCheckup(informacaoTotem, clienteUnidadePasseLivre,
					tokenResult, detalhePreparacao, ePacoteResult, questionariosExamesResult, perguntas);
			parametroPedido.getPaciente().setOperadora(Constantes.OPERADORA_CAMPANHA);
			service.fazerPedido(parametroPedido);
			if (service.isSuccess()) {
				criaPedidoResult = (CriarPedidoResult) service.getResponseObject();
				registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(),
						MensagemUtil.retornarMensagemAoFinalizarPedido(criaPedidoResult.getPedido(),
								criaPedidoResult.getUnidade()),
						sessionId, createBasicLogMap());
			} else {
				throw new RegraNegocioException(service.getResponseMessage());
			}
		} catch (final Exception locExc) {
			gerarLogErroAoFazerPedido(locExc.getMessage());
			throw new RegraNegocioException(locExc.getMessage());
		}
	}

	public String cancelar() {
		try {
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId, createBasicLogMap());
			return redirectIndex();
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return "";
		}
	}

	public String getMensagemCabecalho() {
		try {
			return MensagemUtil.retornarMensagemCabelhoPagamento(clienteUnidadePasseLivre);
		} catch (final Exception locExc) {
			return "";
		}
	}

	public String finalizar() {
		try {
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId, createBasicLogMap());
			return redirectIndex();
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return "";
		}
	}

	private String redirectIndex() throws Exception {
		final String nomeMaquina = TotemUtil.retornarNomeDaMaquina();
		getSession().removeAttribute("indexBean");
		TotemUtil.limparSession();
		return "/indexTotem.xhtml?faces-redirect=true&nomeTotem=" + nomeMaquina;
	}

	private void gerarLogEstatistico() {
		try {
			final ControleEstatisticoService controleEstatisticoService = new ControleEstatisticoService(
					getHttpServletRequest());
			final ControleEstatistico controleEstatistico = new ControleEstatistico(
					clienteUnidadePasseLivre.getCodigoCliente(), null,
					FuncaoLogEstatistico.REALIZAR_ATENDIMENTO_CHECKUP_MASCULINO.toString(),
					informacoesTotem.get(0).getId(), null, null, retornarUnidade());
			controleEstatisticoService.insert(controleEstatistico);
		} catch (final Exception locExc) {
			gerarLogErroAoGerarLogEstatistico(locExc.getMessage());
		}
	}

	private String retornarUnidade() {
		if (informacoesTotem == null || informacoesTotem.isEmpty()) {
			return null;
		} else {
			return informacoesTotem.get(0).getIdUnidade();
		}
	}

	private void gerarLogErroAoGerarLogEstatistico(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, sessionId,
					createBasicLogMap());
		} catch (final Exception exc) {
		}
	}

	private void gerarLogErroAoFazerPedido(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN,
					clienteUnidadePasseLivre.getCodigoCliente());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, sessionId,
					createBasicLogMap());
		} catch (final Exception exc) {
		}
	}

	private void cancelarPedido(final String parMessage) {
		try {
			final PedidoService service = new PedidoService(getHttpServletRequest());
			CancelarPedidoResult locCancelarPedidoResult = new CancelarPedidoResult();
			final ParametroCancelaPedido parametroCancelaPedido = ParametroCancelaPedido
					.criarParametrosParaCancelarPedido(informacaoTotem, sessionId, criaPedidoResult,
							"Problema ao fazer o pagamento", tokenResult);
			service.cancelar(parametroCancelaPedido);
			if (service.isSuccess()) {
				locCancelarPedidoResult = (CancelarPedidoResult) service.getResponseObject();
				gerarLogAoCancelarPedido(parametroCancelaPedido.getPedido());
			} else {
				gerarLogErroAoCancelarPedido(service.getResponseMessage());
			}
		} catch (final Exception locExc) {
			gerarLogErroAoCancelarPedido(locExc.getMessage());
		}
	}

	private void gerarLogAoCancelarPedido(final String parPedido) {
		try {
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(),
					MensagemUtil.retornarMensagemAoCancelarPedido(parPedido), sessionId, createBasicLogMap());
		} catch (final Exception locExc) {
		}
	}

	private void gerarLogErroAoCancelarPedido(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN,
					clienteUnidadePasseLivre.getCodigoCliente());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, sessionId,
					createBasicLogMap());
		} catch (final Exception exc) {
		}
	}

	private void fazerPagamentoNaCielo() throws PagamentoException {
		try {
			final String token = new Util().retornarEndPoint("TOKEN_PAGAMENTO_CIELO", getHttpServletRequest());
			final PagamentoService service = new PagamentoService(getHttpServletRequest());
			parametroPagamento = ParametroPagamento.criarPagamentoCheckup(
					Customer.criarClienteCheckup(clienteUnidadePasseLivre),
					Product.criarCheckup(detalhePreparacao, criaPedidoResult), Payment.criarDadosPagemento(dadosCartao),
					token);
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(),
					"Dados de entrada:" + retornarParametroJson(), sessionId, createBasicLogMap());
			service.realizarPagamento(parametroPagamento);
			if (service.isSuccess()) {
				registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId,
						createBasicLogMap());
				pagamentoResult = (PagamentoResult) service.getResponseObject();
			} else {
				registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(), service.getResponseMessage(),
						sessionId, createBasicLogMap());
				throw new PagamentoException("Serviço de pagamento fora do ar. Tente mais tarde.");
			}
		} catch (final Exception locExc) {
			gerarLogErroAoFazerPagamento(locExc.getMessage());
			throw new PagamentoException("Serviço de pagamento fora do ar. Tente mais tarde.");
		}
	}

	private String retornarParametroJson() {
		try {
			final Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
			return gson.toJson(parametroPagamento);
		} catch (final Exception locExc) {
			return "";
		}
	}

	private void gerarLogErroAoFazerPagamento(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, sessionId,
					createBasicLogMap());
		} catch (final Exception exc) {
		}
	}

	public Map createBasicLogMap() {
		Long idTotem = null;
		Long idUnidade = null;
		if (informacoesTotem != null && !informacoesTotem.isEmpty()) {
			idTotem = informacoesTotem.get(0).getId();
			idUnidade = Long.valueOf(informacoesTotem.get(0).getIdUnidade());
		}
		try {
			return TotemUtil.createBasicLogMap(idTotem, idUnidade, Util.getClientIpAddr(getHttpServletRequest()));
		} catch (Exception e) {
			e.printStackTrace();
			return new HashMap();
		}
	}

	public String mensagemCabecalho(String linha) {
		try {

			return MensagemUtil.retornarMensagemCabelho(clienteUnidadePasseLivre, "", linha);
		} catch (final Exception locExc) {
			return "";
		}
	}

	public DadosCartao getCartaoPagamento() {
		return dadosCartao;
	}

	public void setCartaoPagamento(final DadosCartao parCartaoPagamento) {
		dadosCartao = parCartaoPagamento;
	}

	public DadosCartao getDadosCartao() {
		return dadosCartao;
	}

	public void setDadosCartao(final DadosCartao parDadosCartao) {
		dadosCartao = parDadosCartao;
	}

	public String getMensagemAviso() {
		return mensagemAviso;
	}

	public void setMensagemAviso(final String parMensagemAviso) {
		mensagemAviso = parMensagemAviso;
	}

	public String getPedido() {
		return criaPedidoResult.getPedido().toString();
	}
}
