package br.com.hermespardini.passelivre.bean;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.primefaces.context.RequestContext;

import br.com.hermespardini.commons.http.HttpUtil;
import br.com.hermespardini.corebusiness.model.LogAplicacaoUsuarioFactory;
import br.com.hermespardini.corebusiness.util.SessionIdBuilder;
import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.constantsenum.OrigemIniciarInformacoesTokenSessaoEnum;
import br.com.hermespardini.passelivre.constantsenum.TipoServicoEnum;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.format.FormataCep;
import br.com.hermespardini.passelivre.format.FormataCpf;
import br.com.hermespardini.passelivre.format.FormataEndereco;
import br.com.hermespardini.passelivre.format.FormataTelefone;
import br.com.hermespardini.passelivre.model.ClienteUnidadePasseLivre;
import br.com.hermespardini.passelivre.model.ConsultaConfiguracaoResult;
import br.com.hermespardini.passelivre.model.InformacaoTotem;
import br.com.hermespardini.passelivre.model.Localidade;
import br.com.hermespardini.passelivre.model.MensagemAviso;
import br.com.hermespardini.passelivre.model.ParametroConsultaConfiguracao;
import br.com.hermespardini.passelivre.model.ParametroUsuarioToken;
import br.com.hermespardini.passelivre.model.Servico;
import br.com.hermespardini.passelivre.model.TokenResult;
import br.com.hermespardini.passelivre.model.Totem;
import br.com.hermespardini.passelivre.model.UserAuth;
import br.com.hermespardini.passelivre.service.AutenticaService;
import br.com.hermespardini.passelivre.service.InformacaoTotemService;
import br.com.hermespardini.passelivre.service.LocalidadeService;
import br.com.hermespardini.passelivre.utils.ControleBotaoUtil;
import br.com.hermespardini.passelivre.utils.NomeComputadorLocalUtil;
import br.com.hermespardini.passelivre.utils.TotemUtil;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.bean.MainBean;

@SuppressWarnings("serial")
@ManagedBean(name = "indexBean")
public class IndexBean extends MainBean {

	private UserAuth user;
	private String dataAtual;

	private boolean loggedIn;
	private String sessionId;
	private Integer activeIndex;
	private String paramForwardPath;
	private TokenResult tokenResult;
	private TipoServicoEnum tipoServico;
	private FormataEndereco formataEndereco;
	private ControleBotaoUtil controleBotaoUtil;
	private List<InformacaoTotem> informacoesTotem;
	private static final String SERVICO_ATIVO = "S";
	private ClienteUnidadePasseLivre clienteUnidadePasseLivre;
	private String nomeComputador;
	private String senha;
	private String numeroCarteira;
	private String caminhoCSS;
	private String caminhoBotoes;
	private String mensagemAviso;
	private String nomeTotem;
	private boolean execForcarBuscaInformacoes;

	@PostConstruct
	public void onLoad() {

		user = new UserAuth();
		activeIndex = 0;
		tokenResult = new TokenResult();
		informacoesTotem = new ArrayList<>();
		controleBotaoUtil = new ControleBotaoUtil();
		clienteUnidadePasseLivre = new ClienteUnidadePasseLivre();
		dataAtual = new SimpleDateFormat("dd/MM/yyyy").format(Calendar.getInstance().getTime());
		nomeComputador = recuperaNomeTotemUrl();
		nomeTotem = TotemUtil.retornarNomeDaMaquina();
		final ServletContext servletContext = (ServletContext) FacesContext.getCurrentInstance().getExternalContext()
				.getContext();
		try {
			Boolean forcarBuscaInformacoes = Boolean.FALSE;
			String erro = iniciarInformacoesTokenSessao(forcarBuscaInformacoes, OrigemIniciarInformacoesTokenSessaoEnum.ONLOAD.getDescricao());		
			if(Objects.isNull(erro)) {
				buscarTipoServico();
				getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_SIGLA_APLICACAO, getApplicationSecurityCode());
				verificarSeTotemEstaHabilitato();
			}
		} catch (final Exception locExc) {
			Logger logger = Logger.getLogger(IndexBean.class);
			logger.error("LOG DE EXCESSÃO ONLOAD locExc IndexBean", locExc);
			try {
				final HttpServletRequest locRequest = getHttpServletRequest();
				locRequest.getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_SIGLA_APLICACAO,
						getApplicationSecurityCode());
			} catch (final Exception exc) {
				logger.error("LOG DE EXCESSÃO ONLOAD exc IndexBean", locExc);
			}
		}
	}
	
	public String iniciarAtendimento() {
		try {
			if (nomeComputador != null && "nometotemindisponivel".equals(nomeComputador)) {
				nomeComputador = TotemUtil.retornarNomeDaMaquina();
			}
			
			final String nomeMaquina = nomeComputador;

			Boolean forcarBuscaInformacoes = Boolean.TRUE;
			String erro = iniciarInformacoesTokenSessao(forcarBuscaInformacoes, OrigemIniciarInformacoesTokenSessaoEnum.INICIAR_ATENDIMENTO.getDescricao()) ;

			if(Objects.isNull(erro)) {
				return  "/indexTotem.xhtml?faces-redirect=true&nomeTotem=" + nomeMaquina;
			}
		} catch (final Exception locExc) {
			try {
				FacesContext.getCurrentInstance().getExternalContext().redirect(createAndGetPageErrorRedirect(locExc.getMessage()));
			} catch (IOException e) {
				Logger logger = Logger.getLogger(IndexBean.class);
				logger.error("LOG DE EXCESSÃO AO REDIRECIONAR PARA PÁGINA DE ERRO iniciarAtendimento", e);
			}
		}
		return null;
	}

	private void buscarTipoServico() throws Exception {
		final HttpSession session = getHttpServletRequest().getSession();
		tipoServico = (TipoServicoEnum) session.getAttribute("tipoServico");
	}

	private void gerarLogErroAoAtualizar(final Exception locExc) {
		try {
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), locExc.getMessage(), sessionId,
					createBasicLogMap());
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	private void formatarValores() {
		clienteUnidadePasseLivre.setCelular(formatarTelefone(clienteUnidadePasseLivre.getCelular()));
		clienteUnidadePasseLivre.setTelefone(formatarTelefone(clienteUnidadePasseLivre.getTelefone()));
		clienteUnidadePasseLivre.setCep(formatarCep(clienteUnidadePasseLivre.getCep()));
		clienteUnidadePasseLivre.setCpf(formatarCpf(clienteUnidadePasseLivre.getCpf()));
	}

	private String formatarCep(final String cep) {
		return new FormataCep(cep).formatar();
	}

	private String formatarCpf(final String cpf) {
		try {
			return new FormataCpf(cpf).formatar();
		} catch (final Exception locExc) {
			return null;
		}
	}

	private String formatarTelefone(final String telefone) {
		return new FormataTelefone(telefone).formatar();
	}

	private void verificarSeTotemEstaHabilitato() throws Exception {
		try {
			verificarSeEhGuicheOuTotem();
		} catch (final Exception exc) {
			MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso(exc.getMessage());
			getSession().setAttribute("mensagemAviso", mensagemAviso);
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(),
					"Redirecionando para tela sistema indisponivel: " + getHttpServletRequest().getRequestURI()
							+ " Totem: " + TotemUtil.retornarNomeDaMaquina(),
					sessionId, createBasicLogMap());
			FacesContext.getCurrentInstance().getExternalContext().redirect(
					"/passelivretotem/pages/erro/sistemaIndisponivelSemRodape.xhtml?faces-redirect=true&sessionId="
							+ sessionId + "&nomeTotem=" + TotemUtil.retornarNomeDaMaquina());
			Logger logger = Logger.getLogger(TelaErroBean.class);
			logger.error("LOG DE EXCESSÃO verificarSeTotemEstaHabilitato IndexBean", exc);			
		}
	}

	private void verificarSeEhGuicheOuTotem() throws Exception, IOException {
		buscarInformacoesTotem();
		if (informacoesTotem.isEmpty() || todosServicosDesativados()) {
			getHttpServletRequest().getSession().setAttribute("tokenResult", tokenResult);
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(),
					"Redirecionando para tela sistema indisponivel: " + getHttpServletRequest().getRequestURI()
							+ " Totem: " + TotemUtil.retornarNomeDaMaquina(),
					sessionId, createBasicLogMap());
			MensagemAviso mensagemAviso = TotemUtil
					.createMensagemAviso("Sem informações de servi�os do totem ou todos os serviços desativados.");
			getSession().setAttribute("mensagemAviso", mensagemAviso);
			FacesContext.getCurrentInstance().getExternalContext().redirect(
					"/passelivretotem/pages/erro/sistemaIndisponivelSemRodape.xhtml?faces-redirect=true&nomeTotem="
							+ TotemUtil.retornarNomeDaMaquina());
			getHttpServletRequest().getSession().setAttribute("siglaEmpresa", buscarSigla(Boolean.TRUE));
			
			Long idEmpresa = informacoesTotem.isEmpty() ? 0 : informacoesTotem.get(0).getIdEmpresa();
			getHttpServletRequest().getSession().setAttribute("IdEmpresa", idEmpresa);
		} else {
			sessionId = SessionIdBuilder.build(informacoesTotem.get(0));
			getHttpServletRequest().getSession().setAttribute("siglaEmpresa", buscarSigla(Boolean.TRUE));
			getHttpServletRequest().getSession().setAttribute("IdEmpresa", informacoesTotem.get(0).getIdEmpresa());
		}
	}

	public String buscarSigla(Boolean isPrimeiraVez) throws Exception {

		if (existeInformacoes()) {
			switch (informacoesTotem.get(0).getNomeEmpresa()) {
			case "INSTITUTO HERMES PARDINI S/A":
				return "IHP";
			case "IHP DIGIMAGEM MEDICINA DIAGNOSTICA S/A":
				return "DIGIM";
			case "CENTRO DE MEDICINA":
				return "CMNG";
			case "LABORATORIO PADRÃO S/A":
				return "PDRAO";
			case "ECOAR - MEDICINA DIAGNOSTICA":
				return "ECO";
			case "LABORATORIO DE ANALISES CLINICAS HUMBERTO ABRAO":
				return "HUM";
			case "UNIMED FORTALEZA":
				return "UF";
			default:
				return "IHP";
			}
		} else if(isPrimeiraVez){
			buscarInformacoesTotem();
			buscarSigla(Boolean.FALSE);
		}
		return "";
	}

	public boolean existeInformacoes() {
		return informacoesTotem != null && !informacoesTotem.isEmpty();
	}

	private boolean ehTotemGuiche() throws RegraNegocioException {
		return !retornarNomeDaMaquina().toLowerCase().contains("totem");
	}

	public String aceitarTermo() {
		try {
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId, createBasicLogMap());
			return tipoServico.aceitar();
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return "";
		}
	}

	private String redirectLogin() {
		return "/pages/login.xhtml?faces-redirect=true";
	}

	public String naoAceitarTermo() {
		try {
			final String nomeMaquina = TotemUtil.retornarNomeDaMaquina();
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId, createBasicLogMap());
			return "/indexTotem.xhtml?faces-redirect=true&nomeTotem=" + nomeMaquina;
		} catch (final Exception locExc) {
			return "";
		}
	}

	public String redirectIndex() throws Exception {
		final String nomeMaquina = TotemUtil.retornarNomeDaMaquina();
		TotemUtil.limparSession();
		return "/indexTotem.xhtml?faces-redirect=true&nomeTotem=" + nomeMaquina;
	}

	public void retornarErroAtendimento() {
		try {
			final String nomeMaquina = TotemUtil.retornarNomeDaMaquina();
			Thread.currentThread();
			Thread.sleep(5000);
			FacesContext.getCurrentInstance().getExternalContext()
					.redirect("/passelivretotem/pages/erro/atendimentoNaoConcluido.xhtml?faces-redirect=true&nomeTotem="
							+ nomeMaquina);
		} catch (final InterruptedException exc) {
			exc.printStackTrace();
		} catch (final IOException exc) {
			exc.printStackTrace();
		}
	}

	private boolean todosServicosDesativados() {
		int cont = 0;
		for (final InformacaoTotem locInformacaoTotem : informacoesTotem) {
			if (servicoEstaAtivado(locInformacaoTotem)) {
				cont += 1;
			}
		}
		return cont == 0 ? true : false;
	}

	public void buscarInformacoesTotem() throws Exception {
		try {
			String erro = iniciarInformacoesTokenSessao(execForcarBuscaInformacoes, OrigemIniciarInformacoesTokenSessaoEnum.BUSCAR_INFORMACOES_TOTEM.getDescricao());
			if(Objects.isNull(erro)) {
				informacoesTotem = new ArrayList<>();
				final InformacaoTotem informacaoTotem = new InformacaoTotem();
				informacoesTotem.addAll(retornarInformacoesTotem());
				if (informacoesTotem != null && !informacoesTotem.isEmpty()) {
	
					// C�DIGO TEMPOR�RIO AT� OS DADOS SEREM RETORNADOS DO SERVI�O DE CONSULTA
					// CONFIGURA��O
					// -----------------------------------------------------------
	
					// -----------------------------------------------------------
	
					final Localidade localidade = adicionarIpALocalidade();
					if (localidade != null) {
						String codigoPrestadorUnimed = localidade.getCodigounimed();
						if (codigoPrestadorUnimed != null) {
							getSession().setAttribute("codigoPrestadorUnimed", codigoPrestadorUnimed);
						} else {
							getSession().setAttribute("codigoPrestadorUnimed", Constantes.CODIGO_PRESTADOR_HERMESPARDINI);
						}
						validarFilialPorLocalidade(localidade);
					}
	
					getHttpServletRequest().getSession().setAttribute("informacoesTotem", informacoesTotem);
					registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
							Thread.currentThread().getStackTrace()[1].getMethodName(),
							"Informações do totem recuperadas: " + TotemUtil.retornarNomeDaMaquina(), sessionId,
							createBasicLogMap());
				} else {
					Localidade localidade = adicionarIpALocalidade();
					validarFilialPorLocalidade(localidade);
				}
			}
		} catch (final RegraNegocioException exc) {
			exc.printStackTrace();
			gerarLogErroBuscarInformacoesTotem(exc.getMessage());
			final String nomeMaquina = TotemUtil.retornarNomeDaMaquina();
			MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso(exc.getMessage());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(),
					"Redirecionando para tela sistema indisponivel: " + getHttpServletRequest().getRequestURI()
							+ " Totem: " + TotemUtil.retornarNomeDaMaquina() + " - Mensagem: "
							+ mensagemAviso.getMensagem(),
					sessionId, createBasicLogMap());

			getSession().setAttribute("mensagemAviso", mensagemAviso);
			throw exc;
		} catch (final Exception exc) {
			exc.printStackTrace();
			gerarLogErroBuscarInformacoesTotem(exc.getMessage());
			final String nomeMaquina = TotemUtil.retornarNomeDaMaquina();
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(),
					"Redirecionando para tela sistema indisponivel: " + getHttpServletRequest().getRequestURI()
							+ " Totem: " + TotemUtil.retornarNomeDaMaquina(),
					sessionId, createBasicLogMap());
			MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso(exc.getMessage());
			getSession().setAttribute("mensagemAviso", mensagemAviso);
			throw exc;
		}
	}

	private void validarFilialPorLocalidade(Localidade localidade) {
		try {
			if (localidade != null) {
				if (localidade.getFilial() == 120 || localidade.getFilial() == 121 || localidade.getFilial() == 122) {
					getSession().setAttribute("ecoar", true);
				} else {
					getSession().setAttribute("ecoar", false);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private List<InformacaoTotem> retornarInformacoesTotem() throws RegraNegocioException {
		try {
			tokenResult = retornarToken();
			getSession().setAttribute("tokenResult", tokenResult);
			if (nomeComputador == null || ("null").equals(nomeComputador)) {
				throw new RegraNegocioException("Nome do totem inválido: " + nomeComputador);
			} else if (nomeComputador.equals("nometotemindisponivel")) {
				nomeComputador = TotemUtil.retornarNomeDaMaquina();
			}
			final List<InformacaoTotem> locInformacoesTotem = new ArrayList<>();
			final ParametroConsultaConfiguracao parametroConsultaConfiguracao = new ParametroConsultaConfiguracao(
					retornarNomeDaMaquina(), tokenResult);
			final InformacaoTotemService informacaoTotemService = new InformacaoTotemService(getHttpServletRequest());
			informacaoTotemService.consultar(parametroConsultaConfiguracao);
			final ConsultaConfiguracaoResult consultaConfiguracaoResult = (ConsultaConfiguracaoResult) informacaoTotemService
					.getResponseObject();
			if (!Objects.isNull(consultaConfiguracaoResult)) {
				for (final Totem totem : consultaConfiguracaoResult.getTotens()) {
					for (final Servico servico : totem.getServicos()) {
						locInformacoesTotem.add(new InformacaoTotem(totem, servico));
					}
				}
			} else {
				throw new RegraNegocioException(
						"2 - Erro ao buscar informações do totem:" + parametroConsultaConfiguracao.getIp());
			}
			return locInformacoesTotem;
		} catch (final Exception locExc) {
			throw new RegraNegocioException(locExc.getMessage());
		}
	}

	private void gerarLogErroBuscarInformacoesTotem(final String parMensagem) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, clienteUnidadePasseLivre.getCpf());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMensagem, sessionId,
					createBasicLogMap());
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	private String retornarNomeDaMaquina() throws RegraNegocioException {
		try {
			return TotemUtil.retornarNomeDaMaquina();
			/*
			 * final IndexService indexService = new IndexService(); return
			 * indexService.retornarNomeMaquina(getHttpServletRequest());
			 */
		} catch (final Exception exc) {
			exc.printStackTrace();
			gerarLogAoRetornarNomeDaMaquina(exc.getMessage());
			throw new RegraNegocioException(exc.getMessage());
		}
	}

	private void gerarLogAoRetornarNomeDaMaquina(final String parMessage) {
		try {
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, sessionId,
					createBasicLogMap());
		} catch (final Exception locExc) {
		}
	}

	private boolean servicoEstaAtivado(final InformacaoTotem locInformacaoTotem) {
		return locInformacaoTotem.getAtivo().equals(IndexBean.SERVICO_ATIVO);
	}

	public Boolean getHabilitaResultado() {
		return controleBotaoUtil.getHabilitaEntregaResultado(informacoesTotem);
	}

	public Boolean getHabilitaOrcamento() {
		return controleBotaoUtil.getHabilitaOrcamento(informacoesTotem);
	}

	public Boolean getHabilitaPeparacao() {
		return controleBotaoUtil.getHabilitaPreparacaoExame(informacoesTotem);
	}

	public Boolean getHabilitaAtendimentoUnimed() {
		return controleBotaoUtil.getHabilitaAtendimentoUnimed(informacoesTotem);
	}

	public Boolean getHabilitaEntregaMaterial() {
		return controleBotaoUtil.getHabilitaEntregaMaterial(informacoesTotem);
	}

	public Boolean getHabilitaPreAtendimento() {
		return controleBotaoUtil.getHabilitaPreAtendimento(informacoesTotem);
	}

	public Boolean getHabilitaCheckupMasculino() {
		return controleBotaoUtil.getHabilitaCheckupMasculino(informacoesTotem);
	}

	public Boolean getHabilitaCheckupFeminino() {
		return controleBotaoUtil.getHabilitaCheckupFeminino(informacoesTotem);
	}

	public String redirectAtualizaDados() {
		final String nomeMaquina = TotemUtil.retornarNomeDaMaquina();
		return "/pages/emp/atualizarDados.xhtml?faces-redirect=true&nomeTotem=" + nomeMaquina;
	}

	public String redirectPreparacao() {
		try {
			tokenResult = retornarToken();
			setLoggedIn(Boolean.TRUE);
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId, createBasicLogMap());
			getSession().setAttribute("indexBean", this);
			final HttpSession session = getHttpServletRequest().getSession();
			session.setAttribute("informacoesTotem", informacoesTotem);
			session.setAttribute("tokenResult", tokenResult);
			session.setAttribute("sessionId", sessionId);
			session.setAttribute("tipoServico", TipoServicoEnum.PRE);
			return "/pages/ppe/preparacao.xhtml?faces-redirect=true";
			// return "/pages/termoUso.xhtml?faces-redirect=true";
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return "";
		}
	}

	public String redirectUnimed() {
		try {
			tokenResult = retornarToken();
			setLoggedIn(Boolean.TRUE);
			Localidade loc = adicionarIpALocalidade();
			if (loc != null) {
				registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId,
						createBasicLogMap());
				getSession().setAttribute("indexBean", this);
				final HttpSession session = getHttpServletRequest().getSession();
				session.setAttribute("informacoesTotem", informacoesTotem);
				session.setAttribute("tokenResult", tokenResult);
				session.setAttribute("sessionId", sessionId);
				if (informacoesTotem.get(0).getNomeEmpresa().equals(Constantes.NOME_EMPRESA_ECOAR)) {
					session.setAttribute("tipoServico", TipoServicoEnum.NAU_E);
				} else {
					session.setAttribute("tipoServico", TipoServicoEnum.NAU);
				}
				return "/pages/nau/termoUso.xhtml?faces-redirect=true";
			}

			setMensagemAviso("Não existe localidade de biometria cadastrada para o IP local (" + ipLocal() + ")."
					+ "Favor consultar a equipe de suporte.");

			RequestContext.getCurrentInstance().update("dlgMessage");
			exibirDialogMensagem();
			return "";
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return "";
		}
	}

	private void exibirDialogMensagem() {
		RequestContext.getCurrentInstance().execute("PF('dlgMessage').show()");
	}

	public String redirectOrcamento() {
		try {
			tokenResult = retornarToken();
			setLoggedIn(Boolean.TRUE);
			getSession().setAttribute("indexBean", this);
			final HttpSession session = getHttpServletRequest().getSession();
			session.setAttribute("informacoesTotem", informacoesTotem);
			session.setAttribute("tipoFuncao", TipoServicoEnum.ORM);
			session.setAttribute("tokenResult", tokenResult);
			return "/pages/ocm/preparacao.xhtml?faces-redirect=true";
			// return "/pages/termoUso.xhtml?faces-redirect=true";
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return "";
		}
	}

	public String redirectResultado() {
		try {
			setLoggedIn(Boolean.TRUE);
			getSession().setAttribute("indexBean", this);
			tokenResult = retornarToken();
			final HttpSession session = getHttpServletRequest().getSession();
			session.setAttribute("informacoesTotem", informacoesTotem);
			if (informacoesTotem.get(0).getNomeEmpresa().equals(Constantes.NOME_EMPRESA_ECOAR)) {
				session.setAttribute("tipoServico", TipoServicoEnum.RES_E);
			} else if (Long.toString(informacoesTotem.get(0).getIdEmpresa()).equals("8")) {
				session.setAttribute("tipoServico", TipoServicoEnum.RES_P);
			} else {
				session.setAttribute("tipoServico", TipoServicoEnum.RES);
			}
			session.setAttribute("tokenResult", tokenResult);
			session.setAttribute("sessionId", sessionId);
			return "/pages/res/termoUso.xhtml?faces-redirect=true";
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return "";
		}
	}

	public String redirectPagamento() {
		try {
			tokenResult = retornarToken();
			setLoggedIn(Boolean.TRUE);
			getSession().setAttribute("indexBean", this);
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId, createBasicLogMap());
			final HttpSession session = getHttpServletRequest().getSession();
			session.setAttribute("informacoesTotem", informacoesTotem);
			session.setAttribute("tipoServico", TipoServicoEnum.PAG);
			session.setAttribute("tokenResult", tokenResult);
			session.setAttribute("sessionId", sessionId);
			// return "/pages/pag/termoUso.xhtml?faces-redirect=true";
			return "/pages/termoUso.xhtml?faces-redirect=true";
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return "";
		}
	}

	public String redirectMaterialPendente() {
		try {
			setLoggedIn(Boolean.TRUE);
			tokenResult = retornarToken();
			getSession().setAttribute("indexBean", this);
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId, createBasicLogMap());
			final HttpSession session = getHttpServletRequest().getSession();
			session.setAttribute("informacoesTotem", informacoesTotem);
			session.setAttribute("tokenResult", tokenResult);
			if (Long.toString(informacoesTotem.get(0).getIdEmpresa()).equals("8")) {
				session.setAttribute("tipoServico", TipoServicoEnum.EMP_P);
			} else {
				session.setAttribute("tipoServico", TipoServicoEnum.EMP);
			}
			session.setAttribute("sessionId", sessionId);
			// return "/pages/emp/termoUso.xhtml?faces-redirect=true";
			return "/pages/termoUso.xhtml?faces-redirect=true";
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return "";
		}
	}

	public String redirectCheckupMasculino() {
		try {
			tokenResult = retornarToken();
			setLoggedIn(Boolean.TRUE);
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId, createBasicLogMap());
			getSession().setAttribute("indexBean", this);
			final HttpSession session = getHttpServletRequest().getSession();
			session.setAttribute("informacoesTotem", informacoesTotem);
			session.setAttribute("tokenResult", tokenResult);
			session.setAttribute("sessionId", sessionId);
			session.setAttribute("tipoServico", TipoServicoEnum.CKM);
			return "/pages/termoUso.xhtml?faces-redirect=true";
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return "";
		}
	}

	public String redirectCheckupFeminino() {
		try {
			tokenResult = retornarToken();
			setLoggedIn(Boolean.TRUE);
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId, createBasicLogMap());
			getSession().setAttribute("indexBean", this);
			final HttpSession session = getHttpServletRequest().getSession();
			session.setAttribute("informacoesTotem", informacoesTotem);
			session.setAttribute("tokenResult", tokenResult);
			session.setAttribute("sessionId", sessionId);
			session.setAttribute("tipoServico", TipoServicoEnum.CKF);
			return "/pages/termoUso.xhtml?faces-redirect=true";
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return "";
		}
	}

	public String redirectPreAtendimento() {
		try {
			setLoggedIn(Boolean.TRUE);
			tokenResult = retornarToken();
			getSession().setAttribute("indexBean", this);
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId, createBasicLogMap());
			final HttpSession session = getHttpServletRequest().getSession();
			session.setAttribute("informacoesTotem", informacoesTotem);
			session.setAttribute("tokenResult", tokenResult);
			session.setAttribute("tipoServico", TipoServicoEnum.PAT);
			session.setAttribute("sessionId", sessionId);
			// return "/pages/emp/termoUso.xhtml?faces-redirect=true";
			return "/pages/termoUso.xhtml?faces-redirect=true";
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return "";
		}
	}

	private TokenResult retornarToken() throws Exception, RegraNegocioException {
		try {
			final ParametroUsuarioToken parametroUsuarioToken = new ParametroUsuarioToken(Constantes.ORIGEM_PADRAO);
			final AutenticaService autenticaService = new AutenticaService(getHttpServletRequest());
			autenticaService.gerarToken(parametroUsuarioToken);
			if (autenticaService.isSuccess()) {
				return (TokenResult) autenticaService.getResponseObject();
			} else {
				throw new RegraNegocioException("Erro ao retornar token: " + autenticaService.getResponseMessage());
			}
		} catch (final Exception locExc) {
			throw new RegraNegocioException("Exceção gerada ao retornar token: " + locExc.getMessage());
		}
	}

	private void gerarLogErroBuscarToken(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, Constantes.USUARIO_TOKEN);
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, sessionId,
					createBasicLogMap());
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	private String ipLocal() {
		try {
			return Util.getClientIpAddr(getHttpServletRequest());
		} catch (final Exception exc) {
			exc.printStackTrace();
			return "";
		}
	}

	public String irParaLogin(final TipoServicoEnum tipoFuncao) {
		HttpSession session;
		try {
			session = getHttpServletRequest().getSession();
			session.setAttribute("tipoServico", tipoServico);
			session.setAttribute("informacoesTotem", informacoesTotem);
			session.setAttribute("tokenResult", tokenResult);
			return "/pages/login.xhtml";
		} catch (final Exception exc) {
			exc.printStackTrace();
			return "";
		}
	}

	public String getRetornarAmbiente() {
		StringBuilder sb;
		try {
			sb = new StringBuilder().append("-IP: ").append(retornarIp()).append(" Equipamento: ")
					.append(retornarNomeDaMaquina()).append(" Impressora:").append(retornarImpressoraDefault());
			if (getAmbienteProducao()) {
				return " - " + Constantes.AMBIENTE_PRODUCAO + sb.toString();
			} else {
				return " - " + Constantes.AMBIENTE_HOMOLOGACAO + sb.toString();
			}
		} catch (final Exception exc) {
			gerarLogErroRetornarAmbiente(exc.getMessage());
			exc.printStackTrace();
			return "";
		}
	}

	private String retornarImpressoraDefault() throws RegraNegocioException {
		if (informacoesTotem != null && !informacoesTotem.isEmpty() && !informacoesTotem.isEmpty()) {
			return informacoesTotem.get(0).getImpressoraDefault();
		} else {
			throw new RegraNegocioException("Erro ao buscar dados do totem!");
		}
	}

	private void gerarLogErroRetornarAmbiente(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, clienteUnidadePasseLivre.getCpf());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, sessionId,
					createBasicLogMap());
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	public String recuperaNomeTotemUrl() {
		String nomeTotem = "";
		try {
			if (getHttpServletRequest().getParameter("nomeTotem") != null) {
				nomeTotem = getHttpServletRequest().getParameter("nomeTotem").toLowerCase();
				getHttpServletRequest().getSession().setAttribute("nomeTotem", nomeTotem.toLowerCase());
			} else {
				nomeTotem = (String) getHttpServletRequest().getSession().getAttribute("nomeTotem");
			}
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
		if (nomeTotem == null || nomeTotem.isEmpty()) {
			NomeComputadorLocalUtil nomeComputadorLocalUtil = new NomeComputadorLocalUtil();
			try {
				nomeTotem = nomeComputadorLocalUtil.retornar(getHttpServletRequest().getRemoteHost());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return nomeTotem;
	}

	public Map createBasicLogMap() {
		Long idTotem = null;
		Long idUnidade = null;
		if (informacoesTotem != null && !informacoesTotem.isEmpty()) {
			idTotem = informacoesTotem.get(0).getId();
			idUnidade = Long.valueOf(informacoesTotem.get(0).getIdUnidade());
		}
		try {
			return TotemUtil.createBasicLogMap(idTotem, idUnidade, Util.getClientIpAddr(getHttpServletRequest()));
		} catch (Exception e) {
			e.printStackTrace();
			return new HashMap();
		}
	}

	public Long recuperarIdEmpresa() {
		return informacoesTotem.get(0).getIdEmpresa();
	}

	public String recuperarNomeEmpresa() {
		if (informacoesTotem != null && !informacoesTotem.isEmpty() && informacoesTotem.get(0) != null
				&& informacoesTotem.get(0).getNomeEmpresa() != null) {
			return informacoesTotem.get(0).getNomeEmpresa();
		} else {
			return Constantes.NOME_EMPRESA_HERMESPARDINI;
		}
	}

	public String recuperarCaminhoCSS() {
		try {
			String sigla = (String) getSession().getAttribute("siglaEmpresa") == null ? "IHP" : (String) getSession().getAttribute("siglaEmpresa");
			if (existeInformacoes()) {
				switch (sigla) {
				case "IHP":
					return FacesContext.getCurrentInstance().getExternalContext().getRequestContextPath()
							+ "/resources/css";
				case "DIGIM":
					return FacesContext.getCurrentInstance().getExternalContext().getRequestContextPath()
							+ "/resources/css";
				case "CMNG":
					return FacesContext.getCurrentInstance().getExternalContext().getRequestContextPath()
							+ "/resources/css/centroMedicina";
				case "PDRAO":
					return FacesContext.getCurrentInstance().getExternalContext().getRequestContextPath()
							+ "/resources/css/padrao";
				case "ECO":
					return FacesContext.getCurrentInstance().getExternalContext().getRequestContextPath()
							+ "/resources/css/ecoar";
				case "HUM":
					return FacesContext.getCurrentInstance().getExternalContext().getRequestContextPath()
							+ "/resources/css/humberto";
				case "UF":
					return FacesContext.getCurrentInstance().getExternalContext().getRequestContextPath()
							+ "/resources/css/unimedFortaleza";
				default:
					return FacesContext.getCurrentInstance().getExternalContext().getRequestContextPath()
							+ "/resources/css";
				}
			} else {
				buscarInformacoesTotem();
				buscarSigla(Boolean.TRUE);
			}
		} catch (Exception e) {
			Logger logger = Logger.getLogger(TelaErroBean.class);
			logger.error("LOG DE EXCESSÃO recuperarCaminhoCSS IndexBean", e);
			return FacesContext.getCurrentInstance().getExternalContext().getRequestContextPath() + "/resources/css";
		}
		return FacesContext.getCurrentInstance().getExternalContext().getRequestContextPath() + "/resources/css";
	}

	public String recuperarCaminhoBotoes() {
		try {
			HttpSession sessao = getSession();
			boolean ecoar = (boolean) getSession().getAttribute("ecoar");
			if (ecoar) {
				return "/images/buttons/ecoar";
			} else {
				return "/images/buttons";
			}
		} catch (Exception e) {
			e.printStackTrace();
			return "/images/buttons";
		}
	}

	private Localidade adicionarIpALocalidade() throws Exception {
		HttpServletRequest request = getHttpServletRequest();
		
		request.getParameter("actionPage");
		request.getParameter("actionType");
		request.getParameter("language");
		final LocalidadeService loLocalidadeService = new LocalidadeService(getHttpServletRequest());
		String ipLocal = retornarIpValido();
		ipLocal = ipLocal + "0";
		final Localidade localidade = new Localidade();
		localidade.setIp(ipLocal);
		loLocalidadeService.setValueObject(localidade);
		return loLocalidadeService.getLocalidadeByIp();
	}

	private String retornarIpValido() throws Exception {
		if (getAmbienteProducao()) {
			return HttpUtil.retornaIpSemUltimoOcteto(Util.getClientIpAddr(getHttpServletRequest()));
		} else {
			// c�digo necess�rio para testes na ecoar
			return recuperarIpTeste();
		}
	}

	private String recuperarIpTeste() {
		if (informacoesTotem != null && !informacoesTotem.isEmpty()) {
			if (informacoesTotem.get(0).getIp().contains("eco1") || informacoesTotem.get(0).getIp().contains("eco2")
					|| informacoesTotem.get(0).getIp().contains("eco3")) {
				return HttpUtil.retornaIpSemUltimoOcteto(Constantes.IP_LOCALIDADE_DEFAULT_ECOAR);
			} else {
				return HttpUtil.retornaIpSemUltimoOcteto(Constantes.IP_LOCALIDADE_DEFAULT);
			}
		} else if (nomeComputador != null && (nomeComputador.contains("eco1") || nomeComputador.contains("eco2")
				|| nomeComputador.contains("eco3"))) {
			return HttpUtil.retornaIpSemUltimoOcteto(Constantes.IP_LOCALIDADE_DEFAULT_ECOAR);
		} else {
			return HttpUtil.retornaIpSemUltimoOcteto(Constantes.IP_LOCALIDADE_DEFAULT);
		}
	}

	public void cancelarSessao() {
		try {
			numeroCarteira = "";
			final String nomeTotem = retornarNomeDaMaquina();
			getSession().removeAttribute("indexBean");
			getSession().removeAttribute("tipoServico");
			TotemUtil.limparSession();
			FacesContext.getCurrentInstance().getExternalContext()
					.redirect("/passelivretotem/indexTotem.xhtml?nomeTotem=" + nomeTotem);
		} catch (final Exception exc) {
		}
	}

	public String getMensagemTermoUso() {
		return tipoServico.descricaoTermoUso();
	}

	private String retornarIp() throws Exception {
		final HttpServletRequest request = getHttpServletRequest();
		return Util.getClientIpAddr(request);
	}

	public String getDataAtual() {
		return dataAtual;
	}

	public void setDataAtual(final String dataAtual) {
		this.dataAtual = dataAtual;
	}

	public boolean isLoggedIn() {
		return loggedIn;
	}

	public void setLoggedIn(final boolean loggedIn) {
		this.loggedIn = loggedIn;
	}

	public UserAuth getUser() {
		return user;
	}

	public void setUser(final UserAuth parUser) {
		user = parUser;
	}

	public String getSessionId() {
		return sessionId;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public String getCaminhoCSS() {
		if (caminhoCSS == null || caminhoCSS.trim().contentEquals("")) {
			caminhoCSS = recuperarCaminhoCSS();
		}
		return caminhoCSS;
	}

	public void setCaminhoCSS(String caminhoCSS) {
		this.caminhoCSS = caminhoCSS;
	}

	public String getCaminhoBotoes() {
		if (caminhoBotoes == null || caminhoBotoes.trim().equals("")) {
			caminhoBotoes = recuperarCaminhoBotoes();
		}
		return caminhoBotoes;
	}

	public void setCaminhoBotoes(String caminhoBotoes) {
		this.caminhoBotoes = caminhoBotoes;
	}

	public List<InformacaoTotem> getInformacoesTotem() {
		return informacoesTotem;
	}

	public String getIpLocal() throws Exception {
		return retornarIp();
	}

	public String getMensagemAviso() {
		return mensagemAviso;
	}

	public void setMensagemAviso(String mensagemAviso) {
		this.mensagemAviso = mensagemAviso;
	}

	public String getNomeTotem() {
		return nomeTotem;
	}
	
	private String iniciarInformacoesTokenSessao(Boolean forcarBuscaInformacoes, String origem) throws IOException  {
		String erro = null;
		try {
			final InformacaoTotemService informacaoTotemService = new InformacaoTotemService(getHttpServletRequest());
	
			if(!forcarBuscaInformacoes) {
				tokenResult = new TokenResult();
				final ParametroConsultaConfiguracao parametroConsultaConfiguracao = new ParametroConsultaConfiguracao(
						retornarNomeDaMaquina(), tokenResult);
				
				informacaoTotemService.consultar(parametroConsultaConfiguracao);
				final ConsultaConfiguracaoResult consultaConfiguracaoResult = (ConsultaConfiguracaoResult) informacaoTotemService
						.getResponseObject();
				
				forcarBuscaInformacoes = Objects.isNull(consultaConfiguracaoResult);
				execForcarBuscaInformacoes = forcarBuscaInformacoes && origem.equals(OrigemIniciarInformacoesTokenSessaoEnum.ONLOAD.getDescricao());
			}
			
			if(execForcarBuscaInformacoes && !origem.equals(OrigemIniciarInformacoesTokenSessaoEnum.ONLOAD.getDescricao())) {
				execForcarBuscaInformacoes = false;
				tokenResult = retornarToken();
				getSession().setAttribute("tokenResult", tokenResult);
				if (nomeComputador == null || ("null").equals(nomeComputador)) {
					throw new RegraNegocioException("Nome do totem inválido: " + nomeComputador);
				} else if (nomeComputador.equals("nometotemindisponivel")) {
					nomeComputador = TotemUtil.retornarNomeDaMaquina();
				}
				
				String nomeDaMaquina = retornarNomeDaMaquina();

				final ParametroConsultaConfiguracao parametroConsultaConfiguracao = new ParametroConsultaConfiguracao(
						nomeDaMaquina, tokenResult);

				if(!nomeDaMaquina.equals("nometotemindisponivel")) {
					informacaoTotemService.consultarInformacoesTokenSessao(parametroConsultaConfiguracao);
					if (informacaoTotemService.isSuccess()) {
						totemManagerConsultaConfiguracao();				
					} else {
						erro = createErrorTotemManagerConsultaConfiguracao(informacaoTotemService, parametroConsultaConfiguracao);
					}
				} else {
					erro = createErrorTotemManagerConsultaConfiguracao(informacaoTotemService, parametroConsultaConfiguracao);
				}
			}
		} catch(Exception e) {
			erro = "3 - Erro ao buscar informações do totem:" + e.getMessage();
			errorTotemManagerConsultaConfiguracao(e.getMessage());
		}
		if(!Objects.isNull(erro)) {
			FacesContext.getCurrentInstance().getExternalContext().redirect(createAndGetPageErrorRedirect(erro));
		}
		
		return erro;
	}

	private String createAndGetPageErrorRedirect(final String exceptionMessage) {
		MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso(exceptionMessage);
		try {
			getSession().setAttribute("mensagemAviso", mensagemAviso);
		} catch (Exception e) {
			Logger logger = Logger.getLogger(IndexBean.class);
			logger.error("LOG DE EXCESSÃO AO SETAR mensagemAviso", e);
		}
		
		String pageErrorRedirect = "/pages/erro/sistemaIndisponivelSemRodape.xhtml?faces-redirect=true&sessionId="
				+ sessionId + "&nomeTotem=" + TotemUtil.retornarNomeDaMaquina();
		
		HttpServletRequest req = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		String url = req.getRequestURL().toString();
		url = url.substring(0, url.length() - req.getRequestURI().length()) + req.getContextPath();
		pageErrorRedirect = url + pageErrorRedirect;
		
		return  pageErrorRedirect;
	}
	
	private void totemManagerConsultaConfiguracao() throws Exception {
		registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
				Thread.currentThread().getStackTrace()[1].getMethodName(),
				"Informações do totemManagerConsultaConfiguracao recuperadas: " + TotemUtil.retornarNomeDaMaquina(), sessionId,
				createBasicLogMap());
	}	
	
	private void errorTotemManagerConsultaConfiguracao(final String message) {
		try {
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), message, sessionId,
					createBasicLogMap());
		} catch (final Exception exc) {
			Logger logger = Logger.getLogger(IndexBean.class);
			logger.error("LOG DE EXCESSÃO totemManagerConsultaConfiguracao exc IndexBean", exc);

		}
	}
	
	private String createErrorTotemManagerConsultaConfiguracao(final InformacaoTotemService informacaoTotemService,
			final ParametroConsultaConfiguracao parametroConsultaConfiguracao) {
		String erro;
		String message = Objects.isNull(informacaoTotemService.getResponseMessage()) ? "" : informacaoTotemService.getResponseMessage();
		erro = "4 - Erro ao buscar informações do totem:" + message
				+ " parametros:" + parametroConsultaConfiguracao.getIp();
		errorTotemManagerConsultaConfiguracao(erro);
		return erro;
	}
}
