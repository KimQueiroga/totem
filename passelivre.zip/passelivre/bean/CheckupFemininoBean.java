package br.com.hermespardini.passelivre.bean;

import java.text.ParseException;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.servlet.http.HttpSession;

import org.primefaces.context.RequestContext;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.model.ClienteUnidadePasseLivre;
import br.com.hermespardini.passelivre.model.DetalhePreparacao;
import br.com.hermespardini.passelivre.model.InformacaoTotem;
import br.com.hermespardini.passelivre.model.MensagemAviso;
import br.com.hermespardini.passelivre.model.ParametroPreparacao;
import br.com.hermespardini.passelivre.model.Preparacao;
import br.com.hermespardini.passelivre.service.DetalhePreparacaoService;
import br.com.hermespardini.passelivre.utils.DataUtil;
import br.com.hermespardini.passelivre.utils.MensagemUtil;
import br.com.hermespardini.passelivre.utils.TotemUtil;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.bean.MainBean;

@ManagedBean
@ViewScoped
public class CheckupFemininoBean extends MainBean {

	private String sessionId;
	private String mensagemAviso;
	private List<Preparacao> preparacoes;
	private DetalhePreparacao detalhePreparacao;
	private List<InformacaoTotem> informacoesTotem;
	private ClienteUnidadePasseLivre clienteUnidadePasseLivre;

	@PostConstruct
	public void onLoad() {
		mensagemAviso = "";
		preparacoes = new ArrayList<>();
		detalhePreparacao = new DetalhePreparacao();
		clienteUnidadePasseLivre = new ClienteUnidadePasseLivre();
		buscarInformacoesTotem();
		buscarDetalhePreparacoes();
		burscarSessionId();
	}

	private void burscarSessionId() {
		try {
			sessionId = getHttpServletRequest().getSession().getAttribute("sessionId").toString();
		} catch (final Exception locExc) {
		}
	}

	@SuppressWarnings("unchecked")
	private void buscarInformacoesTotem() {
		try {
			informacoesTotem = new ArrayList<>();
			final HttpSession session = getHttpServletRequest().getSession();
			informacoesTotem = (List<InformacaoTotem>) session.getAttribute("informacoesTotem");
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	public String cancelar() {
		try {
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, sessionId, createBasicLogMap());
			return redirectIndex();
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			return "";
		}
	}

	public String redirectIndex() throws Exception {
		final String nomeMaquina = TotemUtil.retornarNomeDaMaquina();
		getSession().removeAttribute("indexBean");
		TotemUtil.limparSession();
		return "/indexTotem.xhtml?faces-redirect=true&nomeTotem=" + nomeMaquina;
	}

	public String avancar() {
		try {
			adicionarAtributoEmSessaoAposAvancar();
			return "/pages/ckf/loginckf.xhtml?faces-redirect=true";
		} catch (final Exception locExc) {
			gerarLogErroAoAvancar(locExc.getMessage());
			MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso(locExc.getMessage());
			try {
				getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return redirectAtendimentoNaoConcluido();
		}
	}

	private String redirectAtendimentoNaoConcluido() {
		return "/pages/erro/atendimentoNaoConcluido.xhtml?faces-redirect=true&sessionId=";
	}

	private void gerarLogErroAoAvancar(final String parMessage) {
		try {
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, sessionId,
					createBasicLogMap());
		} catch (final Exception exc) {
		}
	}

	private void adicionarAtributoEmSessaoAposAvancar() throws Exception {
		getHttpServletRequest().getSession().setAttribute("detalhePreparacao", detalhePreparacao);
		getHttpServletRequest().getSession().setAttribute("informacoesTotem", informacoesTotem);
	}

	public String formatarDataNascimento(final String data) {
		try {
			if (data != null || !data.isEmpty() || naoContemNumero(data)) {
				return new DataUtil().formatarStringParaStringBR(data);
			}
			return "";
		} catch (final ParseException exc) {
			return "";
		}
	}

	public void buscarDetalhePreparacoes() {
		try {
			final DetalhePreparacaoService detalhePreparacaoService = new DetalhePreparacaoService(
					getHttpServletRequest());
			detalhePreparacaoService.consultar(ParametroPreparacao.criarBuscaCheckupFeminino());
			if (detalhePreparacaoService.isSuccess()) {
				detalhePreparacao = (DetalhePreparacao) detalhePreparacaoService.getResponseObject();

				////////////////////////////////////////////////////
				/////// trocar
				////////////////////////////////////////////////////

				detalhePreparacao.setPrivatePrice("65,00");

				////////////////////////////////////////////////////
			} else {
				gerarLogErroAoBuscarPreparacoes(detalhePreparacaoService.getResponseMessage());
			}
		} catch (final RegraNegocioException locExc) {
			locExc.printStackTrace();
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
			gerarLogAoBuscarPreparacoes(locExc.getMessage());
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
			gerarLogErroAoBuscarPreparacoes(locExc.getMessage());
		}
	}

	private void exibirDialogMensagem() {
		RequestContext.getCurrentInstance().execute("PF('dlgMessage').show()");
	}

	private void gerarLogAoBuscarPreparacoes(final String parMessage) {
		try {
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, sessionId,
					createBasicLogMap());
		} catch (final Exception locExc) {
		}
	}

	private void gerarLogErroAoBuscarPreparacoes(final String parMessage) {
		try {
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, sessionId,
					createBasicLogMap());
		} catch (final Exception locExc) {
		}
	}

	public Map createBasicLogMap() {
		Long idTotem = null;
		Long idUnidade = null;
		if (informacoesTotem != null && !informacoesTotem.isEmpty()) {
			idTotem = informacoesTotem.get(0).getId();
			idUnidade = Long.valueOf(informacoesTotem.get(0).getIdUnidade());
		}
		try {
			return TotemUtil.createBasicLogMap(idTotem, idUnidade, Util.getClientIpAddr(getHttpServletRequest()));
		} catch (Exception e) {
			e.printStackTrace();
			return new HashMap();
		}
	}

	private int calcularDigito(String str, int[] peso) {
		int soma = 0;
		for (int indice = str.length() - 1, digito; indice >= 0; indice--) {
			digito = Integer.parseInt(str.substring(indice, indice + 1));
			soma += digito * peso[peso.length - str.length() + indice];
		}
		soma = 11 - soma % 11;
		return soma > 9 ? 0 : soma;
	}

	public void isValidCPF() {
		String cpf = clienteUnidadePasseLivre.getCpf();
		cpf = cpf.replace(".", "").replace("-", "");
		if ((cpf == null) || (cpf.length() != 11)) {
			mensagemAviso = "CPF Inválido";
			exibirDialogMensagem();
			return;
		}

		Integer digito1 = calcularDigito(cpf.substring(0, 9), Constantes.PESOCPF);
		Integer digito2 = calcularDigito(cpf.substring(0, 9) + digito1, Constantes.PESOCPF);

		if (!cpf.equals(cpf.substring(0, 9) + digito1.toString() + digito2.toString())) {
			clienteUnidadePasseLivre.setCpf(null);
			mensagemAviso = "CPF Inválido";
			exibirDialogMensagem();
		}
	}

	public String mensagemCabecalho(String linha) {
		try {

			return MensagemUtil.retornarMensagemCabelho(clienteUnidadePasseLivre, "", linha);
		} catch (final Exception locExc) {
			return "";
		}
	}

	private boolean naoContemNumero(final String parData) {
		return !org.apache.commons.lang.StringUtils.isNumeric(parData);
	}

	public DetalhePreparacao getDetalhePreparacao() {
		return detalhePreparacao;
	}

	public void setDetalhePreparacao(final DetalhePreparacao parDetalhePreparacao) {
		detalhePreparacao = parDetalhePreparacao;
	}

	public String getMensagemAviso() {
		return mensagemAviso;
	}

	public void setMensagemAviso(final String parMensagemAviso) {
		mensagemAviso = parMensagemAviso;
	}

	public ClienteUnidadePasseLivre getClienteUnidadePasseLivre() {
		return clienteUnidadePasseLivre;
	}

	public void setClienteUnidadePasseLivre(final ClienteUnidadePasseLivre parClienteUnidadePasseLivre) {
		clienteUnidadePasseLivre = parClienteUnidadePasseLivre;
	}

}
