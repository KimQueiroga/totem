package br.com.hermespardini.passelivre.bean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;


import br.com.hermespardini.passelivre.dao.ExameCalculadoDAO;
import br.com.hermespardini.passelivre.model.ExameHermesPardini;
import br.com.hermespardini.passelivre.model.ExameSimplificado;
import br.com.hermespardini.passelivre.to.ProcedimentoComExamesTO;

public class ExameCalculadoBean {
	
	private Map<String, List<String>> combinacao;
	
	public ExameCalculadoBean(Map<String, List<String>> combinacao) {
		this.combinacao = combinacao;	
	}
	
	public Boolean existeCombinacaoPossivel(List<ProcedimentoComExamesTO> guiaComExames) {
		List<ExameHermesPardini> hermesPardinis = guiaComExames.stream().map(exameGuia -> exameGuia.getExame()).collect(Collectors.toList());
		
		for (Entry<String, List<String>> mnemonicoPaiCalc : combinacao.entrySet()) {
			if (contemTodosFilhos(hermesPardinis, mnemonicoPaiCalc.getValue())) {
				return true;
			}
		}
		
		return false;
	}
	
	private Boolean contemTodosFilhos(List<ExameHermesPardini> examesHPGuia, List<String> mnemonicosFilhos) {
		return mnemonicosFilhos.stream().allMatch(mneFilho -> examesHPGuia.stream().anyMatch(exameGuia -> exameGuia.getMnemonicoConcat().equals(mneFilho)));
	}
	
	private Boolean validaExameComCombinacao(ExameHermesPardini exameHermesPardini, List<String> mnemonicosFilhos) {
		String mnemonico = exameHermesPardini.getMnemonicoConcat();
		return mnemonicosFilhos.stream().anyMatch(mneFilho -> mneFilho.equals(mnemonico));
	}
	
	public Map<ExameSimplificado, List<ExameSimplificado>> retornaPossiveisCombinacoes(List<ProcedimentoComExamesTO> guiaComExames) {
		
		Map<ExameSimplificado, List<ExameSimplificado>> combinacoesPossiveis = new HashMap<ExameSimplificado, List<ExameSimplificado>>();
		List<ExameHermesPardini> hermesPardinis = guiaComExames.stream().map(exameGuia -> exameGuia.getExame()).collect(Collectors.toList());
		
		for (Entry<String, List<String>> mnemonicoPaiCalc : combinacao.entrySet()) {
			List<ExameSimplificado> filhos = new ArrayList<ExameSimplificado>();
			for (ProcedimentoComExamesTO procedimento: guiaComExames) {
				
				if (!contemTodosFilhos(hermesPardinis, mnemonicoPaiCalc.getValue())) {
					break;
				}
				else if (validaExameComCombinacao(procedimento.getExame(), mnemonicoPaiCalc.getValue()) 
						&& !filhos.stream().anyMatch(filho -> filho.getExame().getMnemonicoConcat().equals(procedimento.getExame().getMnemonicoConcat()))
						) {
					
					if (filhos.size() < mnemonicoPaiCalc.getValue().size()) {
						procedimento.setRemoveCalculado(true);
						filhos.add(retornaExameSimplificadoByProcedimento(procedimento));
					}
					if (filhos.size() == mnemonicoPaiCalc.getValue().size()) {
						combinacoesPossiveis.put(ExameCalculadoDAO.retornaExameSimplificadoByMnemonico(mnemonicoPaiCalc.getKey(), procedimento.getGuia()), filhos);
					}
				}
			}
		}
		
		return combinacoesPossiveis;
	}
	
	

	private boolean validaSeExameFilhoValido() {
		// TODO Auto-generated method stub
		return false;
	}

	private ExameSimplificado retornaExameSimplificadoByProcedimento(ProcedimentoComExamesTO procedimento) {
		// TODO Auto-generated method stub
		return new ExameSimplificado(procedimento);
	}

	private ExameHermesPardini preencheExamePai() {
		return null;
	}
	
	public List<ProcedimentoComExamesTO> retornaNovaGuia() {
		return null;
	}
	
	public void removeCalcDaLista(final String mnemonicoPai) {
		this.combinacao.remove(mnemonicoPai);
	}

	public List<ProcedimentoComExamesTO> retornaProcedimentosGuiaDesmembra(
			List<ProcedimentoComExamesTO> procedimentosGuia, List<ExameSimplificado> examesFilhos,
			ExameSimplificado examePaiASerRemovido) {
		List<ProcedimentoComExamesTO> novaLista = new ArrayList<ProcedimentoComExamesTO>();
		for (ProcedimentoComExamesTO examesTO: procedimentosGuia) {
			if (examesTO.getExame().getMnemonicoConcat().equals(examePaiASerRemovido.getExame().getMnemonicoConcat())) {
				for (ExameSimplificado simplificado: examesFilhos) {
					novaLista.add(new ProcedimentoComExamesTO(simplificado, Integer.valueOf(procedimentosGuia.size()+1)));
				}
			}
			else {
				novaLista.add(examesTO);
			}
		}
		return novaLista;
	}

	public List<ProcedimentoComExamesTO> retornaProcedimentosGuiaSubst(
			List<ProcedimentoComExamesTO> procedimentosGuia, List<ExameSimplificado> examesASeremRemovidos,
			ExameSimplificado examePai) {
		List<ProcedimentoComExamesTO> novaLista = new ArrayList<ProcedimentoComExamesTO>();
		
		for (ProcedimentoComExamesTO examesTO: procedimentosGuia) {
			for(ExameSimplificado exameASerRemovido: examesASeremRemovidos) {
				if (examesTO.getExame().getMnemonicoConcat().equals(exameASerRemovido.getExame().getMnemonicoConcat())
						&& examesTO.getId().equals(exameASerRemovido.getIdExameGuia())
						&& !novaLista.stream().anyMatch(prodNovo -> prodNovo.getExame().getMnemonicoConcat().equals(examePai.getExame().getMnemonicoConcat()))
						) {
					examePai.setObservacao("Adicionado por opção do cliente ou atendente.");
					novaLista.add(new ProcedimentoComExamesTO(examePai, Integer.valueOf(procedimentosGuia.size()+1)));
				}
				else if (!examesASeremRemovidos.stream().anyMatch(exameRemover -> exameRemover.getIdExameGuia().equals(examesTO.getId()))
						&& !novaLista.stream().anyMatch(novoProd -> novoProd.getId().equals(examesTO.getId()))) {
					novaLista.add(examesTO);
				}
			}
		}
		return novaLista;
	}

}
