package br.com.hermespardini.passelivre.bean;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.primefaces.context.RequestContext;

import br.com.hermespardini.corebusiness.model.LogAplicacaoUsuarioFactory;
import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.constantsenum.TipoServicoEnum;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.model.AgendamentoUnidade;
import br.com.hermespardini.passelivre.model.ClienteUnidadePasseLivre;
import br.com.hermespardini.passelivre.model.InformacaoTotem;
import br.com.hermespardini.passelivre.model.ParametroAgendamentoCliente;
import br.com.hermespardini.passelivre.model.TokenResult;
import br.com.hermespardini.passelivre.service.AgendamentoService;
import br.com.hermespardini.passelivre.utils.MensagemUtil;
import br.com.hermespardini.passelivre.utils.TotemUtil;
import br.com.hermespardini.web.bean.MainBean;

@SuppressWarnings("serial")
@ManagedBean
@ViewScoped
//teste
public class AgendamentoBean extends MainBean {

	private ClienteUnidadePasseLivre clienteUnidadePasseLivre;
	private TipoServicoEnum tipoServico;
	private TokenResult tokenResult;
	private String sessionId;
	private String mensagemAviso;
	private List<InformacaoTotem> informacoesTotem;

	private ParametroAgendamentoCliente parametroAgendamento;
	private AgendamentoUnidade agendamentoUnidade;
	private List<AgendamentoUnidade> agendamentosUnidade;

	@PostConstruct
	public void onLoad() {
		tipoServico = TotemUtil.recuperarTipoServico();
		tokenResult = TotemUtil.buscarToken();
		clienteUnidadePasseLivre = TotemUtil.recuperarClientePasseLivre();
		sessionId = TotemUtil.buscarSessionId();
		informacoesTotem = TotemUtil.buscarInformacoesTotem();
		verificarAgendamento();
	}

	private String verificarAgendamento() {
		try {
			final AgendamentoService agendamentoService = new AgendamentoService(getHttpServletRequest());
			parametroAgendamento = new ParametroAgendamentoCliente(tokenResult, clienteUnidadePasseLivre);
			parametroAgendamento.setOrigem(Constantes.ORIGEM_PADRAO);
			agendamentoService.consultaAgendamento(parametroAgendamento);

			if (agendamentoService.isSuccess()) {
				if (agendamentoService.getResponseObject() != null) {
					agendamentosUnidade = (List<AgendamentoUnidade>) agendamentoService.getResponseObject();
					return "";
				} else {
					FacesContext.getCurrentInstance().getExternalContext().redirect("verificarPreAtendimentos.xhtml");
				}
			} else {
				mensagemAviso = agendamentoService.getResponseMessage();
				exibirDialogMensagem();
			}
		} catch (final RegraNegocioException locExc) {
			locExc.printStackTrace();
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
		} catch (final Exception locExcexc) {
			locExcexc.printStackTrace();
			mensagemAviso = locExcexc.getMessage();
			exibirDialogMensagem();
			gerarLogErroAoBuscarDadosCliente(locExcexc.getMessage());
		}
		return "";
	}

	public String irParaPreAtendimento() {
		try {
			if (agendamentoUnidade != null) {
				getHttpServletRequest().getSession().setAttribute("agendamentoUnidade", agendamentoUnidade);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "/pages/pat/verificarPreAtendimentos.xhml?faces-redirect=true";
	}

	private void exibirDialogMensagem() {
		RequestContext.getCurrentInstance().execute("PF('dlgMessage').show()");
	}

	public void unselectAll() {
		agendamentoUnidade = null;
		RequestContext.getCurrentInstance().update("dttGuiasAutorizadas");
	}

	public boolean isAgendamentoSelecionado() {
		RequestContext.getCurrentInstance().update("dlgConfirmacaoAvancar");
		return agendamentoUnidade != null && agendamentoUnidade.getDataAgendada() != null;
	}

	public boolean isAgendamentoOutraUnidadeUnidade(final AgendamentoUnidade agendamento) {
		return !retornarUnidade().equals(agendamento.getUnidade());
	}

	private String retornarUnidade() {
		if (informacoesTotem == null || informacoesTotem.isEmpty()) {
			return null;
		} else {
			return informacoesTotem.get(0).getIdUnidade();
		}
	}

	public void cancelar() {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN,
					clienteUnidadePasseLivre.getCodigoCliente());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, TotemUtil.buscarSessionId(),
					TotemUtil.createBasicLogMap());
			cancelarSessao();
		} catch (final Exception locExc) {
		}
	}

	public void cancelarSessao() {
		try {
			final String nomeTotem = TotemUtil.retornarNomeDaMaquina();
			getSession().removeAttribute("indexBean");
			getSession().removeAttribute("tipoServico");
			TotemUtil.limparSession();
			FacesContext.getCurrentInstance().getExternalContext()
					.redirect("/passelivretotem/indexTotem.xhtml?nomeTotem=" + nomeTotem);
		} catch (final Exception exc) {
		}
	}

	public String getMensagemCabecalho() {
		try {
			return MensagemUtil.retornarMensagemCabelho(clienteUnidadePasseLivre, "");
		} catch (final Exception locExc) {
			return "";
		}
	}

	public String mensagemCabecalho(String linha) {
		try {

			return MensagemUtil.retornarMensagemCabelho(clienteUnidadePasseLivre, "", linha);
		} catch (final Exception locExc) {
			return "";
		}
	}

	private void gerarLogErroAoBuscarDadosCliente(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN,
					clienteUnidadePasseLivre.getCodigoCliente());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, TotemUtil.buscarSessionId(),
					TotemUtil.createBasicLogMap());
		} catch (final Exception exc) {
		}
	}

	public ClienteUnidadePasseLivre getClienteUnidadePasseLivre() {
		return clienteUnidadePasseLivre;
	}

	public void setClienteUnidadePasseLivre(final ClienteUnidadePasseLivre parClienteUnidadePasseLivre) {
		clienteUnidadePasseLivre = parClienteUnidadePasseLivre;
	}

	public TipoServicoEnum getTipoServico() {
		return tipoServico;
	}

	public void setTipoServico(final TipoServicoEnum parTipoServico) {
		tipoServico = parTipoServico;
	}

	public TokenResult getTokenResult() {
		return tokenResult;
	}

	public void setTokenResult(final TokenResult parTokenResult) {
		tokenResult = parTokenResult;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(final String parSessionId) {
		sessionId = parSessionId;
	}

	public String getMensagemAviso() {
		return mensagemAviso;
	}

	public void setMensagemAviso(String mensagemAviso) {
		this.mensagemAviso = mensagemAviso;
	}

	public ParametroAgendamentoCliente getParametroAgendamento() {
		return parametroAgendamento;
	}

	public void setParametroAgendamento(ParametroAgendamentoCliente parametroAgendamento) {
		this.parametroAgendamento = parametroAgendamento;
	}

	public AgendamentoUnidade getAgendamentoUnidade() {
		return agendamentoUnidade;
	}

	public void setAgendamentoUnidade(AgendamentoUnidade agendamentoUnidade) {
		this.agendamentoUnidade = agendamentoUnidade;
	}

	public List<AgendamentoUnidade> getAgendamentosUnidade() {
		return agendamentosUnidade;
	}

	public void setAgendamentosUnidade(List<AgendamentoUnidade> agendamentosUnidade) {
		this.agendamentosUnidade = agendamentosUnidade;
	}

}
