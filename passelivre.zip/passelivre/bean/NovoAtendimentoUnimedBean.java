
package br.com.hermespardini.passelivre.bean;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.SocketTimeoutException;
import java.rmi.RemoteException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.component.EditableValueHolder;
import javax.faces.component.UIComponent;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;
import javax.faces.context.PartialViewContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.primefaces.component.panel.Panel;
import org.primefaces.component.panelgrid.PanelGrid;
import org.primefaces.context.RequestContext;
import org.primefaces.extensions.component.masterdetail.MasterDetail;
import org.primefaces.extensions.component.masterdetail.MasterDetailLevel;
import org.primefaces.model.StreamedContent;
import org.slf4j.LoggerFactory;
import org.wdelmaschio.base.util.Date;

import com.google.gson.Gson;

import br.com.hermespardini.commons.http.HttpUtil;
import br.com.hermespardini.corebusiness.model.Cep;
import br.com.hermespardini.corebusiness.model.LogAplicacaoUsuarioFactory;
import br.com.hermespardini.corebusiness.util.SessionIdBuilder;
import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.constantsenum.FuncaoLogEstatistico;
import br.com.hermespardini.passelivre.constantsenum.SituacaoPedidoClienteEnum;
import br.com.hermespardini.passelivre.dao.ExameCalculadoDAO;
import br.com.hermespardini.passelivre.dao.ExamesCalculadosDAO;
import br.com.hermespardini.passelivre.exception.BiometriaDesativadaException;
import br.com.hermespardini.passelivre.exception.DownloadUnimedException;
import br.com.hermespardini.passelivre.exception.EnvioEmailException;
import br.com.hermespardini.passelivre.exception.ExameCalculadoException;
import br.com.hermespardini.passelivre.exception.GuiasAutorizadasException;
import br.com.hermespardini.passelivre.exception.ImpressaoException;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.exception.SelecaoCampoException;
import br.com.hermespardini.passelivre.factory.AplicaExcecaoExameFactory;
import br.com.hermespardini.passelivre.factory.AplicaExcecaoGuiasFactory;
import br.com.hermespardini.passelivre.factory.AplicaExcecaoProcedimentoFactory;
import br.com.hermespardini.passelivre.factory.AplicaExcecaoQuestionarioFactory;
import br.com.hermespardini.passelivre.factory.ComponenteFactory;
import br.com.hermespardini.passelivre.format.FormataCep;
import br.com.hermespardini.passelivre.format.FormataCpf;
import br.com.hermespardini.passelivre.format.FormataDataAnoMesDia;
import br.com.hermespardini.passelivre.format.FormataEndereco;
import br.com.hermespardini.passelivre.format.FormataTelefone;
import br.com.hermespardini.passelivre.interfaces.FormataCampo;
import br.com.hermespardini.passelivre.model.Agenda;
import br.com.hermespardini.passelivre.model.AgendamentoUnidade;
import br.com.hermespardini.passelivre.model.ClienteUnidadePasseLivre;
import br.com.hermespardini.passelivre.model.ConfiguracaoImpressoraResult;
import br.com.hermespardini.passelivre.model.ConfirmaBiometriaResult;
import br.com.hermespardini.passelivre.model.ConsultaCepResult;
import br.com.hermespardini.passelivre.model.ConsultaCodigoResult;
import br.com.hermespardini.passelivre.model.ConsultaPreparoResult;
import br.com.hermespardini.passelivre.model.ConsultaQuestionarioExameResult;
import br.com.hermespardini.passelivre.model.ControleEstatistico;
import br.com.hermespardini.passelivre.model.CriarPedidoResult;
import br.com.hermespardini.passelivre.model.ExameHermesPardini;
import br.com.hermespardini.passelivre.model.ExamePedido;
import br.com.hermespardini.passelivre.model.ExameSimplificado;
import br.com.hermespardini.passelivre.model.ExameSimplificado.TypeCalculo;
import br.com.hermespardini.passelivre.model.ExamesResultadosPedido;
import br.com.hermespardini.passelivre.model.ExcecaoAtendimentoResult;
import br.com.hermespardini.passelivre.model.Guia;
import br.com.hermespardini.passelivre.model.GuiaAutorizadaExcecao;
import br.com.hermespardini.passelivre.model.Guias;
import br.com.hermespardini.passelivre.model.InformacaoConvenio;
import br.com.hermespardini.passelivre.model.InformacaoTotem;
import br.com.hermespardini.passelivre.model.Localidade;
import br.com.hermespardini.passelivre.model.MensagemAviso;
import br.com.hermespardini.passelivre.model.ParametroAgendamentoCliente;
import br.com.hermespardini.passelivre.model.ParametroConfirmaBiometria;
import br.com.hermespardini.passelivre.model.ParametroConsultaCliente;
import br.com.hermespardini.passelivre.model.ParametroConsultaMatricula;
import br.com.hermespardini.passelivre.model.ParametroConsultaSolicitante;
import br.com.hermespardini.passelivre.model.ParametroDataPrevisaoResultado;
import br.com.hermespardini.passelivre.model.ParametroExcecaoAtendimento;
import br.com.hermespardini.passelivre.model.ParametroImpressaoQuestionario;
import br.com.hermespardini.passelivre.model.ParametroInformacaoImpressora;
import br.com.hermespardini.passelivre.model.ParametroNaoSouEu;
import br.com.hermespardini.passelivre.model.ParametroPedido;
import br.com.hermespardini.passelivre.model.ParametroPreparoExame;
import br.com.hermespardini.passelivre.model.ParametroQuestionario;
import br.com.hermespardini.passelivre.model.ParametroRegistraCliente;
import br.com.hermespardini.passelivre.model.PerguntaEntrega;
import br.com.hermespardini.passelivre.model.Presenca;
import br.com.hermespardini.passelivre.model.PresencaHistorico;
import br.com.hermespardini.passelivre.model.Procedimento;
import br.com.hermespardini.passelivre.model.Questionario;
import br.com.hermespardini.passelivre.model.TokenResult;
import br.com.hermespardini.passelivre.model.UserAuth;
import br.com.hermespardini.passelivre.service.AgendamentoService;
import br.com.hermespardini.passelivre.service.AtendimentoService;
import br.com.hermespardini.passelivre.service.BaixarGuiaUnimedService;
import br.com.hermespardini.passelivre.service.CepService;
import br.com.hermespardini.passelivre.service.ClienteService;
import br.com.hermespardini.passelivre.service.ComposicaoService;
import br.com.hermespardini.passelivre.service.ConfiguracaoImpressoraService;
import br.com.hermespardini.passelivre.service.ConfirmaBiometriaService;
import br.com.hermespardini.passelivre.service.ConsultaExamesAutorizadosService;
import br.com.hermespardini.passelivre.service.ConsultaGuiasAutorizadasService;
import br.com.hermespardini.passelivre.service.ConsultaSituacaoCoberturaService;
import br.com.hermespardini.passelivre.service.ControleEstatisticoService;
import br.com.hermespardini.passelivre.service.EnviaEmailService;
import br.com.hermespardini.passelivre.service.ExcecaoAtendimentoService;
import br.com.hermespardini.passelivre.service.IndexService;
import br.com.hermespardini.passelivre.service.LocalidadeService;
import br.com.hermespardini.passelivre.service.NovoAtendimentoService;
import br.com.hermespardini.passelivre.service.PedidoService;
import br.com.hermespardini.passelivre.service.PerguntasService;
import br.com.hermespardini.passelivre.service.PreparacaoExameService;
import br.com.hermespardini.passelivre.service.PresencaHistoricoService;
import br.com.hermespardini.passelivre.service.PresencaService;
import br.com.hermespardini.passelivre.service.QuestionarioService;
import br.com.hermespardini.passelivre.service.SenhaService;
import br.com.hermespardini.passelivre.service.SolicitanteService;
import br.com.hermespardini.passelivre.to.HabilitacaoCamposCadastroTO;
import br.com.hermespardini.passelivre.to.PerguntaComExameTO;
import br.com.hermespardini.passelivre.to.ProcedimentoComExamesTO;
import br.com.hermespardini.passelivre.to.ProcedimentoComExamesTOExcecao;
import br.com.hermespardini.passelivre.utils.ArquivoUtil;
import br.com.hermespardini.passelivre.utils.ControleBotaoUtil;
import br.com.hermespardini.passelivre.utils.DataUtil;
import br.com.hermespardini.passelivre.utils.ImpressoraUtil;
import br.com.hermespardini.passelivre.utils.MensagemUtil;
import br.com.hermespardini.passelivre.utils.TotemUtil;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.bean.MainBean;
import br.com.unimedbh.esb.prontuario.schemas.ComposicaoDTO;
import br.com.unimedbh.www.Ct_dadosAutorizacao;
import br.com.unimedbh.www.DestinatarioInvalido;
import br.com.unimedbh.www.HashInvalido;
import br.com.unimedbh.www.RemetenteInvalido;
import br.com.unimedbh.www.VersaoInvalida;
import br.com.unimedbh.www.Ws_consultaSolicitacoes;
import br.com.unimedbh.www.Ws_situacaoAutorizacao;
import br.com.unimedbh.www.schemas.Ct_respostaComunicacao;
import br.com.unimedbh.www.ws.tipos.Ws_consultaSituacaoCobertura;
import br.com.unimedbh.www.ws.tipos.Ws_respostaCobertura;
import br.com.unimedbh.www.ws.tipos.Ws_respostaComunicacao;
import br.gov.ans.www.padroes.tiss.schemas.Ct_beneficiario;
import br.gov.ans.www.padroes.tiss.schemas.Ct_itemSolicitacao;

@ManagedBean
@SessionScoped
public class NovoAtendimentoUnimedBean extends MainBean {

	private static Logger log = Logger.getLogger(NovoAtendimentoUnimedBean.class);

	private UserAuth user;
	private String sessionId;
	private DataUtil dataUtil;
	private Presenca presenca;
	private Integer activeIndex;
	private String mensagemAviso;
	private String numeroCarteira;
	private Integer numeroPedido;
	private Constantes constantes;
	private Panel pnlQuestionario;
	private Localidade localidade;
	private Boolean houveAlteracao;
	private TokenResult tokenResult;
	private Boolean exibeListaExame;
	private Integer quantidadeExameVT;
	private FormataCampo formataCampo;
	private String providencia;
	private String resultadoBiometria;
	private Questionario questionario;
	private Boolean exibeSimplesExame;
	private PanelGrid pngQuestionario;
	private StreamedContent relatorioGA;
	private MasterDetail mtdQuestionario;
	private PerguntasService perguntasUtil;
	private List<PerguntaEntrega> perguntas;
	private FormataEndereco formataEndereco;
	private List<ExameHermesPardini> exames;
	private Ws_situacaoAutorizacao situacao;
	private ParametroPedido parametroPedido;
	private InformacaoTotem informacaoTotem;
	private static final int TIPO_PACOTE = 1;
	private List<Procedimento> procedimentos;
	private MasterDetailLevel mdlQuestionario;
	private ControleBotaoUtil controleBotaoUtil;
	private Map<String, String> mapQuestionarios;
	private List<ExameHermesPardini> examesExcecao;
	private List<InformacaoTotem> informacoesTotem;
	private static final long serialVersionUID = 1L;
	private List<MasterDetailLevel> mdlsQuestionario;
	private static final String CODIGO_IMAGEM = "03";
	private Ws_respostaCobertura ws_respostaCobertura;
	private List<Ct_dadosAutorizacao> guiasAutorizadas;
	private ParametroQuestionario parametroQuestionario;
	private ConsultaPreparoResult consultaPreparoResult;
	private static final String CODIGO_PATOLOGIA = "09";
	private List<Procedimento> procedimentosSelecionados;
	private ProcedimentoComExamesTO procedimentoParametro;
	private Ct_dadosAutorizacao guiasAutorizadaSelecionada;
	private ClienteUnidadePasseLivre clienteUnidadePasseLivre;
	private ExcecaoAtendimentoResult excecaoAtendimentoResult;
	private ParametroConsultaCliente parametroConsultaCliente;
	private List<GuiaAutorizadaExcecao> guiasAutorizadasExcecao;
	private List<ProcedimentoComExamesTO> procedimentosComExames;
	private List<ProcedimentoComExamesTO> procedimentosExcluidos;
	private List<Ct_dadosAutorizacao> guiasAutorizadasSelecionadas;
	private List<Ct_dadosAutorizacao> guiasAutorizadasRespondidas;
	private List<Ct_dadosAutorizacao> guiasAutorizadasNaoRespondidas;
	private HabilitacaoCamposCadastroTO habilitacaoCamposCadastroTO;
	private Map<String, List<PerguntaComExameTO>> todasPerguntasAgrupadas;
	private List<ConsultaQuestionarioExameResult> questionariosExamesResult;
	private ConsultaQuestionarioExameResult consultaQuestionarioExameResult;
	private List<ProcedimentoComExamesTO> procedimentosComExamesSelecionados;
	private List<ProcedimentoComExamesTOExcecao> procedimentosComExamesExcecao;
	private List<ProcedimentoComExamesTO> procedimentosComExamesParaGerarPedido;
	private Map<String, List<PerguntaComExameTO>> todasPerguntasAgrupadasEConsolidadas;
	private ParametroAgendamentoCliente parametroAgendamento;
	private AgendamentoUnidade agendamentoUnidade;
	private List<AgendamentoUnidade> agendamentosUnidade;
	private Boolean habilitarMarcacao = false;
	private String msgTelaFinalizacao;
	private String tentativasBiometria;
	private CriarPedidoResult locCriarPedidoResult;
	// hard code exame covid
	private boolean exameCovid;

	// Exames calculados
	private Map<ExameSimplificado, List<ExameSimplificado>> combinacaoExamesCalculados;
	private Map<String, List<String>> combinacaoPaiFilhos;
	private boolean combinacaoUniao;
	private boolean jaVerificouExamesCalcs;
	private ExameCalculadoBean calculadoBean;

	private String cep;
	private String bairro;
	private String numero;
	private String complemento;
	private boolean editarLogradouro;
	private boolean editarBairro;
	private String uf;
	private String cidade;
	private String logradouro;

	private String descStatusImpressora;
	private Boolean sessaoValida;
	private Boolean houveErroAoImprimirGa;
	private int contagemErros;
	private String msgObservacao;
	private String mensagemMotivo;

	@PostConstruct
	public final void onLoad() {
		try {
			sessaoValida = Boolean.TRUE;
			activeIndex = 0;
			resultadoBiometria = "";
			numeroCarteira = "";
			informacaoTotem = new InformacaoTotem();
			houveAlteracao = false;
			providencia = "";
			setUser(new UserAuth());
			procedimentoParametro = new ProcedimentoComExamesTO();
			habilitacaoCamposCadastroTO = new HabilitacaoCamposCadastroTO();
			perguntasUtil = new PerguntasService();
			excecaoAtendimentoResult = new ExcecaoAtendimentoResult();
			parametroConsultaCliente = new ParametroConsultaCliente();
			controleBotaoUtil = new ControleBotaoUtil();
			mtdQuestionario = new MasterDetail();
			dataUtil = new DataUtil();
			locCriarPedidoResult = new CriarPedidoResult();
			mdlsQuestionario = new ArrayList<>();
			guiasAutorizadasSelecionadas = new ArrayList<>();
			guiasAutorizadasRespondidas = new ArrayList<>();
			guiasAutorizadasNaoRespondidas = new ArrayList<>();
			procedimentosSelecionados = new ArrayList<>();
			clienteUnidadePasseLivre = new ClienteUnidadePasseLivre();
			formataEndereco = new FormataEndereco();
			procedimentosExcluidos = new ArrayList<>();
			buscarInformacoesTotem();
			if(Objects.isNull(informacoesTotem)) {
				mensagemErroBuscarInformacoesTotem();
			} else {
				buscarInformacaoTotem();
				buscarToken();
				verificarSeClientePasseLivreExiste();
				sessionId = buscarSessionId();
			}
			agendamentosUnidade = new ArrayList<>();
			exameCovid = false;
			// TODO refatorar os exames calculados e deixar mais simples
			combinacaoExamesCalculados = new HashMap<ExameSimplificado, List<ExameSimplificado>>();
			combinacaoPaiFilhos = new HashMap<String, List<String>>();
			combinacaoUniao = false;
			jaVerificouExamesCalcs = false;
			calculadoBean = null;
			mensagemAviso = "";
			mensagemMotivo = "";
			descStatusImpressora = checkStatusPrinter();
			contagemErros = BigInteger.ZERO.intValue();
			houveErroAoImprimirGa = Boolean.FALSE;
			msgObservacao = "Caso deseje, tente novamente através da botão Imprimir.";

		} catch (final Exception locExc) {
			String msgCausa = "";
			if(!Objects.isNull(locExc.getCause())) {
				msgCausa = " - Causa: " + locExc.getCause();
			}
			mensagemAviso = "Erro ao iniciar novo atendimento: " + locExc.getMessage() + msgCausa;
			MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso(this.mensagemAviso);
			try {
				getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
			} catch (Exception e) {
				e.printStackTrace();
			}
			redirectTelaErro();
		}
	}

	private String buscarSessionId() {
		try {
			final HttpSession session = getHttpServletRequest().getSession();
			return session.getAttribute("sessionId").toString();
		} catch (final Exception locExc) {
			return "";
		}
	}

	public void abrirDetalheExames(final ProcedimentoComExamesTO procedimentoComExamesTO) {
		procedimentoParametro = procedimentoComExamesTO;
		if (!procedimentoComExamesTO.getExame().getDescricaoExame().equals("Selecione")) {
			buscarPreparacaoExame(procedimentoComExamesTO.getExame());
			RequestContext.getCurrentInstance().execute("PF('dlgDetalhe').show();");
		}
	}

	public void abrirDetalheCondicoes(final ExameHermesPardini exameHermesPardini) {
		buscarPreparacaoExame(exameHermesPardini);
		RequestContext.getCurrentInstance().execute("PF('dlgCondicao').show();");
	}

	private void redirectTelaErro() {
		try {
			FacesContext.getCurrentInstance().getExternalContext().redirect(redirectAtendimentoNaoConcluidoIndex());
		} catch (Exception e) {
		}
	}

	private String redirectAtendimentoNaoConcluidoIndex() throws Exception {
		final String nomeTotem = retornarNomeDaMaquina();
		registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
				Thread.currentThread().getStackTrace()[1].getMethodName(), mensagemAviso, TotemUtil.buscarSessionId(),
				createBasicLogMap());
		return "/passelivretotem/pages/erro/atendimentoNaoConcluido.xhtml?faces-redirect=true&sessionId=" + sessionId
				+ "&nomeTotem=" + nomeTotem;
	}

	private void buscarToken() {
		try {
			final HttpSession session = getHttpServletRequest().getSession();
			tokenResult = (TokenResult) session.getAttribute("tokenResult");
			if (tokenResult == null) {
				tokenResult = TotemUtil.gerarToken();
			}
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	private void verificarResultadoDaBiometria() throws Exception {
		if (!resultadoBiometria.equals("0")) {
			throw new Exception("Erro ao ler o número da carteirinha!");
		}

	}

	private boolean confirmarBiometria(boolean primeiraTentativa) throws Exception {
		if (!numeroCarteira.startsWith("0006")) {
			return true;
		} else {
			
				try {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				ParametroConfirmaBiometria parametroConfirmaBiometria = new ParametroConfirmaBiometria();
				parametroConfirmaBiometria.setNumeroCarteira(numeroCarteira);
				parametroConfirmaBiometria.setUnbh("unbh" + retornarLocalidade(localidade));
				
				Calendar ajusteData = Calendar.getInstance();
				ajusteData.add(Calendar.SECOND, 10);
				
				parametroConfirmaBiometria.setDataAtendimento(sdf.format(ajusteData.getTime()));
				
				ConfirmaBiometriaService confirmaBiometriaService = new ConfirmaBiometriaService(getHttpServletRequest());
				ConfirmaBiometriaResult result;
				result = confirmaBiometriaService.consultarBiometria(parametroConfirmaBiometria);
	
				if (result != null) {
					gravarLogSimplificado(Thread.currentThread().getStackTrace()[1].getClassName(),
							Thread.currentThread().getStackTrace()[1].getMethodName(),
							String.format("Enviado: %s. Resposta: %s", Util.retornaJsonResult(parametroConfirmaBiometria),
									Util.retornaJsonResult(result)));
	
					if (result.getCertificacao().equals("SIM")) {
						mensagemAviso = "";
						return true;
					} else {
						mensagemAviso = String.format("%s. Carteira Unimed: %s", result.getValidacaoBiometrica(),
								numeroCarteira);
	
						if (primeiraTentativa) {
							Util.aguardar(5000);
							return confirmarBiometria(false);
						}
						return false;
					}
				}
			} catch (BiometriaDesativadaException e) {
				return true;
			}
			
			gravarLogSimplificado(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(),
					"Servico de confirmacao de biometria indisponível");
			return false;
		} 
	}

	private void gravarLogSimplificadoSemExecao(String className, String methodName, String mensagem) {
		try {
			registrarLogAcessoFuncionalidadeMap(className, methodName, mensagem, TotemUtil.buscarSessionId(),
					createBasicLogMap());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void gravarLogSimplificado(final String className, final String methodName, final String mensagem)
			throws Exception {
		registrarLogAcessoFuncionalidadeMap(className, methodName, mensagem, TotemUtil.buscarSessionId(),
				createBasicLogMap());
	}

	@SuppressWarnings("unchecked")
	private void buscarInformacoesTotem() {
		try {
			informacoesTotem = new ArrayList<>();
			final HttpSession session = getHttpServletRequest().getSession();
			informacoesTotem = (List<InformacaoTotem>) session.getAttribute("informacoesTotem");
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	public String aceitarTermo() {
		try {
			String retorno = "";
			if(sessaoValida) {
				registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(), null, TotemUtil.buscarSessionId(),
						createBasicLogMap());
				localidade = retornarLocalidade();
				retorno = retornarTelaColetaDeAcordoComAmbiente();
			}
			return retorno;
		} catch (final Exception locExc) {
			gerarLogErroAoAceitarTermo(locExc.getMessage());
			MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso(locExc.getMessage());
			try {
				getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return redirectAtendimentoNaoConcluido();
		}
	}

	private String retornarTelaColetaDeAcordoComAmbiente() {
		try {
			if (getAmbienteProducao()) {
				return redirectColetaBiometria();
			} else {
				return redirectColetaBiometriaTemp();
			}
		} catch (final Exception locExc) {
			return redirectColetaBiometria();
		}
	}

	private String redirectColetaBiometriaTemp() {
		return "/pages/nau/coletaBiometriaTeste.xhtml?faces-redirect=true";
	}

	private void gerarLogErroAoAceitarTermo(final String parMessage) {
		try {
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, TotemUtil.buscarSessionId(),
					createBasicLogMap());
		} catch (final Exception exc) {
		}
	}

	private String ipLocal() {
		try {
			return Util.getClientIpAddr(getHttpServletRequest());
		} catch (final Exception exc) {
			return "";
		}
	}

	public String avancarPedido() {
		try {
			verificarSeExameFoiSelecionado();
			verificarExamesCalculados(procedimentosComExames);
			adicionarProcedimentoExcluidos();
			if (procedimentosExcluidos.isEmpty()) {
				return avancarExames();
			} else {
				exibirDialogProcedimentosExcluidos();
				return "";
			}
		} catch (final ExameCalculadoException e) {
			return "";

		} catch (final SelecaoCampoException locExc) {
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
			// gerarLogIrParaQuestionario(locExc.getMessage()); //n�o gerar log para
			// valida��o de campos
			return null;
		} catch (final Exception locExc) {
			return "";
		}
	}

	private void exibirDialogProcedimentosExcluidos() {
		RequestContext.getCurrentInstance().execute("PF('dlgProcedimentosExcluidos').show()");
	}

	public String avancarExames() {
		try {
		    getSession().setAttribute("questionarioIsBotaoOn", true);
			gerarExameParaVT();
			verificarExamesExcluidosDaGuia();
			verificarSeExameFoiSelecionado();
			validarCamposAlterados();
			guiasAutorizadasRespondidas.add(guiasAutorizadaSelecionada);
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, retornarCodigo());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, TotemUtil.buscarSessionId(),
					createBasicLogMap());
			gerarQuestionario();
			agruparPerguntasEOrdenar();
			final ComponenteFactory componenteFactory = new ComponenteFactory(pnlQuestionario, mdlsQuestionario,
					mtdQuestionario, mdlQuestionario, pngQuestionario);
			return verificarSeExisteQuestionario(componenteFactory);
		} catch (final RegraNegocioException locExc) {
			locExc.printStackTrace();
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
			// gerarLogErroIrParaQuestionario(locExc.getMessage());
			return null;
		} catch (final SelecaoCampoException locExc) {
			locExc.printStackTrace();
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
			// gerarLogIrParaQuestionario(locExc.getMessage()); //n�o gerar log para
			// valida��o de campos
			return null;
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
			gerarLogErroIrParaQuestionario(locExc.getMessage());
			return null;
		}
	}

	private void validarCamposAlterados() throws SelecaoCampoException {
		for (final ProcedimentoComExamesTO locProcedimento : procedimentosComExames) {
			if (exameNaoSeraExcluido(locProcedimento)) {
				validarCamposDescricaoMaterial(locProcedimento);
				validarCamposCondicaoAmostra(locProcedimento);
			}
		}
	}

	private void validarCamposDescricaoMaterial(final ProcedimentoComExamesTO locProcedimento)
			throws SelecaoCampoException {
		if (materialEhDiv(locProcedimento) && isInformacaoAdicionalEstaVazio(locProcedimento)) {
			throw new SelecaoCampoException(
					MensagemUtil.retornarMensagemErroAoValidarCamposDescricaoMaterial(locProcedimento));
		}
	}

	private void validarCamposCondicaoAmostra(final ProcedimentoComExamesTO locProcedimento)
			throws SelecaoCampoException {
		if (!materialEhVivo(locProcedimento) && !materialEhVAC(locProcedimento)) {
			if (locProcedimento.getQuantidadeSolicitacadas().intValue() > 1) {
				if (locProcedimento.getCondicaoAmostra() == null || locProcedimento.getCondicaoAmostra().isEmpty()) {
					throw new SelecaoCampoException(
							MensagemUtil.retornarMensagemErroAoValidarCamposCondicaoAmostra(locProcedimento));
				}
				for (ProcedimentoComExamesTO procedimento : procedimentosComExames) {
					if (procedimento.getProcedimento().equals(locProcedimento.getProcedimento())
							&& !procedimento.getSequenciaExame().equals(locProcedimento.getSequenciaExame())
							&& procedimento.getCondicaoAmostra().equals(locProcedimento.getCondicaoAmostra())) {
						throw new SelecaoCampoException(MensagemUtil
								.retornarMensagemErroAoValidarCamposCondicaoAmostraRepetida(locProcedimento));
					}
				}
			}
		}
	}

	private void gerarLogIrParaQuestionario(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, retornarCodigo());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, TotemUtil.buscarSessionId(),
					createBasicLogMap());
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	private void gerarExameParaVT() throws RegraNegocioException {
		procedimentosComExamesParaGerarPedido = new ArrayList<>();
		quantidadeExameVT = 0;
		for (final ProcedimentoComExamesTO procedimentoComExamesTO : procedimentosComExames) {
			if (exameNaoSeraExcluido(procedimentoComExamesTO)) {
				if (procedimentosComExamesSelecionados.contains(procedimentoComExamesTO)) {
					procedimentoComExamesTO.setVt(false);
					procedimentosComExamesParaGerarPedido.add(procedimentoComExamesTO);
				} else {
					procedimentoComExamesTO.setVt(true);
					quantidadeExameVT += 1;
					procedimentosComExamesParaGerarPedido.add(procedimentoComExamesTO);
				}
			}
		}
	}

	private boolean exameNaoSeraExcluido(final ProcedimentoComExamesTO locProcedimento) {
		try {
			return !locProcedimento.getExcluido();
		} catch (final Exception locExc) {
			return true;
		}
	}

	public void executarFuncaoNaoSouEu() {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, numeroCarteira);
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(),
					"Usuário listado não corresponde ao requisitante.", TotemUtil.buscarSessionId(),
					createBasicLogMap());
			ParametroNaoSouEu parametroNaoSouEu = new ParametroNaoSouEu(clienteUnidadePasseLivre, numeroCarteira);
			final ClienteService clienteService = new ClienteService(getHttpServletRequest());
			clienteService.executaNaoSouEu(parametroNaoSouEu);
			if (clienteService.isSuccess()) {
				registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(),
						"Matricula(" + numeroCarteira + ") foi desassociada do cliente ("
								+ clienteUnidadePasseLivre.getCodigoCliente() + ").",
						sessionId, createBasicLogMap());
			}
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	private String verificarSeExisteQuestionario(final ComponenteFactory componenteFactory) throws Exception {
		if ((!todasPerguntasAgrupadas.isEmpty() || todasPerguntasAgrupadas.size() != 0) && !isQuestionarioImpresso()) {
			final HttpSession session = getHttpServletRequest().getSession();
			session.setAttribute("mdlsQuestionario", mdlsQuestionario);
			session.setAttribute("sessionId", sessionId);
			session.setAttribute("quantidadeExameVT", quantidadeExameVT);
			session.setAttribute("todasPerguntasAgrupadas", todasPerguntasAgrupadas);
			session.setAttribute("questionariosExamesResult", questionariosExamesResult);
			session.setAttribute("consultaQuestionarioExameResult", consultaQuestionarioExameResult);
			session.setAttribute("numeroCarteira", numeroCarteira);
			session.setAttribute("sessionId", sessionId);
			session.setAttribute("tokenResult", tokenResult);
			session.setAttribute("procedimentosExcluidos", procedimentosExcluidos);
			session.setAttribute("ws_respostaCobertura", ws_respostaCobertura);
			session.setAttribute("clienteUnidadePasseLivre", clienteUnidadePasseLivre);
			session.setAttribute("procedimentosComExamesParaGerarPedido", procedimentosComExamesParaGerarPedido);
			session.setAttribute("guiasAutorizadaSelecionada", guiasAutorizadaSelecionada);
			session.setAttribute("questionariosExamesResult", questionariosExamesResult);
			session.setAttribute("informacaoTotem", informacaoTotem);
			session.setAttribute("informacoesTotem", informacoesTotem);
			session.setAttribute("providencia", providencia);
			return "/pages/nau/questionario.xhtml?faces-redirect=true";
		} else {
			return fazerPedido();
		}
	}

	private void adicionarProcedimentoExcluidos() throws Exception {
		procedimentosExcluidos.clear();
		for (final ProcedimentoComExamesTO locProcedimento : procedimentosComExames) {
			if (locProcedimento.getExcluido()) {
				procedimentosExcluidos.add(locProcedimento);
			}
		}
		final HttpSession session = getHttpServletRequest().getSession();
		session.setAttribute("procedimentosExcluidos", procedimentosExcluidos);
	}

	private void gerarLogErroIrParaQuestionario(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, retornarCodigo());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, TotemUtil.buscarSessionId(),
					createBasicLogMap());
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	private void verificarSeExameFoiSelecionado() throws SelecaoCampoException {
		for (final ProcedimentoComExamesTO locProcedimento : procedimentosComExames) {
			if (locProcedimento.getExame() == null
					|| locProcedimento.getExame().getDescricaoExame().equals("Selecione")) {
				throw new SelecaoCampoException("Exame deve ser selecionado!");
			}
		}
	}

	private void verificarExamesExcluidosDaGuia() throws SelecaoCampoException {
		if (procedimentosComExamesParaGerarPedido.isEmpty()) {
			try {
				/*
				 * registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace(
				 * )[1]. getClassName(),
				 * Thread.currentThread().getStackTrace()[1].getMethodName(),
				 * "� preciso ter pelo menos um exame para gerar pedido!", sessionId,
				 * createBasicLogMap());
				 */
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			throw new SelecaoCampoException("É preciso ter pelo menos um exame para gerar pedido!");
		}
	}

	private void agruparPerguntasEOrdenar() throws Exception {
		perguntasUtil = new PerguntasService();
		todasPerguntasAgrupadas = new TreeMap<>(perguntasUtil.agruparPerguntasPorAba(questionariosExamesResult));
		filtrarPerguntasConsolidadas();
	}

	private void filtrarPerguntasConsolidadas() {
		final AplicaExcecaoQuestionarioFactory aplicaExcecaoParaQuestionarioFactory = new AplicaExcecaoQuestionarioFactory();
		todasPerguntasAgrupadasEConsolidadas = new TreeMap<>(
				aplicaExcecaoParaQuestionarioFactory.retornarQuestionariosFiltrados(todasPerguntasAgrupadas));
	}

	private void preencherQuestionario() throws Exception {
		try {
			perguntas = (List<PerguntaEntrega>) getSession().getAttribute("perguntas");
			/*
			 * final QuestionarioService questionarioService = new
			 * QuestionarioService(getHttpServletRequest(), perguntas, mapQuestionarios);
			 * perguntas = new ArrayList<>(); if (mapQuestionarios.isEmpty()) {
			 * mapQuestionarios = (Map<String, String>)
			 * getSession().getAttribute("mapQuestionarios"); } if (mapQuestionarios != null
			 * && !mapQuestionarios.isEmpty()) {
			 * perguntas.addAll(questionarioService.preencherQuestionarioConsolidado()); //
			 * Validar respostas invioláveis for (final ConsultaQuestionarioExameResult
			 * questionario : questionariosExamesResult) { if
			 * (!questionarioService.validarRespostaInviolavel(questionario.getQuestionarios
			 * ())) { final String parMessage = "Resposta viola regras do questionário";
			 * registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace(
			 * )[1 ].getClassName (),
			 * Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage,
			 * sessionId); throw new RegraNegocioException(parMessage); } } } else {
			 * mapQuestionarios = new HashMap<>(); }
			 */
		} catch (final Exception locExc) {
			throw new Exception("Não foi possível recuperar as respostas do questionário" + locExc.getMessage());
		}
	}

	public String retornarSituacao(final String situacao) {
		return SituacaoPedidoClienteEnum.valueOfSituacao(situacao).getDescricao();
	}

	public void changeListener(final ValueChangeEvent event) {
	}

	public String atualizarDados() {
		try {
			acoesNoClienteAoAtualizar();
			formatarValores();
			return realizarAtualicacao();
		} catch (final RuntimeException locExc) {
			gerarLogErroAoAtualizar(locExc.getMessage());
			MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso(locExc.getMessage());
			try {
				getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return redirectAtendimentoNaoConcluido();
		} catch (final GuiasAutorizadasException locExc) {
			gerarLogErroAoBuscarGuias(locExc.getMessage());
			return redirectGuiasAutorizadas();
		} catch (final RegraNegocioException locExc) {
			// gerarLogErroAoAtualizar(locExc.getMessage());// n�o gravar log de valida��o
			// de campos
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
			return null;
		} catch (final Exception locExc) {
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
			locExc.printStackTrace();
			gerarLogErroAoAtualizar(locExc.getMessage());
			return null;
		}
	}

	private String retornarSomenteGuias() {
		try {
			String guias = "";
			for (final Ct_dadosAutorizacao locGuias : guiasAutorizadas) {
				guias += locGuias.getIdentificacaoAutorizacao().getNumeroGuiaOperadora() + "( "
						+ locGuias.getProcedimentos().length + " exames), ";
			}
			return guias;
		} catch (final Exception locExc) {
			return "Não existe guias!";
		}
	}

	private void gerarLogErroAoBuscarGuias(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, retornarCodigo());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, TotemUtil.buscarSessionId(),
					createBasicLogMap());
		} catch (final Exception exc) {
		}
	}

	// FIXME Verificar dados condicionais para atualização dos dados - Luiz
	private String retornarAcaoAposVerificarSeDadosForamAtualizados() throws RuntimeException, Exception {
		if (houveAlteracao) {
			houveAlteracao = false;
			return realizarAtualicacao();
		} else {
			houveAlteracao = false;
			return verificarAgendamento();
			// return irParaGuias(); Ellen Maia
		}
	}

	private String verificarAgendamento() {
		// verificar se há agendamento

		try {
			final AgendamentoService agendamentoService = new AgendamentoService(getHttpServletRequest());
			parametroAgendamento = new ParametroAgendamentoCliente(tokenResult, clienteUnidadePasseLivre);
			parametroAgendamento.setOrigem(Constantes.ORIGEM_PADRAO);
			agendamentoService.consultaAgendamento(parametroAgendamento);
			// Fazer list resposta breno

			agendamentoUnidade = new AgendamentoUnidade();
			if (agendamentoService.isSuccess()) {
				if (agendamentoService.getResponseObject() != null) {
					agendamentosUnidade = (List<AgendamentoUnidade>) agendamentoService.getResponseObject();
					// getHttpServletRequest().getSession().setAttribute("agendamentoUnidade",
					// agendamentoUnidade);
					// getHttpServletRequest().getSession().setAttribute("agendamentosUnidade",
					// agendamentosUnidade);
					return redirectAgendamento();
				} else {
					return irParaGuias(); // - DESCOMENTAR ELLEN MAIA
				}
			} else {
				mensagemAviso = agendamentoService.getResponseMessage();
				exibirDialogMensagem();
				// gerarLogErroAoBuscarDadosCliente(mensagemAviso);
			}
		} catch (final RegraNegocioException locExc) {
			locExc.printStackTrace();
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
			// gerarLogErroAoBuscarDadosCliente(locExc.getMessage());
		} catch (final Exception locExcexc) {
			locExcexc.printStackTrace();
			mensagemAviso = locExcexc.getMessage();
			exibirDialogMensagem();
			gerarLogErroAoBuscarDadosCliente(locExcexc.getMessage());
		}
		return mensagemAviso; // Melhorar isso aqui - Ellen Maia
		// return redirectAgendamento();
	}

	private String realizarAtualicacao()
			throws RuntimeException, RegraNegocioException, GuiasAutorizadasException, Exception {
		try {
			final ClienteService clienteService = new ClienteService(getHttpServletRequest());
			acoesNoClienteAoAtualizar();
			formatarValores();
			formataEndereco.convertStreetAndComplement(clienteUnidadePasseLivre);
			clienteService.setValueObject(clienteUnidadePasseLivre);
			ParametroRegistraCliente parRegistraCliente = new ParametroRegistraCliente(clienteUnidadePasseLivre);
			clienteService.registrarCliente(parRegistraCliente);
			String textoLog = String.format(
					"Foi atualizado os dados do seguinte cliente: %s (CPF), %s (nome), %s (codigo), %s (data nascimento)",
					parRegistraCliente.getCpf(), parRegistraCliente.getNomeCompleto(), parRegistraCliente.getCodigo(),
					parRegistraCliente.getDataNascimento());
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, retornarCodigo());

			if (clienteService.isSuccess()) {
				registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(), textoLog,
						TotemUtil.buscarSessionId(), createBasicLogMap());
				gerarLogEstatisticoAoAtualizar();
				return verificarAgendamento();
				// return irParaGuias(); Ellen Maia
			} else {
				mensagemAviso = clienteService.getResponseMessage();
				RequestContext.getCurrentInstance().execute("PF('dlgMessage').show()");
				if (mensagemAviso.contains("CPF(")
						&& (mensagemAviso.contains("inválido") || mensagemAviso.contains("pertence ao cliente"))) {
					clienteUnidadePasseLivre.setCpf(null);
				}
				return "";
			}
		} catch (Exception e) {
			throw e;
		}
	}

	// private String irParaGuias() {
	// try {
	// buscarGuiasAutorizadas();
	// return redirectGuiasAutorizadas();
	// } catch (final Exception locExc) {
	// return redirectGuiasAutorizadas();
	// }
	// }

	public String irParaGuias() throws GuiasAutorizadasException {
		try {
			buscarGuiasAutorizadas();
			return redirectGuiasAutorizadas();
		} catch (final Exception locExc) {
			throw new GuiasAutorizadasException(locExc.getMessage());
		}
	}

	private void gerarLogEstatisticoAoAtualizar() {
		try {
			final ControleEstatisticoService controleEstatisticoService = new ControleEstatisticoService(
					getHttpServletRequest());
			final ControleEstatistico controleEstatistico = new ControleEstatistico(
					clienteUnidadePasseLivre.getCodigoCliente(), null, FuncaoLogEstatistico.ATUALIZAR_DADOS.toString(),
					informacoesTotem.get(0).getId(), null, null, retornarUnidade());
			controleEstatisticoService.insert(controleEstatistico);
		} catch (final Exception locExc) {
			gerarLogErroAoGerarLogEstatistico(locExc.getMessage());
		}
	}

	private void acoesNoClienteAoAtualizar() throws Exception {
		clienteUnidadePasseLivre.setSenhaUsuario(user.getAuthPass());
		clienteUnidadePasseLivre.setComplemento(clienteUnidadePasseLivre.retirarCaracteriosInvalidosNoComplemento());
		clienteUnidadePasseLivre.setNumero(clienteUnidadePasseLivre.retornarNumeroValido());
		clienteUnidadePasseLivre.verificarCamposEmBrancoAoAtualizar();
		clienteUnidadePasseLivre.validarEmail();
		clienteUnidadePasseLivre.validarCpfComIdade();
	}

	private void formatarValores() {
		clienteUnidadePasseLivre.setCelular(formatarTelefone(clienteUnidadePasseLivre.getCelular()));
		clienteUnidadePasseLivre.setTelefone(formatarTelefone(clienteUnidadePasseLivre.getTelefone()));
		clienteUnidadePasseLivre.setCep(formatarCep(clienteUnidadePasseLivre.getCep()));
		clienteUnidadePasseLivre.setCpf(formatarCpf(clienteUnidadePasseLivre.getCpf()));
	}

	private InputStream gerarRelatorioGA(final CriarPedidoResult parCriarPedidoResult,
			final Ct_dadosAutorizacao parLocalCt_dadosAutorizacao) {
		try {
			final NovoAtendimentoService novoAtendimentoService = new NovoAtendimentoService(getHttpServletRequest());
			String codPrestadorUnimed = (String) getSession().getAttribute("codigoPrestadorUnimed");
			final String pathArquivoReport = getServletContext()
					.getRealPath("/WEB-INF/relatorio/GuiaAtendimento.jasper");
			return novoAtendimentoService.gerarRelatorioGA(parCriarPedidoResult, ws_respostaCobertura,
					parLocalCt_dadosAutorizacao, getServletContext(), pathArquivoReport, procedimentosExcluidos,
					questionariosExamesResult, procedimentosComExamesParaGerarPedido, codPrestadorUnimed,
					informacaoTotem.getNomeEmpresa(), informacaoTotem.getCnesUnidade());
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			mensagemAviso = "Erro ao gerar relatório!";
			exibirDialogMensagem();
			return null;
		}
	}

	public StreamedContent getRelatorioGA() {
		return relatorioGA;
	}

	private String formatarCpf(final String cpf) {
		try {
			return new FormataCpf(cpf).formatar();
		} catch (final Exception locExc) {
			return null;
		}
	}

	private String formatarTelefone(final String telefone) {
		return new FormataTelefone(telefone).formatar();
	}

	private void gerarLogErroAoAtualizar(final String parMensagemErro) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, retornarCodigo());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMensagemErro,
					TotemUtil.buscarSessionId(), createBasicLogMap());
		} catch (final Exception exc) {
		}
	}

	private void buscarGuiasAutorizadas() throws GuiasAutorizadasException {
		try {
			situacao = new Ws_situacaoAutorizacao();
			final Ws_consultaSolicitacoes wsConsulta = new Ws_consultaSolicitacoes();
			final ConsultaGuiasAutorizadasService guiasAutorizadasService = new ConsultaGuiasAutorizadasService(
					getHttpServletRequest());
			final Ct_beneficiario beneficiario = new Ct_beneficiario(numeroCarteira, "", "", null, null, null);
			situacao = guiasAutorizadasService.buscarGuiasAutorizadas(beneficiario);
			adicionarGuias();
		} catch (final Exception locExc) {
			limparTelaDeGuia();
			// gerarLogErroAoBuscarGuiasAutorizadas(MensagemUtil.retornarMensagemErroAoBuscarGuias(numeroCarteira,
			// informacoesTotem, locExc.getMessage()));
			redirectGuiasAutorizadas();
			// throw new GuiasAutorizadasException("Erro ao buscar as guias!" +
			// locExc.getMessage());
		}
	}

	public void buscarGuiasAutorizadasSemFiltro() throws GuiasAutorizadasException {
		try {
			limparTelaDeGuia();
			situacao = new Ws_situacaoAutorizacao();
			final Ws_consultaSolicitacoes wsConsulta = new Ws_consultaSolicitacoes();
			final ConsultaGuiasAutorizadasService guiasAutorizadasService = new ConsultaGuiasAutorizadasService(
					getHttpServletRequest());
			final Ct_beneficiario beneficiario = new Ct_beneficiario(numeroCarteira, "", "", null, null, null);
			situacao = guiasAutorizadasService.buscarGuiasAutorizadas(beneficiario);
			guiasAutorizadas = new ArrayList<>();
			if (situacao.getSituacaoAutorizacao().getDadosAutorizacao().length == 0) {
				mensagemAviso = "Nenhuma guia encontrada.";
			}
			for (final br.com.unimedbh.www.Ct_dadosAutorizacao ct_autorizacaoProcedimento : situacao
					.getSituacaoAutorizacao().getDadosAutorizacao()) {
				if (dataAutorizacaoNaoForNull(ct_autorizacaoProcedimento)
						&& medicoNaoForNull(ct_autorizacaoProcedimento)) {
					guiasAutorizadas.add(ct_autorizacaoProcedimento);
				}
			}
			if (guiasAutorizadas.isEmpty()) {
				mensagemAviso = "Nenhuma guia encontrada";
			}
		} catch (final Exception locExc) {
			mensagemAviso = "Nenhuma guia encontrada: " + locExc.getMessage();
			System.out.println(locExc.getMessage());
		}
	}

	private void limparTelaDeGuia() {
		excecaoAtendimentoResult = new ExcecaoAtendimentoResult();
		guiasAutorizadas = new ArrayList<>();
		guiasAutorizadasExcecao = new ArrayList<>();
	}

	private void gerarLogErroAoBuscarGuiasAutorizadas(final String parMensagem) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, retornarCodigo());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMensagem, TotemUtil.buscarSessionId(),
					createBasicLogMap());
		} catch (final Exception locExc) {
		}
	}

	private void buscarQuestionario() throws RegraNegocioException {
		try {
			final QuestionarioService questionarioService = new QuestionarioService(getHttpServletRequest());
			final List<ParametroQuestionario> parametrosQuestionario = new ArrayList<>();
			adicionarParametrosAoQuestionario(parametrosQuestionario);
			questionariosExamesResult = new ArrayList<>();
			consultarQuestionario(questionarioService, parametrosQuestionario);
		} catch (final Exception locExc) {
			throw new RegraNegocioException("Erro ao buscar o questionário!" + locExc.getMessage());
		}
	}

	private void adicionarParametrosAoQuestionario(final List<ParametroQuestionario> parametrosQuestionario) {
		for (final ProcedimentoComExamesTO procedimento : procedimentosComExamesSelecionados) {
			if (!procedimento.getExcluido()) {
				if (existePacoteNoExame(procedimento.getExame())) {
					for (final ExameHermesPardini exame : procedimento.getExame().getComposicaoPacote()) {
						parametroQuestionario = new ParametroQuestionario(exame, procedimento.getExame(),
								clienteUnidadePasseLivre, tokenResult);
						parametrosQuestionario.add(parametroQuestionario);
					}
				} else {
					parametroQuestionario = new ParametroQuestionario(procedimento, clienteUnidadePasseLivre,
							tokenResult);
					parametrosQuestionario.add(parametroQuestionario);
				}
			}
		}
	}

	private void consultarQuestionario(final QuestionarioService questionarioService,
			final List<ParametroQuestionario> parametrosQuestionario) throws RegraNegocioException {
		for (final ParametroQuestionario locParametroQuestionario : parametrosQuestionario) {
			questionarioService.setValueObject(locParametroQuestionario);
			questionarioService.consultar();
			if (questionarioService.isSuccess()) {
				consultaQuestionarioExameResult = new ConsultaQuestionarioExameResult(
						(ConsultaQuestionarioExameResult) questionarioService.getResponseObject(),
						locParametroQuestionario);
				questionariosExamesResult.add(consultaQuestionarioExameResult);
			} else {
				throw new RegraNegocioException(questionarioService.getResponseMessage());
			}
		}
	}

	private boolean existePacoteNoExame(final ExameHermesPardini exame) {
		return exame.getEPacote() == NovoAtendimentoUnimedBean.TIPO_PACOTE;
	}

	public void goToTab(final int index) {
		activeIndex = index;
	}

	private void adicionarGuias() throws Exception {
		excecaoAtendimentoResult = buscarExcecoes();
		guiasAutorizadas = new ArrayList<>();
		guiasAutorizadasExcecao = new ArrayList<>();
		for (final br.com.unimedbh.www.Ct_dadosAutorizacao ct_autorizacaoProcedimento : situacao
				.getSituacaoAutorizacao().getDadosAutorizacao()) {
			if (dataAutorizacaoNaoForNull(ct_autorizacaoProcedimento) && medicoNaoForNull(ct_autorizacaoProcedimento)) {
				if (solicitanteEstaCadastrado(ct_autorizacaoProcedimento)) {
					guiasAutorizadas.add(ct_autorizacaoProcedimento);
				} else {
					String nomeSolicitante = "";
					if (ct_autorizacaoProcedimento.getSolicitante() != null) {
						nomeSolicitante = ct_autorizacaoProcedimento.getSolicitante().getNomeSolicitante() + " ("
								+ ct_autorizacaoProcedimento.getSolicitante().getSiglaConselho() + "-"
								+ ct_autorizacaoProcedimento.getSolicitante().getUfConselho() + ": "
								+ ct_autorizacaoProcedimento.getSolicitante().getNumeroConselho().toString() + ")";
					}
					GuiaAutorizadaExcecao guiaExcessao = new GuiaAutorizadaExcecao(ct_autorizacaoProcedimento,
							"Solicitante não cadastrado " + nomeSolicitante);
					if (!guiasAutorizadasExcecao.contains(guiaExcessao)) {
						guiasAutorizadasExcecao.add(guiaExcessao);
					}
				}
			}
		}
		filtrarExcecaoDasGuiasAutorizadas();
		filtrarGuiasAutorizadas();

		final List<Ct_dadosAutorizacao> guiasAutorizadasAux = new ArrayList<>();
		guiasAutorizadasAux.addAll(guiasAutorizadas);
		String msgLogAgendamento = "";

		// FIXME - AGENDAMENTO SELECIONADO - ELLEN
		if (agendamentosUnidade != null && !agendamentosUnidade.isEmpty()) {
			if (agendamentoUnidade != null && agendamentoUnidade.getDataAgendada() != null) {
				for (final Ct_dadosAutorizacao guiaAutorizada : guiasAutorizadasAux) {

					procurarExamesVivos(guiaAutorizada);

					if (procedimentosComExamesSelecionados.get(0).getExame() != null) {
						if (!procedimentosComExamesSelecionados.get(0).getExame().getMaterial().equals("VIVO")) {
							guiasAutorizadas.remove(guiaAutorizada);
						}
					}
				}
				msgLogAgendamento = "Cliente escolheu exame agendado";
			} else {
				msgLogAgendamento = "Cliente escolheu exame não agendado";
			}
		} else {
			msgLogAgendamento = "Não existe agendamento hoje para o cliente.";
		}
		registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
				Thread.currentThread().getStackTrace()[1].getMethodName(), msgLogAgendamento,
				TotemUtil.buscarSessionId(), createBasicLogMap());

		registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
				Thread.currentThread().getStackTrace()[1].getMethodName(),
				"Guias autorizadas: " + retornarSomenteGuias(), sessionId, createBasicLogMap());
	}

	public List<ProcedimentoComExamesTO> procurarExamesVivos(final Ct_dadosAutorizacao guiaAutorizada) {
		try {
			providencia = "";
			quantidadeExameVT = 0;
			procedimentos = new ArrayList<>();
			// passar numero da guia
			exibeListaExame = true;
			exibeSimplesExame = true;
			// FIXME VERIFICAR SE GLOSA VEM COM CARTEIRINHA INV�LIDA
			ws_respostaCobertura = retornarCoberturaBeneficiario();

			// INICIO BUSCAR COMPOSIÇAO
			final List<Procedimento> procedimentos = new ArrayList<>();
			try {
				final ComposicaoDTO[] composicoesArray = buscarComposicao(guiaAutorizada);
				if (composicoesArray != null && composicoesArray.length >= 1) {
					final List<ComposicaoDTO> composicoes = new ArrayList(Arrays.asList(composicoesArray));
					adicionarProcedimentos(procedimentos, guiaAutorizada, composicoes);
				} else {
					adicionarProcedimentosSemComposicao(procedimentos, guiaAutorizada);
				}
				// return procedimentos;
			} catch (final Exception locExc) {
				throw new RuntimeException(
						"Erro ao buscar procedimentos e adicionar composição!" + locExc.getMessage());
			}
			// FIM BUSCAR COMPOSIÇÃO

			preencherExames(procedimentos);
			filtrarProcedimentosComExcecao();
			filtrarProcedimentos();
			procedimentosComExamesSelecionados = new ArrayList<>();
			procedimentosComExamesSelecionados.addAll(procedimentosComExames);

			return procedimentosComExamesSelecionados;
		} catch (final RuntimeException locExc) {
			procedimentosComExamesSelecionados = new ArrayList<>();
			procedimentosComExamesSelecionados.addAll(procedimentosComExames);
			gerarLogErroAoBuscarExames(locExc.getMessage());
			return null;
		} catch (final Exception locExc) {
			gerarLogErroAoBuscarExames(locExc.getMessage());
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
			return null;
		}
	}

	private ComposicaoDTO[] buscarComposicao(final Ct_dadosAutorizacao parGuiaAutorizada) {
		try {
			final ComposicaoService composicaoService = new ComposicaoService(getHttpServletRequest());
			if (parGuiaAutorizada != null) {
				return composicaoService.consultar(Long.parseLong(retornarSenhaAutorizacaoSemDigitioVerificacao(
						parGuiaAutorizada.getDadosAutorizacao().getSenhaAutorizacao())), null);
			} else {
				getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, retornarCodigo());
				registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(), "Erro ao buscar composição!",
						sessionId, createBasicLogMap());
				return null;
			}
		} catch (final Exception locExc) {
			gerarLogErroAoBuscarComposicao(locExc.getMessage());
			return new ComposicaoDTO[0];
		}
	}

	private void filtrarExcecaoDasGuiasAutorizadas() throws Exception {
		final AplicaExcecaoGuiasFactory aplicaExcecaoGuiasFactory = new AplicaExcecaoGuiasFactory();
		guiasAutorizadasExcecao
				.addAll(aplicaExcecaoGuiasFactory.retornarGuiasExcecao(guiasAutorizadas, excecaoAtendimentoResult));
		// gerarLogParaGuiasExcluidosDoTotem();
	}

	private void gerarLogParaGuiasExcluidosDoTotem() throws Exception {
		for (final GuiaAutorizadaExcecao guiaAutorizadaExcecao : guiasAutorizadasExcecao) {
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(),
					"Log para guias não atendidas pelo totem: " + guiaAutorizadaExcecao.getNumeroGuiaOperadora()
							+ ", senha:" + guiaAutorizadaExcecao.getSenhaAutorizacao() + " Motivo:"
							+ guiaAutorizadaExcecao.getObservacao(),
					sessionId, createBasicLogMap());
		}
	}

	public Boolean getExibirGuiasAutorizadasExcecao() {
		try {
			return !guiasAutorizadasExcecao.isEmpty();
		} catch (final Exception locExc) {
			return false;
		}
	}

	public Boolean getExibirExameExcecao() {
		try {
			return !examesExcecao.isEmpty();
		} catch (final Exception locExc) {
			return false;
		}
	}

	public Boolean getExibirProcedimentoExcecao() {
		try {
			return !procedimentosComExamesExcecao.isEmpty();
		} catch (final Exception locExc) {
			return false;
		}
	}

	private void filtrarGuiasAutorizadas() throws Exception {
		final AplicaExcecaoGuiasFactory aplicaExcecaoGuiasFactory = new AplicaExcecaoGuiasFactory();
		guiasAutorizadas = aplicaExcecaoGuiasFactory.retornarGuiasFiltradas(guiasAutorizadas, excecaoAtendimentoResult);
	}

	public String getRetornarEnderecoBiometria() {
		try {
			final NovoAtendimentoService novoAtendimentoService = new NovoAtendimentoService(getHttpServletRequest());
			return novoAtendimentoService.retornarEnderecoBiometria(localidade);
		} catch (final Exception locExc) {
			gerarLogErroAoRetornarEnderecoBiometria(locExc.getMessage());
			return "";
		}
	}

	private void gerarLogErroAoRetornarEnderecoBiometria(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, numeroCarteira);
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, TotemUtil.buscarSessionId(),
					createBasicLogMap());
		} catch (final Exception exc) {
		}
	}

	private ExcecaoAtendimentoResult buscarExcecoes() throws Exception {
		final ExcecaoAtendimentoService excecaoAtendimentoService = new ExcecaoAtendimentoService(
				getHttpServletRequest());
		final ParametroExcecaoAtendimento parametroExcecaoAtendimento = new ParametroExcecaoAtendimento(
				informacoesTotem, retornarIdServico(), tokenResult);
		excecaoAtendimentoService.retornarExcecao(parametroExcecaoAtendimento);
		if (excecaoAtendimentoService.isSuccess()) {
			return (ExcecaoAtendimentoResult) excecaoAtendimentoService.getResponseObject();
		} else {
			throw new Exception(excecaoAtendimentoService.getResponseMessage());
		}
	}

	private Long retornarIdServico() {
		if (!informacoesTotem.isEmpty()) {
			for (final InformacaoTotem informacaoTotem : informacoesTotem) {
				if (informacaoTotem.getDescricao().equals(Constantes.SERVICO_ATENDIMENTO_UNIMED)) {
					return informacaoTotem.getIdService();
				}
			}
		}
		return null;
	}

	private boolean dataAutorizacaoNaoForNull(
			final br.com.unimedbh.www.Ct_dadosAutorizacao ct_autorizacaoProcedimento) {
		try {
			if (ct_autorizacaoProcedimento.getDadosAutorizacao() != null) {
				return ct_autorizacaoProcedimento.getDadosAutorizacao().getDataAutorizacao() != null
						|| !org.apache.axis.utils.StringUtils
								.isEmpty(ct_autorizacaoProcedimento.getDadosAutorizacao().getDataAutorizacao());
			}
			return false;
		} catch (final Exception locExc) {
			System.out.println("Erro dataAutorizacao " + locExc.getMessage());
			return false;
		}
	}

	private boolean medicoNaoForNull(final br.com.unimedbh.www.Ct_dadosAutorizacao ct_autorizacaoProcedimento) {
		try {
			if (ct_autorizacaoProcedimento.getSolicitante().getNomeSolicitante() != null) {
				return ct_autorizacaoProcedimento.getSolicitante().getNomeSolicitante() != null
						|| !org.apache.axis.utils.StringUtils
								.isEmpty(ct_autorizacaoProcedimento.getSolicitante().getNomeSolicitante());
			}
			return false;
		} catch (final Exception locExc) {
			System.out.println("Erro medico for null " + locExc.getMessage());
			return false;
		}
	}

	private boolean solicitanteEstaCadastrado(
			final br.com.unimedbh.www.Ct_dadosAutorizacao ct_autorizacaoProcedimento) {
		try {
			if (ct_autorizacaoProcedimento.getSolicitante() != null) {
				ParametroConsultaSolicitante parametroConsultaSolicitante = new ParametroConsultaSolicitante(
						tokenResult, ct_autorizacaoProcedimento.getSolicitante());
				SolicitanteService solicitanteService = new SolicitanteService(getHttpServletRequest());
				if (solicitanteService.verificaSolicitanteCadastrado(parametroConsultaSolicitante)) {
					return true;
				} else {
					return false;
				}
			}
			return false;
		} catch (final Exception locExc) {
			return false;
		}
	}

	private ConsultaCodigoResult buscarExamesAutorizados(final InformacaoConvenio informacoesConvenio)
			throws Exception {
		String mensagem = "";
		ConsultaExamesAutorizadosService examesAutorizadosService;
		ConsultaCodigoResult consultaCodigoResult = new ConsultaCodigoResult();
		final List<ConsultaCodigoResult> consultasCodigoResult = new ArrayList<>();
		try {
			examesAutorizadosService = new ConsultaExamesAutorizadosService(getHttpServletRequest());
			examesAutorizadosService.setValueObject(informacoesConvenio);
			examesAutorizadosService.consultar();
			if (examesAutorizadosService.isSuccess()) {
				consultaCodigoResult = (ConsultaCodigoResult) examesAutorizadosService.getResponseObject();
				consultasCodigoResult.add(consultaCodigoResult);
				mensagem = examesAutorizadosService.getResponseMessage();
				return consultaCodigoResult;
			} else {
				throw new Exception("Consulta aos exames autorizados falhou: " + mensagem + " Convenio: "
						+ informacoesConvenio.getConvenio() + " Plano: " + informacoesConvenio.getPlano());
			}
		} catch (final Exception exc) {
			throw new Exception("Exceção gerada ao buscar exames autorizados: " + exc.getMessage());
		}
	}

	public String getCachOption() {
		return Constantes.PARAM_APPLET_CACHE_OPTION;
	}

	private final Localidade retornarLocalidade() throws Exception {
		localidade = new Localidade();
		final LocalidadeService loLocalidadeService = new LocalidadeService(getHttpServletRequest());
		final Localidade paramLocalidade = new Localidade();
		String ipLocal = retornarIpValido();
		ipLocal = ipLocal + "0";
		localidade.setIp(ipLocal);
		paramLocalidade.setIp(ipLocal);
		loLocalidadeService.setValueObject(paramLocalidade);
		loLocalidadeService.getLocalidadeByIp();
		if (loLocalidadeService.isSuccess()) {
			return loLocalidadeService.getLocalidadeByIp();
		}
		throw new Exception(loLocalidadeService.getResponseMessage());
	}

	public String getLogInclusao() {
		return Constantes.PARAM_APPLET_LOGININCLUSAO;
	}

	public String getExibirProtocolo() {
		return Constantes.PARAM_APPLET_EXIBIR_PROTOCOLO;
	}

	public String getDiretorioRetorno() {
		return Constantes.PARAM_APPLET_DIRETORIO_RETORNO_WINDOWS;
	}

	public String getExibirWebService() {
		return Constantes.PARAM_APPLET_URL_WEBSERVICE;
	}

	public String getEnderecoArquivoConfiguracao() {
		try {
			return HttpUtil.obterHostName(getHttpServletRequest()) + Constantes.ARQUIVO_PROPERTIES_CONFIGURACAO;
		} catch (final Exception e) {
			return "";
		}
	}

	private Ws_respostaCobertura retornarCoberturaBeneficiario() throws RegraNegocioException {
		try {
			final ConsultaSituacaoCoberturaService situacaoCoberturaService = new ConsultaSituacaoCoberturaService(
					getHttpServletRequest());
			final Ct_beneficiario beneficiario = new Ct_beneficiario(numeroCarteira, "", "", null, null, null);
			final Ws_consultaSituacaoCobertura consultaSituacaoCobertura = situacaoCoberturaService
					.adicionarValoresAConsulta(beneficiario);
			return situacaoCoberturaService.consultar(consultaSituacaoCobertura);
		} catch (final Exception exc) {
			throw new RegraNegocioException("Erro ao buscar cobertura: " + exc.getMessage());
		}
	}

	private List<Procedimento> buscarProcedimentosEAdicionarComposicao() throws Exception {
		final List<Procedimento> procedimentos = new ArrayList<>();
		try {
			ComposicaoDTO[] composicoesArray = buscarComposicao();
			if (composicoesArray != null && composicoesArray.length >= 1) {
				final List<ComposicaoDTO> composicoes = new ArrayList(Arrays.asList(composicoesArray));
				adicionarProcedimentos(procedimentos, guiasAutorizadaSelecionada, composicoes);
			} else {
				adicionarProcedimentosSemComposicao(procedimentos, guiasAutorizadaSelecionada);
			}
			// por aqui um provavel adicionar procedimentos para os pais dos exames
			// calculados
			return procedimentos;
		} catch (final ExameCalculadoException exCalEx) {
			throw exCalEx;
		} catch (final Exception locExc) {
			throw new RuntimeException("Erro ao buscar procedimentos e adicionar composição!" + locExc.getMessage());
		}
	}

	public String retornarExameSemComposicao(String exameCompleto) {
		exameCompleto = exameCompleto.replaceAll("Composição:", "");
		return exameCompleto;
	}

	private void adicionarProcedimentosSemComposicao(final List<Procedimento> parProcedimentos,
			final Ct_dadosAutorizacao parLoc_dadosAutorizacao) throws Exception {
		for (final Ct_itemSolicitacao loc_itemSolicitacao : parLoc_dadosAutorizacao.getProcedimentos()) {
			for (int x = 1; chegouNoLimiteDaQuantidadeDe(loc_itemSolicitacao, x); x++) {
				parProcedimentos.add(new Procedimento(parLoc_dadosAutorizacao, loc_itemSolicitacao, null));
			}
			parProcedimentos.add(new Procedimento(parLoc_dadosAutorizacao, loc_itemSolicitacao));
		}
	}

	private void adicionarProcedimentos(final List<Procedimento> procedimentos,
			final Ct_dadosAutorizacao loc_dadosAutorizacao, final List<ComposicaoDTO> parComposicoes)
			throws RuntimeException {
		for (final Ct_itemSolicitacao loc_itemSolicitacao : loc_dadosAutorizacao.getProcedimentos()) {
			for (int quantidadeSolicitacao = 1; chegouNoLimiteDaQuantidadeDe(loc_itemSolicitacao,
					quantidadeSolicitacao); quantidadeSolicitacao++) {
				procedimentos.add(new Procedimento(loc_dadosAutorizacao, null, parComposicoes, loc_itemSolicitacao));
			}
			procedimentos.add(new Procedimento(loc_dadosAutorizacao, parComposicoes, loc_itemSolicitacao));
		}
	}

	private Long retornarComposicao(final List<ComposicaoDTO> parComposicoes, final Procedimento parProcedimento) {
		Long idComposicao = 0L;
		for (int x = 0; x < parComposicoes.size(); x++) {
			if (parComposicoes.get(x).getCodProced().equals(parProcedimento.getProcedimento())) {
				idComposicao = parComposicoes.get(x).getIdCtrlComposProcSolicItem();
				parComposicoes.remove(parComposicoes.get(x));
				return idComposicao;
			} else {
				return null;
			}
		}
		return null;
	}

	private String retornarSenhaAutorizacaoSemDigitioVerificacao(final String senhaAutorizacao) {
		try {
			if (!senhaAutorizacao.isEmpty()) {
				return senhaAutorizacao.substring(0, senhaAutorizacao.length() - 1);
			} else {
				return "0";
			}
		} catch (final Exception locExc) {
			return "0";
		}
	}

	private boolean chegouNoLimiteDaQuantidadeDe(final Ct_itemSolicitacao loc_itemSolicitacao, final int x) {
		return loc_itemSolicitacao.getQuantidadeAutorizada().compareTo(new BigDecimal(x)) == 1;
	}

	private boolean quantidadeAutorizadaEhMaiorQue_0(final Ct_itemSolicitacao loc_itemSolicitacao) {
		return loc_itemSolicitacao.getQuantidadeAutorizada().compareTo(new BigDecimal(0)) == 1;
	}

	public String irParaExames() {
		try {
			providencia = "";
			quantidadeExameVT = 0;
			procedimentos = new ArrayList<>();
			verificarSeGuiasForamSelecionadas();
			exibeListaExame = true;
			exibeSimplesExame = true;
			// FIXME VERIFICAR SE GLOSA VEM COM CARTEIRINHA INV�LIDA
			ws_respostaCobertura = retornarCoberturaBeneficiario();
			preencherExames(buscarProcedimentosEAdicionarComposicao());
			filtrarProcedimentosComExcecao();
			filtrarProcedimentos();
			procedimentosComExamesSelecionados = new ArrayList<>();
			verificarExamesSuspensos(procedimentosComExames);
			// verificar exames repetidos
			procedimentosComExames = verificarExamesRepetidos(procedimentosComExames);			
			procedimentosComExamesSelecionados.addAll(procedimentosComExames);
			setarDescricaoDefault();
			jaVerificouExamesCalcs = false;
			return "/pages/nau/exames.xhtml?faces-redirect=true";
		} catch (final RuntimeException locExc) {
			gerarLogErroAoBuscarExames(locExc.getMessage());
			return "/pages/nau/exames.xhtml?faces-redirect=true";
		} catch (final RegraNegocioException locExc) {
			gerarLogErroAoBuscarExames(locExc.getMessage());
			MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso(locExc.getMessage());
			if (guiasAutorizadaSelecionada != null) {
				mensagemAviso
						.setGuia(guiasAutorizadaSelecionada.getIdentificacaoAutorizacao().getNumeroGuiaOperadora());
			}
			try {
				getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return redirectAtendimentoNaoConcluido();
		} catch (final SelecaoCampoException locExc) {
			// gerarLogAoBuscarExames(locExc.getMessage()); //n�o gerar log para valida��o
			// de campo
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
			return null;
		} catch (final ExameCalculadoException exaEx) {
			return null;
		} catch (final Exception locExc) {
			gerarLogErroAoBuscarExames(locExc.getMessage());
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
			return null;
		}
	}

	private List<ProcedimentoComExamesTO> verificarExamesRepetidos(
			List<ProcedimentoComExamesTO> procedimentosComExamesSelecionados2) {
		List<ProcedimentoComExamesTO> procedimentoSemRepeticao = new ArrayList<ProcedimentoComExamesTO>();
		Integer i = 1;
		for (ProcedimentoComExamesTO proExamesTO : procedimentosComExamesSelecionados2) {
			proExamesTO.setId(i);
			i++;
			if (Util.customFrequencyProcedimento(procedimentosComExamesSelecionados2, proExamesTO) > 1) {
				proExamesTO.getExames().add(0, new ExameHermesPardini("Selecione"));
				proExamesTO.setExame(null);
				proExamesTO.setRepetido(true);
			}
			procedimentoSemRepeticao.add(proExamesTO);
		}
		return procedimentoSemRepeticao;
	}
	
	private void verificarExamesSuspensos(List<ProcedimentoComExamesTO> procedimentosComExamesSelecionados2) throws Exception {
		boolean temExameSuspenso = false;
		boolean todosExamesSuspensos = false;
		StringBuilder msgExameSuspenso = new StringBuilder();
		List<String> listMsgExameSuspensoLista = new ArrayList<>();
		for (ProcedimentoComExamesTO proExamesTO : procedimentosComExamesSelecionados2) {
			todosExamesSuspensos = true;
			boolean temExameSuspensoNaLista = false;
			StringBuilder msgExameSuspensoLista = new StringBuilder();
			
			if(Objects.isNull(proExamesTO.getExame()) && proExamesTO.getExames().isEmpty()) {
				String descricaoExame = proExamesTO.getDescricao();
				if(!listMsgExameSuspensoLista.contains(descricaoExame)) {
					listMsgExameSuspensoLista.add(descricaoExame);
					msgExameSuspensoLista.append(descricaoExame).append(", ");
				}
			}
			
			for (ExameHermesPardini exame : proExamesTO.getExames()) {
				if(!exame.getDescricaoExame().equals("Selecione")) {
					if(!("S").equals(exame.getSituacao())) {
						todosExamesSuspensos = false;
					} 
					if(!Objects.isNull(exame.getSituacao()) && ("S").equals(exame.getSituacao())){
						temExameSuspensoNaLista = true;
						String descricaoExame = exame.getDescricaoExame();
						if(!listMsgExameSuspensoLista.contains(descricaoExame)) {
							listMsgExameSuspensoLista.add(descricaoExame);
							msgExameSuspensoLista.append(descricaoExame).append(", ");
						}
					}
				}
			}
			if(todosExamesSuspensos) {
				temExameSuspenso = true;
				msgExameSuspenso.append(msgExameSuspensoLista);
			} else if(temExameSuspensoNaLista && !Objects.isNull(proExamesTO.getExame())){
				proExamesTO.getExames().add(0, new ExameHermesPardini("Selecione"));
				proExamesTO.setExame(null);
			}
		}
		if(temExameSuspenso) {
			StringBuilder msgExcecaoExameSuspenso = new StringBuilder();
			msgExcecaoExameSuspenso.append("O(s) exame(s) ").append(msgExameSuspenso.toString()).append(" está(ão) suspenso(s). Favor realizar o processo de separação de guia e efetuar nova tentativa.");
			throw new Exception(msgExcecaoExameSuspenso.toString());
		}
	}

//	private void verificarExamesCalculados(List<Ct_itemSolicitacao> procedimentosGuia) throws Exception {
//		if (jaVerificouExamesCalcs && combinacaoExamesCalculados.size() > 0) {
//			combinacaoUniao = tipoCalculoExames();
//			RequestContext.getCurrentInstance().execute("PF('dlgExamesCalc').show();");
//			throw new ExameCalculadoException("validar exames calc");
//		}
//		else if (jaVerificouExamesCalcs && combinacaoExamesCalculados.isEmpty()){
//			return;
//		}
//		jaVerificouExamesCalcs = true;
//					
//		ExamesCalculadosBean calculadosBean = new ExamesCalculadosBean();
//		List<ExamePreCalculado> listaExamesPreCalcGuia = procedimentosGuia.stream()
//				.map(itemSol -> new ExamePreCalculado(itemSol.getIdentificacaoProcedimentos().getDescricao().toUpperCase(),
//						itemSol.getIdentificacaoProcedimentos().getCodigo(),
//						itemSol.getQuantidadeAutorizada()))
//				.collect(Collectors.toCollection(ArrayList<ExamePreCalculado>::new));
//				
//		if (calculadosBean.existeExamesCalculos(listaExamesPreCalcGuia)) {			
//			combinacaoExamesCalculados = calculadosBean.getPossiveisCalculosNew(procedimentosGuia, listaExamesPreCalcGuia);
//			combinacaoUniao = tipoCalculoExames();
//			RequestContext.getCurrentInstance().execute("PF('dlgExamesCalc').show();");
//			throw new ExameCalculadoException("validar exames calc");
//		}		
//	}

	private void verificarExamesCalculados(List<ProcedimentoComExamesTO> procedimentoComExamesTOs) throws Exception {
		// jaVerificouExamesCalcs = false;
		if (!jaVerificouExamesCalcs) {
			combinacaoPaiFilhos = ExameCalculadoDAO.getTodasCombinacoes();

			calculadoBean = new ExameCalculadoBean(combinacaoPaiFilhos);
			if (calculadoBean.existeCombinacaoPossivel(procedimentoComExamesTOs)) {
				combinacaoExamesCalculados = calculadoBean.retornaPossiveisCombinacoes(procedimentoComExamesTOs);
			}
			jaVerificouExamesCalcs = true;
		}

		if (jaVerificouExamesCalcs && calculadoBean.existeCombinacaoPossivel(procedimentoComExamesTOs)) {
			combinacaoExamesCalculados = calculadoBean.retornaPossiveisCombinacoes(procedimentoComExamesTOs);
			combinacaoUniao = tipoCalculoExames();
			RequestContext.getCurrentInstance().execute("PF('dlgExamesCalc').show();");
			throw new ExameCalculadoException("validar exames calc");
		} else {
			jaVerificouExamesCalcs = true;
			RequestContext.getCurrentInstance().execute("PF('dlgExamesCalc').hide()");
			return;
		}

	}

	private boolean tipoCalculoExames() {
		if (getCombinacao() == null)
			return false;
		return TypeCalculo.SUBSTITUI.equals(getCombinacao().getKey().getTipoCalculo());
	}

	public String realizaCalculoExames(Entry<ExameSimplificado, List<ExameSimplificado>> examesPaiFilhos) {

		if (TypeCalculo.DESMEMBRA.equals(examesPaiFilhos.getKey().getTipoCalculo())) {
			List<ProcedimentoComExamesTO> novaLista = (calculadoBean.retornaProcedimentosGuiaDesmembra(
					procedimentosComExames, examesPaiFilhos.getValue(), examesPaiFilhos.getKey()));
			procedimentosComExames = novaLista;
			procedimentosComExamesSelecionados = novaLista;

			gerarLogExamesCalculados("Realizado exames Calculados - Desmembramento. Exames Pai: "
					+ examesPaiFilhos.getKey().getCodigo() + "). Exames Filho: (" + examesPaiFilhos.getValue().stream()
							.map(codigos -> codigos.getCodigo()).collect(Collectors.toList())
					+ ")");
		} else if (TypeCalculo.SUBSTITUI.equals(examesPaiFilhos.getKey().getTipoCalculo())) {
			List<ProcedimentoComExamesTO> novaLista = (calculadoBean.retornaProcedimentosGuiaSubst(
					procedimentosComExames, examesPaiFilhos.getValue(), examesPaiFilhos.getKey()));

			procedimentosComExames = novaLista;
			procedimentosComExamesSelecionados = novaLista;
			gerarLogExamesCalculados("Realizado exames Calculados - Substituicao. Exames Pai: "
					+ examesPaiFilhos.getKey().getCodigo() + "). Exames Filho: (" + examesPaiFilhos.getValue().stream()
							.map(codigos -> codigos.getCodigo()).collect(Collectors.toList())
					+ ")");
		}

		combinacaoPaiFilhos.remove(examesPaiFilhos.getKey().getExame().getMnemonicoConcat());
		RequestContext.getCurrentInstance().execute("PF('dlgExamesCalc').hide()");

		return avancarPedido();

	}

	public String naoRealizaCalculoExames(Entry<ExameSimplificado, List<ExameSimplificado>> examesPaiFilhos) {
		combinacaoExamesCalculados.remove(examesPaiFilhos.getKey());
		combinacaoPaiFilhos.remove(examesPaiFilhos.getKey().getExame().getMnemonicoConcat());
		RequestContext.getCurrentInstance().execute("PF('dlgExamesCalc').hide()");
		return "";
	}

	public Entry<ExameSimplificado, List<ExameSimplificado>> getCombinacao() {
		if (combinacaoExamesCalculados.isEmpty())
			return null;
		Set<Map.Entry<ExameSimplificado, List<ExameSimplificado>>> combinacaoSet = combinacaoExamesCalculados
				.entrySet();
		return new ArrayList<Entry<ExameSimplificado, List<ExameSimplificado>>>(combinacaoSet).get(0);
	}

	private void setarDescricaoDefault() {
		for (final ProcedimentoComExamesTO procedimento : procedimentosComExamesSelecionados) {
			if (procedimento.getExame() != null && procedimento.getExame().getMaterial().equals("DIV")) {
				if (procedimento.getExame().getExame().equals("UR")) {
					procedimento.setInformacoesAdicionais("URINA JATO MÉDIO");
				}
				if (procedimento.getExame().getExame().equals("PFLIP")) {
					procedimento.setInformacoesAdicionais("SANGUE");
				}
			}
		}
	}

	private void gerarLogAoBuscarExames(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, retornarCodigo());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, TotemUtil.buscarSessionId(),
					createBasicLogMap());
		} catch (final Exception exc) {
		}
	}

	private void gerarLogErroAoBuscarExames(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, retornarCodigo());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, TotemUtil.buscarSessionId(),
					createBasicLogMap());
		} catch (final Exception exc) {
		}
	}

	private ComposicaoDTO[] buscarComposicao() {
		try {
			final ComposicaoService composicaoService = new ComposicaoService(getHttpServletRequest());
			if (guiasAutorizadaSelecionada != null) {
				return composicaoService.consultar(Long.parseLong(retornarSenhaAutorizacaoSemDigitioVerificacao(
						guiasAutorizadaSelecionada.getDadosAutorizacao().getSenhaAutorizacao())), null);
			} else {
				getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, retornarCodigo());
				registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(), "Erro ao buscar composição!",
						sessionId, createBasicLogMap());
				return null;
			}
		} catch (final Exception locExc) {
			gerarLogErroAoBuscarComposicao(locExc.getMessage());
			return null;
		}
	}

	private void gerarLogErroAoBuscarComposicao(final String parMensagem) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, retornarCodigo());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMensagem, TotemUtil.buscarSessionId(),
					createBasicLogMap());
		} catch (final Exception locExc) {
		}
	}

	private void gerarLogExamesCalculados(final String mensagem) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, retornarCodigo());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), mensagem, TotemUtil.buscarSessionId(),
					createBasicLogMap());
		} catch (final Exception locExc) {
		}
	}

	private void preencherExames(final List<Procedimento> parProcedimentosSelecionados) throws RegraNegocioException {
		procedimentosComExames = new ArrayList<>();
		final List<ProcedimentoComExamesTO> procedimentosComExamesCompleta = new ArrayList<>();
		final List<ProcedimentoComExamesTO> procedimentosComExamesFiltrados = new ArrayList<>();
		examesExcecao = new ArrayList<>();
		try {
			for (final Procedimento locProcedimento : parProcedimentosSelecionados) {
				ConsultaCodigoResult consultaCodigoResult = new ConsultaCodigoResult();
				consultaCodigoResult = buscarExamesAutorizados(
						new InformacaoConvenio(locProcedimento, ws_respostaCobertura, tokenResult, retornarUnidade(),
								numeroCarteira, clienteUnidadePasseLivre));
//				if (ExamesCalculadosDAO.getCodigosExamePais().contains(locProcedimento.getProcedimento()) 
//						&& consultaCodigoResult.getExames().isEmpty()) {
//					preencherExamePaiCalculado(consultaCodigoResult, locProcedimento);
//				}
				clienteUnidadePasseLivre.setOperadora(consultaCodigoResult.getOperadora());
				verificarSeExamesForamPreenchidos(consultaCodigoResult, locProcedimento);
				procedimentosComExamesCompleta.add(new ProcedimentoComExamesTO(locProcedimento, consultaCodigoResult));
				filtrarDadosAoProcedimentosComExames(locProcedimento, consultaCodigoResult,
						procedimentosComExamesFiltrados);
				verificarSeExisteMaisDeUmExame(locProcedimento, consultaCodigoResult);
			}
			filtrarExamesComExcecao(procedimentosComExamesCompleta);
		} catch (final Exception exc) {
			exc.printStackTrace();
			throw new RegraNegocioException("Erro ao preencher exames!" + exc.getMessage());
		}
	}

	private void preencherExamePaiCalculado(ConsultaCodigoResult codigoResult, Procedimento procedimento) {
		codigoResult.setExames(ExamesCalculadosDAO.getDadosExameHPbyCod(procedimento.getProcedimento()));
	}

	private String retornarUnidade() {
		if (informacoesTotem == null || informacoesTotem.isEmpty()) {
			return null;
		} else {
			return informacoesTotem.get(0).getIdUnidade();
		}
	}

	private void verificarSeExamesForamPreenchidos(final ConsultaCodigoResult parConsultaCodigoResult,
			final Procedimento parProcedimento) {
		try {
			if (parConsultaCodigoResult.getExames().isEmpty()) {
				getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN,
						clienteUnidadePasseLivre.getCodigoCliente());
				registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(),
						MensagemUtil.retornarMensagemAoVerificarSeExamesForamPreenchidos(parProcedimento),
						TotemUtil.buscarSessionId(), createBasicLogMap());

			}
		} catch (final Exception locExc) {
		}
	}

	private void verificarSeExisteMaisDeUmExame(final Procedimento locProcedimento,
			final ConsultaCodigoResult consultaCodigoResult) throws Exception {
		if (existeMaisDeUmExameParaOProcedimento(consultaCodigoResult)) {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, retornarCodigo());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(),
					retornarMensagemProcedimentoComVariosExames(locProcedimento, consultaCodigoResult),
					TotemUtil.buscarSessionId(), createBasicLogMap());
		}
	}

	private void filtrarProcedimentos() {
		final AplicaExcecaoProcedimentoFactory aplicaExcecaoProcedimentoFactory = new AplicaExcecaoProcedimentoFactory();
		procedimentosComExames = aplicaExcecaoProcedimentoFactory.retornarProcedimentosFiltrados(procedimentosComExames,
				excecaoAtendimentoResult);
		Collections.sort(procedimentosComExames);
	}

	private void filtrarProcedimentosComExcecao() throws Exception {
		final AplicaExcecaoProcedimentoFactory aplicaExcecaoProcedimentoFactory = new AplicaExcecaoProcedimentoFactory();
		procedimentosComExamesExcecao = new ArrayList<>();
		procedimentosComExamesExcecao.addAll(aplicaExcecaoProcedimentoFactory
				.retornarProcedimentosFiltradosExcecao(procedimentosComExames, excecaoAtendimentoResult));
		gerarLogParaProcedimentosExcluidosDoTotem();
	}

	private void gerarLogParaProcedimentosExcluidosDoTotem() throws Exception {
		for (final ProcedimentoComExamesTOExcecao procedimentoComExamesTOExcecao : procedimentosComExamesExcecao) {
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(),
					MensagemUtil.retornarMensagemParaProcedimentosExcluidos(
							procedimentoComExamesTOExcecao.getProcedimento(),
							retornarMotivoParaProcedimentoNaoAtendido(procedimentoComExamesTOExcecao)),
					sessionId, createBasicLogMap());
		}
	}

	// FIXME Verificar melhor a regra para buscar o motivo real de não atendimento
	// do procedimento.
	private String retornarMotivoParaProcedimentoNaoAtendido(
			final ProcedimentoComExamesTOExcecao procedimentoComExamesTOExcecao) {
		try {
			return procedimentoComExamesTOExcecao.getGlosas().get(0).getDescricaoGlosa();
		} catch (final Exception locExc) {
			return "";
		}
	}

	private boolean existeMaisDeUmExameParaOProcedimento(final ConsultaCodigoResult consultaCodigoResult) {
		return consultaCodigoResult.getExames().size() > 1;
	}

	private void filtrarDadosAoProcedimentosComExames(final Procedimento locProcedimento,
			final ConsultaCodigoResult consultaCodigoResult,
			final List<ProcedimentoComExamesTO> procedimentosComExamesFiltrados) {
		procedimentosComExamesFiltrados
				.add(new ProcedimentoComExamesTO(locProcedimento, consultaCodigoResult, excecaoAtendimentoResult, ""));
		adicionarSequenciaAoProcedimentosComExames(procedimentosComExamesFiltrados, locProcedimento,
				consultaCodigoResult);
	}

	private void adicionarSequenciaAoProcedimentosComExames(
			final List<ProcedimentoComExamesTO> procedimentosComExamesFiltrados, final Procedimento parLocProcedimento,
			final ConsultaCodigoResult parConsultaCodigoResult) {
		procedimentosComExames.add(new ProcedimentoComExamesTO(procedimentosComExamesFiltrados, parLocProcedimento,
				excecaoAtendimentoResult, parConsultaCodigoResult, ""));
	}

	private void filtrarExamesComExcecao(final List<ProcedimentoComExamesTO> procedimentosComExamesCompleta)
			throws Exception {
		final AplicaExcecaoExameFactory aplicaExcecaoProcedimentoFactory = new AplicaExcecaoExameFactory();
		for (final ProcedimentoComExamesTO locProcedimentoComExamesTO : procedimentosComExamesCompleta) {
			examesExcecao.addAll(aplicaExcecaoProcedimentoFactory
					.retornarExamesExcecao(locProcedimentoComExamesTO.getExames(), excecaoAtendimentoResult));
		}
		gerarLogParaExamesExcluidosDoTotem();
	}

	private void gerarLogParaExamesExcluidosDoTotem() throws Exception {
		for (final ExameHermesPardini exameHermesPardini : examesExcecao) {
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(),
					"Log para exames não atendidos pelo totem: " + exameHermesPardini.toString() + " Motivo:"
							+ exameHermesPardini.getObservacao(),
					sessionId, createBasicLogMap());
		}
	}

	private String retornarMensagemProcedimentoComVariosExames(final Procedimento locProcedimento,
			final ConsultaCodigoResult consultaCodigoResult) {
		return "Na guia: " + locProcedimento.getGuia() + " com o procedimento UNIMED:"
				+ locProcedimento.getProcedimento() + " trouxe mais de uma relacionamento:"
				+ retornarApenasExames(consultaCodigoResult.getExames());
	}

	private String retornarApenasExames(final List<ExameHermesPardini> paraExames) {
		String exames = "";
		for (final ExameHermesPardini locExameHermesPardini : paraExames) {
			if (locExameHermesPardini.getExame() != null) {
				exames += locExameHermesPardini.getExame() + "/" + locExameHermesPardini.getMaterial() + ", ";
			}
		}
		return exames;
	}

	private void verificarSeGuiasForamSelecionadas() throws SelecaoCampoException {
		if (guiasAutorizadaSelecionada == null) {
			throw new SelecaoCampoException("A guia deve ser selecionada!");
		}
	}

	public Boolean getHabilitarListaExames() {
		if (exames.size() == 1) {
			return true;
		} else {
			return false;
		}
	}

	public Boolean getHabilitarSimplesExames() {
		if (exames.size() > 1) {
			return true;
		} else {
			return false;
		}
	}

	private void habilitarListaExames(final List<ExameHermesPardini> parExames) {
		try {
			if (parExames.size() == 1) {
				exibeListaExame = false;
				exibeSimplesExame = true;
			} else {
				if (parExames.size() > 1) {
					exibeListaExame = true;
					exibeSimplesExame = false;
				}
			}
		} catch (final Exception exc) {
		}
	}

	private void gerarQuestionario() throws RegraNegocioException {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, retornarCodigo());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, TotemUtil.buscarSessionId(),
					createBasicLogMap());
			mtdQuestionario = new MasterDetail();
			questionario = new Questionario();
			mdlQuestionario = new MasterDetailLevel();
			mapQuestionarios = new HashMap<>();
			pngQuestionario = new PanelGrid();
			pngQuestionario.setStyleClass("pngQuestionario");
			pngQuestionario.setColumns(3);
			pngQuestionario.setStyle("height: 250px;");
			pnlQuestionario = new Panel();
			mtdQuestionario.setShowBreadcrumb(false);
			mtdQuestionario.setId("mtdQuestionario");
			buscarQuestionario();
		} catch (final Exception locExc) {
			gerarLogErroAoGerarQuestionario(locExc.getMessage());
			throw new RegraNegocioException(locExc.getMessage());
		}
	}

	private void gerarLogErroAoGerarQuestionario(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, retornarCodigo());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, TotemUtil.buscarSessionId(),
					createBasicLogMap());
		} catch (final Exception exc) {
		}
	}

	public String fazerPedido() {
		try {
			// gerarLogProcedimentosExcluidos(); //n�o gerar log para procedimentos
			// exclu�dos pelo usu�rio
			preencherQuestionario();
			buscarInformacaoTotem();
			parametroPedido = criarParametroPedido();

			// HARDCODE - Solicitado pelo John, colocar conv�nio UNDRIV quando tiver somente
			// um exame e for para corona identico ao codigo enviado pela Renata
			/*
			 * - ATUALIZA��O - SOLICITADO REMO��O EM 14-08-2020 if
			 * (parametroPedido.getGuias().size() == 1) { if
			 * (parametroPedido.getGuias().get(0).getExames().size() == 1 &&
			 * parametroPedido.getGuias().get(0).getExames().get(0).getCodigoExame().equals(
			 * "40314618")) { parametroPedido.getPaciente().setOperadora("UNDRIV"); } }
			 */
			verificarSeExamesEmVTEstaoCoerentes();
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, retornarCodigo());
			new MensagemUtil();
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(),
					MensagemUtil.retornarMensagemAoIniciarPedido(retornarSenhaDaGuia()), TotemUtil.buscarSessionId(),
					createBasicLogMap());
			final PedidoService pedidoService = new PedidoService(getHttpServletRequest());
			confirmarPedido();
			pedidoService.fazerPedido(parametroPedido);
			gerarLogEstatistico();
			if (pedidoService.isSuccess()) {
				locCriarPedidoResult = (CriarPedidoResult) pedidoService.getResponseObject();
				pedidoService.getResponseMessage();
				numeroPedido = locCriarPedidoResult.getPedido();
				acoesAposPedidoRealizadoComSucesso(locCriarPedidoResult);
				registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(),
						MensagemUtil.retornarMensagemAoFinalizarPedido(locCriarPedidoResult.getPedido(),
								locCriarPedidoResult.getUnidade()),
						sessionId, createBasicLogMap());
				fazerImpressaoQuestionario();
			} else {
				gerarLogErroAoFazerPedido("Retorno do serviço: " + pedidoService.getResponseMessage());
				MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso(pedidoService.getResponseMessage());
				mensagemAviso.setNumeroCarteira(numeroCarteira);
				mensagemAviso.setGuia(parametroPedido.getGuias().get(0).getNumeroGuiaOperadora());
				try {
					getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
				} catch (Exception e) {
					log.error("Erro ao atribuir mensagem de aviso. ", e);
				}
				// return redirectAtendimentoNaoConcluido();
				return redirectAtendimentoConcluido();
			}
			MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso(pedidoService.getResponseMessage());
			mensagemAviso.setNumeroCarteira(numeroCarteira);
			mensagemAviso.setGuia(parametroPedido.getGuias().get(0).getNumeroGuiaOperadora());
			try {
				getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
			} catch (Exception e) {
				log.error("Erro ao atribuir mensagem de aviso. ", e);
			}

			providencia = "";
			setMsgTelaFinalizacao("Detalhes foram enviados para o seu e-mail.");
			return redirectAtendimentoConcluido();

		} catch (final ImpressaoException exc) {
			log.error(exc.getMessage(), exc);
			gerarLogErroAoFazerPedido(MensagemUtil.retornarMensagemErroAoFazerPedido(exc.getMessage(),
					locCriarPedidoResult, informacoesTotem));
			gerarLogEstatistico();
			setMsgTelaFinalizacao("Falha ao fazer impressão de GA!");
			return redirectAtendimentoConcluido();

		} catch (final EnvioEmailException exc) {
			providencia = "";
			log.error(exc.getMessage(), exc);
			gerarLogErroEmailAoFazerPedido(MensagemUtil.retornarMensagemErroAoFazerPedido(exc.getMessage(),
					locCriarPedidoResult, informacoesTotem));
			gerarLogEstatistico();

			setMsgTelaFinalizacao("Falha ao enviar o email!");
			return redirectAtendimentoConcluido();

		} catch (final Exception exc) {
			log.error(exc.getMessage(), exc);
			gerarLogErroAoFazerPedido(exc.getMessage());
			MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso(exc.getMessage());
			mensagemAviso.setNumeroCarteira(numeroCarteira);
			mensagemAviso.setGuia(parametroPedido.getGuias().get(0).getNumeroGuiaOperadora());
			try {
				getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
			} catch (Exception e) {
				log.error("Erro ao atribuir mensagem de aviso. ", e);
			}
			return redirectAtendimentoNaoConcluido();
		} finally {
		}
	}

	private ParametroPedido criarParametroPedido() throws Exception {
		final ParametroPedido locParametroPedido = new ParametroPedido(guiasAutorizadaSelecionada, procedimentosComExamesParaGerarPedido,
				questionariosExamesResult, informacaoTotem, perguntas, clienteUnidadePasseLivre,
				ws_respostaCobertura, tokenResult, sessionId, providencia);
		
		if (agendamentoUnidade != null && agendamentoUnidade.getDataAgendada() != null) {
			final Agenda agenda = new Agenda();
			agenda.setIdAgendamento(agendamentoUnidade.getIdAgendamento());
			agenda.setDataHoraAgendamento(formataDataAgendamento(agendamentoUnidade));
			// agenda.setTipoServico(agendamentoUnidade.getTipoServico());
			// agenda.setRecursoAgenda(agendamentoUnidade.getGrupoMedicoEspecialidade());
			// agenda.setSequencia(agendamentoUnidade.getSequencia());
			locParametroPedido.setAgenda(agenda);
			locParametroPedido.setGuias(corrigeDataHoraMarcacaoParaExameAgendado(locParametroPedido.getGuias()));
		}
		return locParametroPedido;
	}

	private Guias corrigeDataHoraMarcacaoParaExameAgendado(Guias guias) throws Exception {
		for(final Guia guia : guias) {
			for (ExamePedido exame : guia.getExames()) {
				if(ehExameAgendado(exame, agendamentoUnidade)) {
					exame.setDataHoraMarcacao(recuperaDataHoraMarcacao(agendamentoUnidade));
				}
			}
		}
		return guias;
	}
	
	private boolean ehExameAgendado(ExamePedido parExame, AgendamentoUnidade parAgendUnidade) {
	    return parAgendUnidade != null && parAgendUnidade.getExame().equals(parExame.getExame());
	}
	  
	private String recuperaDataHoraMarcacao(AgendamentoUnidade parAgendUnidade) throws Exception {
	    final PedidoService pedidoService = new PedidoService(getHttpServletRequest());
	    final ParametroDataPrevisaoResultado parametroDataPrevisao = new ParametroDataPrevisaoResultado(parAgendUnidade, tokenResult);
	    pedidoService.obterDataHoraMarcacaoExamesEspeciais(parametroDataPrevisao);
	    if(pedidoService.isSuccess()) {
	        return (String) pedidoService.getResponseObject();
	    } else {
	        throw new Exception(pedidoService.getResponseMessage());
	    }
	}

	private String formataDataAgendamento(final AgendamentoUnidade agendamentoUnidade) {
		String dataFormatada = "";
		final SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		dataFormatada = formatter.format(agendamentoUnidade.getDataAgendada());
		dataFormatada = dataFormatada.concat(" ");
		dataFormatada = dataFormatada.concat(agendamentoUnidade.getHorarioAgendado());
		return dataFormatada;
	}

	private void fazerImpressaoQuestionario() {
		try {
			if (consultaQuestionarioExameResult != null
					&& !consultaQuestionarioExameResult.getQuestionarios().isEmpty()) {
				for (final Questionario locQuestionario : consultaQuestionarioExameResult.getQuestionarios()) {
					if (locQuestionario.getImpresso().equals("S")) {
						imprimirQuestionario();
					}
				}
			}
		} catch (Exception e) {
		}
	}

	private void imprimirQuestionario() throws Exception {
		final QuestionarioService questionarioService = new QuestionarioService(getHttpServletRequest());
		try {
			final ParametroImpressaoQuestionario locParametroImpressaoQuestionario = new ParametroImpressaoQuestionario(
					parametroQuestionario, procedimentosComExames, informacaoTotem.getImpressoraDefault());
			questionarioService.setValueObject(locParametroImpressaoQuestionario);
			questionarioService.imprimir();
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(),
					MensagemUtil.retornaMensagemQuestionarioImpresso(true), TotemUtil.buscarSessionId(),
					createBasicLogMap());
		} catch (final Exception locExc) {
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(),
					MensagemUtil.retornaMensagemQuestionarioImpresso(false), TotemUtil.buscarSessionId(),
					createBasicLogMap());
			// throw new Exception(questionarioService.getResponseMessage());
		}
	}

	private void gerarLogProcedimentosExcluidos() {
		try {
			if (procedimentosExcluidos != null && !procedimentosExcluidos.isEmpty()) {
				for (final ProcedimentoComExamesTO locProcedimentoComExamesTO : procedimentosExcluidos) {
					getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, retornarCodigo());
					registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
							Thread.currentThread().getStackTrace()[1].getMethodName(),
							MensagemUtil.retornarMensagemParaProcedimentoExcluidosPeloUsuario(numeroCarteira,
									locProcedimentoComExamesTO),
							sessionId, createBasicLogMap());
				}
			}
		} catch (final Exception locExc) {
		}
	}

	private void buscarInformacaoTotem() throws RegraNegocioException {
		for (final InformacaoTotem localInformacaoTotem : informacoesTotem) {
			if (localInformacaoTotem.getIp().equalsIgnoreCase(retornarNomeDaMaquina())
					&& localInformacaoTotem.getDescricao().equals(Constantes.SERVICO_ATENDIMENTO_UNIMED)) {
				informacaoTotem = localInformacaoTotem;
			}
		}
	}

	private String retornarNomeDaMaquina() throws RegraNegocioException {
		try {
			final IndexService indexService = new IndexService();
			return indexService.retornarNomeMaquina(getHttpServletRequest());
		} catch (final Exception exc) {
			exc.printStackTrace();
			gerarLogAoRetornarNomeDaMaquina(exc.getMessage());
			throw new RegraNegocioException(exc.getMessage());
		}
	}

	private void gerarLogAoRetornarNomeDaMaquina(final String parMessage) {
		try {
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, TotemUtil.buscarSessionId(),
					createBasicLogMap());
		} catch (final Exception locExc) {
		}
	}

	public void fazerAtualizacao() {
		houveAlteracao = true;
	}

	private void verificarSeExamesEmVTEstaoCoerentes() throws RegraNegocioException {
		final Integer quantidadeVTNoPedido = retornarQuantidadeEmVt();
		if (quantidadeExameVT != quantidadeVTNoPedido) {
			throw new RegraNegocioException(MensagemUtil.retornarMensagemErroInconsistenciaVt(quantidadeVTNoPedido,
					quantidadeExameVT, mensagemAviso));
		}
	}

	private Integer retornarQuantidadeEmVt() {
		Integer localQuanddadeExaneVt = 0;
		for (final ProcedimentoComExamesTO locProcedimentoComExame : procedimentosComExamesParaGerarPedido) {
			if (locProcedimentoComExame.getVt() && !locProcedimentoComExame.getExcluido()) {
				localQuanddadeExaneVt += 1;
			}
		}
		return localQuanddadeExaneVt;
	}

	private void acoesAposPedidoRealizadoComSucesso(final CriarPedidoResult locCriarPedidoResult)
			throws EnvioEmailException, ImpressaoException {
		if (getAmbienteProducao()) {
			// imprimirGA(locCriarPedidoResult);
			enviarEmailPedidoFinalizado(locCriarPedidoResult);
		}
	}

	public void fecharDialogImprimirGA() {
		RequestContext.getCurrentInstance().execute("PF('dlgimprimirGA').hide()");
	}

	private String retornarSenhaDaGuia() {
		try {
			if (guiasAutorizadaSelecionada.getDadosAutorizacao().getSenhaAutorizacao() != null) {
				return guiasAutorizadaSelecionada.getDadosAutorizacao().getSenhaAutorizacao();
			}
			return "";
		} catch (final Exception locExc) {
			return "";
		}
	}

	private void gerarLogEstatistico() {
		try {
			final ControleEstatisticoService controleEstatisticoService = new ControleEstatisticoService(
					getHttpServletRequest());
			final ControleEstatistico controleEstatistico = new ControleEstatistico(
					clienteUnidadePasseLivre.getCodigoCliente(), null, retornarDescricaoDeServico(),
					informacoesTotem.get(0).getId(), null, null, retornarUnidade());
			controleEstatisticoService.insert(controleEstatistico);
		} catch (final Exception locExc) {
			gerarLogErroAoGerarLogEstatistico("Erro ao gerar log Estatístico " + locExc.getMessage());
		}
	}

	private String retornarDescricaoDeServico() {
		if (isExisteExameDeImagem()) {
			if (agendamentoUnidade != null && agendamentoUnidade.getDataAgendada() != null) {
				return FuncaoLogEstatistico.REALIZAR_ATENDIMENTO_IMAGEM_AGENDADO.toString();
			} else {
				return FuncaoLogEstatistico.REALIZAR_ATENDIMENTO_IMAGEM.toString();
			}
		} else {
			return FuncaoLogEstatistico.REALIZAR_ATENDIMENTO.toString();
		}
	}

	private void confirmarPedido() throws Exception, HashInvalido, RemetenteInvalido, VersaoInvalida,
			DestinatarioInvalido, RemoteException, ParseException {
		try {
			if (getAmbienteProducao()) {
				final Localidade localidade = adicionarIpALocalidade();
				this.localidade = localidade;
				String codigoPrestadorUnimed = localidade.getCodigounimed();
				if (codigoPrestadorUnimed != null) {
					getSession().setAttribute("codigoPrestadorUnimed", codigoPrestadorUnimed);
				} else {
					getSession().setAttribute("codigoPrestadorUnimed", Constantes.CODIGO_PRESTADOR_HERMESPARDINI);
				}
				final AtendimentoService atendimentoService = new AtendimentoService(getHttpServletRequest());
				registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(),
						"Início processo: Confirmar guia servi�o Unimed", TotemUtil.buscarSessionId(),
						createBasicLogMap());
				final Ws_respostaComunicacao ws_respostaComunicacao = atendimentoService.confirmarAtendimento(
						guiasAutorizadaSelecionada, retornarLocalAtendimento(localidade), retornarCodigoLabCdt());
				registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(),
						MensagemUtil.retornarMensagemAoConfirmarPedido(retornarSenhaDaGuia()),
						TotemUtil.buscarSessionId(), createBasicLogMap());
				// 09 - patologia, 03 - imagem
				if (ws_respostaComunicacao != null) {
					for (final Ct_respostaComunicacao localCt_respostaComunicacao : ws_respostaComunicacao
							.getRespostaComunicacao()) {
						if (!localCt_respostaComunicacao.getRespostaComunicacao().equals("1")) {
							throw new Exception("Resposta UNIMED:" + MensagemUtil.retornarMensagemErroAoConfirmarPedido(
									localCt_respostaComunicacao.getDadosBeneficiario().getNumeroCarteira(),
									retornarSenhaAutorizada(),
									localCt_respostaComunicacao.getGlosas(0).getDescricaoGlosa() + " Cod. Prestador: ("
											+ codigoPrestadorUnimed + ") Local Atendimento: "
											+ retornarLocalAtendimento(localidade) + " Unidade:" + retornarUnidade()));
						}
					}
				}
			}
		} catch (final Exception e) {
			throw new Exception("Exception: "
					+ MensagemUtil.retornarMensagemErroAoConfirmarPedido(numeroCarteira, retornarSenhaAutorizada(),
							e.getMessage() + " Cod. Prestador: (" + localidade.getCodigounimed()
									+ ") Local Atendimento: " + retornarLocalAtendimento(localidade) + " unidade:"
									+ retornarUnidade()));
		}
	}

	private String retornarCodigoLabCdt() {
		if (isExisteExameDeImagem()) {
			return NovoAtendimentoUnimedBean.CODIGO_IMAGEM;
		} else {
			return NovoAtendimentoUnimedBean.CODIGO_PATOLOGIA;
		}
	}

	private String retornarSenhaAutorizada() {
		try {
			return guiasAutorizadaSelecionada.getDadosAutorizacao().getSenhaAutorizacao();
		} catch (final Exception locExc) {
			return "";
		}
	}

	public void buscarDadosCliente() {
		try {
			final DataUtil dataUtil = new DataUtil();
			final ClienteService clienteService = new ClienteService(getHttpServletRequest());
			parametroConsultaCliente = new ParametroConsultaCliente(tokenResult, parametroConsultaCliente);
			parametroConsultaCliente
					.setBirthDate(dataUtil.formatarStringBRParaString(parametroConsultaCliente.getBirthDate()));
			verificarSeCamposForamPreenchidos();
			if (ehUmaDataValida()) {
				clienteService.consultaCliente(parametroConsultaCliente);
				clienteUnidadePasseLivre = new ClienteUnidadePasseLivre();
				if (clienteService.isSuccess() && clienteService.getResponseObject() != null) {
					clienteUnidadePasseLivre = ((List<ClienteUnidadePasseLivre>) clienteService.getResponseObject())
							.get(0);
					formatarEndereco();
					irParaTelaAtualizacaoDados();
				} else {
					irParaTelaCadastroDados();
				}
			}
		} catch (final RegraNegocioException locExc) {
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
		} catch (final ParseException locExc) {
			mensagemAviso = "A data informada não possui um valor v�lido!";
			exibirDialogMensagem();
		} catch (final Exception exc) {
			try {
				mensagemAviso = "Erro ao buscar dados do cliente: " + exc.getMessage() + " - Causa: " + exc.getCause();
				MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso(this.mensagemAviso);
				getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
				registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(), mensagemAviso.getMensagem(),
						sessionId, createBasicLogMap());
			} catch (Exception e) {
				e.printStackTrace();
			}
			redirectTelaErro();
		}
	}

	private void gerarLogErroAoBuscarDadosCliente(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, retornarCodigoPesquisado());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, TotemUtil.buscarSessionId(),
					createBasicLogMap());
		} catch (final Exception exc) {
		}
	}

	private String retornarCodigoPesquisado() {
		try {
			if (parametroConsultaCliente.getCodigo() != null) {
				return parametroConsultaCliente.getCodigo();
			} else {
				return parametroConsultaCliente.getAuthKey();
			}
		} catch (final Exception locExc) {
			return "";
		}
	}

	private void irParaTelaAtualizacaoDados() throws Exception, IOException {
		getSession().setAttribute("clienteUnidadePasseLivre", clienteUnidadePasseLivre);
		FacesContext.getCurrentInstance().getExternalContext().redirect(redirectAtualizacaoUsuario());
	}

	private String redirectAtualizacaoUsuario() {
		return "/passelivretotem/pages/nau/atualizarDados.xhtml?faces-redirect=true";
	}

	private void verificarSeCamposForamPreenchidos() throws RegraNegocioException {
		if (parametroConsultaCliente.getAuthKey().isEmpty()) {
			throw new RegraNegocioException("Campo CPF não pode ser vazio!");
		}
		if (parametroConsultaCliente.getBirthDate().isEmpty()) {
			throw new RegraNegocioException("Campo Data Nascimento não pode ser vazio!");
		}
	}

	private void irParaTelaCadastroDados() throws Exception, IOException {
		final DataUtil dataUtil = new DataUtil();
		clienteUnidadePasseLivre.setCpf(parametroConsultaCliente.getAuthKey());
		clienteUnidadePasseLivre
				.setDataNascimento(dataUtil.formatarStringParaStringBR(parametroConsultaCliente.getBirthDate()));
		getSession().setAttribute("clienteUnidadePasseLivre", clienteUnidadePasseLivre);
		FacesContext.getCurrentInstance().getExternalContext().redirect(redirectCadastroUsuario());
	}

	private boolean ehUmaDataValida() throws RegraNegocioException {
		if (parametroConsultaCliente.getBirthDate().length() == 10) {

			Date dataDascimento = null;
			try {
				dataDascimento = new Date().parseDate("yyyy-MM-dd", parametroConsultaCliente.getBirthDate());
			} catch (Exception e) {
			}
			if (dataDascimento != null && dataDascimento.after(new Date())) {
				throw new RegraNegocioException("Campo data nascimento não pode ser maior que a data atual!");
			}
			return true;
		}
		throw new RegraNegocioException("É nescessário informar uma data de nascimento válida!");
	}

	private String redirectAtendimentoConcluidoSemEmail() {
		String nomeTotem = "";
		try {
			nomeTotem = retornarNomeDaMaquina();
		} catch (RegraNegocioException e) {
			e.printStackTrace();
		}
		return "/pages/nau/atendimentoConcluidoSemEmail.xhtml?faces-redirect=true&nomeTotem=" + nomeTotem;
	}

	private String redirectAtendimentoConcluidoSemImpressaoGA() {
		String nomeTotem = "";
		try {
			nomeTotem = retornarNomeDaMaquina();
		} catch (RegraNegocioException e) {
			e.printStackTrace();
		}
		return "/pages/nau/atendimentoConcluidoSemImpressaoGA.xhtml?faces-redirect=true&nomeTotem=" + nomeTotem;
	}

	private void enviarEmailPedidoFinalizado(final CriarPedidoResult parCriarPedidoResult) throws EnvioEmailException {
		final ExamesResultadosPedido locExamesResultadosPedido = new ExamesResultadosPedido();
		try {

			if (informacoesTotem.get(0).getIdEmpresa().equals(Long.parseLong(Constantes.ID_EMPRESA_ECOAR))) {

				adicionarUnidade(parCriarPedidoResult);
				locExamesResultadosPedido.addAll(parCriarPedidoResult.getExames());
				final EnviaEmailService envioEmailService = new EnviaEmailService(getHttpServletRequest());
				envioEmailService.enviarEmailFinalizarPedido(clienteUnidadePasseLivre, locExamesResultadosPedido,
						getAmbienteProducao(), true);

			} else {

				adicionarUnidade(parCriarPedidoResult);
				locExamesResultadosPedido.addAll(parCriarPedidoResult.getExames());
				final EnviaEmailService envioEmailService = new EnviaEmailService(getHttpServletRequest());
				envioEmailService.enviarEmailFinalizarPedido(clienteUnidadePasseLivre, locExamesResultadosPedido,
						getAmbienteProducao(), false);

			} 

		} catch (final Exception exc) {
			throw new EnvioEmailException("Erro ao enviar e-mail: " + exc.getMessage());
		}
	}

	private void adicionarUnidade(final CriarPedidoResult parCriarPedidoResult) {
		for (final InformacaoTotem locInformacaoTotem : informacoesTotem) {
			if (locInformacaoTotem.getIdUnidade().equals(parCriarPedidoResult.getUnidade().toString())) {
				clienteUnidadePasseLivre
						.setUnidade(parCriarPedidoResult.getPedido() + "-" + locInformacaoTotem.getNomeUnd());
			}
		}
	}

	private Localidade adicionarIpALocalidade() throws Exception {
		final LocalidadeService loLocalidadeService = new LocalidadeService(getHttpServletRequest());
		String ipLocal = retornarIpValido();
		ipLocal = ipLocal + "0";
		final Localidade localidade = new Localidade();
		localidade.setIp(ipLocal);
		loLocalidadeService.setValueObject(localidade);
		return loLocalidadeService.getLocalidadeByIp();
	}

	private String retornarIpValido() throws Exception {
		if (getAmbienteProducao()) {
			return HttpUtil.retornaIpSemUltimoOcteto(Util.getClientIpAddr(getHttpServletRequest()));
		} else {
			// c�digo necess�rio para testes na ecoar
			if (informacoesTotem.get(0).getIp().contains("eco1") || informacoesTotem.get(0).getIp().contains("eco2")
					|| informacoesTotem.get(0).getIp().contains("eco3")) {
				return HttpUtil.retornaIpSemUltimoOcteto(Constantes.IP_LOCALIDADE_DEFAULT_ECOAR);
			} else {
				return HttpUtil.retornaIpSemUltimoOcteto(Constantes.IP_LOCALIDADE_DEFAULT);
			}
		}
	}

	private String retornarLocalAtendimento(final Localidade localidade) {
		// hard code - exame codiv
		/*
		 * ATUALIZA��O - SOLITICATO REMO��O EM 14-08-2020 if(false) { exameCovid =
		 * false; return Constantes.PARAM_INICAL_LOCAL_ATENDIMENTO + "13576"; //fim hard
		 * code - remover bloco IF } else
		 */
		if (localidade != null) {
			return Constantes.PARAM_INICAL_LOCAL_ATENDIMENTO + localidade.getCodigounidade();
		} else {
			return "";
		}
	}

	public String redirectAtendimentoConcluido() {
		if (isExisteExameDeImagem()) {
			setMsgTelaFinalizacao("");
			return "/pages/nau/finalizacaoPedido.xhtml?faces-redirect=true";
		} else {
			return "/pages/nau/finalizacaoPedido.xhtml?faces-redirect=true";
		}
	}

	private boolean isExisteExameDeImagem() {
		try {
			for (final ProcedimentoComExamesTO locProcedimentoComExamesTO : procedimentosComExamesParaGerarPedido) {
				if (locProcedimentoComExamesTO.getExame().getMaterial().equals("VIVO")) {
					return true;
				}
			}
			return false;
		} catch (final Exception e) {
			return false;
		}
	}

	private boolean isQuestionarioImpresso() {
		boolean questionarioSaoImpressos = false;
		for (final Questionario questionario : consultaQuestionarioExameResult.getQuestionarios()) {
			if (questionario.getImpresso().equals("S")) {
				questionarioSaoImpressos = true;
			}
		}
		return questionarioSaoImpressos;
	}

	public String cancelarAtualizacao() {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, retornarCodigo());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, TotemUtil.buscarSessionId(),
					createBasicLogMap());
			return redirectIndex();
		} catch (final Exception exc) {
			return "";
		}
	}

	public void finalizarPedido() {
		providencia = "";
		contagemErros = BigInteger.ZERO.intValue();
		cancelarSessao();
	}

	private void gerarLogErroAoFazerPedido(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN,
					clienteUnidadePasseLivre.getCodigoCliente());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage,
					getSession().getAttribute("sessionId").toString(), createBasicLogMap());
		} catch (final Exception exc) {
		}
	}

	private void gerarLogErroEmailAoFazerPedido(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, retornarCodigo());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, TotemUtil.buscarSessionId(),
					createBasicLogMap());
		} catch (final Exception exc) {
		}
	}

	private String retornarCodigo() {
		try {
			if (clienteUnidadePasseLivre.getCodigoCliente() != null) {
				return clienteUnidadePasseLivre.getCodigoCliente();
			} else {
				return "";
			}
		} catch (final Exception locExc) {
			return "";
		}
	}

	public void buscarPreparacaoExame(final ExameHermesPardini exameHermesPardini) {
		try {
			final ParametroPreparoExame parametroPreparoExame = new ParametroPreparoExame(exameHermesPardini,
					informacoesTotem, tokenResult);
			final PreparacaoExameService preparacaoExameService = new PreparacaoExameService(getHttpServletRequest());
			preparacaoExameService.setValueObject(parametroPreparoExame);
			preparacaoExameService.consultar();
			if (preparacaoExameService.isSuccess()) {
				consultaPreparoResult = (ConsultaPreparoResult) preparacaoExameService.getResponseObject();
			} else {
				MensagemAviso mensagemAviso = TotemUtil
						.createMensagemAviso(preparacaoExameService.getResponseMessage());
				try {
					getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
				} catch (Exception e) {
					e.printStackTrace();
				}
				gerarLogAoBuscarPreparacaoExame(preparacaoExameService.getResponseMessage());
				FacesContext.getCurrentInstance().getExternalContext().redirect(redirectAtendimentoNaoConcluido());
			}
		} catch (final Exception exc) {
			gerarLogAoBuscarPreparacaoExame(exc.getMessage());
		}
	}

	private void gerarLogAoBuscarPreparacaoExame(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, retornarCodigo());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, TotemUtil.buscarSessionId(),
					createBasicLogMap());
		} catch (final Exception exc) {
		}
	}

	private void buscarUsuarioPorMatricula() throws Exception, RegraNegocioException {
		final ClienteService clienteService = new ClienteService(getHttpServletRequest());
		final ParametroConsultaMatricula parametroConsultaMatricula = new ParametroConsultaMatricula(numeroCarteira,
				tokenResult);
		clienteService.consultarMatricula(parametroConsultaMatricula);
		if (clienteService.isSuccess()) {
			clienteUnidadePasseLivre = (ClienteUnidadePasseLivre) clienteService.getResponseObject();
		} else {
			throw new RegraNegocioException("Usuário não foi encontrado!");
		}
	}

	public void pesquisarCep() {
		try {
			final FacesContext facesContext = FacesContext.getCurrentInstance();
			final PartialViewContext partialViewContext = facesContext.getPartialViewContext();
			final Collection<String> renderIds = partialViewContext.getRenderIds();
			final UIViewRoot viewRoot = getContext().getViewRoot();
			for (final String renderId : renderIds) {
				final UIComponent component = viewRoot.findComponent(renderId);
				final EditableValueHolder input = (EditableValueHolder) component;
				if (input != null) {
					input.resetValue();
				} else {
					limparCamposEndereco();
				}
			}
			adicionarEnderecoPeloCEP();
		} catch (final NullPointerException locE) {
			limparCamposEndereco();
			gerarLogAoBuscarCEP("CEP não existe!");
		} catch (final Exception locE) {
			limparCamposEndereco();
			gerarLogAoBuscarCEP(locE.getMessage());
		}
	}

	private void limparCamposEndereco() {
		clienteUnidadePasseLivre.limparCamposEndereco();
	}

	private void adicionarEnderecoPeloCEP() throws Exception {
		String cep = getClienteUnidadePasseLivre().getCep().replaceAll("[^0-9]", "");
		if (cep.length() == 8) {
			final CepService cepService = new CepService(getHttpServletRequest());
			ConsultaCepResult cepResult = cepService.consultarCep(cep, tokenResult.getToken());
			if (cepService.isSuccess()) {
				if (cepResult != null) {
					adiconarEnderecoAoCliente(cepResult);
				} else {
					limparCamposEndereco();
					exibirDialogMensagemAlert("CEP não encontrado!");
				}
			} else {
				limparCamposEndereco();
				exibirDialogMensagemAlert("CEP não encontrado!");
			}
		} else {
			limparCamposEndereco();
			exibirDialogMensagemAlert("CEP deve conter 8 caracteres numéricos!");
		}		
	}
	
	private void exibirDialogMensagemAlert(String msg) {
		setMensagemAviso(msg);
//		PrimeFaces.current().executeScript("PF('dlgMessageAviso').show()");
	}

	private void gerarLogAoBuscarCEP(final String mensagem) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, retornarCodigo());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), mensagem, TotemUtil.buscarSessionId(),
					createBasicLogMap());
		} catch (final Exception exc) {
		}
	}

	private String formatarCep(final String cep) {
		formataCampo = new FormataCep(cep);
		return formataCampo.formatar();
	}

	private void verificarSeClientePasseLivreExiste() throws Exception {
		if (clienteUnidadePasseLivre.getNomeCliente() == null) {
			receberClientePasseLivre();
		}
	}

	private void receberClientePasseLivre() throws Exception {
		final HttpSession session = getHttpServletRequest().getSession();
		clienteUnidadePasseLivre = (ClienteUnidadePasseLivre) session.getAttribute("clienteUnidadePasseLivre");
	}

	private boolean cepELogradouroNaoEstaoNulos(final Cep cep) {
		return cep != null;
	}

	private void adiconarEnderecoAoCliente(ConsultaCepResult consultaCepResult) {
		clienteUnidadePasseLivre.setUf(consultaCepResult.getUf());
		clienteUnidadePasseLivre.setCidade(consultaCepResult.getLocalidade());
		clienteUnidadePasseLivre.setLogradouro(montarEnderecoLogradouro(consultaCepResult));
		clienteUnidadePasseLivre.setBairro(consultaCepResult.getBairro() != null ? consultaCepResult.getBairro() : "");
		clienteUnidadePasseLivre.setNumero("");
		clienteUnidadePasseLivre.setComplemento("");
		
		if(clienteUnidadePasseLivre.getLogradouro().equals(""))
			setEditarLogradouro(true);
		else
			setEditarLogradouro(false);
		
		if(clienteUnidadePasseLivre.getBairro().equals(""))
			setEditarBairro(true);
		else
			setEditarBairro(false);
	}
	
	private String montarEnderecoLogradouro(ConsultaCepResult consultaCepResult) {
		if(consultaCepResult.getLogradouro() != null && !consultaCepResult.getLogradouro().equals("") && consultaCepResult.getTipoEndereco() != null && !consultaCepResult.getTipoEndereco().equals(""))
			return consultaCepResult.getTipoEndereco() + " " + consultaCepResult.getLogradouro();
		else if(consultaCepResult.getLogradouroAbreviado() != null && !consultaCepResult.getLogradouroAbreviado().equals(""))
			return consultaCepResult.getLogradouroAbreviado();		
		else {
			return "";
		}
	}


	private void verificarSeHabilitaCampoUf(final String parUf) {
		getClienteUnidadePasseLivre().setUf(parUf);
		if (parUf.isEmpty() || parUf == "") {
			habilitacaoCamposCadastroTO.setHabilitaUF(true);
		}
	}

	private void verificarSeHabilitaCampoCidade(final String parLocalidade) {
		getClienteUnidadePasseLivre().setCidade(parLocalidade);
		if (parLocalidade.isEmpty() || parLocalidade == "") {
			habilitacaoCamposCadastroTO.setHabilitaCidade(true);
		}
	}

	private void verificarSeHabilitaCampoBairro(final String parBairro) {
		getClienteUnidadePasseLivre().setBairro(parBairro);
		if (parBairro.isEmpty() || parBairro == "") {
			habilitacaoCamposCadastroTO.setHabilitaBairro(true);
		}
	}

	private void verificarSeHabilitaCampoLogradouro(final String parLogradouro) {
		getClienteUnidadePasseLivre().setLogradouro(parLogradouro);
		if (parLogradouro.isEmpty() || parLogradouro == "") {
			habilitacaoCamposCadastroTO.setHabilitaLogradouro(true);
		}
	}

	private String redirectGuiasAutorizadas() {
		return "/pages/nau/guiasAutorizadas.xhtml?faces-redirect=true";
	}

	private String redirectAtendimentoNaoConcluido() {
		String nomeTotem = "";
		try {
			nomeTotem = retornarNomeDaMaquina();
		} catch (RegraNegocioException e) {
			e.printStackTrace();
		}
		return "/pages/erro/atendimentoNaoConcluido.xhtml?faces-redirect=true&sessionId=" + sessionId + "&nomeTotem="
				+ nomeTotem;
	}

	public String getRetornarNomeCliente() {
		try {
			final String[] nomeSeparado = clienteUnidadePasseLivre.getNomeCliente().split(" ");
			return nomeSeparado[0] + " " + nomeSeparado[nomeSeparado.length - 1];
		} catch (final Exception locExc) {
			return "";
		}
	}

	public void verificarRespostaDaMatricula() throws IOException {
		if (!numeroCarteira.isEmpty()) {
			try {
				verificarResultadoDaBiometria();
				if (confirmarBiometria(true)) {
					salvarHistoricoBiometria(salvarBiometria());
					buscarUsuarioPorMatricula();
					formatarEndereco();
					getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, numeroCarteira);
					registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
							Thread.currentThread().getStackTrace()[1].getMethodName(), null,
							TotemUtil.buscarSessionId(), createBasicLogMap());
					FacesContext.getCurrentInstance().getExternalContext().redirect(redirectTelaDeConfirmacao());
				} else {
					exibeMensagemNaoVerificado();
				}
			} catch (final RegraNegocioException locExc) {
				gerarLogAoVerificarRepostaMatricula(locExc.getMessage());
				FacesContext.getCurrentInstance().getExternalContext().redirect(redirectParaVerificaCadastro());
			} catch (final Exception locExc) {
				mensagemAviso = locExc.getMessage();
				exibirDialogMensagem();
				gerarLogAoVerificarRepostaMatricula(locExc.getMessage());
				MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso(locExc.getMessage());
				try {
					getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
				} catch (Exception e) {
					e.printStackTrace();
				}
				FacesContext.getCurrentInstance().getExternalContext()
						.redirect(redirectAtendimentoNaoConcluidoBiometria());
			}
		}
	}

	private void exibeMensagemNaoVerificado() {
		this.mensagemAviso = String.format("Sem registro de biometria. Carteira Unimed: %s", numeroCarteira);
		RequestContext.getCurrentInstance().execute("PF('dlgMessageVerif').show()");
	}

	public void retornaInicioAtendUnimed() throws Exception {
		FacesContext.getCurrentInstance().getExternalContext().redirect("/passelivretotem" + redirectColetaBiometria());
	}

	public void verificarRespostaDaMatriculaTemp() throws IOException {
		try {
			if (confirmarBiometria(true)) {
				buscarUsuarioPorMatricula();
				formatarEndereco();
				getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, numeroCarteira);
				registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(), null, TotemUtil.buscarSessionId(),
						createBasicLogMap());
				FacesContext.getCurrentInstance().getExternalContext().redirect(redirectTelaDeConfirmacao());
			} else {
				exibeMensagemNaoVerificado();
			}
		} catch (final RegraNegocioException locExc) {
			gerarLogAoVerificarRepostaMatricula(locExc.getMessage());
			FacesContext.getCurrentInstance().getExternalContext().redirect(redirectParaVerificaCadastro());
		} catch (final Exception locExc) {
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
			gerarLogAoVerificarRepostaMatricula(locExc.getMessage());
			MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso(locExc.getMessage());
			try {
				getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
			} catch (Exception e) {
				e.printStackTrace();
			}
			FacesContext.getCurrentInstance().getExternalContext().redirect(redirectAtendimentoNaoConcluidoBiometria());
		}
	}

	private void salvarHistoricoBiometria(final Presenca presenca) throws RegraNegocioException {
		try {
			final PresencaHistoricoService presencaHistoricoService = new PresencaHistoricoService(
					getHttpServletRequest());
			final Long id = presencaHistoricoService.getId();
			final PresencaHistorico presencaHistorico = new PresencaHistorico(presenca, id);
			presencaHistoricoService.salvarHistoricoBiometria(presencaHistorico);
			if (!presencaHistoricoService.isSuccess()) {
				throw new RegraNegocioException(presencaHistoricoService.getResponseMessage());
			}
		} catch (final Exception locExc) {
			throw new RegraNegocioException(locExc.getMessage());
		}
	}

	private Presenca salvarBiometria() throws RegraNegocioException {
		try {
			Presenca presencaLocal = new Presenca();
			final PresencaService presencaService = new PresencaService(getHttpServletRequest());
			presenca = new Presenca(numeroCarteira, localidade.getFilial());
			presencaLocal = presencaService.salvarBiometria(presenca);
			if (presencaService.isSuccess()) {
				return presencaLocal;
			} else {
				throw new RegraNegocioException(presencaService.getResponseMessage());
			}
		} catch (final Exception locExc) {
			throw new RegraNegocioException(locExc.getMessage());
		}
	}

	private String redirectAtendimentoNaoConcluidoBiometria() {
		return "/passelivretotem/pages/erro/atendimentoNaoConcluido.xhtml?faces-redirect=true&sessionId=" + sessionId;
	}

	private void gerarLogAoVerificarRepostaMatricula(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, numeroCarteira);
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, TotemUtil.buscarSessionId(),
					createBasicLogMap());
		} catch (final Exception locExc) {
		}
	}

	private String redirectTelaDeConfirmacao() {
		return "/passelivretotem/pages/nau/confirmaNome.xhtml?faces-redirect=true";
	}

	private String redirectColetaBiometria() {
		return "/pages/nau/coletaBiometria.xhtml?faces-redirect=true";
	}

	public String voltarParaGuias() {
		try {
			limparDadosParaNovaGuia();
			buscarGuiasAutorizadas();
			contagemErros = BigInteger.ZERO.intValue(); 
			return redirectGuiasAutorizadas();
		} catch (final Exception locExc) {
			MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso(locExc.getMessage());
			try {
				getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return redirectAtendimentoNaoConcluido();
		}
	}

	public void limparDadosParaNovaGuia() {
		perguntas = null;
		numeroPedido = null;
		parametroPedido = null;
		guiasAutorizadaSelecionada = null;
		procedimentosComExamesParaGerarPedido = null;
		questionariosExamesResult = null;
		quantidadeExameVT = 0;
		jaVerificouExamesCalcs = false;
	}

	public Boolean botaoCPFEstaAtivado() {
		getRequestContext().update("frmPrincipal:btnBotao");
		return activeIndex == 0;
	}

	public Boolean botaoCodigoEstaAtivado() {
		getRequestContext().update("frmPrincipal:btnBotao");
		return activeIndex == 1;
	}

	public void esquecerSenha() {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, TotemUtil.buscarSessionId(),
					createBasicLogMap());
		} catch (final Exception locExc) {
		}
	}

	public String entrarComMatricula() {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, retornarCodigo());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, TotemUtil.buscarSessionId(),
					createBasicLogMap());
			return redirectAtualizarUsuario();
		} catch (final Exception locExc) {
			return "";
		}
	}

	public String cancelarLogin() {
		try {
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, TotemUtil.buscarSessionId(),
					createBasicLogMap());
			return redirectIndex();
		} catch (final Exception locExc) {
			return "";
		}
	}

	public void cancelarConfirmaNome() {
		try {
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, TotemUtil.buscarSessionId(),
					createBasicLogMap());
			final String nomeMaquina = retornarNomeDaMaquina();
			getSession().removeAttribute("indexBean");
			TotemUtil.limparSession();
			FacesContext.getCurrentInstance().getExternalContext()
					.redirect("/passelivretotem/indexTotem.xhtml?nomeTotem=" + nomeMaquina);
		} catch (final Exception exc) {
		}
	}

	public void cancelarExame() {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, retornarCodigo());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, TotemUtil.buscarSessionId(),
					createBasicLogMap());
			final String nomeMaquina = retornarNomeDaMaquina();
			getSession().removeAttribute("indexBean");
			TotemUtil.limparSession();
			FacesContext.getCurrentInstance().getExternalContext()
					.redirect("/passelivretotem/indexTotem.xhtml?nomeTotem=" + nomeMaquina);
		} catch (final Exception exc) {
		}
	}

	public void cancelarSessao() {
		try {
			providencia = "";
			numeroCarteira = "";
			final String nomeTotem = retornarNomeDaMaquina();
			getSession().removeAttribute("indexBean");
			getSession().removeAttribute("tipoServico");
			TotemUtil.limparSession();
			FacesContext.getCurrentInstance().getExternalContext()
					.redirect("/passelivretotem/indexTotem.xhtml?nomeTotem=" + nomeTotem);
		} catch (final Exception exc) {
		}
	}

	public void cancelarGuias() {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, retornarCodigo());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, TotemUtil.buscarSessionId(),
					createBasicLogMap());
			cancelarSessao();
		} catch (final Exception locExc) {
		}
	}

	public String cancelarVerificaDadosCliente() {
		try {
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, TotemUtil.buscarSessionId(),
					createBasicLogMap());
			return redirectIndex();
		} catch (final Exception locExc) {
			return "";
		}
	}

	public void gerarLogFalhaCarregamentoBiometria(ActionEvent evento) {
		try {
			String parMessage = "Falha ao carregar biometria. Tentativa " + tentativasBiometria;
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, sessionId,
					createBasicLogMap());
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	public Boolean habilitarBotaoQuestionarioVoltar(final Integer level) {
		return controleBotaoUtil.habilitarBotaoQuestionarioVoltar(mdlsQuestionario, level);
	}

	public Boolean habilitarBotaoQuestionarioCancelar(final Integer level) {
		return controleBotaoUtil.habilitarBotaoQuestionarioCancelar(mdlsQuestionario, level);
	}

	public Boolean habilitarBotaoQuestionarioAvancar(final Integer level) {
		return controleBotaoUtil.habilitarBotaoQuestionarioAvancar(mdlsQuestionario, level);
	}

	public Boolean habilitarBotaoQuestionarioFinalizar(final Integer level) {
		return controleBotaoUtil.habilitarBotaoQuestionarioFinalizar(mdlsQuestionario, level);
	}

	public Boolean getHabilitaEntregaResultado() {
		return controleBotaoUtil.getHabilitaEntregaResultado(informacoesTotem);
	}

	public Boolean getHabilitaOrcamento() {
		return controleBotaoUtil.getHabilitaOrcamento(informacoesTotem);
	}

	public Boolean getHabilitaPeparacao() {
		return controleBotaoUtil.getHabilitaPreparacaoExame(informacoesTotem);
	}

	public Boolean getHabilitaAtendimentoUnimed() {
		return controleBotaoUtil.getHabilitaAtendimentoUnimed(informacoesTotem);
	}

	public Boolean getHabilitaEntregaMaterial() {
		return controleBotaoUtil.getHabilitaEntregaMaterial(informacoesTotem);
	}

	public boolean getHappyBirthDate() {
		try {
			if (new ClienteService(getHttpServletRequest())
					.getHappyBirthDate(clienteUnidadePasseLivre.getDataNascimento())) {
				gerarLogEstatisticoParaAniversariante();
				return true;
			} else {
				return false;
			}
		} catch (final Exception locExc) {
			return false;
		}
	}

	private void gerarLogEstatisticoParaAniversariante() {
		try {
			final ControleEstatisticoService controleEstatisticoService = new ControleEstatisticoService(
					getHttpServletRequest());
			final ControleEstatistico controleEstatistico = new ControleEstatistico(
					clienteUnidadePasseLivre.getCodigoCliente(), null,
					FuncaoLogEstatistico.LEMBRETE_ANIVERSARIO.toString(), informacoesTotem.get(0).getId(), null, null,
					retornarUnidade());
			controleEstatisticoService.insert(controleEstatistico);
		} catch (final Exception locExc) {
			gerarLogErroAoGerarLogEstatistico(locExc.getMessage());
		}
	}

	private void gerarLogErroAoGerarLogEstatistico(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, TotemUtil.buscarSessionId(),
					createBasicLogMap());
		} catch (final Exception exc) {
		}
	}

	private void verificarTipoLogin() {
		if (botaoCodigoEstaAtivado()) {
			user.setAuthKeyType(Constantes.CODEAUTHKEYTYPE);
		} else {
			user.setAuthKeyType(Constantes.CPFAUTHKEYTYPE);
			final String dataNascimentoRetorno = formatarDataNascimentoParaRecebimento(user.getBirthDate());
			user.setBirthDate(dataNascimentoRetorno);
		}
	}

	private void formatarEndereco() throws Exception {
		formataEndereco.formataEnderecoAoLogar(clienteUnidadePasseLivre);
	}

	private String formatarDataNascimentoParaRecebimento(final String dataNascimento) {
		formataCampo = new FormataDataAnoMesDia(dataNascimento);
		return formataCampo.formatar();
	}

	public String naoAceitarTermo() {
		try {
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, TotemUtil.buscarSessionId(),
					createBasicLogMap());
			return redirectIndex();
		} catch (final Exception locExc) {
			return "";
		}
	}

	public void redirectResultado() {
		try {
			sessionId = SessionIdBuilder.build(informacoesTotem.get(0)).toString();
			getSession().removeAttribute("resultadoPedidoBean");
			controleBotaoUtil.redirectResultado(getHttpServletRequest(), clienteUnidadePasseLivre, sessionId);
		} catch (final Exception exc) {
		}
	}

	public String formatarDataNascimento(final String data) {
		try {
			if (data != null || !data.isEmpty() || naoContemNumero(data)) {
				return dataUtil.formatarStringParaStringBR(data);
			}
			return "";
		} catch (final ParseException exc) {
			return "";
		}
	}

	private boolean naoContemNumero(final String parData) {
		return !org.apache.commons.lang.StringUtils.isNumeric(parData);
	}

	public void redirectUnimed() {
		try {
			buscarGuiasAutorizadas();
			controleBotaoUtil.redirectUnimed(getHttpServletRequest(), clienteUnidadePasseLivre, sessionId);
		} catch (final RegraNegocioException exc) {
			exc.printStackTrace();
			mensagemAviso = exc.getMessage();
			exibirDialogMensagem();
		} catch (final Exception exc) {
			exc.printStackTrace();
			mensagemAviso = exc.getMessage();
			exibirDialogMensagem();
		}
	}

	public void recuperaSenha() {
		try {
			final SenhaService senhaService = new SenhaService(getHttpServletRequest());
			verificarTipoLogin();
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN,
					clienteUnidadePasseLivre.getCodigoCliente());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), null, TotemUtil.buscarSessionId(),
					createBasicLogMap());
			senhaService.recuperaSenha(user);
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			RequestContext.getCurrentInstance().execute("PF('insertEmailDialogVar').hide()");
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
			gerarLogErroAoRecuperarSenha(locExc.getMessage());
		}
	}

	private void gerarLogErroAoRecuperarSenha(final String parMessage) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN, user.getAuthKey());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, TotemUtil.buscarSessionId(),
					createBasicLogMap());
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	public void alterarSenha() {
		try {
			verificarSeSenhasConferem();
			final ClienteUnidadePasseLivre locClienteUnidadePasseLivre = new ClienteUnidadePasseLivre(user.getNewPass(),
					clienteUnidadePasseLivre);
			final SenhaService loSenhaService = new SenhaService(getHttpServletRequest());
			loSenhaService.setValueObject(locClienteUnidadePasseLivre);
			loSenhaService.atualizarSenha();
			if (loSenhaService.isSuccess()) {
				getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN,
						clienteUnidadePasseLivre.getCodigoCliente());
				registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(), null, TotemUtil.buscarSessionId(),
						createBasicLogMap());
			} else {
				gerarLogErroAoValidarSenha(loSenhaService.getResponseMessage());
			}
			mensagemAviso = loSenhaService.getResponseMessage();
		} catch (final Exception locExc) {
			locExc.printStackTrace();
			mensagemAviso = locExc.getMessage();
			gerarLogErroAoValidarSenha(locExc.getMessage());
		} finally {
			fecharDialogResetSenha();
			exibirDialogMensagem();
			resetarCampos();
		}
	}

	private void exibirDialogMensagem() {
		RequestContext.getCurrentInstance().execute("PF('dlgMessage').show()");
	}

	private void verificarSeSenhasConferem() throws Exception {
		if (!user.getNewPass().equals(user.getConfirmAuthPass())) {
			throw new Exception("As senhas não conferem");
		}
	}

	private void fecharDialogResetSenha() {
		RequestContext.getCurrentInstance().execute("PF('dlgAlterarSenha').hide()");
	}

	private void gerarLogErroAoValidarSenha(final String parMensagemErro) {
		try {
			getSession().setAttribute(LogAplicacaoUsuarioFactory.STR_USER_LOGIN,
					clienteUnidadePasseLivre.getCodigoCliente());
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMensagemErro,
					TotemUtil.buscarSessionId(), createBasicLogMap());
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	public void imprimirGATeste() throws ImpressaoException {
		houveErroAoImprimirGa = Boolean.FALSE;
		ArquivoUtil arquivoUtil = new ArquivoUtil();
		String msgErro = null;		
		try {
			//arquivoUtil.fazerImpressaoFrenteVersoTeste("GA_40_teste" + ".pdf", "10.62.195.54");
			
			BaixarGuiaUnimedService baixarGuiaUnimedService = new BaixarGuiaUnimedService(getHttpServletRequest());

			String idSolic = "1021361018";
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(),
					"Início processo: Baixar guia serviço Unimed", TotemUtil.buscarSessionId(), createBasicLogMap());
			final ConfiguracaoImpressoraResult configuracaoImpressoraResult = retornarConfiguracoesImpressora();
			InputStream guiaUnimed = baixarGuiaUnimedService.baixarGuiaUnimed(idSolic,
					informacoesTotem.get(0).getIdEmpresa().equals(Long.parseLong(Constantes.ID_EMPRESA_ECOAR)));

			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(),
					"Fim processo: Baixar guia serviço Unimed", TotemUtil.buscarSessionId(), createBasicLogMap());
			if (guiaUnimed != null) {

				final byte[] bytes = IOUtils.toByteArray(guiaUnimed);

				arquivoUtil.salvarDiretorioLocal(bytes, "GA_40_teste" + ".pdf");

				registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(), "Início processo: Imprimir guia.",
						TotemUtil.buscarSessionId(), createBasicLogMap());
				arquivoUtil.fazerImpressaoFrenteVerso("GA_40_teste" + ".pdf",
						configuracaoImpressoraResult.getIp());

				registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(), "Fim processo: Imprimir guia.",
						TotemUtil.buscarSessionId(), createBasicLogMap());

				guiaUnimed.close();
			} else {

				final byte[] bytes = IOUtils
						.toByteArray(gerarRelatorioGA(locCriarPedidoResult, guiasAutorizadaSelecionada));

				arquivoUtil.salvarDiretorioLocal(bytes, "GA_40_teste" + ".pdf");

				arquivoUtil.fazerImpressaoFrenteVerso("GA_40_teste" + ".pdf",
						configuracaoImpressoraResult.getIp());

			}
			fecharDlgMessage();
		} catch (SocketTimeoutException e) {
			contagemErros++;
			houveErroAoImprimirGa = Boolean.TRUE;
			atualizarMsgObservacao();
			msgErro = "Não foi possível concluir conexão impressora.";
			mensagemMotivo = "Falha acessar impressora";
			gravarLogSimplificadoSemExecao(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(),
					String.format("Não foi possível concluir conexão impressora (Falha acessar impressora). %s", e.getMessage()));

		} catch (DownloadUnimedException e) {
			contagemErros++;
			houveErroAoImprimirGa = Boolean.TRUE;
			atualizarMsgObservacao();
			msgErro = "Não foi possível concluir a impressão da Guia de Autorização.";
			mensagemMotivo = "Falha ao baixar a guia da Unimed";
			gravarLogSimplificadoSemExecao(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(),
					String.format("Não foi possível concluir a impressão da Guia de Autorização. ( Falha ao baixar a guia da Unimed). %s", e.getMessage()));
		} catch (final Exception exc) {
			contagemErros++;
			houveErroAoImprimirGa = Boolean.TRUE;
			atualizarMsgObservacao();
			msgErro = "Não foi possível concluir a impressão da Guia de Autorização.";
			mensagemMotivo = "Falha ao imprimir guia Unimed";
			gravarLogSimplificadoSemExecao(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(),
					String.format("Não foi possível concluir a impressão da Guia de Autorização. (Falha ao imprimir guia Unimed): %s", exc.getMessage()));
		} finally {
			fecharDialogImprimirGA();
			
			if (msgErro != null) {
				//exibir mensagem erro na tela
				mensagemAviso = msgErro;
				exibirDialogMensagem();
			}
		}
	}
	
	private String checkStatusPrinter() {
		String statusImpressora = "";
		try {
			statusImpressora = ImpressoraUtil.checkStatusPrinter(retornarConfiguracoesImpressora().getIp(), getHttpServletRequest());
			
		} catch (Exception e) {
			log.warn("Erro ao buscar dados da Impressora");
		}
		return statusImpressora;
	}

	public void imprimirGA() /* throws ImpressaoException */ {
		final ArquivoUtil arquivoUtil = new ArquivoUtil();
		String msgErro = null;
		String idSolic = "";
		try {
			BaixarGuiaUnimedService baixarGuiaUnimedService = new BaixarGuiaUnimedService(getHttpServletRequest());

			idSolic = retornarSenhaAutorizacaoSemDigitioVerificacao(
					guiasAutorizadaSelecionada.getDadosAutorizacao().getSenhaAutorizacao());
			
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(),
					"Início processo: Baixar guia serviço Unimed", TotemUtil.buscarSessionId(), createBasicLogMap());
			final ConfiguracaoImpressoraResult configuracaoImpressoraResult = retornarConfiguracoesImpressora();
			
			InputStream guiaUnimed = baixarGuiaUnimedService.baixarGuiaUnimed(idSolic,
					informacoesTotem.get(0).getIdEmpresa().equals(Long.parseLong(Constantes.ID_EMPRESA_ECOAR)));

			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(),
					"Fim processo: Baixar guia serviço Unimed", TotemUtil.buscarSessionId(), createBasicLogMap());
			if (guiaUnimed != null) {

				final byte[] bytes = IOUtils.toByteArray(guiaUnimed);

				arquivoUtil.salvarDiretorioLocal(bytes, retornarDadosGA(locCriarPedidoResult) + ".pdf");

				registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(), "Início processo: Imprimir guia.",
						TotemUtil.buscarSessionId(), createBasicLogMap());
				arquivoUtil.fazerImpressaoFrenteVerso(retornarDadosGA(locCriarPedidoResult) + ".pdf",
						configuracaoImpressoraResult.getIp());

				registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(), "Fim processo: Imprimir guia.",
						TotemUtil.buscarSessionId(), createBasicLogMap());

				guiaUnimed.close();
			} else {

				final byte[] bytes = IOUtils
						.toByteArray(gerarRelatorioGA(locCriarPedidoResult, guiasAutorizadaSelecionada));

				arquivoUtil.salvarDiretorioLocal(bytes, retornarDadosGA(locCriarPedidoResult) + ".pdf");

				arquivoUtil.fazerImpressaoFrenteVerso(retornarDadosGA(locCriarPedidoResult) + ".pdf",
						configuracaoImpressoraResult.getIp());

			}
			fecharDlgMessage();
			
			/*
			 * gerarRelatorioGA(parCriarPedidoResult, guiasAutorizadaSelecionada)
			 * 
			 * // Não imprimir duas vias da guia mesmo para exames de imagem. // Thiers
			 * 24/12/2018
			 * 
			 * if (isExisteExameDeImagem()) {
			 * arquivoUtil.fazerImpressaoDuplicada(retornarDadosGA(parCriarPedidoResult) +
			 * ".pdf", configuracaoImpressoraResult.getIp()); } else { }
			 */

		} catch (SocketTimeoutException e) {
			contagemErros++;
			houveErroAoImprimirGa = Boolean.TRUE;
			atualizarMsgObservacao();
			msgErro = "Não foi possível concluir conexão impressora.";
			mensagemMotivo = "Falha acessar impressora";
			gravarLogSimplificadoSemExecao(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(),
					String.format("Não foi possível concluir conexão impressora (Falha acessar impressora). %s", e.getMessage()));
		} catch (DownloadUnimedException e) {
			contagemErros++;
			houveErroAoImprimirGa = Boolean.TRUE;
			atualizarMsgObservacao();
			msgErro = "Não foi possível concluir a impressão da Guia de Autorização.";
			mensagemMotivo = "Falha ao baixar a guia da Unimed";
			gravarLogSimplificadoSemExecao(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(),
					String.format("Não foi possível concluir a impressão da Guia de Autorização. ( Falha ao baixar a guia da Unimed). %s", e.getMessage()));
		} catch (final Exception exc) {
			contagemErros++;
			houveErroAoImprimirGa = Boolean.TRUE;
			atualizarMsgObservacao();
			msgErro = "Não foi possível concluir a impressão da Guia de Autorização.";
			mensagemMotivo = "Falha ao imprimir guia Unimed";
			gravarLogSimplificadoSemExecao(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(),
					String.format("Não foi possível concluir a impressão da Guia de Autorização. (Falha ao imprimir guia Unimed): %s", exc.getMessage()));
		} finally {
			fecharDialogImprimirGA();
			
			if (msgErro != null) {
				//exibir mensagem erro na tela
				mensagemAviso = msgErro;
				exibirDialogMensagem();
			}
		}
	}

	private ConfiguracaoImpressoraResult retornarConfiguracoesImpressora() throws Exception {
		final ParametroInformacaoImpressora parametroInformacaoImpressora = new ParametroInformacaoImpressora(
				informacoesTotem.get(0), tokenResult);
		ConfiguracaoImpressoraResult configuracaoImpressoraResult = new ConfiguracaoImpressoraResult();
		final ConfiguracaoImpressoraService configuracaoImpressoraService = new ConfiguracaoImpressoraService(
				getHttpServletRequest());
		configuracaoImpressoraService.retornarInformacoes(parametroInformacaoImpressora);
		if (configuracaoImpressoraService.isSuccess()) {
			configuracaoImpressoraResult = (ConfiguracaoImpressoraResult) configuracaoImpressoraService
					.getResponseObject();
			return configuracaoImpressoraResult;
		} else {
			throw new Exception(configuracaoImpressoraService.getResponseMessage());
		}
	}

	public Integer retornarValorDefault(final ProcedimentoComExamesTO procedimentoComExamesTO) {
		try {
			if (procedimentoJaFoiUtilizado(procedimentoComExamesTO)) {
				return 2;
			} else {
				if (procedimentoComExamesTO.getRepetido()) {
					return 0;
				}
				if (condicaoParaExibirExameDefault(procedimentoComExamesTO)) {
					int indexOF = procedimentoComExamesTO.getExames().indexOf(procedimentoComExamesTO.getExame());
					return procedimentoComExamesTO.getExames().get(indexOF).getValueDefault();
				} else {
					return 0;
				}
			}
		} catch (final Exception locExc) {
			return 0;
		}
	}

	private boolean procedimentoJaFoiUtilizado(final ProcedimentoComExamesTO procedimentoComExamesTO) {
		return procedimentoComExamesTO.getExames().get(0).getUtilizado() == 1;
	}

	private boolean condicaoParaExibirExameDefault(final ProcedimentoComExamesTO procedimentoComExamesTO) {
		return procedimentoComExamesTO.getExames() != null && !procedimentoComExamesTO.getExames().isEmpty()
				&& procedimentoComExamesTO.getExames().size() > 1;
	}

	private String retornarDadosGA(final CriarPedidoResult parCriarPedidoResult) {
		final StringBuilder sb = new StringBuilder();
		sb.append("GA_").append(retornarUnidade()).append("_").append(parCriarPedidoResult.getPedido());
		return sb.toString();
	}

	private void resetarCampos() {
		getUser().setNewPass("");
		getUser().setConfirmAuthPass("");
	}

	public String redirectAgendamento() {
		return "/pages/nau/agendamento.xhtml?faces-redirect=true";
	}

	public String redirectParaVerificaCadastro() {
		return "/passelivretotem/pages/nau/verificaCadastro.xhtml?faces-redirect=true";
	}

	private String redirectCadastroUsuario() {
		return "/passelivretotem/pages/nau/cadastroUsuario.xhtml?faces-redirect=true";
	}

	private String redirectLogin() {
		return "/pages/nau/login.xhtml?faces-redirect=true";
	}

	private String redirectAtualizarUsuario() {
		return "/pages/nau/atualizarDados.xhtml?faces-redirect=true";
	}

	public String redirectIndex() throws Exception {
		final String nomeMaquina = retornarNomeDaMaquina();
		getSession().removeAttribute("indexBean");
		TotemUtil.limparSession();
		return "/indexTotem.xhtml?faces-redirect=true&nomeTotem=" + nomeMaquina;
	}

	public String fazerLogin() {
		try {
			return redirectLogin();
		} catch (final Exception e) {
			return "";
		}
	}

	public String fazerCadastro() {
		try {
			return redirectCadastroUsuario();
		} catch (final Exception e) {
			return "";
		}
	}

	public String retornarSolicitante(final Ct_dadosAutorizacao ct_dadosAutorizacao) {
		try {
			final ConsultaGuiasAutorizadasService guiasAutorizadasService = new ConsultaGuiasAutorizadasService(
					getHttpServletRequest());
			return guiasAutorizadasService.retornarSolicitante(ct_dadosAutorizacao);
		} catch (final Exception exc) {
			return "";
		}
	}

	public boolean isAgendamentoOutraUnidadeUnidade(final AgendamentoUnidade agendamento) {
		return !retornarUnidade().equals(agendamento.getUnidade());
	}

	public boolean isAgendamentoSelecionado() {
		RequestContext.getCurrentInstance().update("dlgConfirmacaoAvancar");
		return agendamentoUnidade != null && agendamentoUnidade.getDataAgendada() != null;
	}

	public void unselectAll() {
		agendamentoUnidade = null;
		RequestContext.getCurrentInstance().update("dttGuiasAutorizadas");
	}

	public String getMensagemCabecalho() {
		try {
			return MensagemUtil.retornarMensagemCabelho(clienteUnidadePasseLivre, numeroCarteira);
		} catch (final Exception locExc) {
			return "";
		}
	}

	public String mensagemCabecalho(String linha) {
		try {

			return MensagemUtil.retornarMensagemCabelho(clienteUnidadePasseLivre, numeroCarteira, linha);
		} catch (final Exception locExc) {
			return "";
		}
	}

	public Boolean isHabilitaDescricaoExame(final ProcedimentoComExamesTO parProcedimento) {
		try {
			return !(materialEhDiv(parProcedimento) && (isInformacaoAdicionalEstaVazio(parProcedimento)
					|| parProcedimento.getInformacoesAdicionais().equals("URINA JATO MÉDIO")
					|| parProcedimento.getInformacoesAdicionais().equals("SANGUE")));
		} catch (final Exception locExc) {
			return false;
		}
	}

	private boolean isInformacaoAdicionalEstaVazio(final ProcedimentoComExamesTO locProcedimento) {
		return locProcedimento.getInformacoesAdicionais() == null
				|| locProcedimento.getInformacoesAdicionais().isEmpty();
	}

	private boolean isCondicaoAmostraEstaVazio(final ProcedimentoComExamesTO locProcedimento) {
		return locProcedimento.getCondicaoAmostra() == null || locProcedimento.getCondicaoAmostra().isEmpty();
	}

	private Boolean materialEhDiv(final ProcedimentoComExamesTO parProcedimento) {
		try {
			if (parProcedimento.getExame() != null) {
				return parProcedimento.getExame().getMaterial().equals("DIV");
			} else if (!parProcedimento.getExames().isEmpty()) {
				return parProcedimento.getExames().get(0).getMaterial().equals("DIV");
			}
			return false;
		} catch (final Exception locExc) {
			return false;
		}
	}

	private Boolean materialEhVivo(final ProcedimentoComExamesTO parProcedimento) {
		try {
			if (parProcedimento.getExame() != null) {
				return parProcedimento.getExame().getMaterial().equals("VIVO");
			} else if (!parProcedimento.getExames().isEmpty()) {
				return parProcedimento.getExames().get(0).getMaterial().equals("VIVO");
			}
			return false;
		} catch (final Exception locExc) {
			return false;
		}
	}

	private Boolean materialEhVAC(final ProcedimentoComExamesTO parProcedimento) {
		try {
			if (parProcedimento.getExame() != null) {
				return parProcedimento.getExame().getMaterial().equals("VAC");
			} else if (!parProcedimento.getExames().isEmpty()) {
				return parProcedimento.getExames().get(0).getMaterial().equals("VAC");
			}
			return false;
		} catch (final Exception locExc) {
			return false;
		}
	}

	public String retornarNomeBeneficiario() {
		if (guiasAutorizadas != null && !guiasAutorizadas.isEmpty()
				&& guiasAutorizadas.get(0).getBeneficiario() != null) {
			return guiasAutorizadas.get(0).getBeneficiario().getNomeBeneficiario();
		}
		return "";
	}

	public Map createBasicLogMap() {
		Long idTotem = null;
		Long idUnidade = null;
		if (informacoesTotem != null && !informacoesTotem.isEmpty()) {
			idTotem = informacoesTotem.get(0).getId();
			idUnidade = Long.valueOf(informacoesTotem.get(0).getIdUnidade());
		}
		try {
			return TotemUtil.createBasicLogMap(idTotem, idUnidade, Util.getClientIpAddr(getHttpServletRequest()));
		} catch (Exception e) {
			e.printStackTrace();
			return new HashMap();
		}
	}

	private int calcularDigito(String str, int[] peso) {
		int soma = 0;
		for (int indice = str.length() - 1, digito; indice >= 0; indice--) {
			digito = Integer.parseInt(str.substring(indice, indice + 1));
			soma += digito * peso[peso.length - str.length() + indice];
		}
		soma = 11 - soma % 11;
		return soma > 9 ? 0 : soma;
	}

	public void isValidCPF() {
		String cpf = clienteUnidadePasseLivre.getCpf();
		cpf = cpf.replace(".", "").replace("-", "");
		if ((cpf == null) || (cpf.length() != 11)) {
			mensagemAviso = "CPF Inválido";
			exibirDialogMensagem();
			return;
		}

		Integer digito1 = calcularDigito(cpf.substring(0, 9), Constantes.PESOCPF);
		Integer digito2 = calcularDigito(cpf.substring(0, 9) + digito1, Constantes.PESOCPF);

		if (!cpf.equals(cpf.substring(0, 9) + digito1.toString() + digito2.toString())) {
			clienteUnidadePasseLivre.setCpf(null);
			mensagemAviso = "CPF Inválido";
			exibirDialogMensagem();
		}
	}

	public void abrirDialogExamesDaGuia(final Ct_dadosAutorizacao ct_dadosAutorizacao) {
		guiasAutorizadaSelecionada = ct_dadosAutorizacao;
	}

	public void onRowSelect() {
		// quantidadeExameVT -= 1;
	}

	public void onRowUnselect() {
		// quantidadeExameVT += 1;
	}

	public Integer getActiveIndex() {
		return activeIndex;
	}

	public void setActiveIndex(final Integer activeIndex) {
		this.activeIndex = activeIndex;
	}

	public ClienteUnidadePasseLivre getClienteUnidadePasseLivre() {
		return clienteUnidadePasseLivre;
	}

	public void setClienteUnidadePasseLivre(final ClienteUnidadePasseLivre clienteUnidadePasseLivre) {
		this.clienteUnidadePasseLivre = clienteUnidadePasseLivre;
	}

	public UserAuth getUser() {
		return user;
	}

	public void setUser(final UserAuth user) {
		this.user = user;
	}

	public Constantes getConstantes() {
		return constantes;
	}

	public List<br.com.unimedbh.www.Ct_dadosAutorizacao> getGuiasAutorizadasSelecionadas() {
		return guiasAutorizadasSelecionadas;
	}

	public void setGuiasAutorizadasSelecionadas(
			final List<br.com.unimedbh.www.Ct_dadosAutorizacao> parGuiasAutorizadasSelecionadas) {
		guiasAutorizadasSelecionadas = parGuiasAutorizadasSelecionadas;
	}

	public List<br.com.unimedbh.www.Ct_dadosAutorizacao> getGuiasAutorizadas() {
		return guiasAutorizadas;
	}

	public List<Ct_dadosAutorizacao> getGuiasAutorizadasNaoRespondidas() {
		guiasAutorizadasNaoRespondidas.clear();
		guiasAutorizadasNaoRespondidas.addAll(guiasAutorizadas);
		guiasAutorizadasNaoRespondidas.removeAll(guiasAutorizadasRespondidas);
		return guiasAutorizadasNaoRespondidas;
	}

	public void setGuiasAutorizadas(final List<br.com.unimedbh.www.Ct_dadosAutorizacao> parGuiasAutorizadas) {
		guiasAutorizadas = parGuiasAutorizadas;
	}

	public ParametroQuestionario getParametroQuestionario() {
		return parametroQuestionario;
	}

	public void setParametroQuestionario(final ParametroQuestionario parParametroQuestionario) {
		parametroQuestionario = parParametroQuestionario;
	}

	public ConsultaQuestionarioExameResult getConsultaQuestionarioExameResult() {
		return consultaQuestionarioExameResult;
	}

	public void setConsultaQuestionarioExameResult(
			final ConsultaQuestionarioExameResult parConsultaQuestionarioExameResult) {
		consultaQuestionarioExameResult = parConsultaQuestionarioExameResult;
	}

	public List<Procedimento> getProcedimentos() {
		return procedimentos;
	}

	public void setProcedimentos(final List<Procedimento> parProcedimentos) {
		procedimentos = parProcedimentos;
	}

	public PanelGrid getPngQuestionario() {
		return pngQuestionario;
	}

	public void setPngQuestionario(final PanelGrid parPngQuestionario) {
		pngQuestionario = parPngQuestionario;
	}

	public Panel getPnlQuestionario() {
		return pnlQuestionario;
	}

	public void setPnlQuestionario(final Panel parPnlQuestionario) {
		pnlQuestionario = parPnlQuestionario;
	}

	public MasterDetail getMasterDetail() {
		return mtdQuestionario;
	}

	public void setMasterDetail(final MasterDetail parMasterDetail) {
		mtdQuestionario = parMasterDetail;
	}

	public MasterDetailLevel getMdlQuestionario() {
		return mdlQuestionario;
	}

	public void setMdlQuestionario(final MasterDetailLevel parMdlQuestionario) {
		mdlQuestionario = parMdlQuestionario;
	}

	public MasterDetail getMtdQuestionario() {
		return mtdQuestionario;
	}

	public void setMtdQuestionario(final MasterDetail parMtdQuestionario) {
		mtdQuestionario = parMtdQuestionario;
	}

	public List<MasterDetailLevel> getMdlsQuestionario() {
		return mdlsQuestionario;
	}

	public void setMdlsQuestionario(final List<MasterDetailLevel> parMdlsQuestionario) {
		mdlsQuestionario = parMdlsQuestionario;
	}

	public Questionario getQuestionario() {
		return questionario;
	}

	public void setQuestionario(final Questionario parQuestionario) {
		questionario = parQuestionario;
	}

	public Map<String, String> getMapQuestionarios() {
		return mapQuestionarios;
	}

	public void setMapQuestionarios(final Map<String, String> parMapQuestionarios) {
		mapQuestionarios = parMapQuestionarios;
	}

	public ConsultaPreparoResult getConsultaPreparoResult() {
		return consultaPreparoResult;
	}

	public void setConsultaPreparoResult(final ConsultaPreparoResult parConsultaPreparoResult) {
		consultaPreparoResult = parConsultaPreparoResult;
	}

	public List<Procedimento> getProcedimentosSelecionados() {
		return procedimentosSelecionados;
	}

	public void setProcedimentosSelecionados(final List<Procedimento> parProcedimentosSelecionados) {
		procedimentosSelecionados = parProcedimentosSelecionados;
	}

	public Boolean getExibeListaExame() {
		return exibeListaExame;
	}

	public void setExibeListaExame(final Boolean parExibeListaExame) {
		exibeListaExame = parExibeListaExame;
	}

	public Boolean getExibeSimplesExame() {
		return exibeSimplesExame;
	}

	public void setExibeSimplesExame(final Boolean parExibeSimplesExame) {
		exibeSimplesExame = parExibeSimplesExame;
	}

	public List<ProcedimentoComExamesTO> getProcedimentosComExames() {
		return procedimentosComExames;
	}

	public void setProcedimentosComExames(final List<ProcedimentoComExamesTO> parProcedimentosComExames) {
		procedimentosComExames = parProcedimentosComExames;
	}

	public List<ProcedimentoComExamesTO> getProcedimentosComExamesSelecionados() {
		return procedimentosComExamesSelecionados;
	}

	public void setProcedimentosComExamesSelecionados(
			final List<ProcedimentoComExamesTO> parProcedimentosComExamesSelecionados) {
		procedimentosComExamesSelecionados = parProcedimentosComExamesSelecionados;
	}

	public String getNumeroCarteira() {
		return numeroCarteira;
	}

	public void setNumeroCarteira(final String parNumeroCarteira) {
		numeroCarteira = parNumeroCarteira;
	}

	public String getResultadoBiometria() {
		return resultadoBiometria;
	}

	public void setResultadoBiometria(final String parResultadoBiometria) {
		resultadoBiometria = parResultadoBiometria;
	}

	public String getMensagemAviso() {
		return mensagemAviso;
	}

	public void setMensagemAviso(final String parMensagemAviso) {
		mensagemAviso = parMensagemAviso;
	}

	public ParametroConsultaCliente getParametroConsultaCliente() {
		return parametroConsultaCliente;
	}

	public void setParametroConsultaCliente(final ParametroConsultaCliente parParametroConsultaCliente) {
		parametroConsultaCliente = parParametroConsultaCliente;
	}

	public List<ExameHermesPardini> getExamesExcecao() {
		return examesExcecao;
	}

	public void setExamesExcecao(final List<ExameHermesPardini> parExamesExcecao) {
		examesExcecao = parExamesExcecao;
	}

	public List<GuiaAutorizadaExcecao> getGuiasAutorizadasExcecao() {
		return guiasAutorizadasExcecao;
	}

	public void setGuiasAutorizadasExcecao(final List<GuiaAutorizadaExcecao> parGuiasAutorizadasExcecao) {
		guiasAutorizadasExcecao = parGuiasAutorizadasExcecao;
	}

	public HabilitacaoCamposCadastroTO getHabilitacaoCamposCadastroTO() {
		return habilitacaoCamposCadastroTO;
	}

	public void setHabilitacaoCamposCadastroTO(final HabilitacaoCamposCadastroTO parHabilitacaoCamposCadastroTO) {
		habilitacaoCamposCadastroTO = parHabilitacaoCamposCadastroTO;
	}

	public ProcedimentoComExamesTO getProcedimentoParametro() {
		return procedimentoParametro;
	}

	public void setProcedimentoParametro(final ProcedimentoComExamesTO parProcedimentoParametro) {
		procedimentoParametro = parProcedimentoParametro;
	}

	public List<ProcedimentoComExamesTOExcecao> getProcedimentosComExamesExcecao() {
		return procedimentosComExamesExcecao;
	}

	public void setProcedimentosComExamesExcecao(
			final List<ProcedimentoComExamesTOExcecao> parProcedimentosComExamesExcecao) {
		procedimentosComExamesExcecao = parProcedimentosComExamesExcecao;
	}

	public Ct_dadosAutorizacao getGuiasAutorizadaSelecionada() {
		return guiasAutorizadaSelecionada;
	}

	public void setGuiasAutorizadaSelecionada(final Ct_dadosAutorizacao parGuiasAutorizadaSelecionada) {
		guiasAutorizadaSelecionada = parGuiasAutorizadaSelecionada;
	}

	public Boolean getHouveAlteracao() {
		return houveAlteracao;
	}

	public void setHouveAlteracao(final Boolean parHouveAlteracao) {
		houveAlteracao = parHouveAlteracao;
	}

	public List<ProcedimentoComExamesTO> getProcedimentosExcluidos() {
		return procedimentosExcluidos;
	}

	public void setProcedimentosExcluidos(final List<ProcedimentoComExamesTO> parProcedimentosExcluidos) {
		procedimentosExcluidos = parProcedimentosExcluidos;
	}

	public AgendamentoUnidade getAgendamentoUnidade() {
		return agendamentoUnidade;
	}

	public void setAgendamentoUnidade(final AgendamentoUnidade parAgendamentoUnidade) {
		agendamentoUnidade = parAgendamentoUnidade;
	}

	public List<AgendamentoUnidade> getAgendamentosUnidade() {
		return agendamentosUnidade;
	}

	public void setAgendamentosUnidade(final List<AgendamentoUnidade> parAgendamentosUnidade) {
		agendamentosUnidade = parAgendamentosUnidade;
	}

	public Integer getNumeroPedido() {
		return numeroPedido;
	}

	public void setNumeroPedido(Integer numeroPedido) {
		this.numeroPedido = numeroPedido;
	}

	public InformacaoTotem getInformacaoTotem() {
		return informacaoTotem;
	}

	public void setInformacaoTotem(InformacaoTotem informacaoTotem) {
		this.informacaoTotem = informacaoTotem;
	}

	public String getNumeroGuia() {
		if (guiasAutorizadaSelecionada != null && guiasAutorizadaSelecionada.getIdentificacaoAutorizacao() != null) {
			return guiasAutorizadaSelecionada.getIdentificacaoAutorizacao().getNumeroGuiaOperadora();
		}
		return "";
	}

	public Boolean getHabilitarMarcacao() {
		return habilitarMarcacao;
	}

	public void setHabilitarMarcacao(Boolean habilitarMarcacao) {
		this.habilitarMarcacao = habilitarMarcacao;
	}

	public String getMsgTelaFinalizacao() {
		return msgTelaFinalizacao;
	}

	public void setMsgTelaFinalizacao(String msgTelaFinalizacao) {
		this.msgTelaFinalizacao = msgTelaFinalizacao;
	}

	public String getTentativasBiometria() {
		return tentativasBiometria;
	}

	public void setTentativasBiometria(String tentativasBiometria) {
		this.tentativasBiometria = tentativasBiometria;
	}

	public String getProvidencia() {
		return providencia;
	}

	public void setProvidencia(String providencia) {
		this.providencia = providencia;
	}

	public Map<ExameSimplificado, List<ExameSimplificado>> getCombinacaoExamesCalculados() {
		return combinacaoExamesCalculados;
	}

	public void setCombinacaoExamesCalculados(
			Map<ExameSimplificado, List<ExameSimplificado>> combinacaoExamesCalculados) {
		this.combinacaoExamesCalculados = combinacaoExamesCalculados;
	}

	public boolean isCombinacaoUniao() {
		return combinacaoUniao;
	}

	public void setCombinacaoUniao(boolean combinacaoUniao) {
		this.combinacaoUniao = combinacaoUniao;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getComplemento() {
		return complemento;
	}

	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}

	public boolean isEditarLogradouro() {
		return editarLogradouro;
	}

	public void setEditarLogradouro(boolean editarLogradouro) {
		this.editarLogradouro = editarLogradouro;
	}

	public boolean isEditarBairro() {
		return editarBairro;
	}

	public void setEditarBairro(boolean editarBairro) {
		this.editarBairro = editarBairro;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getLogradouro() {
		return logradouro;
	}

	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}

	public String getDescStatusImpressora() {
		return descStatusImpressora;
	}

	public void setDescStatusImpressora(String descStatusImpressora) {
		this.descStatusImpressora = descStatusImpressora;
	}

	private void mensagemErroBuscarInformacoesTotem() throws Exception {
		sessaoValida = Boolean.FALSE;
		throw new Exception("Perda de informações do totem, favor procurar atendente");
	}
	
	private String retornarLocalidade(Localidade localidade) {
		if (localidade != null) {
			if (Util.isTotemAim33()) {
				return "13667";
			} else {
				return localidade.getCodigounidade();
			}
		}
		return "";
	}

	public Boolean getPermitirReimpressaoGa() {
		return houveErroAoImprimirGa && (contagemErros < BigInteger.valueOf(3l).intValue());		
	}

	private void atualizarMsgObservacao() {
		if(!getPermitirReimpressaoGa()) {
			setMsgObservacao("FAVOR PROCURAR ATENDENTE");
		}
	}	
	
	public String getMsgObservacao() {
		return msgObservacao;
	}

	public void setMsgObservacao(String msgObservacao) {
		this.msgObservacao = msgObservacao;
	}	
	
	public String getMensagemMotivo() {
		return mensagemMotivo;
	}

	public void setMensagemMotivo(String mensagemMotivo) {
		this.mensagemMotivo = mensagemMotivo;
	}	
	
	public void fecharDlgMessage() {
		if(contagemErros > BigInteger.ZERO.intValue()) {
			RequestContext.getCurrentInstance().execute("PF('dlgMessage').hide()");
		}
	}

}
