package br.com.hermespardini.passelivre.bean;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import org.primefaces.context.RequestContext;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.constantsenum.TipoServicoEnum;
import br.com.hermespardini.passelivre.exception.EnvioEmailException;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.exception.SelecaoCampoException;
import br.com.hermespardini.passelivre.model.Agenda;
import br.com.hermespardini.passelivre.model.AgendamentoUnidade;
import br.com.hermespardini.passelivre.model.ClienteUnidadePasseLivre;
import br.com.hermespardini.passelivre.model.ConsultaCodigoResult;
import br.com.hermespardini.passelivre.model.ConsultaQuestionarioExameResult;
import br.com.hermespardini.passelivre.model.CriarPedidoResult;
import br.com.hermespardini.passelivre.model.ExameHermesPardini;
import br.com.hermespardini.passelivre.model.ExamePedido;
import br.com.hermespardini.passelivre.model.ExamesResultadosPedido;
import br.com.hermespardini.passelivre.model.Guia;
import br.com.hermespardini.passelivre.model.Guias;
import br.com.hermespardini.passelivre.model.InformacaoConvenio;
import br.com.hermespardini.passelivre.model.InformacaoTotem;
import br.com.hermespardini.passelivre.model.InformacaoTotemDesktop;
import br.com.hermespardini.passelivre.model.MensagemAviso;
import br.com.hermespardini.passelivre.model.ParametroDataPrevisaoResultado;
import br.com.hermespardini.passelivre.model.ParametroPedido;
import br.com.hermespardini.passelivre.model.ParametroPreAtendimento;
import br.com.hermespardini.passelivre.model.PerguntaEntrega;
import br.com.hermespardini.passelivre.model.PreAtendimento;
import br.com.hermespardini.passelivre.model.Solicitante;
import br.com.hermespardini.passelivre.model.TokenResult;
import br.com.hermespardini.passelivre.model.Unidade;
import br.com.hermespardini.passelivre.service.ConsultaExamesAutorizadosService;
import br.com.hermespardini.passelivre.service.EnviaEmailService;
import br.com.hermespardini.passelivre.service.PedidoService;
import br.com.hermespardini.passelivre.service.PreAtendimentoService;
import br.com.hermespardini.passelivre.to.ProcedimentoComExamesTO;
import br.com.hermespardini.passelivre.utils.MensagemUtil;
import br.com.hermespardini.passelivre.utils.QuestionarioUtil;
import br.com.hermespardini.passelivre.utils.TotemUtil;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.bean.MainBean;

@SessionScoped
@SuppressWarnings({ "serial" })
@ManagedBean(name = "preAtendimentoBean")
public class PreAtendimentoBean extends MainBean {

	private String sessionId;
	private TipoServicoEnum tipoServico;
	private String mensagemAviso;
	private List<InformacaoTotem> informacoesTotem;
	private List<InformacaoTotemDesktop> informacoesTotemDesktop;
	private TokenResult tokenResult;
	private ClienteUnidadePasseLivre clienteUnidadePasseLivre;
	private PreAtendimento preAtendimentoSelecionado;
	private List<PreAtendimento> listaPreAtendimento;
	private List<ExamePedido> listaExames;
	private List<ExamePedido> examesSelecionados;
	private List<ProcedimentoComExamesTO> listaProcedimentos;
	private List<ProcedimentoComExamesTO> listaProcedimentosSelecionados;
	private List<ProcedimentoComExamesTO> procedimentosComExamesParaGerarPedido;
	private List<PerguntaEntrega> perguntas;
	private List<ConsultaQuestionarioExameResult> consultaQuesitonarioExameResult;
	private boolean desktop;
	private InformacaoTotem informacaoTotem;
	private String providencia;
	private String detalhesEmail;

	@PostConstruct
	public void onLoad() {
		tipoServico = TotemUtil.recuperarTipoServico();
		tokenResult = TotemUtil.buscarToken();
		clienteUnidadePasseLivre = TotemUtil.recuperarClientePasseLivre();
		listaProcedimentosSelecionados = new ArrayList<>();
		sessionId = TotemUtil.buscarSessionId();
		consultaQuesitonarioExameResult = new ArrayList<>();

		desktop = TotemUtil.isDesktop();
		if (desktop) {
			informacoesTotemDesktop = TotemUtil.buscarInformacoesTotemDesktop();
		} else {
			informacoesTotem = TotemUtil.buscarInformacoesTotem();
			informacaoTotem = informacoesTotem.stream().filter(x -> x.getDescricao().equals("PRE_ATENDIMENTO"))
					.findFirst().get();
		}
		recuperaPreAtendimento();
		if (preAtendimentoSelecionado != null) {
			pularTelaSelecaoPreAtendimento();
		} else {
			consultarPreAtendimento();
		}
	}

	public void consultarPreAtendimento() {
		final ParametroPreAtendimento parametroPreAtendimento = new ParametroPreAtendimento(clienteUnidadePasseLivre,
				tokenResult);
		try {
			final PreAtendimentoService preAtendimentoService = new PreAtendimentoService(getHttpServletRequest());
			List<PreAtendimento> listaPreAtendimentoRetorno = preAtendimentoService
					.consultarPreAtendimento(parametroPreAtendimento);
			listaPreAtendimento = new ArrayList<PreAtendimento>();
			boolean contemParticular = false;
			boolean exibirDialog = false;
			for (PreAtendimento p : listaPreAtendimentoRetorno) {
				contemParticular = false;
				if (p.getDataValidade() != null) {
					Date dataValidade = new SimpleDateFormat("yyyy-MM-dd").parse(p.getDataValidade());
					Date hoje = new Date();

					if (dataValidade.getDate() != hoje.getDate() && dataValidade.before(hoje)) {
						continue;
					}
				}
				if (p.getPaciente().getOperadora().equals("PART")) {
					contemParticular = true;
					exibirDialog = true;
				}

				for (Guia guia : p.getGuias()) {
					for (ExamePedido ep : guia.getExames()) {
						if (ep.getParticular().equals("S")) {
							contemParticular = true;
							exibirDialog = true;
						}
					}
				}
				listaPreAtendimento.add(p);
				if (contemParticular) {
					// mensagemAviso =
					// getGlobalResourceBundleString("textoPreAtendimentoParticular");
					mensagemAviso = "Pré-atendimento na modalidade particular favor procurar um de nossos atendentes.";
				}
			}
			if (exibirDialog) {
				exibirDialogMensagem();
			}
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(),
					"Foi realizada consulta de pré atendimentos. Pr�-atendimentos dispon�veis: "
							+ listaPreAtendimento.size(),
					TotemUtil.buscarSessionId(), createBasicLogMap());
		} catch (final Exception exc) {
			exc.printStackTrace();

		}
	}

	public String getMensagemCabecalho() {
		try {
			return MensagemUtil.retornarMensagemCabelho(clienteUnidadePasseLivre, "");
		} catch (final Exception locExc) {
			return "";
		}
	}

	public String avancarExames() throws Exception {
		try {
			gerarExameParaVT();
			verificarExamesExcluidosDaGuia();
			if (isExisteQuestionario()) {
				getSession().setAttribute("questionarioIsBotaoOn", true);
				return "/pages/questionario.xhtml?faces-redirect=true";
			} else {
				return fazerPedido();
			}
		} catch (final RegraNegocioException locExc) {
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
			return null;
		} catch (final SelecaoCampoException locExc) {
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
			return null;
		} catch (final Exception locExc) {
			mensagemAviso = locExc.getMessage();
			exibirDialogMensagem();
			return null;
		}
	}

	private void verificarExamesExcluidosDaGuia() throws SelecaoCampoException {
		if (procedimentosComExamesParaGerarPedido.isEmpty()) {
			throw new SelecaoCampoException("É preciso ter pelo menos um exame para gerar pedido!");
		}
	}

	private void verificaSeExamesForamSelecionados() throws SelecaoCampoException {
		if (listaProcedimentosSelecionados.isEmpty()) {
			throw new SelecaoCampoException("Exame deve ser selecionado!");
		}
	}

	private void exibirDialogMensagem() {
		RequestContext.getCurrentInstance().execute("PF('dlgMessage').show()");
	}

	private void converterExames() throws Exception {
		listaProcedimentos = new ArrayList<>();
		if (!isPreAtendimentoParticular()) {
			for (final Guia guia : preAtendimentoSelecionado.getGuias()) {
				for (final ExamePedido exame : guia.getExames()) {
					InformacaoConvenio informacaoConvenio = new InformacaoConvenio(exame, preAtendimentoSelecionado, 
							tokenResult, informacaoTotem.getIdUnidade(), "", clienteUnidadePasseLivre); 
					ConsultaCodigoResult consultaCodigoResult = buscarExamesAutorizados(informacaoConvenio);
					
					if (!consultaCodigoResult.getExames().isEmpty()) { 
						listaProcedimentos.add(new ProcedimentoComExamesTO(exame, guia.getNumeroGuiaOperadora(),
								consultaCodigoResult)); 
					} else { 
						listaProcedimentos.add(new ProcedimentoComExamesTO(exame, guia.getNumeroGuiaOperadora())); 
					}
				}
			}
		} else {
			for (final Guia guia : preAtendimentoSelecionado.getGuias()) {
				for (final ExamePedido exame : guia.getExames()) {
					listaProcedimentos.add(new ProcedimentoComExamesTO(exame, guia.getNumeroGuiaOperadora()));
				}
			}
		}
	}

	private ConsultaCodigoResult buscarExamesAutorizados(final InformacaoConvenio informacoesConvenio)
			throws Exception {
		String mensagem = "";
		ConsultaExamesAutorizadosService examesAutorizadosService;
		ConsultaCodigoResult consultaCodigoResult = new ConsultaCodigoResult();
		final List<ConsultaCodigoResult> consultasCodigoResult = new ArrayList<>();
		try {
			examesAutorizadosService = new ConsultaExamesAutorizadosService(getHttpServletRequest());
			examesAutorizadosService.setValueObject(informacoesConvenio);
			examesAutorizadosService.consultar();
			if (examesAutorizadosService.isSuccess()) {
				consultaCodigoResult = (ConsultaCodigoResult) examesAutorizadosService.getResponseObject();
				consultasCodigoResult.add(consultaCodigoResult);
				mensagem = examesAutorizadosService.getResponseMessage();

				return consultaCodigoResult;
			} else {
				throw new Exception(examesAutorizadosService.getResponseMessage());
			}
		} catch (final RuntimeException exc) {
			throw new RuntimeException(exc.getMessage());

		} catch (final Exception exc) {
			throw new Exception(exc.getMessage());
		}
	}

	public void mostrarDataHoraMarcacao(final ExameHermesPardini exame) {
		listaProcedimentos.size();
	}

	private boolean isExisteQuestionario() throws Exception {
		final QuestionarioUtil questionarioUtil = new QuestionarioUtil();
		try {
			questionarioUtil.buscarQuestionario(listaProcedimentosSelecionados, clienteUnidadePasseLivre, tokenResult);
			if (questionarioUtil.isExisteQuestionario()) {
				consultaQuesitonarioExameResult.add(questionarioUtil.getConsultaQuestionarioExameResult());
				registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(),
						"Foi encontrado questionário para os exames selecionados. Redirecionado para questionários.",
						sessionId, createBasicLogMap());
			} else {
				registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(),
						"Não foi encontrado questionário para os exames selecionados.", TotemUtil.buscarSessionId(),
						createBasicLogMap());
			}
			return questionarioUtil.isExisteQuestionario();
		} catch (final RegraNegocioException exc) {
			exc.printStackTrace();

		}
		return false;

	}

	private void gerarExameParaVT() throws RegraNegocioException {
		procedimentosComExamesParaGerarPedido = new ArrayList<>();
		for (final ProcedimentoComExamesTO procedimentoComExamesTO : listaProcedimentos) {
			if (exameNaoSeraExcluido(procedimentoComExamesTO)) {
				if (listaProcedimentosSelecionados.contains(procedimentoComExamesTO)) {
					procedimentoComExamesTO.setVt(false);
					procedimentosComExamesParaGerarPedido.add(procedimentoComExamesTO);
				} else {
					procedimentoComExamesTO.setVt(true);
					procedimentoComExamesTO.getExame().setDataHoraMarcacao(null);
					procedimentosComExamesParaGerarPedido.add(procedimentoComExamesTO);
				}
			}
		}

	}

	private boolean exameNaoSeraExcluido(final ProcedimentoComExamesTO locProcedimento) {
		try {
			return !locProcedimento.getExcluido();
		} catch (final Exception locExc) {
			return true;
		}
	}

	public String fazerPedido() throws Exception {
		try {
			gerarExameParaVT();
			preencherQuestionario();
			final ParametroPedido parametroPedido = criarParametroPedido();
			final PedidoService pedidoService = new PedidoService(getHttpServletRequest());
			pedidoService.fazerPedido(parametroPedido);
			if (pedidoService.isSuccess()) {
				final CriarPedidoResult result = (CriarPedidoResult) pedidoService.getResponseObject();
				registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(),
						"Pedido realizado com sucesso:" + result.getPedido(), TotemUtil.buscarSessionId(),
						createBasicLogMap());
				imprimirQuestionario();
				acoesAposPedidoRealizadoComSucesso(result);

				return "/pages/finalizacaoPedido.xhtml?faces-redirect=true";
			} else {
				registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(),
						"Erro ao fazer pedido de pré-atendimento." + pedidoService.getResponseMessage(),
						TotemUtil.buscarSessionId(), createBasicLogMap());
				System.out.println("Erro ao fazer pedido");
			}
			return "/pages/erro/atendimentoNaoConcluido.xhtml?faces-redirect=true";
		} catch (RegraNegocioException locEx) {

			MensagemAviso mensagemAviso = TotemUtil
					.createMensagemAviso("Erro ao criar pedido de pré-atendimento: " + locEx.getMessage());
			try {
				getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return "/pages/erro/atendimentoNaoConcluido.xhtml?faces-redirect=true";
		} catch (Exception e) {
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(),
					"Erro ao fazer pedido de pré-atendimento." + e.getMessage(), TotemUtil.buscarSessionId(),
					createBasicLogMap());
			MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso("Erro ao criar pedido de pré-atendimento ("
					+ preAtendimentoSelecionado.getNumeroPreAtendimento() + "): " + e.getMessage());
			try {
				getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
			} catch (Exception ex) {
				e.printStackTrace();
			}
			return "/pages/erro/atendimentoNaoConcluido.xhtml?faces-redirect=true";
		}
	}

	public ParametroPedido criarParametroPedido() throws Exception {
		final ParametroPedido parametroPedido = new ParametroPedido(informacaoTotem, clienteUnidadePasseLivre,
				tokenResult, listaProcedimentos, preAtendimentoSelecionado, consultaQuesitonarioExameResult, perguntas,
				recuperaSolicitante(), isPreAtendimentoParticular());
		AgendamentoUnidade agendamentoUnidade = (AgendamentoUnidade) getHttpServletRequest().getSession()
				.getAttribute("agendamentoUnidade");
		if (agendamentoUnidade != null && agendamentoUnidade.getDataAgendada() != null) {
			final Agenda agenda = new Agenda();
			agenda.setIdAgendamento(agendamentoUnidade.getIdAgendamento());
			agenda.setDataHoraAgendamento(formataDataAgendamento(agendamentoUnidade));
			parametroPedido.setAgenda(agenda);
			parametroPedido.setGuias(corrigeDataHoraMarcacaoParaExameAgendado(parametroPedido.getGuias(), agendamentoUnidade));
		}
		return parametroPedido;
	}

	private String formataDataAgendamento(final AgendamentoUnidade agendamentoUnidade) {
		String dataFormatada = "";
		final SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		dataFormatada = formatter.format(agendamentoUnidade.getDataAgendada());
		dataFormatada = dataFormatada.concat(" ");
		dataFormatada = dataFormatada.concat(agendamentoUnidade.getHorarioAgendado());
		return dataFormatada;
	}

	private boolean isPreAtendimentoParticular() {
		for (Guia guia : preAtendimentoSelecionado.getGuias()) {
			for (ExamePedido ep : guia.getExames()) {
				if (ep.getParticular().equals("S")) {
					return true;
				}
			}
		}
		return false;
	}

	private void preencherQuestionario() throws Exception {
		try {
			perguntas = (List<PerguntaEntrega>) getSession().getAttribute("perguntas");
		} catch (final Exception locExc) {
			throw new Exception(locExc.getMessage());
		}
	}

	private void imprimirQuestionario() throws Exception {
		final QuestionarioUtil questionarioUtil = new QuestionarioUtil();
		try {
			questionarioUtil.imprimirQuestionario(listaProcedimentosSelecionados, clienteUnidadePasseLivre,
					tokenResult);
			if (questionarioUtil.isQuestionarioImpresso()) {
				registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
						Thread.currentThread().getStackTrace()[1].getMethodName(), "Questionário foi impresso.",
						sessionId, createBasicLogMap());
			}
		} catch (final Exception exc) {
			exc.printStackTrace();
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), "Erro ao tentar imprimir questionário.",
					sessionId, createBasicLogMap());
		}
	}

	private void acoesAposPedidoRealizadoComSucesso(final CriarPedidoResult locCriarPedidoResult) throws Exception {
		getHttpServletRequest().getSession().setAttribute("numeroPedido", locCriarPedidoResult.getPedido());
		// if (getAmbienteProducao()) {
		if (true) {
			try {
				enviarEmailPedidoFinalizado(locCriarPedidoResult);
				detalhesEmail = "Detalhes foram enviados para o seu e-mail.";
			} catch (Exception e) {
				detalhesEmail = "Falha ao enviar o email!";
			}
		}

	}

	private void enviarEmailPedidoFinalizado(final CriarPedidoResult parCriarPedidoResult) throws Exception {
		final ExamesResultadosPedido locExamesResultadosPedido = new ExamesResultadosPedido();
		try {
			adicionarUnidade(parCriarPedidoResult);
			locExamesResultadosPedido.addAll(parCriarPedidoResult.getExames());
			final EnviaEmailService envioEmailService = new EnviaEmailService(getHttpServletRequest());

			if (informacoesTotem.get(0).getIdEmpresa().equals(Long.parseLong(Constantes.ID_EMPRESA_ECOAR))) {
				envioEmailService.enviarEmailFinalizarPedido(clienteUnidadePasseLivre, locExamesResultadosPedido,
						getAmbienteProducao(), true);

			} else {
				envioEmailService.enviarEmailFinalizarPedido(clienteUnidadePasseLivre, locExamesResultadosPedido,
						getAmbienteProducao(), false);

			}

		} catch (final Exception exc) {
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(),
					"Erro ao recuperar solicitante do exame.", TotemUtil.buscarSessionId(), createBasicLogMap());
			throw new EnvioEmailException(exc.getMessage());
		}
	}

	private void adicionarUnidade(final CriarPedidoResult parCriarPedidoResult) {
		if (desktop) {
			final Unidade unidade = TotemUtil.buscarUnidade();
			clienteUnidadePasseLivre.setUnidade(parCriarPedidoResult.getPedido() + "-" + unidade.getNome());
		} else {
			for (final InformacaoTotem locInformacaoTotem : informacoesTotem) {
				if (locInformacaoTotem.getIdUnidade().equals(parCriarPedidoResult.getUnidade().toString())) {
					clienteUnidadePasseLivre
							.setUnidade(parCriarPedidoResult.getPedido() + "-" + locInformacaoTotem.getNomeUnd());
				}
			}
		}
	}

	public Solicitante recuperaSolicitante() throws Exception {
		Solicitante solicitante = null;
		try {
			solicitante = preAtendimentoSelecionado.getGuias().get(0).getSolicitante();
			// Na UNIMED a vari�vel se chama NOME, no PR�-ATENDIMENTO a vari�vel �
			// NOMESOLICITANTE, sendo necess�rio as duas vari�veis
			if (solicitante != null && solicitante.getNome() != null) {
				solicitante.setNomeSolicitante(solicitante.getNome());
			}

		} catch (final Exception exc) {
			exc.printStackTrace();
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(),
					"Erro ao recuperar solicitante do exame.", TotemUtil.buscarSessionId(), createBasicLogMap());
		}
		return solicitante;
	}

	private void recuperaPreAtendimento() {
		try {
			final HttpSession session = getSession();
			preAtendimentoSelecionado = (PreAtendimento) session.getAttribute("preAtendimentoSelecionado");
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	public void cancelar() {
		TotemUtil.cancelarSessao();
	}

	public String voltar() {
		return "/pages/pat/verificarPreAtendimentos.xhtml?faces-redirect=true";
	}

	public String irParaExames() {
		if (preAtendimentoSelecionado.getGuias() != null && !preAtendimentoSelecionado.getGuias().isEmpty()) {
			listaExames = preAtendimentoSelecionado.getGuias().get(0).getExames().getExamesPedidos();
		} else {
			mensagemAviso = "Esse pre atendimento nao tem guia associada";
			exibirDialogMensagem();
			return "";
		}
		try {
			converterExames();
			selecionarTodosExames();
			return "/pages/pat/examesPreAtendimento.xhtml?faces-redirect=true";
		} catch (Exception e) {
			e.printStackTrace();
			mensagemAviso = e.getMessage();
			exibirDialogMensagem();
			return "";
		}
	}

	private void selecionarTodosExames() {
		listaProcedimentosSelecionados.addAll(listaProcedimentos);
	}

	private void pularTelaSelecaoPreAtendimento() {
		try {
			FacesContext.getCurrentInstance().getExternalContext().redirect("/passelivretotem" + irParaExames());
		} catch (final IOException exc) {
			exc.printStackTrace();
		}
	}

	public boolean particular(PreAtendimento parPreAtendimento) {
		for (Guia guia : parPreAtendimento.getGuias()) {
			for (ExamePedido ep : guia.getExames()) {
				if (ep.getParticular().equals("S")) {
					return true;
				}
			}
		}
		return false;
	}

	public String verificarEstilo(PreAtendimento parPreAtendimento) {
		if (particular(parPreAtendimento)) {
			return "rowDisabled";
		} else {
			return "";
		}
	}

	public Map createBasicLogMap() {
		Long idTotem = null;
		Long idUnidade = null;
		if (informacoesTotem != null && !informacoesTotem.isEmpty()) {
			idTotem = informacoesTotem.get(0).getId();
			idUnidade = Long.valueOf(informacoesTotem.get(0).getIdUnidade());
		}
		try {
			return TotemUtil.createBasicLogMap(idTotem, idUnidade, Util.getClientIpAddr(getHttpServletRequest()));
		} catch (Exception e) {
			e.printStackTrace();
			return new HashMap();
		}
	}

	public TipoServicoEnum getTipoServico() {
		return tipoServico;
	}

	public void setTipoServico(final TipoServicoEnum parTipoServico) {
		tipoServico = parTipoServico;
	}

	public String getMensagemAviso() {
		return mensagemAviso;
	}

	public void setMensagemAviso(final String parMensagemAviso) {
		mensagemAviso = parMensagemAviso;
	}

	public List<InformacaoTotem> getInformacoesTotem() {
		return informacoesTotem;
	}

	public void setInformacoesTotem(final List<InformacaoTotem> parInformacoesTotem) {
		informacoesTotem = parInformacoesTotem;
	}

	public TokenResult getTokenResult() {
		return tokenResult;
	}

	public void setTokenResult(final TokenResult parTokenResult) {
		tokenResult = parTokenResult;
	}

	public ClienteUnidadePasseLivre getClienteUnidadePasseLivre() {
		return clienteUnidadePasseLivre;
	}

	public void setClienteUnidadePasseLivre(final ClienteUnidadePasseLivre parClienteUnidadePasseLivre) {
		clienteUnidadePasseLivre = parClienteUnidadePasseLivre;
	}

	public PreAtendimento getPreAtendimentoSelecionado() {
		return preAtendimentoSelecionado;
	}

	public void setPreAtendimentoSelecionado(final PreAtendimento parPreAtendimentoSelecionado) {
		preAtendimentoSelecionado = parPreAtendimentoSelecionado;
	}

	public List<PreAtendimento> getListaPreAtendimento() {
		return listaPreAtendimento;
	}

	public void setListaPreAtendimento(final List<PreAtendimento> parListaPreAtendimento) {
		listaPreAtendimento = parListaPreAtendimento;
	}

	public List<ExamePedido> getListaExames() {
		return listaExames;
	}

	public void setListaExames(final List<ExamePedido> parListaExames) {
		listaExames = parListaExames;
	}

	public List<ExamePedido> getExamesSelecionados() {
		return examesSelecionados;
	}

	public void setExamesSelecionados(final List<ExamePedido> parExamesSelecionados) {
		examesSelecionados = parExamesSelecionados;
	}

	public List<ProcedimentoComExamesTO> getListaProcedimentos() {
		return listaProcedimentos;
	}

	public void setListaProcedimentos(final List<ProcedimentoComExamesTO> parListaProcedimentos) {
		listaProcedimentos = parListaProcedimentos;
	}

	public List<ProcedimentoComExamesTO> getListaProcedimentosSelecionados() {
		return listaProcedimentosSelecionados;
	}

	public void setListaProcedimentosSelecionados(
			final List<ProcedimentoComExamesTO> parListaProcedimentosSelecionados) {
		listaProcedimentosSelecionados = parListaProcedimentosSelecionados;
	}

	public boolean getDesktop() {
		return desktop;
	}

	public void setDesktop(final boolean parDesktop) {
		desktop = parDesktop;
	}

	public String getProvidencia() {
		return providencia;
	}

	public void setProvidencia(String providencia) {
		this.providencia = providencia;
	}

	public String getDetalhesEmail() {
		return detalhesEmail;
	}

	public void setDetalhesEmail(String detalhesEmail) {
		this.detalhesEmail = detalhesEmail;
	}
	
	private Guias corrigeDataHoraMarcacaoParaExameAgendado(Guias guias, AgendamentoUnidade parAgendamentoUnidade) throws Exception {
		for(final Guia guia : guias) {
			for (ExamePedido exame : guia.getExames()) {
				if(ehExameAgendado(exame, parAgendamentoUnidade)) {
					exame.setDataHoraMarcacao(recuperaDataHoraMarcacao(parAgendamentoUnidade));
				}
			}
		}
		return guias;
	}
	
	private boolean ehExameAgendado(ExamePedido parExame, AgendamentoUnidade parAgendUnidade) {
	    return parAgendUnidade != null && parAgendUnidade.getExame().equals(parExame.getExame());
	}
	  
	private String recuperaDataHoraMarcacao(AgendamentoUnidade parAgendUnidade) throws Exception {
	    final PedidoService pedidoService = new PedidoService(getHttpServletRequest());
	    final ParametroDataPrevisaoResultado parametroDataPrevisao = new ParametroDataPrevisaoResultado(parAgendUnidade, tokenResult);
	    pedidoService.obterDataHoraMarcacaoExamesEspeciais(parametroDataPrevisao);
	    if(pedidoService.isSuccess()) {
	        return (String) pedidoService.getResponseObject();
	    } else {
	        throw new Exception(pedidoService.getResponseMessage());
	    }
	}
	
}