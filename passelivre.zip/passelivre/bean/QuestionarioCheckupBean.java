package br.com.hermespardini.passelivre.bean;

import java.io.IOException;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.primefaces.component.panel.Panel;
import org.primefaces.component.panelgrid.PanelGrid;
import org.primefaces.extensions.component.masterdetail.MasterDetail;
import org.primefaces.extensions.component.masterdetail.MasterDetailLevel;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.factory.AplicaExcecaoQuestionarioFactory;
import br.com.hermespardini.passelivre.factory.ComponenteFactory;
import br.com.hermespardini.passelivre.model.ClienteUnidadePasseLivre;
import br.com.hermespardini.passelivre.model.Composicao;
import br.com.hermespardini.passelivre.model.ConsultaQuestionarioExameResult;
import br.com.hermespardini.passelivre.model.DetalhePreparacao;
import br.com.hermespardini.passelivre.model.EPacoteResult;
import br.com.hermespardini.passelivre.model.InformacaoTotem;
import br.com.hermespardini.passelivre.model.MensagemAviso;
import br.com.hermespardini.passelivre.model.ParametroExamePacote;
import br.com.hermespardini.passelivre.model.ParametroQuestionario;
import br.com.hermespardini.passelivre.model.PerguntaEntrega;
import br.com.hermespardini.passelivre.model.TokenResult;
import br.com.hermespardini.passelivre.model.UserAuth;
import br.com.hermespardini.passelivre.service.ExamePacoteService;
import br.com.hermespardini.passelivre.service.PerguntasService;
import br.com.hermespardini.passelivre.service.QuestionarioService;
import br.com.hermespardini.passelivre.to.PerguntaComExameTO;
import br.com.hermespardini.passelivre.utils.ControleBotaoUtil;
import br.com.hermespardini.passelivre.utils.TotemUtil;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.bean.MainBean;

@ViewScoped
@ManagedBean
public class QuestionarioCheckupBean extends MainBean {

	private UserAuth user;
	private String sessionId;
	private String mensagemAviso;
	private Panel pnlQuestionario;
	private TokenResult tokenResult;
	private PanelGrid pngQuestionario;
	private EPacoteResult ePacoteResult;
	private MasterDetail mtdQuestionario;
	private List<PerguntaEntrega> perguntas;
	private InformacaoTotem informacaoTotem;
	private MasterDetailLevel mdlQuestionario;
	private DetalhePreparacao detalhePreparacao;
	private ControleBotaoUtil controleBotaoUtil;
	private Map<String, String> mapQuestionarios;
	private List<MasterDetailLevel> mdlsQuestionario;
	private ParametroQuestionario parametroQuestionario;
	private ClienteUnidadePasseLivre clienteUnidadePasseLivre;
	private List<ParametroQuestionario> parametrosQuestionario;
	private Map<String, List<PerguntaComExameTO>> todasPerguntasAgrupadas;
	private ConsultaQuestionarioExameResult consultaQuestionarioExameResult;
	private List<ConsultaQuestionarioExameResult> questionariosExamesResult;
	private Map<String, List<PerguntaComExameTO>> todasPerguntasAgrupadasEConsolidadas;

	@PostConstruct
	public void onLoad() {
		try {
			buscarSessionId();
			buscarUser();
			buscarDadosCliente();
			buscarDetalhePreparacao();
			buscarInformacaoTotem();
			buscarTokenResult();
			buscarEPacote();
			mtdQuestionario = new MasterDetail();
			mapQuestionarios = new HashMap<>();
			mdlsQuestionario = new ArrayList<>();
			controleBotaoUtil = new ControleBotaoUtil();
			buscarQuestionario();
			agruparPerguntasEOrdenar();
			construtirQuestionario();
		} catch (final Exception locExc) {
			MensagemAviso mensagemAviso = TotemUtil.createMensagemAviso(locExc.getMessage());
			try {
				getHttpServletRequest().getSession().setAttribute("mensagemAviso", mensagemAviso);
			} catch (Exception e) {
				e.printStackTrace();
			}
			redirectTelaErro();
		}
	}

	private void redirectTelaErro() {
		try {
			FacesContext.getCurrentInstance().getExternalContext().redirect(redirectAtendimentoNaoConcluidoIndex());
		} catch (final IOException exc) {
		}
	}

	private String redirectAtendimentoNaoConcluidoIndex() {
		return "/passelivretotem/pages/erro/atendimentoNaoConcluido.xhtml?faces-redirect=true&sessionId=" + sessionId;
	}

	private void agruparPerguntasEOrdenar() throws Exception {
		final PerguntasService perguntasUtil = new PerguntasService();
		todasPerguntasAgrupadas = new TreeMap<>(perguntasUtil.agruparPerguntasPorAba(questionariosExamesResult));
		filtrarPerguntasConsolidadas();
	}

	private void filtrarPerguntasConsolidadas() {
		final AplicaExcecaoQuestionarioFactory aplicaExcecaoParaQuestionarioFactory = new AplicaExcecaoQuestionarioFactory();
		todasPerguntasAgrupadasEConsolidadas = new TreeMap<>(
				aplicaExcecaoParaQuestionarioFactory.retornarQuestionariosFiltrados(todasPerguntasAgrupadas));
	}

	private void buscarEPacote() throws RegraNegocioException {
		try {
			final ExamePacoteService service = new ExamePacoteService(getHttpServletRequest());
			final ParametroExamePacote parametroExamePacote = ParametroExamePacote
					.criarParametrosParaRetornarExamesFilhos(detalhePreparacao, tokenResult);
			parametroExamePacote.setOperadora(Constantes.OPERADORA_CAMPANHA);
			service.buscarExamesFilhosfinal(parametroExamePacote);
			if (service.isSuccess()) {
				ePacoteResult = (EPacoteResult) service.getResponseObject();
			} else {
				throw new RegraNegocioException(service.getResponseMessage());
			}
		} catch (final Exception locExc) {
			gerarLogErroAoBuscarExamesFilhos(locExc.getMessage());
			throw new RegraNegocioException(locExc.getMessage());
		}
	}

	private void gerarLogErroAoBuscarExamesFilhos(final String parMessage) {
		try {
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, null, createBasicLogMap());
		} catch (final Exception locExc) {
		}
	}

	private void buscarSessionId() {
		try {
			sessionId = getHttpServletRequest().getSession().getAttribute("sessionId").toString();
		} catch (final Exception locExc) {
		}
	}

	private void buscarUser() {
		try {
			user = (UserAuth) getHttpServletRequest().getSession().getAttribute("user");
		} catch (final Exception locExc) {
		}
	}

	private void buscarDadosCliente() {
		try {
			clienteUnidadePasseLivre = (ClienteUnidadePasseLivre) getHttpServletRequest().getSession()
					.getAttribute("clienteUnidadePasseLivre");
		} catch (final Exception locExc) {
		}
	}

	private void buscarDetalhePreparacao() {
		try {
			detalhePreparacao = (DetalhePreparacao) getHttpServletRequest().getSession()
					.getAttribute("detalhePreparacao");
		} catch (final Exception locExc) {
		}
	}

	private void buscarInformacaoTotem() {
		try {
			informacaoTotem = (InformacaoTotem) getHttpServletRequest().getSession().getAttribute("informacaoTotem");
		} catch (final Exception locExc) {
		}
	}

	private void buscarTokenResult() {
		try {
			tokenResult = (TokenResult) getHttpServletRequest().getSession().getAttribute("tokenResult");
		} catch (final Exception locExc) {
		}
	}

	private void buscarQuestionario() throws RegraNegocioException {
		try {
			adicionarParametrosAoQuestionario();
			questionariosExamesResult = new ArrayList<>();
			consultarQuestionario(parametrosQuestionario);
		} catch (final Exception locExc) {
			throw new RegraNegocioException("Falha ao tentar consultar se existe questionário, erro: " + locExc.getMessage());
		}
	}

	public void cancelar() {
		try {
			final String nomeMaquina = TotemUtil.retornarNomeDaMaquina();
			getSession().removeAttribute("indexBean");
			TotemUtil.limparSession();
			FacesContext.getCurrentInstance().getExternalContext()
					.redirect("/passelivretotem/indexTotem.xhtml?nomeTotem=" + nomeMaquina);
		} catch (final Exception exc) {
		}
	}

	public String fazerPagamento() {
		try {
			preencherQuestionario();
			adicionarAtributoEmSessaoAposResponderQuestionario();
			return "/pages/ckm/pagamento.xhtml?faces-redirect=true";
		} catch (final Exception locExc) {
			return "";
		}
	}

	private void preencherQuestionario() throws Exception {
		try {
			perguntas = new ArrayList<>();
			perguntas.addAll(new QuestionarioService(getHttpServletRequest(), perguntas, mapQuestionarios)
					.preencherQuestionario());
		} catch (final Exception locExc) {
			throw new Exception(locExc.getMessage());
		}
	}

	private void construtirQuestionario() throws Exception {
		mtdQuestionario = new MasterDetail();
		mdlQuestionario = new MasterDetailLevel();
		mapQuestionarios = new HashMap<>();
		pngQuestionario = new PanelGrid();
		pngQuestionario.setStyleClass("pngQuestionario");
		pngQuestionario.setColumns(3);
		pngQuestionario.setStyle("height: 250px;");
		pnlQuestionario = new Panel();
		mtdQuestionario.setShowBreadcrumb(false);
		mtdQuestionario.setId("mtdQuestionario");
		final ComponenteFactory componenteFactory = new ComponenteFactory(pnlQuestionario, mdlsQuestionario,
				mtdQuestionario, mdlQuestionario, pngQuestionario);
		componenteFactory.construirComponentesCheckup(mapQuestionarios, todasPerguntasAgrupadas);
	}

	private void adicionarAtributoEmSessaoAposResponderQuestionario() throws Exception {
		getHttpServletRequest().getSession().setAttribute("user", user);
		getHttpServletRequest().getSession().setAttribute("sessionId", sessionId);
		getHttpServletRequest().getSession().setAttribute("perguntas", perguntas);
		getHttpServletRequest().getSession().setAttribute("tokenResult", tokenResult);
		getHttpServletRequest().getSession().setAttribute("ePacoteResult", ePacoteResult);
		getHttpServletRequest().getSession().setAttribute("informacaoTotem", informacaoTotem);
		getHttpServletRequest().getSession().setAttribute("detalhePreparacao", detalhePreparacao);
		getHttpServletRequest().getSession().setAttribute("questionariosExamesResult", questionariosExamesResult);
		getHttpServletRequest().getSession().setAttribute("clienteUnidadePasseLivre", clienteUnidadePasseLivre);
	}

	private void consultarQuestionario(final List<ParametroQuestionario> parametrosQuestionario)
			throws RegraNegocioException {
		try {
			final QuestionarioService questionarioService = new QuestionarioService(getHttpServletRequest());
			for (final ParametroQuestionario locParametroQuestionario : parametrosQuestionario) {
				questionarioService.setValueObject(locParametroQuestionario);
				questionarioService.consultar();
				if (questionarioService.isSuccess()) {
					consultaQuestionarioExameResult = new ConsultaQuestionarioExameResult(
							(ConsultaQuestionarioExameResult) questionarioService.getResponseObject(),
							locParametroQuestionario);
					questionariosExamesResult.add(consultaQuestionarioExameResult);
				} else {
					throw new RegraNegocioException(questionarioService.getResponseMessage());
				}
			}
		} catch (final Exception locExc) {
			throw new RegraNegocioException(locExc.getMessage());
		}
	}

	private void adicionarParametrosAoQuestionario() {
		parametrosQuestionario = new ArrayList<>();
		for (final Composicao locComposicao : ePacoteResult.getComposicao()) {
			parametroQuestionario = ParametroQuestionario.criarBuscarParaCheckup(locComposicao,
					clienteUnidadePasseLivre, tokenResult, "");
			parametrosQuestionario.add(parametroQuestionario);
		}
	}

	public Map createBasicLogMap() {
		Long idTotem = null;
		Long idUnidade = null;
		List<InformacaoTotem> informacoesTotem = TotemUtil.buscarInformacoesTotem();
		if (informacoesTotem != null && !informacoesTotem.isEmpty()) {
			idTotem = informacoesTotem.get(0).getId();
			idUnidade = Long.valueOf(informacoesTotem.get(0).getIdUnidade());
		}
		try {
			return TotemUtil.createBasicLogMap(idTotem, idUnidade, Util.getClientIpAddr(getHttpServletRequest()));
		} catch (Exception e) {
			e.printStackTrace();
			return new HashMap();
		}
	}

	public Boolean habilitarBotaoQuestionarioVoltar(final Integer level) {
		return controleBotaoUtil.habilitarBotaoQuestionarioVoltar(todasPerguntasAgrupadas, level);
	}

	public Boolean habilitarBotaoQuestionarioCancelar(final Integer level) {
		return controleBotaoUtil.habilitarBotaoQuestionarioCancelar(todasPerguntasAgrupadas, level);
	}

	public Boolean habilitarBotaoQuestionarioAvancar(final Integer level) {
		return controleBotaoUtil.habilitarBotaoQuestionarioAvancar(todasPerguntasAgrupadas, level);
	}

	public Boolean habilitarBotaoQuestionarioFinalizar(final Integer level) {
		return controleBotaoUtil.habilitarBotaoQuestionarioFinalizar(todasPerguntasAgrupadas, level);
	}

	public String getMensagemAviso() {
		return mensagemAviso;
	}

	public void setMensagemAviso(final String parMensagemAviso) {
		mensagemAviso = parMensagemAviso;
	}

	public List<MasterDetailLevel> getMdlsQuestionario() {
		return mdlsQuestionario;
	}

	public void setMdlsQuestionario(final List<MasterDetailLevel> parMdlsQuestionario) {
		mdlsQuestionario = parMdlsQuestionario;
	}

	public ClienteUnidadePasseLivre getClienteUnidadePasseLivre() {
		return clienteUnidadePasseLivre;
	}

	public void setClienteUnidadePasseLivre(final ClienteUnidadePasseLivre parClienteUnidadePasseLivre) {
		clienteUnidadePasseLivre = parClienteUnidadePasseLivre;
	}

	public MasterDetail getMtdQuestionario() {
		return mtdQuestionario;
	}

	public void setMtdQuestionario(final MasterDetail parMtdQuestionario) {
		mtdQuestionario = parMtdQuestionario;
	}

	public MasterDetailLevel getMdlQuestionario() {
		return mdlQuestionario;
	}

	public void setMdlQuestionario(final MasterDetailLevel parMdlQuestionario) {
		mdlQuestionario = parMdlQuestionario;
	}

	public Map<String, String> getMapQuestionarios() {
		return mapQuestionarios;
	}

	public void setMapQuestionarios(final Map<String, String> parMapQuestionarios) {
		mapQuestionarios = parMapQuestionarios;
	}

}
