package br.com.hermespardini.passelivre.bean;

import java.sql.Time;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import br.com.hermespardini.passelivre.constantsenum.Constantes;
import br.com.hermespardini.passelivre.exception.RegraNegocioException;
import br.com.hermespardini.passelivre.model.ConsultaConfiguracaoResult;
import br.com.hermespardini.passelivre.model.InformacaoTotem;
import br.com.hermespardini.passelivre.model.MensagemAviso;
import br.com.hermespardini.passelivre.model.ParametroConsultaConfiguracao;
import br.com.hermespardini.passelivre.model.Servico;
import br.com.hermespardini.passelivre.model.TokenResult;
import br.com.hermespardini.passelivre.model.Totem;
import br.com.hermespardini.passelivre.service.InformacaoTotemService;
import br.com.hermespardini.passelivre.utils.TotemUtil;
import br.com.hermespardini.passelivre.utils.Util;
import br.com.hermespardini.web.bean.MainBean;

@ManagedBean
public class TelaErroBean extends MainBean {

	private String tempoTimout = "180000";
	private LocalTime horaFim;
	private String sessionId;
	private LocalTime horaInicio;
	private TokenResult tokenResult;
	private static final Integer MINIMO = 3;
	private static final Integer MAXIMO = 30;
	private static final String INTERVALO_MAXIMO = "1800000";
	private static final String INTERVALO_MINIMO = "59000";
	private MensagemAviso mensagemAviso;

	@PostConstruct
	public void onLoad() {
		try {
			sessionId = retornarSessionId();
			mensagemAviso = recuperaMensagemAviso();
			if (Objects.isNull(mensagemAviso)) {
				mensagemAviso = TotemUtil.createMensagemAviso("O erro não foi identificado.");
			}
			retornarHoraInicioEHoraFim();
			tempoTimout = verificarHoraAtual();
		} catch (final Exception locExc) {
			mensagemAviso = TotemUtil.createMensagemAviso(locExc.getMessage());
			if (Objects.isNull(mensagemAviso)) {
				mensagemAviso = TotemUtil.createMensagemAviso("O erro não foi identificado.");
			}			
			Logger logger = Logger.getLogger(TelaErroBean.class);
			logger.error("LOG DE EXCESSÃO ONLOAD TelaErroBean", locExc);
		}

	}

	private String retornarSessionId() {
		try {
			final HttpSession session = getHttpServletRequest().getSession();
			return (String) session.getAttribute("sessionId");
		} catch (final Exception exc) {
			exc.printStackTrace();
			return "";
		}
	}

	private MensagemAviso recuperaMensagemAviso() {
		try {
			final HttpSession session = getHttpServletRequest().getSession();
			return (MensagemAviso) session.getAttribute("mensagemAviso");
		} catch (final Exception exc) {
			exc.printStackTrace();
			return new MensagemAviso();
		}
	}

	private String verificarHoraAtual() {
		if (ehHorarioDeFuncionamento()) {
			return TelaErroBean.INTERVALO_MINIMO;
		} else {
			return TelaErroBean.INTERVALO_MAXIMO;
		}
	}

	private boolean ehHorarioDeFuncionamento() {
		final LocalTime horaAgora = LocalTime.now();
		if (horaInicio != null && horaFim != null) {
			if (horaAgora.isAfter(horaInicio.minus(30, ChronoUnit.MINUTES)) && horaAgora.isBefore(horaFim)) {
				return true;
			}
		}
		return horaAtualEhMaiorQueHoraInicio(horaAgora, horaInicio) && horaAtualEhMenorQueHoraFim(horaAgora, horaFim);
	}

	private boolean horaAtualEhMenorQueHoraFim(final LocalTime dataAgora, final LocalTime dataFim) {
		try {
			if (dataAgora.isBefore(dataFim)) {
				return diferencaDaHoraAtualParaProximaEhMaiorQueOMaximo(dataAgora, dataFim);
			} else {
				return false;
			}
		} catch (final Exception locExc) {
			return false;
		}
	}

	private boolean diferencaDaHoraAtualParaProximaEhMaiorQueOMaximo(final LocalTime parDataAgora,
			final LocalTime parDataFim) {
		final Time agora = new Time(new Date().getTime());
		LocalTime localtime = agora.toLocalTime();
		localtime = localtime.plusMinutes(TelaErroBean.MAXIMO);
		return localtime.isBefore(parDataFim);
	}

	private boolean horaAtualEhMaiorQueHoraInicio(final LocalTime dataAgora, final LocalTime dataInicio) {
		try {
			if (dataAgora.isAfter(dataInicio)) {
				return diferencaDaHoraAtualParaProximaEhMaiorQueMinimo(dataInicio);
			} else {
				return false;
			}
		} catch (final Exception locExc) {
			return false;
		}
	}

	private boolean diferencaDaHoraAtualParaProximaEhMaiorQueMinimo(final LocalTime parDataInicio) {
		final Time agora = new Time(new Date().getTime());
		LocalTime localtime = agora.toLocalTime();
		localtime = localtime.plusMinutes(TelaErroBean.MINIMO);
		return localtime.isAfter(parDataInicio);
	}

	public void processTimeOut(String tela) throws Exception {
		final String nomeMaquina = TotemUtil.retornarNomeDaMaquina();
		String mensagem = "";
		if (mensagemAviso != null) {
			mensagem = mensagemAviso.getMensagem();
		}
		try {
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(),
					"Processando tela erro: " + tela + " Totem: " + nomeMaquina + " Mensagem: " + mensagem, sessionId,
					createBasicLogMap());
			registrarLogAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(),
					"Redirecionando para INDEX. Totem: " + nomeMaquina, sessionId, createBasicLogMap());
			TotemUtil.limparSession();

			FacesContext.getCurrentInstance().getExternalContext()
					.redirect("/passelivretotem/index.xhtml?nomeTotem=" + nomeMaquina);
		} catch (Exception e) {
			Logger logger = Logger.getLogger(TelaErroBean.class);
			logger.warn("*******************************************************************");
			logger.warn("*         LOG DE EXCESSÃO AO PROCESSAR TIMEOUT TELA ERRO BEAN          ");
			logger.warn("*                                                                  ");
			e.printStackTrace();
		}

	}

	private void retornarHoraInicioEHoraFim() throws RegraNegocioException {
		try {
			tokenResult = TotemUtil.buscarToken();
			
			/**
			 *Setado tokenResult = new TokenResult() para não dar erro no construtor null pointer em ParametroConsultaConfiguracao 
			 *O método novo informacaoTotemService.consultar não usa este parâmetro, logo não há problema em setá-lo new
			 *
			 */
			if(Objects.isNull(tokenResult)) {
				tokenResult = new TokenResult();
			}
			final ParametroConsultaConfiguracao parametroConsultaConfiguracao = new ParametroConsultaConfiguracao(
					retornarNomeDaMaquina(), tokenResult);
			final InformacaoTotemService informacaoTotemService = new InformacaoTotemService(getHttpServletRequest());
			informacaoTotemService.consultar(parametroConsultaConfiguracao);
			final ConsultaConfiguracaoResult consultaConfiguracaoResult = (ConsultaConfiguracaoResult) informacaoTotemService
					.getResponseObject();
			if (!Objects.isNull(consultaConfiguracaoResult)) {
				for (final Totem totem : consultaConfiguracaoResult.getTotens()) {
					for (final Servico servico : totem.getServicos()) {
						adicionarMaiorHorario(servico);
						adicionarMenorHorario(servico);
					}
				}
			} else {
				throw new RegraNegocioException(
						"5 - Erro ao buscar informações do totem:" + parametroConsultaConfiguracao.getIp());
			}
		} catch (final Exception locExc) {
			throw new RegraNegocioException(locExc.getMessage());
		}
	}

	private void adicionarMenorHorario(final Servico parServico) {
		try {
			if (horaInicio == null) {
				horaInicio = LocalTime.parse(parServico.getHoraInicioFuncionamento());
			}
			final LocalTime dataHoraInicio = LocalTime.parse(parServico.getHoraInicioFuncionamento());
			if (horaInicio.isBefore(dataHoraInicio)) {
				horaInicio = dataHoraInicio;
			}
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	private void adicionarMaiorHorario(final Servico parServico) {
		try {
			if (horaFim == null) {
				horaFim = LocalTime.parse(parServico.getHoraFimFuncionamento());
			}
			final LocalTime dataHoraFim = LocalTime.parse(parServico.getHoraFimFuncionamento());
			if (horaFim.isBefore(dataHoraFim)) {
				horaFim = dataHoraFim;
			}
		} catch (final Exception locExc) {
			locExc.printStackTrace();
		}
	}

	public String getTempoTimout() {
		return tempoTimout;
	}

	public void setTempoTimout(final String parTempoTimout) {
		tempoTimout = parTempoTimout;
	}

	public String getRetornarAmbiente() {
		StringBuilder sb;
		try {
			sb = new StringBuilder().append("-IP: ").append(retornarIp()).append(" Equipamento: ")
					.append(retornarNomeDaMaquina()).append(" Impressora:").append("");
			if (getAmbienteProducao()) {
				return sb.toString();
			} else {
				return " - " + Constantes.AMBIENTE_HOMOLOGACAO + sb.toString();
			}
		} catch (final Exception exc) {
			gerarLogErroRetornarAmbiente(exc.getMessage());
			exc.printStackTrace();
			return "";
		}
	}

	private void gerarLogErroRetornarAmbiente(final String parMessage) {
		try {
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, null, createBasicLogMap());
		} catch (final Exception exc) {
			exc.printStackTrace();
		}
	}

	private String retornarIp() throws Exception {
		final HttpServletRequest request = getHttpServletRequest();
		return Util.getClientIpAddr(request);
	}

	private String retornarNomeDaMaquina() throws RegraNegocioException {
		try {
			return TotemUtil.retornarNomeDaMaquina();
			// final IndexService indexService = new IndexService();
			// return indexService.retornarNomeMaquina(getHttpServletRequest());
		} catch (final Exception exc) {
			exc.printStackTrace();
			gerarLogAoRetornarNomeDaMaquina(exc.getMessage());
			throw new RegraNegocioException(exc.getMessage());
		}
	}

	private void gerarLogAoRetornarNomeDaMaquina(final String parMessage) {
		try {
			registrarLogErroAcessoFuncionalidadeMap(Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName(), parMessage, null, createBasicLogMap());
		} catch (final Exception locExc) {
		}
	}

	public Map createBasicLogMap() {
		Long idTotem = null;
		Long idUnidade = null;
		List<InformacaoTotem> informacoesTotem = TotemUtil.buscarInformacoesTotem();
		if (informacoesTotem != null && !informacoesTotem.isEmpty()) {
			idTotem = informacoesTotem.get(0).getId();
			idUnidade = Long.valueOf(informacoesTotem.get(0).getIdUnidade());
		}
		try {
			return TotemUtil.createBasicLogMap(idTotem, idUnidade, Util.getClientIpAddr(getHttpServletRequest()));
		} catch (Exception e) {
			e.printStackTrace();
			return new HashMap();
		}
	}

	public String recuperarCaminhoCSS() {
		try {
			String sigla = (String) getSession().getAttribute("siglaEmpresa") == null ? "IHP" : (String) getSession().getAttribute("siglaEmpresa");
			switch (sigla) {
			case "IHP":
				return FacesContext.getCurrentInstance().getExternalContext().getRequestContextPath()
						+ "/resources/css";
			case "DIGIM":
				return FacesContext.getCurrentInstance().getExternalContext().getRequestContextPath()
						+ "/resources/css";
			case "CMNG":
				return FacesContext.getCurrentInstance().getExternalContext().getRequestContextPath()
						+ "/resources/css/centroMedicina";
			case "PDRAO":
				return FacesContext.getCurrentInstance().getExternalContext().getRequestContextPath()
						+ "/resources/css/padrao";
			case "ECO":
				return FacesContext.getCurrentInstance().getExternalContext().getRequestContextPath()
						+ "/resources/css/ecoar";
			case "HUM":
				return FacesContext.getCurrentInstance().getExternalContext().getRequestContextPath()
						+ "/resources/css/humberto";
			case "UF":
				return FacesContext.getCurrentInstance().getExternalContext().getRequestContextPath()
						+ "/resources/css/unimedFortaleza";
			default:
				return FacesContext.getCurrentInstance().getExternalContext().getRequestContextPath()
						+ "/resources/css";
			}
		} catch (Exception e) {
			e.printStackTrace();
			return FacesContext.getCurrentInstance().getExternalContext().getRequestContextPath() + "/resources/css";
		}
	}

	public String recuperarCaminhoBotoes() {
		try {
			boolean ecoar = (boolean) getSession().getAttribute("ecoar");
			if (ecoar) {
				return "/images/buttons/ecoar";
			} else {
				return "/images/buttons";
			}
		} catch (Exception e) {
			e.printStackTrace();
			return "/images/buttons";
		}
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(final String parSessionId) {
		sessionId = parSessionId;
	}

	public MensagemAviso getMensagemAviso() {
		return mensagemAviso;
	}

	public void setMensagemAviso(final MensagemAviso parMensagemAviso) {
		mensagemAviso = parMensagemAviso;
	}
}
