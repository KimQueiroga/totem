(function (f, b, g) {
	var a = {
		key : "3eeb7027df151c4c",
		campaign : "d3d1e897",
		type : "nps",
		theme : "box",
		name : "|NOMECLI|",
		email : "|EMAILCLI|",
		identification : "|CODIGO|",
		tags : {
			"Data Realização" : "|DATAPED|",
			"Unidade" : "|UNDPED|",
			"Pedido" : "|PED|",
			"Convenio" : "|CONVENIOPED|",
			"Idade" : "|IDADEPED|",
			"Numero" : "|NUMEROENDPED|",
			"Telefone" : "|FONEPED|",
			"Sexo" : "|SEXOPED|",
			"Bairro" : "|BAIRROPED|",
			"Logradouro" : "|LOGRADOUROPED|",
			"CEP" : "|CEPPED|",
			"Cidade" : "|CIDADEPED|",
			"UF" : "|UFPED|",
			"SBU" : "|SBUPED|"
		},
		reminder : 7
	};
	var e;
	var c = f.getElementsByTagName(b)[0];
	if (f.getElementById(g)) {
		return
	}
	e = f.createElement(b);
	e.id = g;
	e.src = "https://tracksale.co/tracksale-js/tracksale.js";
	e.type = "text/javascript";
	e.async = true;
	e.onload = e.onreadystatechange = function() {
		var h = this.readyState;
		if (h && h != "complete" && h != "loaded") {
			return
		}
		try {
			var d = new Tracksale();
			d.init(a)
		} catch (i) {
		}
	};
	c.parentNode.insertBefore(e, c)
}(document, "script", "tracksale-js"));

