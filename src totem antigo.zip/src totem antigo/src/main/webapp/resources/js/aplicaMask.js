//$.isNumeric($("#idTabView\\:idCpf").val()) &&
function maskCpf() {
	var maskFormat = '999.999.999-99';
	var delayMillis = 100;
	var tamanho = $("#idTabView\\:idCpf").val().length;
	if (tamanho == 11) {
		$('#idTabView\\:idCpf').mask(maskFormat);
		setTimeout(function() {
			$("#idTabView\\:dataNascimento").focus();
			showKeyboard('keyboard', "#idTabView\\:dataNascimento",
					'numbers_only');
		}, delayMillis);
	} else {
		$('#idTabView\\:idCpf').unmask();
	}
}

function maskExpiry() {
	var maskFormat = '99/99';
	var delayMillis = 100;
	var tamanho = $("#iptExpiry").val().length;
	if (tamanho == 4) {
		$('#iptExpiry').mask(maskFormat);
	} else {
		$('#iptExpiry').unmask();
	}
}

function maskCpfCadastro() {
	var maskFormat = '999.999.999-99';
	var delayMillis = 100;
	var tamanho = $("#kbdCpf").val().length;

	if (tamanho == 11) {
		$('#kbdCpf').mask(maskFormat);
		setTimeout(function() {
			$("#kbdDataNascimento").focus();
			showKeyboard('keyboard_dialog', "#kbdDataNascimento",
					'numbers_only');
		}, delayMillis);
	} else {
		$('#kbdCpf').unmask();
	}
}

function maskCpfSemfocus() {
	var maskFormat = '999.999.999-99';
	var tamanho = $("#idTabView\\:idCpf").val().length;
	if (tamanho == 11) {
		$('#idTabView\\:idCpf').mask(maskFormat);
	} else {

		$('#idTabView\\:idCpf').unmask();
	}
}
function maskCpfNAU() {
	var delayMillis = 100;
	var maskFormat = '999.999.999-99';
	var tamanho = $("#tbvLogin\\:idCpf").val().length;
	if (tamanho > 10 && tamanho < 12) {
		$('#tbvLogin\\:idCpf').mask(maskFormat);
		setTimeout(function() {
			$("#tbvLogin\\:dataNascimento").focus();
		}, delayMillis);

	} else {
		$('#tbvLogin\\:idCpf').unmask();
	}
}

function manterCPFFocus() {
	var tamanho = $("#idTabView\\:idCpf").val().length;
	if (tamanho < 11) {
		$('#idTabView\\:idCpf').focus();
	}
}

function manterDataFocus() {
	var maskFormat = '99/99/9999';
	var tamanho = $("#dataNascimento").val().length;
	if (tamanho >= 8) {
		$('#dataNascimento').mask(maskFormat);
	}
}

function maskData() {
	var delayMillis = 100;
	var maskFormat = '99/99/9999';
	var tamanho = $("#idTabView\\:dataNascimento").val().length;
	if (tamanho == 8) {
		$('#idTabView\\:dataNascimento').mask(maskFormat);
		setTimeout(function() {
			$("#idTabView\\:senhaCpf").focus();
			showKeyboard('keyboard', '#idTabView\\:senhaCpf',
					'numeric_password')
		}, delayMillis);
	} else {
		$('#idTabView\\:dataNascimento').unmask();
	}
}

function maskDataNAU() {
	var delayMillis = 100;
	var maskFormat = '99/99/9999';
	var tamanho = $("#tbvLogin\\:dataNascimento").val().length;
	if (tamanho > 7 && tamanho < 9) {
		$('#tbvLogin\\:dataNascimento').mask(maskFormat);
		setTimeout(function() {
			$("#tbvLogin\\:senhaCpf").focus();
		}, delayMillis);

	} else {
		$('#tbvLoginNAU\\:dataNascimento').unmask();
	}
}

function maskCepCadastro() {
	var delayMillis = 100;
	var maskFormat = '99999-999';
	var tamanho = $("#cep").val().length;
	if (tamanho > 7 && tamanho < 9) {
		$('#cep').mask(maskFormat);
		setTimeout(function() {
			$("#numero").focus();
		}, delayMillis);
	} else {
		$('#cep').unmask();
	}
}
function maskOnlyCpfConfirma() {

	var maskFormat = '999.999.999-99';
	var tamanho = $("#kbdCpf").val().length;
	if (tamanho > 10 && tamanho < 12) {
		$('#kbdCpf').mask(maskFormat);
	} else {
		$('#kbdCpf').unmask();
	}
}
function maskCpfConfirma() {
	var delayMillis = 100;
	var maskFormat = '999.999.999-99';
	var tamanho = $("#kbdCpf").val().length;
	if (tamanho > 10 && tamanho < 12) {
		$('#kbdCpf').mask(maskFormat);
		setTimeout(function() {
			$("#kbdDataNascimento").focus();
			showKeyboard("keyboard", "#kbdDataNascimento", "numbers_only");
		}, delayMillis);

	} else {
		$('#kbdCpf').unmask();
	}
}
function maskDataConfirma() {
	var delayMillis = 100;
	var maskFormat = '99/99/9999';
	var tamanho = $("#kbdDataNascimento").val().length;
	if (tamanho == 8) {
		$('#kbdDataNascimento').mask(maskFormat);
		hideKeyboard('keyboard');
	} else {
		$('#kbdDataNascimento').unmask();
	}
}
function showKeyboard(divKeyboard, input, typeKeyboard) {
	var keyboard = $('#' + divKeyboard);
	keyboard.jkeyboard({
		layout : typeKeyboard,
		input : $(input)
	});
	$('#' + divKeyboard).show();
}

function hideKeyboard(divKeyboard) {
	$('#' + divKeyboard).hide();
}

function hideKeyboardPasswordCPF() {
	var delayMillis = 100;
	var tamanho = $("#idTabView\\:senhaCpf").val().length;
	if (tamanho == 6) {
		setTimeout(function() {
			hideKeyboard('keyboard')
		}, delayMillis);
	}
}
function hideKeyboardPasswordCodigo() {
	var delayMillis = 100;
	var tamanho = $("#idTabView\\:pswCliente").val().length;
	if (tamanho == 6) {
		setTimeout(function() {
			hideKeyboard('keyboard')
		}, delayMillis);
	}
}