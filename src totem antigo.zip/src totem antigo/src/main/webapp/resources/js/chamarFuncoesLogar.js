$(document).ready(function() {
	maskCpf();
	maskData();
});

function maskCpf() {
	var maskFormat = '999.999.999-99';
	var tamanho = $("#idTabView\\:idCpf").val().length;
	if (tamanho == 11) {
		$('#idTabView\\:idCpf').mask(maskFormat);
	} else {
		$('#idTabView\\:idCpf').unmask();
	}
}

function maskData() {
	var maskFormat = '99/99/9999';
	var tamanho = $("#idTabView\\:dataNascimento").val().length;
	if (tamanho == 8) {
		$('#idTabView\\:dataNascimento').mask(maskFormat);
	} else {
		$('#idTabView\\:dataNascimento').unmask();
	}
}