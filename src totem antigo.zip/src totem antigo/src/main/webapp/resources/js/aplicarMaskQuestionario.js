function maskData(id) {
	var maskFormat = '99/99/9999';
	var tamanho = $(id).val().length;
	if (tamanho == 8) {
		$(id).mask(maskFormat);
	} else {
		$(id).unmask();
	}
}

function maskNumeric32(id) {
	var maskFormat = '999,99';
	var tamanho = $(id).val().length;
	if (tamanho == 5) {
		$(id).mask(maskFormat);
	} else {
		$(id).unmask();
	}
}

function maskHour(id) {
	var maskFormat = '99:99';
	var tamanho = $(id).val().length;
	if (tamanho == 4) {
		$(id).mask(maskFormat);
	} else {
		$(id).unmask();
	}
}
function maskNumeric41(id) {
	var maskFormat = '9999,9';
	var tamanho = $(id).val().length;
	if (tamanho == 5) {
		$(id).mask(maskFormat);
	} else {
		$(id).unmask();
	}
}