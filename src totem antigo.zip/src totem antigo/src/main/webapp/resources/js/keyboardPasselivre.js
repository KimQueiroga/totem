function hideKeyboard(divKeyboard) {
	$('#' + divKeyboard).hide();
}

function showKeyboard(divKeyboard, input, typeKeyboard) {
	var keyboard = $('#' + divKeyboard);
	keyboard.jkeyboard({
		layout : typeKeyboard,
		input : $(input)
	});
	$('#' + divKeyboard).show();
}
