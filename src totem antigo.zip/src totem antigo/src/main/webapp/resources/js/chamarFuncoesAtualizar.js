$(document).ready(function() {
	maskCpfAtualizacao();
	maskDataAtualizacao();
	maskTelefoneAtualizacao();
	maskCelularAtualizacao();
	maskCepSemFocus();
});
function maskCpfAtualizacao() {
	var maskFormat = '999.999.999-99';
	var tamanho = $("#idCpf").val().length;
	if (tamanho > 10 && tamanho < 12) {
		$('#idCpf').mask(maskFormat);
	} else {
		$('#idCpf').unmask();
	}
}
function maskCpfCadastro() {
	var delayMillis = 100;
	var maskFormat = '999.999.999-99';
	var tamanho = $("#idCpf").val().length;
	if (tamanho > 10 && tamanho < 12) {
		$('#idCpf').mask(maskFormat);		
	} else {
		$('#idCpf').unmask();
	}
}

function maskDataAtualizacao() {
	var maskFormat = '99/99/9999';
	var tamanho = $("#dataNascimento").val().length;
	if (tamanho == 8) {
		$('#dataNascimento').mask(maskFormat);
	} else {
		$('#dataNascimento').unmask();
	}
}
function maskDataCadastro() {
	var delayMillis = 100;
	var maskFormat = '99/99/9999';
	var tamanho = $("#dataNascimento").val().length;
	if (tamanho > 7 && tamanho < 9) {
		$('#dataNascimento').mask(maskFormat);		
	} else {
		$('#dataNascimento').unmask();
	}
}
function maskTelefoneAtualizacao() {
	var maskFormat = '(99)9999-9999';
	var tamanho = $("#telefone").val().length;
	if (tamanho > 9) {
		$('#telefone').mask(maskFormat);
	} else {
		$('#telefone').unmask();
	}
}

function maskCelularAtualizacao() {
	var maskFormat = '(99)99999-9999';
	var tamanho = $("#celular").val().length;
	if (tamanho > 10 && tamanho < 12) {
		$('#celular').mask(maskFormat);
	} else {
		$('#celular').unmask();
	}
}

function maskCepAtualizacao() {
	var delayMillis = 1000;
	var maskFormat = '99999-999';
	var tamanho = $("#cep").val().length;
	if (tamanho > 7 && tamanho < 9) {
		$('#cep').mask(maskFormat);		
	} else {
		$('#cep').unmask();
	}
}

function maskCepSemFocus() {
	var maskFormat = '99999-999';
	var tamanho = $("#cep").val().length;
	if (tamanho > 7 && tamanho < 9) {
		$('#cep').mask(maskFormat);
	}
}

function moveConfirmaSenha() {
	var tamanho = $("#novaSenhaId").val().length;
	var delayMillis = 100;
	if (tamanho == 6) {
		setTimeout(function() {
			$("#confirmaNovaSenhaId").focus();
		}, delayMillis);
	}
}

function moveFocusButton() {
	$("alterarSenhaDlgId:btnValidaSenhaDialog").focus();
}

function buscarCep() {
	var maskFormat = '99999-999';
	var tamanho = $("#cep").val().length;
	if (tamanho == 9) {
		buscarCepRemoto();
	}
}