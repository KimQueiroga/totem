$(document).ready(function() {
	$("#botao-mostrar-senha-atual").click(function(e) {
        $(this).toggleClass("fa-eye fa-eye-slash");
        if ($("[id*=senhaatual").attr('type') == 'text'){
            $("[id*=senhaatual").attr('type', 'password');
        }else{
            $("[id*=senhaatual").attr('type', 'text')
        }
        e.preventDefault();
    });
    $("#botao-mostrar-senha").click(function(e) {
        $(this).toggleClass("fa-eye fa-eye-slash");
        if ($("[id=senha").attr('type') == 'text'){
            $("[id=senha").attr('type', 'password');
        }else{
            $("[id=senha").attr('type', 'text')
        }
        if ($("[id*=novaSenhaId").attr('type') == 'text'){
            $("[id*=novaSenhaId").attr('type', 'password');
        }else{
            $("[id*=novaSenhaId").attr('type', 'text')
        }
        if ($("[id*=pswCliente]").attr('type') == 'text'){
            $("[id*=pswCliente]").attr('type', 'password');
        }else{
            $("[id*=pswCliente]").attr('type', 'text')
        }
        if ($("[id*=newPass").attr('type') == 'text'){
            $("[id*=newPass").attr('type', 'password');
        }else{
            $("[id*=newPass").attr('type', 'text')
        }
        if ($("[id*=form-password").attr('type') == 'text'){
            $("[id*=form-password").attr('type', 'password');
        }else{
            $("[id*=form-password").attr('type', 'text')
        }
        e.preventDefault();
    });
    $("#botao-mostrar-senha-conf").click(function(e) {
        $(this).toggleClass("fa-eye fa-eye-slash");
        if ($("[id*=confirmasenha").attr('type') == 'text'){
            $("[id*=confirmasenha").attr('type', 'password');
        }else{
            $("[id*=confirmasenha").attr('type', 'text')
        }
        if ($("[id*=confirmaNovaSenhaId").attr('type') == 'text'){
            $("[id*=confirmaNovaSenhaId").attr('type', 'password');
        }else{
            $("[id*=confirmaNovaSenhaId").attr('type', 'text')
        }
        if ($("[id*=senhaCpf").attr('type') == 'text'){
            $("[id*=senhaCpf").attr('type', 'password');
        }else{
            $("[id*=senhaCpf").attr('type', 'text')
        }
        if ($("[id*=confPass").attr('type') == 'text'){
            $("[id*=confPass").attr('type', 'password');
        }else{
            $("[id*=confPass").attr('type', 'text')
        }
        e.preventDefault();
    });
});