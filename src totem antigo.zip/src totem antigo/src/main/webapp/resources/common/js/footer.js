function footer() {
	$(document).ready(function() {
		calcFooter();
	});	
	$(window).resize(function() {
		calcFooter();
	});
}

function calcFooter() {
	var docHeight = $(window).height();
	var footerHeight = $('#footer').height();
	var footerTop = $('#footer').position().top + footerHeight;

	if (footerTop < docHeight) {
		$('#footer').css('margin-top', 0 + (docHeight - footerTop) + 'px');
	}
}
